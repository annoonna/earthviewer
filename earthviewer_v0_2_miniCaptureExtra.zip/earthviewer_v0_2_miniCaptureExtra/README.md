# EarthViewer 2.0.0

🌍 **Modulare, professionelle 3D-Erd-Visualisierung mit Netzwerk-Tools**

## Features

### 🗺️ Visualisierung
- Interaktive 3D-Erdkugel mit OpenGL
- Marker-System für Städte, IPs, Traceroute-Hops
- Echtzeit-Animation und Auto-Rotation

### 🌐 Netzwerk-Tools
- **Traceroute** mit Live-Visualisierung
- **WHOIS** IP-Informationen
- **Ping Monitor** mit Latenz-Graph
- **DNS Lookup** für Domains

### 📊 Daten
- GeoIP-Datenbank Support
- CSV-Stadt-Daten
- Export/Import von Sessions

## Installation

```bash
# Repository klonen
git clone <repo-url>
cd EarthViewer

# Virtual Environment erstellen
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# oder
venv\Scripts\activate  # Windows

# Dependencies installieren
pip install -r requirements.txt

# Programm starten
python main.py
```

## Ordnerstruktur

```
EarthViewer/
├── src/                  # Quellcode (modular)
│   ├── core/            # Kern-Klassen
│   ├── data/            # Daten-Management
│   ├── rendering/       # 3D-Rendering
│   ├── network/         # Netzwerk-Tools
│   ├── ui/              # User Interface
│   └── utils/           # Hilfsfunktionen
├── data/                # Daten (Geodaten, Texturen)
├── screenshots/         # Screenshots
├── logs/                # Log-Dateien
└── tests/               # Unit-Tests
```

## Verwendung

### Suche
- Städte: `berlin`, `new york`
- Mehrere Städte: `berlin leipzig koblenz`
- IP-Adressen: `8.8.8.8`
- Koordinaten: `52.52, 13.405`

### Steuerung
- **Maus ziehen**: Globus rotieren
- **Mausrad**: Zoom
- **Doppelklick**: Zu Ort navigieren

## Daten-Setup

### Geodaten
1. Erstelle `data/geodata/` Ordner
2. Lade Städte-CSV herunter (z.B. von simplemaps.com)
3. Optional: GeoLite2-City.mmdb für IP-Lokalisierung

### Textur
1. Erstelle `data/textures/` Ordner
2. Platziere `earth_map.jpg` (Equirectangular Projektion)
3. Download z.B. von NASA Visible Earth

## Lizenz

MIT License

## Credits

Erstellt mit ❤️ und Python
