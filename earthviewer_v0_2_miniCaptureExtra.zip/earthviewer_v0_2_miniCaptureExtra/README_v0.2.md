# 🌍 EarthViewer 2.0 - Version 0.2

**3D-Netzwerk-Visualisierung mit Live-Verbindungsanzeige**

## 🎉 Was ist neu in Version 0.2?

### 🔴 Live Verbindungen Tab
Das neue **Live Verbindungen** Tab zeigt alle aktiven Netzwerkverbindungen in Echtzeit auf dem 3D-Globus:

- **Echtzeit-Tracking**: Alle TCP/UDP-Verbindungen werden live erfasst
- **Animierte Linien**: Pulsierende Verbindungslinien auf dem Globus
- **Farbcodierung**:
  - 📥 **Blau**: Incoming Connections (eingehende Verbindungen)
  - 📤 **Grün**: Outgoing Connections (ausgehende Verbindungen)

### 🎬 Animation System
- Smooth pulsierende Animationen entlang der Verbindungslinien
- Einstellbare Geschwindigkeit (1-10)
- Spherical Interpolation für natürliche Bögen auf der Erdkugel

### 🎚️ Filter & Kontrollen
- **Toggle-Filter**: Ein/Ausblenden von Incoming/Outgoing
- **Echtzeit-Statistiken**:
  - Gesamt aktive Verbindungen
  - Incoming Counter
  - Outgoing Counter
- **Verbindungsliste** mit Details:
  - App-Name
  - Remote IP
  - Stadt/Land
  - Richtung
  - Protokoll (TCP/UDP)

### 🗺️ Interaktive Navigation
- Klick auf eine Verbindung in der Liste → Navigiere zum Zielort auf dem Globus
- Automatische Geo-Lokalisierung aller Remote-IPs

### 🔍 Erweiterter Port-Scanner
- Port-Bereich jetzt bis **65535** (vorher 1024)
- Vollständiger Scan aller bekannten Ports möglich

## 🚀 Schnellstart

### 1. Tab öffnen
Navigiere zum neuen Tab **"🔴 Live Verbindungen"** in der Sidebar

### 2. Tracking starten
Klicke auf **"▶️ Tracking starten"**

### 3. Filter einstellen
- ✅ **📥 Incoming (Blau)** - Zeigt eingehende Verbindungen
- ✅ **📤 Outgoing (Grün)** - Zeigt ausgehende Verbindungen

### 4. Animation anpassen
Verwende den Schieberegler **"🎬 Animations-Geschwindigkeit"** (1-10)

### 5. Verbindungen erkunden
Klicke auf eine Verbindung in der Liste um zum Zielort zu navigieren

## 📋 Systemanforderungen

- **OS**: Linux (empfohlen), Windows, macOS
- **Python**: 3.10+
- **RAM**: 4 GB minimum
- **GPU**: OpenGL 3.3+ fähig

### Für optimale Performance:
- **Root-Rechte** für vollständiges Netzwerk-Monitoring
- **GeoIP2-Datenbank** (automatisch geladen)

## 📦 Installation

```bash
cd earthviewer_v0_2

# Virtual Environment aktivieren (falls vorhanden)
source venv/bin/activate

# Dependencies installieren/aktualisieren
pip install -r requirements.txt

# Programm starten
python main.py
```

## 🏗️ Architektur

### Neue Module in v0.2:

```
src/
├── network/
│   └── connection_tracker.py    # Neues Connection Tracking System
└── ui/
    └── widgets/
        └── live_connections_tab.py   # Neues Live Connections Tab
```

### Erweiterte Module:

```
src/
├── ui/
│   └── widgets/
│       ├── globe_widget.py          # + Connection Lines Rendering
│       ├── sidebar.py               # + Live Connections Tab
│       └── network_scanner_tab.py   # + Port Range 65535
```

## 🎨 Features (alle Versionen)

### Visualisierung
- 🗺️ 3D OpenGL Globe mit Earth-Textur
- 🏷️ Intelligente Labels (verhindert Überlappung)
- 📸 Screenshot-Funktion
- 🎨 Themes: Cyberpunk, Matrix, Neon, Classic

### Suche & Navigation
- 🔍 Städte & Länder
- 🌐 IP-Adressen
- 📍 Koordinaten
- ⭐ Favoriten-System

### Netzwerk-Tools
- 🌐 Traceroute-Visualisierung
- 🔍 Port Scanner (1-65535)
- 📊 Live Network Monitoring
- 🛡️ Firewall/Protection Tab
- 📈 Traffic Graphen
- 📊 Protocol Analysis
- 🔴 Live Connections (v0.2)

## 💡 Tipps & Tricks

### Performance Optimierung
1. Deaktiviere nicht benötigte Filter (Incoming/Outgoing)
2. Reduziere Animations-Geschwindigkeit bei vielen Verbindungen
3. Pausiere Tracking wenn nicht benötigt

### Troubleshooting
- **Keine Verbindungen sichtbar?** → Root-Rechte prüfen
- **Koordinaten fehlen?** → GeoIP-Datenbank aktualisieren
- **Langsame Animation?** → GPU-Treiber aktualisieren

## 📜 Changelog

### Version 0.2 (13.11.2025)
- ✨ Neues Live Connections Tab
- ✨ Animierte Connection Lines
- ✨ Filter für Incoming/Outgoing
- ✨ Port Scanner bis 65535
- 🐛 Bugfixes und Performance-Verbesserungen

### Version 0.1
- Initial Release
- Basic 3D Globe
- Traceroute Visualization
- Network Tools

## 🤝 Support

Bei Fragen oder Problemen:
1. Prüfe die Console-Ausgabe für Fehlermeldungen
2. Stelle sicher dass alle Dependencies installiert sind
3. Teste mit Root-Rechten für vollständige Funktionalität

## 📝 Lizenz

Proprietär - Alle Rechte vorbehalten

---

**EarthViewer v0.2** - Professional Network Visualization 🌍
