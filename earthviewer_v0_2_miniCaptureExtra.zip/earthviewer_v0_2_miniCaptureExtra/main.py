import satellite_autostart
#!/usr/bin/env python3
"""
EarthViewer 2.0 - Haupteinstiegspunkt
Modulare, professionelle 3D-Erd-Visualisierung
"""

# KRITISCHER FIX FÜR PYQT6 & PYOPENGL:
# Dieser Block muss absolut zuerst ausgeführt werden, um den Kontext korrekt zu setzen.
from PyQt6 import QtOpenGL
import OpenGL.GL
# -----------------------------------------------------------------------------
import os
os.environ['PYOPENGL_PLATFORM'] = 'osmesa'  # Fallback Platform
# Deaktiviere PyOpenGL Context-Checking GLOBAL
import OpenGL
OpenGL.ERROR_CHECKING = False
OpenGL.ERROR_LOGGING = False
OpenGL.ERROR_ON_COPY = False
OpenGL.FULL_LOGGING = False
OpenGL.FORWARD_COMPATIBLE_ONLY = True

import sys
from pathlib import Path

# FIX für Wayland/OpenGL Probleme: Erzwinge X11-Backend
if 'QT_QPA_PLATFORM' not in os.environ:
    os.environ['QT_QPA_PLATFORM'] = 'xcb'  # X11-Backend verwenden
    print("🔧 X11-Backend aktiviert (Wayland-Kompatibilität)")

# KRITISCH: Füge src/ zum Python-Path hinzu, damit Imports funktionieren
sys.path.insert(0, str(Path(__file__).parent / "src"))

from PyQt6 import QtWidgets, QtGui, QtCore
from ui.widgets.main_window import MainWindow
from core.config import WINDOW_TITLE

def main():
    """Hauptfunktion - Startet die Anwendung"""
    
    # Startup-Banner
    print("=" * 70)
    print("🌍 EarthViewer 2.0 - Modular Edition")
    print("=" * 70)
    
    # Qt-Anwendung erstellen
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    
    # WICHTIG: OpenGL Surface Format MUSS vor Widget-Erstellung gesetzt werden!
    try:
        fmt = QtGui.QSurfaceFormat()
        fmt.setVersion(3, 3)
        # ✅ KORREKTUR: CompatibilityProfile, um glLineWidth zu erlauben
        fmt.setProfile(QtGui.QSurfaceFormat.OpenGLContextProfile.CompatibilityProfile) 
        fmt.setDepthBufferSize(24)
        fmt.setStencilBufferSize(8)
        fmt.setSamples(4)
        QtGui.QSurfaceFormat.setDefaultFormat(fmt)
        print("🔧 Globales OpenGL Surface Format (3.3 Compatibility) konfiguriert.")
    except Exception as e:
        print(f"⚠️  OpenGL Format Setup Warning: {e}")
    
    # Dark Theme Palette
    palette = QtGui.QPalette()
    palette.setColor(QtGui.QPalette.ColorRole.Window, QtGui.QColor(43, 43, 43))
    palette.setColor(QtGui.QPalette.ColorRole.WindowText, QtCore.Qt.GlobalColor.white)
    palette.setColor(QtGui.QPalette.ColorRole.Base, QtGui.QColor(30, 30, 30))
    palette.setColor(QtGui.QPalette.ColorRole.AlternateBase, QtGui.QColor(43, 43, 43))
    palette.setColor(QtGui.QPalette.ColorRole.Text, QtCore.Qt.GlobalColor.white)
    palette.setColor(QtGui.QPalette.ColorRole.Button, QtGui.QColor(43, 43, 43))
    palette.setColor(QtGui.QPalette.ColorRole.ButtonText, QtCore.Qt.GlobalColor.white)
    palette.setColor(QtGui.QPalette.ColorRole.Highlight, QtGui.QColor(13, 115, 119))
    palette.setColor(QtGui.QPalette.ColorRole.HighlightedText, QtCore.Qt.GlobalColor.white)
    app.setPalette(palette)
    
    # Hauptfenster erstellen
    try:
        window = MainWindow()
        window.setWindowTitle(WINDOW_TITLE)
        window.show()
        
        print("\n✅ Anwendung erfolgreich gestartet!")
        print("💡 Tipp: Drücke Strg+C im Terminal zum Beenden\n")
        print("=" * 70)
        
    except Exception as e:
        print(f"\n❌ Fehler beim Starten: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # Event-Loop starten
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
