#!/usr/bin/env python3
"""
Tests für GeoLocation
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from core.geo_location import GeoLocation
import numpy as np

def test_to_cartesian():
    """Test Koordinaten-Konvertierung"""
    berlin = GeoLocation("Berlin", 52.52, 13.405)
    pos = berlin.to_cartesian()
    
    assert isinstance(pos, np.ndarray)
    assert len(pos) == 3
    print(f"✅ Berlin Position: {pos}")

def test_distance():
    """Test Distanz-Berechnung"""
    berlin = GeoLocation("Berlin", 52.52, 13.405)
    paris = GeoLocation("Paris", 48.8566, 2.3522)
    
    dist = berlin.distance_to(paris)
    assert 870 < dist < 880
    print(f"✅ Berlin-Paris: {dist:.2f} km")

if __name__ == "__main__":
    test_to_cartesian()
    test_distance()
    print("\n✅ Alle Tests bestanden!")
