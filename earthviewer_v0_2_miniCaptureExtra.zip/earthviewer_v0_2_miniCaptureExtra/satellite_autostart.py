#!/usr/bin/env python3
"""
Satellite Autostart (Root-Level, Debug-Version)
-----------------------------------------------

Wird von main.py mit:

    import satellite_autostart

geladen.

Dieses Modul:
    - sorgt dafür, dass ./src im sys.path liegt
    - importiert MainWindow & setup_satellites_on_mainwindow
    - patched MainWindow.__init__, um nach der normalen Initialisierung
      automatisch die Satelliten-Integration zu starten.

Zusätzlich druckt es deutlich ins Terminal, was passiert, damit wir
Fehler schnell finden.
"""

from __future__ import annotations

import sys
import traceback
from pathlib import Path

print("[satellite_autostart] Modul geladen (Root)")

ROOT = Path(__file__).resolve().parent
SRC_DIR = ROOT / "src"

if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))
    print(f"[satellite_autostart] SRC_DIR zu sys.path hinzugefügt: {SRC_DIR}")
else:
    print("[satellite_autostart] SRC_DIR war bereits in sys.path")

# Jetzt versuchen wir, MainWindow + Integration zu importieren
try:
    from ui.widgets.main_window import MainWindow
    from ui.widgets.satellite_integration import setup_satellites_on_mainwindow
    print("[satellite_autostart] MainWindow und setup_satellites_on_mainwindow erfolgreich importiert.")
except Exception as exc:
    print("[satellite_autostart] FEHLER beim Importieren von MainWindow/satellite_integration:", exc)
    traceback.print_exc()
else:
    _original_init = MainWindow.__init__

    def _patched_init(self, *args, **kwargs):
        print("[satellite_autostart] MainWindow.__init__ (gepatcht) wird aufgerufen...")
        # Erst die originale Initialisierung
        _original_init(self, *args, **kwargs)
        print("[satellite_autostart] MainWindow.__init__ (original) fertig, jetzt Satelliten-Setup...")

        # Danach Satelliten-Integration versuchen
        try:
            setup_satellites_on_mainwindow(self)
            print("[satellite_autostart] setup_satellites_on_mainwindow(self) wurde ausgeführt.")
        except Exception as exc2:
            print("[satellite_autostart] FEHLER in setup_satellites_on_mainwindow:", exc2)
            traceback.print_exc()

    MainWindow.__init__ = _patched_init
    print("[satellite_autostart] MainWindow.__init__ wurde erfolgreich gepatcht.")
