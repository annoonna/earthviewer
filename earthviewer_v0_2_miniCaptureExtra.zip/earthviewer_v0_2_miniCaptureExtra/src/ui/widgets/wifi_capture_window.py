#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WifiCaptureWindow – zeigt Live-Pakete von einem Monitor-Interface (z.B. wlan1mon) an.
Backend: tcpdump
"""

from PyQt6 import QtWidgets, QtCore
import subprocess
import re


# Beispiel-Zeilen:
# 12:34:56 192.168.1.10.54321 > 93.184.216.34.443: Flags [...], length 123
PACKET_RE = re.compile(
    r'^(?P<time>\d+:\d+:\d+)\s+'
    r'(?P<src>[^ >]+)\s+>\s+(?P<dst>[^:]+):\s*(?P<rest>.*)$'
)


class WifiCaptureWorker(QtCore.QThread):
    """
    Thread, der tcpdump startet und Zeilen parst.
    """
    packet_received = QtCore.pyqtSignal(dict)
    status_changed = QtCore.pyqtSignal(str)

    def __init__(self, iface: str, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._stop_requested = False
        self._proc = None

    def run(self):
        cmd = ["sudo", "tcpdump", "-l", "-n", "-i", self.iface, "-q"]
        self.status_changed.emit(f"Starte tcpdump auf {self.iface} ...")

        try:
            self._proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
        except Exception as e:
            self.status_changed.emit(f"Fehler: tcpdump konnte nicht gestartet werden: {e}")
            return

        for line in self._proc.stdout:
            if self._stop_requested:
                break
            line = line.strip()
            if not line:
                continue

            m = PACKET_RE.match(line)
            if not m:
                # Ungeparste Zeile trotzdem anzeigen
                self.packet_received.emit({
                    "time": "",
                    "src": "",
                    "dst": "",
                    "info": line,
                })
                continue

            d = m.groupdict()
            self.packet_received.emit({
                "time": d.get("time", ""),
                "src": d.get("src", ""),
                "dst": d.get("dst", ""),
                "info": d.get("rest", ""),
            })

        # Aufräumen
        if self._proc:
            try:
                self._proc.terminate()
            except Exception:
                pass

        self.status_changed.emit("tcpdump beendet")

    def stop(self):
        self._stop_requested = True
        if self._proc and self._proc.poll() is None:
            try:
                self._proc.terminate()
            except Exception:
                pass

class WifiCaptureWindow(QtWidgets.QDialog):
    """
    Einfaches Dialogfenster, das WifiCaptureWorker benutzt und
    die Pakete in einer Tabelle anzeigt.
    """

    def __init__(self, interface: str, parent=None):
        super().__init__(parent)
        self.interface = interface
        self.worker = None

        self.setWindowTitle(f"Live WLAN-Pakete – {self.interface}")
        self.resize(900, 500)

        self._setup_ui()
        self._start_worker()

    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        label = QtWidgets.QLabel(
            f"Live-Pakete vom Interface: {self.interface}\n"
            "Hinweis: Es wird tcpdump als Backend verwendet (sudo)."
        )
        label.setStyleSheet("color: #cccccc; font-size: 11px;")
        label.setWordWrap(True)
        layout.addWidget(label)

        self.table = QtWidgets.QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Zeit", "Quelle", "Ziel", "Info"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        layout.addWidget(self.table)

        self.status_label = QtWidgets.QLabel("Status: Initialisiere …")
        self.status_label.setStyleSheet("color: #aaaaaa; font-size: 11px;")
        layout.addWidget(self.status_label)

        btn_row = QtWidgets.QHBoxLayout()
        btn_row.addStretch()
        self.stop_btn = QtWidgets.QPushButton("Capture stoppen")
        self.stop_btn.setStyleSheet(
            "padding: 6px 12px; background: #d32f2f; color: white; "
            "border: none; border-radius: 4px; font-weight: bold;"
        )
        btn_row.addWidget(self.stop_btn)
        layout.addLayout(btn_row)

        self.stop_btn.clicked.connect(self._stop_worker)

        self.setStyleSheet("""
            QDialog { background-color: #202020; }
            QTableWidget { background-color: #1e1e1e; color: white; gridline-color: #444; }
        """)

    def _start_worker(self):
        self.worker = WifiCaptureWorker(self.interface, self)
        self.worker.packet_received.connect(self._on_packet)
        self.worker.status_changed.connect(self._on_status)
        self.worker.start()

    def _stop_worker(self):
        if self.worker:
            self.worker.stop()
            self.status_label.setText("Status: Capture gestoppt")

    def _on_status(self, text: str):
        self.status_label.setText(f"Status: {text}")

    def _on_packet(self, pkt: dict):
        row = self.table.rowCount()
        self.table.insertRow(row)
        for col, key in enumerate(["time", "src", "dst", "info"]):
            item = QtWidgets.QTableWidgetItem(pkt.get(key, ""))
            self.table.setItem(row, col, item)
        self.table.scrollToBottom()

    def closeEvent(self, event):
        self._stop_worker()
        super().closeEvent(event)
