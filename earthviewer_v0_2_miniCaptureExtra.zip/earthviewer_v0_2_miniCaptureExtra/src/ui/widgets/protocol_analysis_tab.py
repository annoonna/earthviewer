#!/usr/bin/env python3
"""Protokoll Analyse Tab - Deep Packet Analysis"""
from PyQt6 import QtWidgets, QtCore

class ProtocolAnalysisTab(QtWidgets.QWidget):
    def __init__(self, network_monitor, parent=None):
        super().__init__(parent)
        self.monitor = network_monitor
        self.monitor.stats_updated.connect(self._update_analysis)
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        title = QtWidgets.QLabel("📊 Protokoll Analyse")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: white; padding: 10px;")
        layout.addWidget(title)
        
        # Große Ansicht Button
        large_btn = QtWidgets.QPushButton("🔍 Große Ansicht")
        large_btn.setStyleSheet("padding: 10px 20px; background: #0d7377; color: white; border: none; border-radius: 6px; font-weight: bold;")
        large_btn.clicked.connect(self._open_large)
        layout.addWidget(large_btn)
        
        info = QtWidgets.QLabel("Detaillierte Analyse aller Netzwerk-Protokolle")
        info.setStyleSheet("color: #888; font-size: 11px; padding: 5px;")
        layout.addWidget(info)
        
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.HLine)
        line.setStyleSheet("background: #3a3a3a;")
        layout.addWidget(line)
        
        # Protokoll Tabelle
        self.protocol_table = QtWidgets.QTableWidget()
        self.protocol_table.setColumnCount(4)
        self.protocol_table.setHorizontalHeaderLabels(["Protokoll", "Traffic", "Pakete", "Anteil %"])
        self.protocol_table.horizontalHeader().setStretchLastSection(True)
        self.protocol_table.verticalHeader().setVisible(False)
        self.protocol_table.setAlternatingRowColors(True)
        self.protocol_table.setStyleSheet("""
            QTableWidget {
                background: #1e1e1e;
                color: white;
                gridline-color: #3a3a3a;
                border: 1px solid #3a3a3a;
            }
            QTableWidget::item { padding: 10px; }
            QTableWidget::item:selected { background: #0d7377; }
            QHeaderView::section {
                background: #2a2a2a;
                color: white;
                padding: 10px;
                font-weight: bold;
            }
        """)
        layout.addWidget(self.protocol_table, 1)
        
        # Details
        details_label = QtWidgets.QLabel("📋 Protokoll Details")
        details_label.setStyleSheet("font-weight: bold; color: white; padding: 10px;")
        layout.addWidget(details_label)
        
        self.details_text = QtWidgets.QTextEdit()
        self.details_text.setReadOnly(True)
        self.details_text.setMaximumHeight(150)
        self.details_text.setStyleSheet("""
            QTextEdit {
                background: #1e1e1e;
                color: #0d7377;
                font-family: monospace;
                border: 1px solid #3a3a3a;
                padding: 10px;
            }
        """)
        layout.addWidget(self.details_text)
    
    def _open_large(self):
        from ui.widgets.protocol_large_window import ProtocolLargeWindow
        if not hasattr(self, 'large_win') or not self.large_win.isVisible():
            self.large_win = ProtocolLargeWindow(self.monitor, self)
            self.large_win.show()
        else:
            self.large_win.raise_()
    
    def _update_analysis(self):
        protocols = self.monitor.get_top_protocols(20)
        total = sum(t for _, t in protocols) if protocols else 1
        
        self.protocol_table.setRowCount(len(protocols))
        
        for row, (protocol, traffic) in enumerate(protocols):
            percentage = (traffic / total * 100) if total > 0 else 0
            
            self.protocol_table.setItem(row, 0, QtWidgets.QTableWidgetItem(protocol))
            self.protocol_table.setItem(row, 1, QtWidgets.QTableWidgetItem(self._format_bytes(traffic)))
            self.protocol_table.setItem(row, 2, QtWidgets.QTableWidgetItem(f"{int(traffic / 1024)}"))
            self.protocol_table.setItem(row, 3, QtWidgets.QTableWidgetItem(f"{percentage:.1f}%"))
        
        # Update Details
        details = f"Gesamt-Traffic: {self._format_bytes(total)}\n"
        details += f"Aktive Protokolle: {len(protocols)}\n"
        details += f"Dominantes Protokoll: {protocols[0][0] if protocols else 'N/A'}"
        self.details_text.setPlainText(details)
    
    def _format_bytes(self, b):
        if b < 1024:
            return f"{b:.0f} B"
        elif b < 1024*1024:
            return f"{b/1024:.1f} KB"
        elif b < 1024*1024*1024:
            return f"{b/(1024*1024):.1f} MB"
        else:
            return f"{b/(1024*1024*1024):.2f} GB"
