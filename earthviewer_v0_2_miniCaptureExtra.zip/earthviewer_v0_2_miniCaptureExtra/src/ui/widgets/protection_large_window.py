#!/usr/bin/env python3
"""Protection Large Window"""
from PyQt6 import QtWidgets

class ProtectionLargeWindow(QtWidgets.QDialog):
    def __init__(self, blocked_ips, parent=None):
        super().__init__(parent)
        self.blocked_ips = blocked_ips
        self.setWindowTitle("🔒 Schutz - Große Ansicht")
        self.resize(1000, 600)
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("🔒 Netzwerk Schutz - Detailansicht")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: white;")
        header.addWidget(title)
        header.addStretch()
        
        close_btn = QtWidgets.QPushButton("❌ Schließen")
        close_btn.setStyleSheet("padding: 8px 16px; background: #d32f2f; color: white; border: none; border-radius: 4px;")
        close_btn.clicked.connect(self.close)
        header.addWidget(close_btn)
        
        layout.addLayout(header)
        
        # Blocked IPs
        info = QtWidgets.QLabel(f"🚫 Blockierte IPs: {len(self.blocked_ips)}")
        info.setStyleSheet("color: white; font-size: 16px; padding: 10px;")
        layout.addWidget(info)
        
        list_widget = QtWidgets.QListWidget()
        list_widget.setStyleSheet("background: #1e1e1e; color: white; font-size: 14px; padding: 10px;")
        for ip in self.blocked_ips:
            list_widget.addItem(f"🚫 {ip}")
        layout.addWidget(list_widget, 1)
        
        self.setStyleSheet("QDialog { background: #1e1e1e; }")
