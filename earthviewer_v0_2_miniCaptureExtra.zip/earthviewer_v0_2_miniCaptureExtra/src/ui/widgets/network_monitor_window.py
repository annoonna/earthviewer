#!/usr/bin/env python3
"""Network Monitor Window - Große Ansicht"""
from PyQt6 import QtWidgets, QtCore
from ui.widgets.network_stats_widget import NetworkStatsWidget

class NetworkMonitorWindow(QtWidgets.QDialog):
    def __init__(self, monitor, parent=None):
        super().__init__(parent)
        self.monitor = monitor
        self.setWindowTitle("📊 EarthViewer - Network Monitor (Live)")
        self.resize(1200, 700)
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("📊 Network Monitor - Live View")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: white;")
        header.addWidget(title)
        header.addStretch()
        
        pause_btn = QtWidgets.QPushButton("⏸️ Pause")
        pause_btn.setStyleSheet("padding: 8px 16px; background: #3a3a3a; color: white; border: none; border-radius: 4px;")
        pause_btn.clicked.connect(self._toggle)
        header.addWidget(pause_btn)
        self.pause_btn = pause_btn
        
        close_btn = QtWidgets.QPushButton("❌ Schließen")
        close_btn.setStyleSheet("padding: 8px 16px; background: #d32f2f; color: white; border: none; border-radius: 4px;")
        close_btn.clicked.connect(self.close)
        header.addWidget(close_btn)
        
        layout.addLayout(header)
        
        status = QtWidgets.QLabel("🔴 Live - Aktualisiert alle 2 Sekunden")
        status.setStyleSheet("color: #4caf50; font-size: 12px;")
        layout.addWidget(status)
        self.status = status
        
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.HLine)
        line.setStyleSheet("background: #3a3a3a;")
        layout.addWidget(line)
        
        self.stats = NetworkStatsWidget(self.monitor, compact=False)
        layout.addWidget(self.stats, 1)
        
        self.setStyleSheet("QDialog { background: #1e1e1e; }")
    
    def _toggle(self):
        if self.monitor.running:
            self.monitor.stop()
            self.pause_btn.setText("▶️ Fortsetzen")
            self.status.setText("⏸️ Pausiert")
        else:
            self.monitor.start()
            self.pause_btn.setText("⏸️ Pause")
            self.status.setText("🔴 Live - Aktualisiert alle 2 Sekunden")
