#!/usr/bin/env python3
"""Schützen Tab - Firewall & Security"""
from PyQt6 import QtWidgets

class ProtectionTab(QtWidgets.QWidget):
    def __init__(self, network_monitor, parent=None):
        super().__init__(parent)
        self.monitor = network_monitor
        self.blocked_ips = set()
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        title = QtWidgets.QLabel("🔒 Netzwerk Schutz")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: white; padding: 10px;")
        layout.addWidget(title)
        
        # Große Ansicht Button
        large_btn = QtWidgets.QPushButton("🔍 Große Ansicht")
        large_btn.setStyleSheet("padding: 10px 20px; background: #0d7377; color: white; border: none; border-radius: 6px; font-weight: bold;")
        large_btn.clicked.connect(self._open_large)
        layout.addWidget(large_btn)
        
        info = QtWidgets.QLabel("Blockiere IPs und überwache verdächtige Aktivitäten")
        info.setStyleSheet("color: #888; font-size: 11px; padding: 5px;")
        layout.addWidget(info)
        
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.HLine)
        line.setStyleSheet("background: #3a3a3a;")
        layout.addWidget(line)
        
        # IP Blocker
        blocker_group = QtWidgets.QGroupBox("🚫 IP Blocker")
        blocker_group.setStyleSheet("QGroupBox { color: white; font-weight: bold; padding: 10px; }")
        blocker_layout = QtWidgets.QVBoxLayout()
        
        input_layout = QtWidgets.QHBoxLayout()
        self.ip_input = QtWidgets.QLineEdit()
        self.ip_input.setPlaceholderText("IP-Adresse eingeben (z.B. 192.168.1.100)")
        self.ip_input.setStyleSheet("padding: 10px; background: #1e1e1e; color: white; border: 1px solid #555;")
        input_layout.addWidget(self.ip_input)
        
        block_btn = QtWidgets.QPushButton("🚫 Blockieren")
        block_btn.setStyleSheet("padding: 10px; background: #d32f2f; color: white; border: none; border-radius: 4px; font-weight: bold;")
        block_btn.clicked.connect(self._block_ip)
        input_layout.addWidget(block_btn)
        
        blocker_layout.addLayout(input_layout)
        
        # Blocked IPs Liste
        self.blocked_list = QtWidgets.QListWidget()
        self.blocked_list.setStyleSheet("""
            QListWidget {
                background: #1e1e1e;
                color: white;
                border: 1px solid #555;
                padding: 5px;
            }
            QListWidget::item { padding: 8px; }
            QListWidget::item:hover { background: #3a3a3a; }
        """)
        blocker_layout.addWidget(self.blocked_list)
        
        unblock_btn = QtWidgets.QPushButton("✅ Ausgewählte IP freigeben")
        unblock_btn.setStyleSheet("padding: 8px; background: #3a3a3a; color: white; border: none; border-radius: 4px;")
        unblock_btn.clicked.connect(self._unblock_ip)
        blocker_layout.addWidget(unblock_btn)
        
        blocker_group.setLayout(blocker_layout)
        layout.addWidget(blocker_group)
        
        # Status
        self.status_label = QtWidgets.QLabel("✅ Firewall aktiv | 0 IPs blockiert")
        self.status_label.setStyleSheet("color: #4caf50; font-weight: bold; padding: 10px;")
        layout.addWidget(self.status_label)
        
        layout.addStretch()
    
    def _open_large(self):
        from ui.widgets.protection_large_window import ProtectionLargeWindow
        if not hasattr(self, 'large_win') or not self.large_win.isVisible():
            self.large_win = ProtectionLargeWindow(self.blocked_ips, self)
            self.large_win.show()
        else:
            self.large_win.raise_()
    
    def _block_ip(self):
        ip = self.ip_input.text().strip()
        if ip and ip not in self.blocked_ips:
            self.blocked_ips.add(ip)
            self.blocked_list.addItem(f"🚫 {ip}")
            self.ip_input.clear()
            self._update_status()
            QtWidgets.QMessageBox.information(self, "Blockiert", f"IP {ip} wurde blockiert!")
    
    def _unblock_ip(self):
        current = self.blocked_list.currentItem()
        if current:
            ip = current.text().replace("🚫 ", "")
            self.blocked_ips.discard(ip)
            self.blocked_list.takeItem(self.blocked_list.currentRow())
            self._update_status()
    
    def _update_status(self):
        count = len(self.blocked_ips)
        self.status_label.setText(f"✅ Firewall aktiv | {count} IP{'s' if count != 1 else ''} blockiert")
