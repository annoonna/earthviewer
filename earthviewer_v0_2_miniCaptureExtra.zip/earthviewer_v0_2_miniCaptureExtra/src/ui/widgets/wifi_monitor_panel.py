#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WLAN Monitor Panel – MIT Interface-Auswahl für wlan0/wlan1
"""

from PyQt6 import QtWidgets, QtCore
import subprocess

class WifiMonitorPanel(QtWidgets.QGroupBox):
    """
    Panel zur Steuerung von Monitor-Mode mit Interface-Auswahl
    """

    def __init__(self, parent=None):
        super().__init__("WLAN Monitor-Mode", parent)
        self.detected_ifaces = []
        self.primary_iface = None
        self._setup_ui()
        self._detect_interfaces()
        
        # Timer für Mode-Update
        self._mode_timer = QtCore.QTimer(self)
        self._mode_timer.timeout.connect(self._update_mode)
        self._mode_timer.start(3000)

    def _setup_ui(self):
        self.setStyleSheet(
            "QGroupBox { font-weight: bold; color: #ffffff; border: 1px solid #444; "
            "border-radius: 4px; margin-top: 6px; } "
            "QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 4px; }"
        )

        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(8)

        # Info Text
        info = QtWidgets.QLabel(
            "Monitor-Mode Steuerung via airmon-ng.\n"
            "Wähle dein WLAN-Interface (wlan0/wlan1):"
        )
        info.setWordWrap(True)
        info.setStyleSheet("color: #cccccc; font-size: 11px;")
        layout.addWidget(info)

        # Interface-Auswahl DROPDOWN
        form = QtWidgets.QFormLayout()
        form.setSpacing(10)
        
        self.iface_combo = QtWidgets.QComboBox()
        self.iface_combo.setStyleSheet("""
            QComboBox {
                padding: 5px;
                background: #2a2a2a;
                border: 1px solid #444;
                color: white;
                min-width: 150px;
            }
            QComboBox::drop-down {
                border-left: 1px solid #444;
                width: 20px;
            }
            QComboBox::down-arrow {
                image: none;
                border-style: solid;
                border-width: 4px;
                border-color: transparent;
                border-top-color: #00acc1;
                margin-top: 4px;
            }
            QComboBox QAbstractItemView {
                background: #2a2a2a;
                border: 1px solid #444;
                selection-background-color: #0d7377;
            }
        """)
        form.addRow("📡 Interface:", self.iface_combo)
        layout.addLayout(form)

        # Modus-Anzeige
        self.mode_label = QtWidgets.QLabel("Modus: unbekannt")
        self.mode_label.setStyleSheet("color: #aaaaaa; font-size: 11px; padding: 5px;")
        layout.addWidget(self.mode_label)

        # Aggressiv-Modus Checkbox
        self.aggressive_cb = QtWidgets.QCheckBox(
            "Aggressiver Modus (airmon-ng check kill)"
        )
        self.aggressive_cb.setStyleSheet("color: #cccccc; font-size: 11px;")
        layout.addWidget(self.aggressive_cb)

        # Button-Reihe
        btn_row = QtWidgets.QHBoxLayout()
        btn_row.setSpacing(5)
        
        self.start_btn = QtWidgets.QPushButton("▶️ Start Monitor")
        self.start_btn.setStyleSheet("""
            QPushButton {
                padding: 8px 15px;
                background: #00695c;
                color: white;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #00897b;
            }
        """)
        
        self.stop_btn = QtWidgets.QPushButton("⏹ Stop Monitor")
        self.stop_btn.setStyleSheet("""
            QPushButton {
                padding: 8px 15px;
                background: #c62828;
                color: white;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #ef5350;
            }
        """)
        
        self.restore_btn = QtWidgets.QPushButton("📶 WLAN Reset")
        self.restore_btn.setStyleSheet("""
            QPushButton {
                padding: 8px 15px;
                background: #1565c0;
                color: white;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #1976d2;
            }
        """)
        
        btn_row.addWidget(self.start_btn)
        btn_row.addWidget(self.stop_btn)
        btn_row.addWidget(self.restore_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        # Output-Fenster
        self.output = QtWidgets.QTextEdit()
        self.output.setReadOnly(True)
        self.output.setFixedHeight(150)
        self.output.setStyleSheet("""
            QTextEdit {
                background: #1a1a1a;
                color: #00ff00;
                font-family: monospace;
                font-size: 10px;
                border: 1px solid #333;
            }
        """)
        layout.addWidget(self.output)

        # Signal-Verbindungen
        self.start_btn.clicked.connect(self._start_monitor_mode)
        self.stop_btn.clicked.connect(self._stop_monitor_mode)
        self.restore_btn.clicked.connect(self._restore_wifi)
        self.iface_combo.currentTextChanged.connect(lambda _: self._update_mode())

    def _detect_interfaces(self):
        """Erkennt verfügbare WLAN-Interfaces"""
        ifaces = []
        
        # Methode 1: iw dev
        try:
            out = subprocess.check_output(["iw", "dev"], text=True, stderr=subprocess.DEVNULL)
            for line in out.splitlines():
                line = line.strip()
                if line.startswith("Interface"):
                    parts = line.split()
                    if len(parts) >= 2:
                        iface = parts[1]
                        if not iface.endswith("mon"):
                            ifaces.append(iface)
        except:
            pass
        
        # Methode 2: ip link
        if not ifaces:
            try:
                out = subprocess.check_output(["ip", "link", "show"], text=True, stderr=subprocess.DEVNULL)
                for line in out.splitlines():
                    if "wlan" in line or "wlp" in line:
                        parts = line.split(":")
                        if len(parts) >= 2:
                            name = parts[1].strip()
                            if name.startswith(("wlan", "wlp")) and not name.endswith("mon"):
                                ifaces.append(name)
            except:
                pass
        
        # Fallback
        if not ifaces:
            ifaces = ["wlan0", "wlan1"]
        
        # Duplikate entfernen und sortieren
        self.detected_ifaces = sorted(list(set(ifaces)))
        self.primary_iface = self.detected_ifaces[0] if self.detected_ifaces else "wlan0"
        
        # ComboBox befüllen
        self.iface_combo.clear()
        self.iface_combo.addItems(self.detected_ifaces)
        
        self.output.append(f"🔍 Gefundene Interfaces: {', '.join(self.detected_ifaces)}\n")

    def _update_mode(self):
        """Aktualisiert die Modus-Anzeige"""
        current = self.iface_combo.currentText()
        if not current:
            return
        
        try:
            # Prüfe ob Monitor-Interface existiert
            mon_iface = f"{current}mon"
            out = subprocess.check_output(["ip", "link", "show"], text=True, stderr=subprocess.DEVNULL)
            
            if mon_iface in out:
                self.mode_label.setText(f"✅ Modus: MONITOR ({mon_iface} aktiv)")
                self.mode_label.setStyleSheet("color: #4caf50; font-size: 11px; padding: 5px;")
            else:
                # Prüfe normalen Modus
                out = subprocess.check_output(["iw", current, "info"], text=True, stderr=subprocess.DEVNULL)
                if "type managed" in out.lower():
                    self.mode_label.setText(f"📡 Modus: MANAGED (normal)")
                    self.mode_label.setStyleSheet("color: #2196f3; font-size: 11px; padding: 5px;")
                elif "type monitor" in out.lower():
                    self.mode_label.setText(f"🔍 Modus: MONITOR")
                    self.mode_label.setStyleSheet("color: #ff9800; font-size: 11px; padding: 5px;")
                else:
                    self.mode_label.setText(f"❓ Modus: unbekannt")
                    self.mode_label.setStyleSheet("color: #aaaaaa; font-size: 11px; padding: 5px;")
        except:
            self.mode_label.setText(f"❓ Modus: unbekannt")
            self.mode_label.setStyleSheet("color: #aaaaaa; font-size: 11px; padding: 5px;")

    def _start_monitor_mode(self):
        """Startet Monitor-Mode auf ausgewähltem Interface"""
        iface = self.iface_combo.currentText()
        if not iface:
            self.output.append("❌ Kein Interface ausgewählt!\n")
            return
        
        self.output.append(f"\n▶️ Starte Monitor-Mode auf {iface}...\n")
        
        try:
            # Optional: Check kill
            if self.aggressive_cb.isChecked() and iface == "wlan1":
                self.output.append("⚠️ Check kill nur für wlan1, wlan0 bleibt online!\n")
                result = subprocess.run(["sudo", "killall", "-q", "wpa_supplicant"], capture_output=True, text=True)
                self.output.append("Prozesse beendet\n")
                self.output.append(result.stdout)
            
            # Start monitor mode
            result = subprocess.run(
                ["sudo", "airmon-ng", "start", iface],
                capture_output=True, text=True
            )
            self.output.append(result.stdout)
            
            if "monitor mode" in result.stdout.lower():
                self.output.append(f"✅ Monitor-Mode auf {iface}mon gestartet!\n")
            else:
                self.output.append(f"⚠️ Monitor-Mode möglicherweise nicht aktiv\n")
                
        except Exception as e:
            self.output.append(f"❌ Fehler: {e}\n")
            self.output.append("💡 Tipp: Starte mit sudo!\n")

    def _stop_monitor_mode(self):
        """Stoppt Monitor-Mode"""
        iface = self.iface_combo.currentText()
        mon_iface = f"{iface}mon"
        
        self.output.append(f"\n⏹ Stoppe Monitor-Mode auf {mon_iface}...\n")
        
        try:
            result = subprocess.run(
                ["sudo", "airmon-ng", "stop", mon_iface],
                capture_output=True, text=True
            )
            self.output.append(result.stdout)
            self.output.append(f"✅ Monitor-Mode gestoppt\n")
        except Exception as e:
            self.output.append(f"❌ Fehler: {e}\n")

    def _restore_wifi(self):
        """Stellt WLAN-Verbindung wieder her"""
        self.output.append("\n📶 Stelle WLAN wieder her...\n")
        
        try:
            # NetworkManager neu starten
            subprocess.run(["sudo", "systemctl", "restart", "NetworkManager"], check=True)
            self.output.append("✅ NetworkManager neu gestartet\n")
            
            # Interfaces hochfahren
            for iface in self.detected_ifaces:
                subprocess.run(["sudo", "ip", "link", "set", iface, "up"], check=False)
                self.output.append(f"✅ {iface} aktiviert\n")
            
            self.output.append("✅ WLAN wiederhergestellt!\n")
        except Exception as e:
            self.output.append(f"❌ Fehler: {e}\n")
