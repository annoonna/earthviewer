from PyQt6 import QtWidgets, QtCore, QtGui
import socket
from collections import defaultdict

class HostsViewWidget(QtWidgets.QWidget):
    """Zeigt alle Hosts mit Hostnamen und verbundenen Apps"""
    
    def __init__(self, monitor, geo_manager):
        super().__init__()
        self.monitor = monitor
        self.geo_manager = geo_manager
        self._hostname_cache = {}  # IP -> Hostname Cache
        
        self.setup_ui()
        
        # Update Timer
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update_data)
        self.timer.start(2000)  # Alle 2 Sekunden
    
    def setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Titel
        title = QtWidgets.QLabel("🌐 Network Hosts")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #4FC3F7;")
        layout.addWidget(title)
        
        # Tabelle
        self.table = QtWidgets.QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Host", "IP", "Traffic", "Apps"])
        
        # Spaltenbreiten
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        
        # Styling
        self.table.setStyleSheet("""
            QTableWidget {
                background-color: #1e1e1e;
                color: white;
                gridline-color: #333;
                border: none;
            }
            QHeaderView::section {
                background-color: #2d2d2d;
                color: #4FC3F7;
                padding: 8px;
                border: none;
                font-weight: bold;
            }
            QTableWidget::item {
                padding: 8px;
            }
            QTableWidget::item:selected {
                background-color: #0d47a1;
            }
        """)
        
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        
        layout.addWidget(self.table)
    
    def get_hostname(self, ip):
        """Cached Reverse DNS Lookup"""
        if ip in self._hostname_cache:
            return self._hostname_cache[ip]
        
        try:
            hostname = socket.gethostbyaddr(ip)[0]
            self._hostname_cache[ip] = hostname
            return hostname
        except:
            self._hostname_cache[ip] = ip
            return ip
    
    def update_data(self):
        """Aktualisiert die Tabelle"""
        from collections import defaultdict
        host_traffic = defaultdict(float)
        
        for app, traffic in self.monitor.get_top_apps(1000):
            hosts = self.monitor.get_hosts_for_app(app, limit=1000)
            for host_ip, host_traffic_val in hosts:
                host_traffic[host_ip] += host_traffic_val
        
        sorted_hosts = sorted(host_traffic.items(), key=lambda x: x[1], reverse=True)
        
        self.table.setRowCount(len(sorted_hosts))
        
        for i, (host_ip, traffic) in enumerate(sorted_hosts):
            hostname = self.get_hostname(host_ip)
            
            if hostname == host_ip:
                host_item = QtWidgets.QTableWidgetItem(f"🌐 {host_ip}")
                ip_item = QtWidgets.QTableWidgetItem("")
            else:
                host_item = QtWidgets.QTableWidgetItem(f"🌐 {hostname}")
                ip_item = QtWidgets.QTableWidgetItem(host_ip)
            
            ip_item.setForeground(QtGui.QColor("#666"))
            ip_item.setFont(QtGui.QFont("Monospace", 9))
            
            traffic_item = QtWidgets.QTableWidgetItem(self._format_bytes(traffic))
            traffic_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
            
            apps = self.monitor.get_apps_for_host(host_ip)
            apps_text = " ".join([self._get_app_icon(app) for app in apps[:5]])
            if len(apps) > 5:
                apps_text += f" +{len(apps)-5}"
            
            apps_item = QtWidgets.QTableWidgetItem(apps_text)
            apps_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            
            self.table.setItem(i, 0, host_item)
            self.table.setItem(i, 1, ip_item)
            self.table.setItem(i, 2, traffic_item)
            self.table.setItem(i, 3, apps_item)
    
    def _get_app_icon(self, app_name):
        app_lower = app_name.lower()
        if "firefox" in app_lower:
            return "🦊"
        elif "chrome" in app_lower or "chromium" in app_lower:
            return "🌐"
        elif "system" in app_lower:
            return "⚙️"
        else:
            return "📱"
    
    def _format_bytes(self, bytes_val):
        if bytes_val < 1024:
            return f"{bytes_val:.0f} B"
        elif bytes_val < 1024 * 1024:
            return f"{bytes_val/1024:.1f} KB"
        else:
            return f"{bytes_val/(1024*1024):.1f} MB"
