#!/usr/bin/env python3
""" Netzwerk-Tab - Vollständige und funktionierende Version """
from PyQt6 import QtWidgets, QtCore
from network.traceroute import Traceroute
from network.ping import Ping, PingResult
from network.whois_lookup import WhoisLookup
from network.network_monitor import NetworkMonitor

class PingThread(QtCore.QThread):
    """Führt Ping in einem separaten Thread aus und sendet Signale für UI-Updates."""
    result_received = QtCore.pyqtSignal(PingResult)
    error_occurred = QtCore.pyqtSignal(str)
    
    def __init__(self, target):
        super().__init__()
        self.target = target
        self.ping_instance = Ping()

    def run(self):
        try:
            for result in self.ping_instance.ping(self.target, count=4):
                self.result_received.emit(result)
        except Exception as e:
            self.error_occurred.emit(str(e))

class NetworkTab(QtWidgets.QWidget):
    def __init__(self, geo_manager, globe_widget, parent=None):
        super().__init__(parent)
        self.geo_manager, self.globe = geo_manager, globe_widget
        self.traceroute, self.whois = Traceroute(geo_manager), WhoisLookup()
        self.network_monitor = NetworkMonitor(geo_manager); self.network_monitor.start()
        self.loop_running = False
        self.loop_timer = QtCore.QTimer(self); self.loop_timer.timeout.connect(self._on_loop_tick)
        self.ping_thread = None
        self._setup_ui()

    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self); layout.setSpacing(10)
        tool_label = QtWidgets.QLabel("🌐 Netzwerk-Tool"); tool_label.setStyleSheet("font-size: 14px; font-weight: bold;"); layout.addWidget(tool_label)
        self.tool_combo = QtWidgets.QComboBox(); self.tool_combo.addItems(["Traceroute", "Ping", "WHOIS"]); layout.addWidget(self.tool_combo)
        target_label = QtWidgets.QLabel("🎯 Ziel"); target_label.setStyleSheet("font-size: 14px; font-weight: bold; margin-top: 10px;"); layout.addWidget(target_label)
        self.target_input = QtWidgets.QLineEdit(); self.target_input.setPlaceholderText("z.B. golem.de oder 8.8.8.8"); layout.addWidget(self.target_input)
        
        loop_widget = QtWidgets.QWidget(); loop_layout = QtWidgets.QHBoxLayout(loop_widget); loop_layout.setContentsMargins(0,0,0,0)
        self.loop_checkbox = QtWidgets.QCheckBox("🔄 Loop"); loop_layout.addWidget(self.loop_checkbox)
        self.loop_interval = QtWidgets.QSpinBox(); self.loop_interval.setRange(5, 300); self.loop_interval.setValue(30); self.loop_interval.setSuffix(" s")
        loop_layout.addWidget(QtWidgets.QLabel("Intervall:")); loop_layout.addWidget(self.loop_interval); loop_layout.addStretch()
        self.loop_widget = loop_widget; layout.addWidget(loop_widget)
        
        self.tool_combo.currentTextChanged.connect(self._on_tool_changed)
        self.loop_checkbox.stateChanged.connect(self._on_loop_toggle)
        
        self.start_btn = QtWidgets.QPushButton("▶️ Starten"); self.start_btn.clicked.connect(self._on_start); layout.addWidget(self.start_btn)
        result_label = QtWidgets.QLabel("📊 Ergebnis"); result_label.setStyleSheet("font-size: 14px; font-weight: bold; margin-top: 10px;"); layout.addWidget(result_label)
        self.result_text = QtWidgets.QTextEdit(); self.result_text.setReadOnly(True); self.result_text.setStyleSheet("font-family: monospace; color: #0f0; background: #1e1e1e;"); layout.addWidget(self.result_text)
        self._on_tool_changed(self.tool_combo.currentText())

    def _on_tool_changed(self, tool):
        self.loop_widget.setVisible(tool == "Traceroute")
        if tool != "Traceroute" and self.loop_running: self._stop_loop()
    
    def _on_loop_toggle(self, state):
        if state == QtCore.Qt.CheckState.Checked.value and not self.loop_running: self._start_loop()
        elif state == QtCore.Qt.CheckState.Unchecked.value and self.loop_running: self._stop_loop()
    
    def _start_loop(self):
        if not self.target_input.text().strip(): self.loop_checkbox.setChecked(False); return
        self.loop_running = True; self.loop_timer.start(self.loop_interval.value() * 1000)
        self.start_btn.setEnabled(False); self.result_text.append("\n🔄 Loop-Modus gestartet.\n"); self._run_traceroute(self.target_input.text().strip())
    
    def _stop_loop(self):
        self.loop_running = False; self.loop_timer.stop()
        self.start_btn.setEnabled(True); self.result_text.append("\n⏹️ Loop-Modus gestoppt.\n")

    def _on_loop_tick(self):
        if self.target_input.text().strip(): self._run_traceroute(self.target_input.text().strip())

    def _on_start(self):
        target = self.target_input.text().strip()
        if not target: self.result_text.setText("❌ Bitte Ziel eingeben"); return
        tool = self.tool_combo.currentText(); self.start_btn.setEnabled(False); self.result_text.clear()
        if tool == "Traceroute": self._run_traceroute(target)
        elif tool == "Ping": self._run_ping(target)
        elif tool == "WHOIS": self._run_whois(target)
    
    def _run_traceroute(self, target):
        self.result_text.append(f"🔍 Traceroute zu {target}...")
        markers, hop_info = [], []
        for hop in self.traceroute.trace(target):
            self.result_text.append(f"Hop {hop.hop_num}: {hop.hostname} ({hop.ip}) - {hop.rtt:.1f}ms")
            if hop.location:
                markers.append(hop.location)
                hop_info.append({'hop_num': hop.hop_num, 'ip': hop.ip, 'hostname': hop.hostname, 'rtt': hop.rtt})
        if markers:
            self.globe.traceroute_markers, self.globe.traceroute_hop_info = markers, hop_info
            self.globe.update(); self.result_text.append(f"\n✅ {len(markers)} Hops lokalisiert")
        if not self.loop_running: self.start_btn.setEnabled(True)

    def _run_ping(self, target):
        self.result_text.append(f"🏓 Pinge {target}...")
        self.ping_thread = PingThread(target)
        self.ping_thread.result_received.connect(self._on_ping_result)
        self.ping_thread.finished.connect(lambda: self.start_btn.setEnabled(True))
        self.ping_thread.start()

    def _on_ping_result(self, result):
        if result.success:
            self.result_text.append(f"✅ Antwort von {self.ping_thread.target}: Zeit={result.rtt:.1f}ms TTL={result.ttl}")
        else:
            self.result_text.append(f"❌ Zeitüberschreitung der Anforderung.")

    def _run_whois(self, target):
        self.result_text.append(f"🔍 WHOIS für {target}...")
        result = self.whois.lookup(target)
        self.result_text.append(result)
        self.start_btn.setEnabled(True)
