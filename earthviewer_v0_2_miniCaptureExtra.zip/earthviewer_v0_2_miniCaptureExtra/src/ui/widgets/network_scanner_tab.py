#!/usr/bin/env python3
"""Netzwerk Scanner Tab - Port Scanner mit echtem Multithreading"""
from PyQt6 import QtWidgets, QtCore
import socket
import threading
from queue import Queue
from typing import List, Tuple

class PortScannerThread(QtCore.QThread):
    """Multithreaded Port Scanner - scannt 1-65535 ohne UI freeze"""
    progress = QtCore.pyqtSignal(int, int, str)  # (current, total, message)
    port_found = QtCore.pyqtSignal(int, str)     # (port, service_name)
    finished = QtCore.pyqtSignal(list)            # (list of open ports)
    
    def __init__(self, target_ip: str, start_port: int, end_port: int, parent=None):
        super().__init__(parent)
        self.target_ip = target_ip
        self.start_port = start_port
        self.end_port = end_port
        self.running = True
        self.open_ports = []
        
    def stop(self):
        """Stop den Scanner"""
        self.running = False
        
    def run(self):
        """Haupt-Scan-Loop mit Multithreading"""
        total_ports = self.end_port - self.start_port + 1
        self.progress.emit(0, total_ports, f"Starte Scan von {self.start_port}-{self.end_port}...")
        
        # Queue für Thread-Pool
        port_queue = Queue()
        for port in range(self.start_port, self.end_port + 1):
            port_queue.put(port)
        
        # Worker-Funktion für Threads
        def scan_worker():
            while not port_queue.empty() and self.running:
                try:
                    port = port_queue.get(timeout=0.1)
                    if self._scan_port(port):
                        service = self._get_service_name(port)
                        self.open_ports.append(port)
                        self.port_found.emit(port, service)
                    
                    # Progress Update
                    scanned = self.start_port + total_ports - port_queue.qsize() - 1
                    if scanned % 100 == 0:  # Update alle 100 Ports
                        self.progress.emit(scanned, total_ports, 
                                         f"Gescannt: {scanned}/{total_ports} ({len(self.open_ports)} offen)")
                    port_queue.task_done()
                except:
                    pass
        
        # Starte Worker-Threads (100 parallel für Geschwindigkeit)
        num_threads = 100
        threads = []
        for _ in range(num_threads):
            t = threading.Thread(target=scan_worker, daemon=True)
            t.start()
            threads.append(t)
        
        # Warte auf alle Threads
        for t in threads:
            t.join()
        
        # Finale Updates
        self.progress.emit(total_ports, total_ports, 
                          f"✅ Scan abgeschlossen! {len(self.open_ports)} offene Ports gefunden")
        self.finished.emit(sorted(self.open_ports))
    
    def _scan_port(self, port: int) -> bool:
        """Scannt einen einzelnen Port"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.5)  # 500ms Timeout
            result = sock.connect_ex((self.target_ip, port))
            sock.close()
            return result == 0
        except:
            return False
    
    def _get_service_name(self, port: int) -> str:
        """Gibt bekannte Service-Namen zurück"""
        services = {
            20: "FTP-Data", 21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP",
            53: "DNS", 80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS",
            445: "SMB", 587: "SMTP-TLS", 993: "IMAPS", 995: "POP3S",
            1433: "MSSQL", 1521: "Oracle", 3306: "MySQL", 3389: "RDP",
            5432: "PostgreSQL", 5900: "VNC", 6379: "Redis", 8080: "HTTP-Alt",
            8443: "HTTPS-Alt", 9090: "WebUI", 27017: "MongoDB"
        }
        return services.get(port, "Unknown")


class NetworkScannerTab(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.scanner_thread = None
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        title = QtWidgets.QLabel("🔍 Netzwerk Scanner")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: white; padding: 10px;")
        layout.addWidget(title)
        
        # Große Ansicht Button
        large_btn = QtWidgets.QPushButton("🔍 Große Ansicht")
        large_btn.setStyleSheet("padding: 10px 20px; background: #0d7377; color: white; border: none; border-radius: 6px; font-weight: bold;")
        large_btn.clicked.connect(self._open_large)
        layout.addWidget(large_btn)
        
        info = QtWidgets.QLabel("Scanne Netzwerke, finde Geräte und prüfe Ports (1-65535)")
        info.setStyleSheet("color: #888; font-size: 11px; padding: 5px;")
        layout.addWidget(info)
        
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.HLine)
        line.setStyleSheet("background: #3a3a3a;")
        layout.addWidget(line)
        
        # Scanner Controls
        controls_group = QtWidgets.QGroupBox("🎯 Scan Optionen")
        controls_group.setStyleSheet("QGroupBox { color: white; font-weight: bold; padding: 10px; }")
        controls_layout = QtWidgets.QVBoxLayout()
        
        # Target
        target_layout = QtWidgets.QHBoxLayout()
        target_layout.addWidget(QtWidgets.QLabel("Ziel:"))
        self.target_input = QtWidgets.QLineEdit()
        self.target_input.setPlaceholderText("IP oder Hostname (z.B. 192.168.1.1 oder google.com)")
        self.target_input.setStyleSheet("padding: 10px; background: #1e1e1e; color: white; border: 1px solid #555;")
        target_layout.addWidget(self.target_input)
        controls_layout.addLayout(target_layout)
        
        # Port Range
        port_layout = QtWidgets.QHBoxLayout()
        port_layout.addWidget(QtWidgets.QLabel("Ports:"))
        self.port_start = QtWidgets.QSpinBox()
        self.port_start.setRange(1, 65535)
        self.port_start.setValue(1)
        self.port_start.setStyleSheet("padding: 8px; background: #1e1e1e; color: white;")
        port_layout.addWidget(self.port_start)
        port_layout.addWidget(QtWidgets.QLabel("-"))
        self.port_end = QtWidgets.QSpinBox()
        self.port_end.setRange(1, 65535)
        self.port_end.setValue(65535)
        self.port_end.setStyleSheet("padding: 8px; background: #1e1e1e; color: white;")
        port_layout.addWidget(self.port_end)
        port_layout.addStretch()
        controls_layout.addLayout(port_layout)
        
        # Scan Button
        self.scan_btn = QtWidgets.QPushButton("🔍 Scan starten")
        self.scan_btn.setStyleSheet("padding: 12px; background: #0d7377; color: white; border: none; border-radius: 6px; font-weight: bold; font-size: 14px;")
        self.scan_btn.clicked.connect(self._toggle_scan)
        controls_layout.addWidget(self.scan_btn)
        
        # Progress Bar
        self.progress_bar = QtWidgets.QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #3a3a3a;
                border-radius: 5px;
                text-align: center;
                background: #1e1e1e;
                color: white;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                           stop:0 #0d7377, stop:1 #14ffec);
                border-radius: 5px;
            }
        """)
        self.progress_bar.setVisible(False)
        controls_layout.addWidget(self.progress_bar)
        
        controls_group.setLayout(controls_layout)
        layout.addWidget(controls_group)
        
        # Results
        results_label = QtWidgets.QLabel("📋 Scan Ergebnisse")
        results_label.setStyleSheet("font-weight: bold; color: white; padding: 10px;")
        layout.addWidget(results_label)
        
        self.results_text = QtWidgets.QTextEdit()
        self.results_text.setReadOnly(True)
        self.results_text.setStyleSheet("""
            QTextEdit {
                background: #1e1e1e;
                color: #00ff00;
                font-family: monospace;
                font-size: 12px;
                border: 1px solid #3a3a3a;
                padding: 10px;
            }
        """)
        layout.addWidget(self.results_text, 1)
    
    def _open_large(self):
        from ui.widgets.scanner_large_window import ScannerLargeWindow
        results = self.results_text.toPlainText()
        if not hasattr(self, 'large_win') or not self.large_win.isVisible():
            self.large_win = ScannerLargeWindow(results, self)
            self.large_win.show()
        else:
            self.large_win.raise_()
    
    def _toggle_scan(self):
        """Start oder Stop den Scan"""
        if self.scanner_thread and self.scanner_thread.isRunning():
            # Stop laufenden Scan
            self.scanner_thread.stop()
            self.scanner_thread.wait()
            self.scan_btn.setText("🔍 Scan starten")
            self.scan_btn.setStyleSheet("padding: 12px; background: #0d7377; color: white; border: none; border-radius: 6px; font-weight: bold; font-size: 14px;")
            self.progress_bar.setVisible(False)
            self.results_text.append("\n❌ Scan abgebrochen!")
        else:
            # Starte neuen Scan
            self._start_scan()
    
    def _start_scan(self):
        target = self.target_input.text().strip()
        if not target:
            self.results_text.setPlainText("❌ Bitte Ziel eingeben!")
            return
        
        start_port = self.port_start.value()
        end_port = self.port_end.value()
        
        if start_port > end_port:
            self.results_text.setPlainText("❌ Start-Port muss kleiner als End-Port sein!")
            return
        
        # Resolve Hostname
        try:
            ip = socket.gethostbyname(target)
        except socket.gaierror:
            self.results_text.setPlainText(f"❌ Konnte {target} nicht auflösen!")
            return
        
        # UI vorbereiten
        self.results_text.setPlainText(f"🔍 Scanne {target} ({ip})\n")
        self.results_text.append(f"📊 Port-Range: {start_port}-{end_port}\n")
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.scan_btn.setText("⏹️ Scan stoppen")
        self.scan_btn.setStyleSheet("padding: 12px; background: #d32f2f; color: white; border: none; border-radius: 6px; font-weight: bold; font-size: 14px;")
        
        # Scanner Thread erstellen und starten
        self.scanner_thread = PortScannerThread(ip, start_port, end_port)
        self.scanner_thread.progress.connect(self._on_progress)
        self.scanner_thread.port_found.connect(self._on_port_found)
        self.scanner_thread.finished.connect(self._on_finished)
        self.scanner_thread.start()
    
    def _on_progress(self, current: int, total: int, message: str):
        """Progress Update vom Scanner"""
        if total > 0:
            percent = int((current / total) * 100)
            self.progress_bar.setValue(percent)
    
    def _on_port_found(self, port: int, service: str):
        """Ein offener Port wurde gefunden"""
        self.results_text.append(f"✅ Port {port:5d} OFFEN - {service}")
    
    def _on_finished(self, open_ports: List[int]):
        """Scan abgeschlossen"""
        self.results_text.append(f"\n{'='*60}")
        self.results_text.append(f"📊 Scan abgeschlossen!")
        self.results_text.append(f"🔓 {len(open_ports)} offene Ports gefunden")
        
        if open_ports:
            self.results_text.append(f"\n📋 Offene Ports: {', '.join(map(str, open_ports))}")
        else:
            self.results_text.append(f"\n⚠️  Keine offenen Ports gefunden")
        
        # UI zurücksetzen
        self.scan_btn.setText("🔍 Scan starten")
        self.scan_btn.setStyleSheet("padding: 12px; background: #0d7377; color: white; border: none; border-radius: 6px; font-weight: bold; font-size: 14px;")
        self.progress_bar.setVisible(False)
