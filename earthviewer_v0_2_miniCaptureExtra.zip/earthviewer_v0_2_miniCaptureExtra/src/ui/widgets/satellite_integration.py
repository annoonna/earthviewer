#!/usr/bin/env python3
"""
Satellite Integration UI (Ultimate Edition)
Features:
- Individual satellite checkboxes
- Click on name to show satellite info
- RIGHT-CLICK on name for options menu
"""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QCheckBox, QGroupBox, QScrollArea, QFrame, QMenu
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction
from data.satellite_manager import SatelliteManager
from data.spectator_api import SpectatorClient
from ui.widgets.globe_widget import GlobeWidget

def _get_api_key():
    return "7xwAr95Kkn8YRUKf2ShcxQ"

def _find_globe_widget(main_window):
    return main_window.findChild(GlobeWidget) or getattr(main_window, "globe_widget", None)

def _find_main_tabwidget(main_window):
    from PyQt6.QtWidgets import QTabWidget
    return main_window.findChild(QTabWidget)

class ClickableLabel(QLabel):
    """Label mit Links & Rechts-Klick"""
    def __init__(self, text, left_callback, right_callback, parent=None):
        super().__init__(text, parent)
        self.left_callback = left_callback
        self.right_callback = right_callback
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("QLabel:hover { color: #0d7377; text-decoration: underline; }")
    
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.left_callback()
        elif event.button() == Qt.MouseButton.RightButton:
            self.right_callback(event.globalPosition().toPoint())

class SatelliteControlWidget(QWidget):
    def __init__(self, globe: GlobeWidget, manager: SatelliteManager, parent=None):
        super().__init__(parent)
        self.globe = globe
        self.manager = manager
        self.globe.satellite_manager = self.manager.engine  # Link ENGINE to globe
        self.monitor_window = None
        self.satellite_visibility = {}
        self.all_satellites = []
        self.sat_checkboxes = {}
        
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("<h2>🛰️ Satelliten-Zentrale</h2>"))
        
        btn_pro = QPushButton("🖥️ PRO Monitor öffnen")
        btn_pro.setStyleSheet("background: #0d7377; color: white; padding: 10px; font-weight: bold;")
        btn_pro.clicked.connect(self._open_monitor_window)
        layout.addWidget(btn_pro)
        layout.addWidget(QLabel("<hr>"))
        
        grp = QGroupBox("Globus Anzeige")
        vbox = QVBoxLayout()
        self.cb_show = QCheckBox("Auf Globus anzeigen")
        self.cb_show.setChecked(True)
        self.cb_show.toggled.connect(self._toggle_globus)
        vbox.addWidget(self.cb_show)
        vbox.addWidget(QLabel("Kategorien:"))
        
        self.cats = ["Space Stations", "Weather", "Starlink", "GPS"]
        self.cat_checks = {}
        for cat in self.cats:
            cb = QCheckBox(cat)
            cb.stateChanged.connect(lambda state, c=cat: self._toggle_category(c, state))
            vbox.addWidget(cb)
            self.cat_checks[cat] = cb
        
        grp.setLayout(vbox)
        layout.addWidget(grp)
        layout.addWidget(QLabel("<b>Aktive Satelliten:</b>"))
        
        btn_layout = QHBoxLayout()
        btn_all = QPushButton("Alle auswählen")
        btn_all.clicked.connect(self._select_all)
        btn_none = QPushButton("Alle abwählen")
        btn_none.clicked.connect(self._deselect_all)
        btn_layout.addWidget(btn_all)
        btn_layout.addWidget(btn_none)
        layout.addLayout(btn_layout)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMinimumHeight(200)
        self.sat_list_widget = QWidget()
        self.sat_list_layout = QVBoxLayout(self.sat_list_widget)
        self.sat_list_layout.setContentsMargins(5, 5, 5, 5)
        self.sat_list_layout.setSpacing(3)
        scroll.setWidget(self.sat_list_widget)
        layout.addWidget(scroll)
        
        self.info_label = QLabel("Wähle eine Kategorie aus...")
        self.info_label.setStyleSheet("color: gray; font-style: italic;")
        layout.addWidget(self.info_label)
        
        self.manager.satellites_updated.connect(self._update_satellites)
        self.cat_checks["Space Stations"].setChecked(True)

    def _open_monitor_window(self):
        from ui.widgets.sat_monitor_window import SatMonitorWindow
        if not self.monitor_window:
            self.monitor_window = SatMonitorWindow(self.manager, self)
        self.monitor_window.show()
        self.monitor_window.raise_()
        self.monitor_window.activateWindow()

    def _toggle_globus(self, state):
        setattr(self.globe, "show_satellites", state)
        self.globe.update()

    def _toggle_category(self, category, state):
        if state:
            self.manager.add_category(category)
        else:
            self.manager.remove_category(category)

    def _update_satellites(self, satellites):
        self.all_satellites = satellites
        self._rebuild_satellite_list()
        self._update_globe_display()
        count = len([s for s in satellites if self.satellite_visibility.get(s.name, True)])
        self.info_label.setText(f"✅ {count}/{len(satellites)} Satelliten aktiv")

    def _rebuild_satellite_list(self):
        for i in reversed(range(self.sat_list_layout.count())):
            item = self.sat_list_layout.itemAt(i)
            if item is not None:
                widget = item.widget()
                if widget is not None:
                    widget.setParent(None)
        
        self.sat_checkboxes.clear()
        display_sats = self.all_satellites[:100]
        
        for sat in display_sats:
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(5)
            
            cb = QCheckBox()
            is_visible = self.satellite_visibility.get(sat.name, True)
            cb.setChecked(is_visible)
            cb.stateChanged.connect(lambda state, s=sat: self._toggle_satellite_visibility(s, state))
            row_layout.addWidget(cb)
            self.sat_checkboxes[sat.name] = cb
            
            cat = sat.category if hasattr(sat, 'category') else "Unknown"
            label = ClickableLabel(
                f"🛰️ {sat.name} ({cat})",
                lambda s=sat: self._show_satellite_info(s),
                lambda pos, s=sat: self._show_satellite_context_menu(s, pos),
                row
            )
            label.setToolTip("Links-Klick: Info | Rechts-Klick: Optionen")
            row_layout.addWidget(label, 1)
            
            self.sat_list_layout.addWidget(row)
        
        self.sat_list_layout.addStretch()
        if len(self.all_satellites) > 100:
            info = QLabel(f"... und {len(self.all_satellites)-100} weitere")
            info.setStyleSheet("color: gray; font-size: 10px;")
            self.sat_list_layout.addWidget(info)

    def _toggle_satellite_visibility(self, sat, state):
        self.satellite_visibility[sat.name] = bool(state)
        self._update_globe_display()

    def _show_satellite_info(self, sat):
        print(f"🎯 Name geklickt: {sat.name}")
        cat = sat.category if hasattr(sat, 'category') else "Unknown"
        selected = {'obj': sat, 'cat': cat, 'type': 'satellite'}
        if hasattr(self.globe, 'selected_satellite'):
            self.globe.selected_satellite = selected
            self.globe.update()
            print(f"✅ Satellit selektiert: {sat.name}")
    
    def _show_satellite_context_menu(self, sat, pos):
        """RECHTSKLICK-MENÜ"""
        print(f"🖱️ RECHTSKLICK auf {sat.name}")
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: #1e1e1e;
                color: #ffffff;
                border: 1px solid #0d7377;
                padding: 5px;
            }
            QMenu::item {
                padding: 5px 20px;
            }
            QMenu::item:selected {
                background-color: #0d7377;
            }
        """)
        
        header = QAction(f"🛰️ {sat.name}", self)
        header.setEnabled(False)
        menu.addAction(header)
        menu.addSeparator()
        
        info_action = QAction("📊 Info anzeigen", self)
        info_action.triggered.connect(lambda: self._show_satellite_info(sat))
        menu.addAction(info_action)
        
        orbit_action = QAction("🌀 Orbit-Linie zeichnen", self)
        orbit_action.triggered.connect(lambda: self._toggle_orbit(sat, True))
        menu.addAction(orbit_action)
        
        orbit_hide = QAction("❌ Orbit ausblenden", self)
        orbit_hide.triggered.connect(lambda: self._toggle_orbit(sat, False))
        menu.addAction(orbit_hide)
        
        menu.addSeparator()
        
        vel_action = QAction("➡️ Bewegungsrichtung zeigen", self)
        vel_action.triggered.connect(lambda: self._toggle_velocity(sat, True))
        menu.addAction(vel_action)
        
        trail_action = QAction("✨ Trail anzeigen (Spur)", self)
        trail_action.triggered.connect(lambda: self._toggle_trail(sat, True))
        menu.addAction(trail_action)
        
        menu.addSeparator()
        
        ground_action = QAction("🌐 Bodenspur (Ground Track)", self)
        ground_action.triggered.connect(lambda: self._toggle_ground_track(sat, True))
        menu.addAction(ground_action)
        
        clear_action = QAction("🧹 Alle Visualisierungen löschen", self)
        clear_action.triggered.connect(lambda: self._clear_all_visualizations(sat))
        menu.addAction(clear_action)
        
        menu.exec(pos)
    
    def _toggle_orbit(self, sat, show):
        if hasattr(self.globe, 'toggle_satellite_orbit'):
            self.globe.toggle_satellite_orbit(sat, show)
            print(f"{'✅' if show else '❌'} Orbit für {sat.name}")
    
    def _toggle_velocity(self, sat, show):
        if hasattr(self.globe, 'toggle_satellite_velocity'):
            self.globe.toggle_satellite_velocity(sat, show)
            print(f"{'➡️' if show else '❌'} Velocity für {sat.name}")
    
    def _toggle_trail(self, sat, show):
        if hasattr(self.globe, 'toggle_satellite_trail'):
            self.globe.toggle_satellite_trail(sat, show)
            print(f"{'✨' if show else '❌'} Trail für {sat.name}")
    
    def _toggle_ground_track(self, sat, show):
        if hasattr(self.globe, 'toggle_satellite_ground_track'):
            self.globe.toggle_satellite_ground_track(sat, show)
            print(f"{'🌐' if show else '❌'} Ground Track für {sat.name}")
    
    def _clear_all_visualizations(self, sat):
        self._toggle_orbit(sat, False)
        self._toggle_velocity(sat, False)
        self._toggle_trail(sat, False)
        self._toggle_ground_track(sat, False)
        print(f"🧹 Alle Visualisierungen für {sat.name} gelöscht")

    def _select_all(self):
        for cb in self.sat_checkboxes.values():
            cb.setChecked(True)

    def _deselect_all(self):
        for cb in self.sat_checkboxes.values():
            cb.setChecked(False)

    def _update_globe_display(self):
        visible_sats = [sat for sat in self.all_satellites if self.satellite_visibility.get(sat.name, True)]
        self.globe.set_satellites(visible_sats)

def setup_satellites_on_mainwindow(main_window, api_key=None):
    globe = _find_globe_widget(main_window)
    if not globe: return
    client = SpectatorClient(api_key="TLE_MODE")
    manager = SatelliteManager(client, parent=main_window, update_interval_ms=2000)
    main_window.satellite_manager = manager
    manager.satellites_updated.connect(globe.set_satellites)
    manager.start_auto_update()
    manager.update_positions()  # Sofort ausführen
    tabs = _find_main_tabwidget(main_window)
    if tabs:
        widget = SatelliteControlWidget(globe, manager, tabs)
        tabs.addTab(widget, "🛰️ Satelliten")
        print("✅ Satelliten V3 Ultimate - RECHTSKLICK AKTIVIERT!")
