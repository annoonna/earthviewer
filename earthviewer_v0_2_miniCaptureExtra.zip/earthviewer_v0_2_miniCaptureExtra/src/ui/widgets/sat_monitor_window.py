#!/usr/bin/env python3
"""
Satelliten PRO Monitor - Vollständige Version aus sat_monitor_modular
Angepasst für EarthViewer 2.0 mit PyQt6
"""
import logging
from datetime import datetime
from PyQt6.QtWidgets import (
    QMainWindow, QTabWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QTableWidget, QTableWidgetItem,
    QHeaderView, QLineEdit, QComboBox, QStatusBar, QMessageBox, QSpinBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
import numpy as np

logger = logging.getLogger("SatMonitor")

# Check for pyqtgraph
try:
    import pyqtgraph as pg
    HAVE_PYQTGRAPH = True
except ImportError:
    HAVE_PYQTGRAPH = False
    logger.warning("pyqtgraph nicht verfügbar - Spektrum-Visualisierung eingeschränkt")

# ============================================================================
# SAT PROFILES (aus Original)
# ============================================================================

SAT_PROFILES = {
    "NOAA": {"center_freq": 137.5e6, "sample_rate": 2.4e6},
    "METEOR": {"center_freq": 137.1e6, "sample_rate": 2.4e6},
    "ADS-B": {"center_freq": 1090.0e6, "sample_rate": 2.4e6},
    "ACARS": {"center_freq": 131.5e6, "sample_rate": 2.4e6},
    "AIS": {"center_freq": 162.0e6, "sample_rate": 2.4e6},
    "ISS": {"center_freq": 145.8e6, "sample_rate": 2.4e6},
}

# ============================================================================
# SPECTRUM TAB (Original mit pyqtgraph)
# ============================================================================

class SimulationWorker(QThread):
    spectrum_ready = pyqtSignal(np.ndarray, np.ndarray)
    
    def __init__(self, fft_size=2048, parent=None):
        super().__init__(parent)
        self.fft_size = fft_size
        self._running = False
        self.pattern = "Rauschen"
        self.center_freq = 137.5e6
        self.sample_rate = 2.4e6
    
    def set_pattern(self, pattern):
        self.pattern = pattern
    
    def set_params(self, center_freq, sample_rate, fft_size):
        self.center_freq = center_freq
        self.sample_rate = sample_rate
        self.fft_size = fft_size
    
    def run(self):
        self._running = True
        while self._running:
            freqs = np.linspace(
                self.center_freq - self.sample_rate / 2,
                self.center_freq + self.sample_rate / 2,
                self.fft_size,
            )
            freqs_mhz = freqs / 1e6
            
            # Grundrauschen
            psd = np.random.normal(-90, 2, self.fft_size)
            
            # Pattern
            if self.pattern == "Sinus-Test":
                psd += self._gaussian(freqs_mhz, freqs_mhz.mean(), 0.05, 30)
            elif self.pattern == "Regen":
                for f0 in np.linspace(freqs_mhz.min(), freqs_mhz.max(), 10):
                    psd += self._gaussian(freqs_mhz, f0, 0.01, 8)
            elif self.pattern == "Eis":
                for f0 in np.linspace(freqs_mhz.min(), freqs_mhz.max(), 4):
                    psd += self._gaussian(freqs_mhz, f0, 0.005, 20)
            elif self.pattern == "Rauch/Interferenz":
                psd += np.sin(freqs_mhz * 10) * 5
                psd += np.random.normal(0, 5, self.fft_size)
            elif self.pattern == "Sat-Beacons":
                centers = [
                    freqs_mhz.min() + 0.1 * (freqs_mhz.max() - freqs_mhz.min()),
                    freqs_mhz.min() + 0.3 * (freqs_mhz.max() - freqs_mhz.min()),
                    freqs_mhz.min() + 0.7 * (freqs_mhz.max() - freqs_mhz.min()),
                ]
                for f0 in centers:
                    psd += self._gaussian(freqs_mhz, f0, 0.01, 25)
            
            psd += np.random.normal(0, 0.5, self.fft_size)
            
            self.spectrum_ready.emit(freqs, psd)
            self.msleep(100)
    
    def _gaussian(self, x, f0, sigma, amp):
        return amp * np.exp(-((x - f0) ** 2) / (2 * sigma ** 2))
    
    def stop(self):
        self._running = False
        self.wait()


class SpectrumTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.sim_worker = None
        
        layout = QVBoxLayout(self)
        
        # Controls Row 1
        ctrl1 = QHBoxLayout()
        ctrl1.addWidget(QLabel("Center Freq (Hz):"))
        self.freq_edit = QLineEdit("137000000")
        ctrl1.addWidget(self.freq_edit)
        
        ctrl1.addWidget(QLabel("Sample Rate (Hz):"))
        self.sample_rate_edit = QLineEdit("2400000")
        ctrl1.addWidget(self.sample_rate_edit)
        
        ctrl1.addWidget(QLabel("FFT Size:"))
        self.fft_spin = QSpinBox()
        self.fft_spin.setRange(256, 8192)
        self.fft_spin.setValue(2048)
        self.fft_spin.setSingleStep(256)
        ctrl1.addWidget(self.fft_spin)
        
        ctrl1.addWidget(QLabel("Sat-Profil:"))
        self.profile_combo = QComboBox()
        self.profile_combo.addItem("— kein Sat-Profil —")
        for name in SAT_PROFILES.keys():
            self.profile_combo.addItem(name)
        self.profile_combo.currentTextChanged.connect(self._apply_profile)
        ctrl1.addWidget(self.profile_combo)
        
        layout.addLayout(ctrl1)
        
        # Controls Row 2
        ctrl2 = QHBoxLayout()
        self.status_label = QLabel("Bereit")
        ctrl2.addWidget(self.status_label)
        
        ctrl2.addWidget(QLabel("Quelle:"))
        self.source_combo = QComboBox()
        self.source_combo.addItems(["Simulation", "RTL-SDR"])
        ctrl2.addWidget(self.source_combo)
        
        ctrl2.addWidget(QLabel("Signalprofil (Simulation):"))
        self.pattern_combo = QComboBox()
        self.pattern_combo.addItems([
            "Rauschen", "Sinus-Test", "Regen", "Eis", 
            "Rauch/Interferenz", "Sat-Beacons"
        ])
        ctrl2.addWidget(self.pattern_combo)
        
        ctrl2.addWidget(QLabel("Diagramm:"))
        self.diagram_combo = QComboBox()
        self.diagram_combo.addItems(["Linie", "Linie+Wasserfall"])
        ctrl2.addWidget(self.diagram_combo)
        
        ctrl2.addWidget(QLabel("Farbschema:"))
        self.color_combo = QComboBox()
        self.color_combo.addItems(["Grau", "Heiß", "Blau-Rot", "Viridis-ähnlich"])
        ctrl2.addWidget(self.color_combo)
        
        self.start_btn = QPushButton("Start")
        self.stop_btn = QPushButton("Stop")
        self.start_btn.clicked.connect(self._start_spectrum)
        self.stop_btn.clicked.connect(self._stop_spectrum)
        self.stop_btn.setEnabled(False)
        ctrl2.addWidget(self.start_btn)
        ctrl2.addWidget(self.stop_btn)
        
        layout.addLayout(ctrl2)
        
        # Spectrum Display
        if HAVE_PYQTGRAPH:
            self.plot_widget = pg.PlotWidget()
            self.plot_widget.setBackground('#1e1e1e')
            self.plot_widget.setLabel('left', 'Leistung (dB)')
            self.plot_widget.setLabel('bottom', 'Frequenz (MHz)')
            self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
            self.curve = self.plot_widget.plot(pen=pg.mkPen('#0d7377', width=2))
            layout.addWidget(self.plot_widget)
        else:
            no_pg_label = QLabel(
                "📊 pyqtgraph nicht installiert!\n\n"
                "Für Spektrum-Visualisierung:\n"
                "pip install pyqtgraph --break-system-packages"
            )
            no_pg_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            no_pg_label.setStyleSheet("background: #2a2a2a; color: #888; padding: 40px; font-size: 14px;")
            layout.addWidget(no_pg_label)
        
        # Info
        info_text = (
            "💡 Hinweis: Wähle ein Sat-Profil, um typische Frequenz-, Sample-Rate- und FFT-Werte "
            "für NOAA, METEOR, ADS-B, ACARS, AIS oder ISS zu setzen."
        )
        info_label = QLabel(info_text)
        info_label.setWordWrap(True)
        info_label.setStyleSheet("background: #333; padding: 10px; color: #0d7377;")
        layout.addWidget(info_label)
    
    def _apply_profile(self, profile_name):
        if profile_name in SAT_PROFILES:
            prof = SAT_PROFILES[profile_name]
            self.freq_edit.setText(str(int(prof["center_freq"])))
            self.sample_rate_edit.setText(str(int(prof["sample_rate"])))
            self.status_label.setText(f"Profil geladen: {profile_name}")
    
    def _start_spectrum(self):
        if not HAVE_PYQTGRAPH:
            self.status_label.setText("pyqtgraph fehlt!")
            return
        
        try:
            center_freq = float(self.freq_edit.text())
            sample_rate = float(self.sample_rate_edit.text())
            fft_size = self.fft_spin.value()
        except:
            self.status_label.setText("Ungültige Parameter!")
            return
        
        self.sim_worker = SimulationWorker(fft_size, self)
        self.sim_worker.set_params(center_freq, sample_rate, fft_size)
        self.sim_worker.set_pattern(self.pattern_combo.currentText())
        self.sim_worker.spectrum_ready.connect(self._update_spectrum)
        self.sim_worker.start()
        
        self.status_label.setText("Läuft...")
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
    
    def _stop_spectrum(self):
        if self.sim_worker:
            self.sim_worker.stop()
            self.sim_worker = None
        self.status_label.setText("Gestoppt")
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
    
    def _update_spectrum(self, freqs, psd):
        if HAVE_PYQTGRAPH:
            freqs_mhz = freqs / 1e6
            self.curve.setData(freqs_mhz, psd)


# ============================================================================
# TRACKING TAB (Original)
# ============================================================================

class TrackingTab(QWidget):
    def __init__(self, satellite_manager=None, parent=None):
        super().__init__(parent)
        self.satellite_manager = satellite_manager
        
        layout = QVBoxLayout(self)
        
        # Controls
        ctrl = QHBoxLayout()
        self.status_label = QLabel("TLEs noch nicht geladen.")
        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("Satellitennamen filtern...")
        self.load_btn = QPushButton("TLEs laden/aktualisieren")
        self.start_btn = QPushButton("Tracking starten")
        self.stop_btn = QPushButton("Tracking stoppen")
        
        ctrl.addWidget(self.status_label)
        ctrl.addWidget(self.filter_edit)
        ctrl.addWidget(self.load_btn)
        ctrl.addWidget(self.start_btn)
        ctrl.addWidget(self.stop_btn)
        layout.addLayout(ctrl)
        
        # Table
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels([
            "Name", "Azimut (°)", "Elevation (°)", "Distanz (km)", "Methode", "Zeit (UTC)"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table)
        
        self.load_btn.clicked.connect(self.load_tles)
        self.filter_edit.textChanged.connect(self._fill_table)
        
        self.satellites = []
    
    def load_tles(self):
        if not self.satellite_manager:
            self.status_label.setText("Kein Satellite Manager verfügbar")
            return
        
        try:
            self.satellites = self.satellite_manager.get_positions()
            self.status_label.setText(f"{len(self.satellites)} Satelliten geladen.")
            self._fill_table()
        except Exception as e:
            self.status_label.setText(f"Fehler: {e}")
    
    def _fill_table(self):
        filter_text = self.filter_edit.text().strip().lower()
        filtered = [s for s in self.satellites if not filter_text or filter_text in s.name.lower()]
        
        self.table.setRowCount(len(filtered))
        for row, sat in enumerate(filtered):
            self.table.setItem(row, 0, QTableWidgetItem(sat.name))
            # Simplified - no actual position calculation
            for col in range(1, 6):
                self.table.setItem(row, col, QTableWidgetItem(""))


# ============================================================================
# SPECTATOR API TAB (Original)
# ============================================================================

class SpectatorTab(QWidget):
    def __init__(self, satellite_manager=None, parent=None):
        super().__init__(parent)
        self.satellite_manager = satellite_manager
        
        layout = QVBoxLayout(self)
        
        # Controls Row 1
        ctrl1 = QHBoxLayout()
        ctrl1.addWidget(QLabel("API-Key:"))
        self.api_key_edit = QLineEdit()
        self.api_key_edit.setText("7xwAr95Kkn8YRUKf2ShcxQ")
        ctrl1.addWidget(self.api_key_edit)
        
        ctrl1.addWidget(QLabel("Box (*):"))
        self.box_edit = QLineEdit("2.0")
        ctrl1.addWidget(self.box_edit)
        
        ctrl1.addWidget(QLabel("Overpass Tage -/+:"))
        self.overpass_spin = QSpinBox()
        self.overpass_spin.setValue(0)
        ctrl1.addWidget(self.overpass_spin)
        
        self.days_spin = QSpinBox()
        self.days_spin.setValue(3)
        ctrl1.addWidget(self.days_spin)
        
        layout.addLayout(ctrl1)
        
        # Controls Row 2
        ctrl2 = QHBoxLayout()
        ctrl2.addWidget(QLabel("Imagery Tage zurück:"))
        self.imagery_spin = QSpinBox()
        self.imagery_spin.setRange(1, 30)
        self.imagery_spin.setValue(7)
        ctrl2.addWidget(self.imagery_spin)
        
        ctrl2.addWidget(QLabel("Beobachter: lat=52.0, lon=13.0"))
        ctrl2.addWidget(QLabel("Satelliten:"))
        self.sat_edit = QLineEdit("Sentinel-2A,Sentinel-2B,Landsat-8")
        ctrl2.addWidget(self.sat_edit)
        
        layout.addLayout(ctrl2)
        
        # Buttons
        btn_row = QHBoxLayout()
        self.overpass_btn = QPushButton("Overpasses abrufen")
        self.imagery_btn = QPushButton("Imagery suchen")
        self.preview_btn = QPushButton("Preview anzeigen")
        btn_row.addWidget(self.overpass_btn)
        btn_row.addWidget(self.imagery_btn)
        btn_row.addWidget(self.preview_btn)
        layout.addLayout(btn_row)
        
        # Table
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels([
            "Typ", "Datum/Zeit", "Satellit", "Zusatz", "Detail 1", "Detail 2"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table)
        
        self.overpass_btn.clicked.connect(self._show_placeholder)
        self.imagery_btn.clicked.connect(self._show_placeholder)
        self.preview_btn.clicked.connect(self._show_placeholder)
    
    def _show_placeholder(self):
        QMessageBox.information(
            self,
            "Spectator API",
            "Diese Funktion benötigt spectator.earth API-Zugriff.\n"
            "Derzeit Platzhalter-Implementierung."
        )


# ============================================================================
# MAIN WINDOW
# ============================================================================

class SatMonitorWindow(QMainWindow):
    def __init__(self, satellite_manager=None, parent=None):
        super().__init__(parent)
        self.satellite_manager = satellite_manager
        
        self.setWindowTitle("SatMonitor – Satelliten & Spektrum")
        self.resize(1400, 900)
        
        # Tabs
        self.tabs = QTabWidget()
        self.spectrum_tab = SpectrumTab(self)
        self.tracking_tab = TrackingTab(satellite_manager, self)
        self.spectator_tab = SpectatorTab(satellite_manager, self)
        
        self.tabs.addTab(self.spectrum_tab, "Spektrum")
        self.tabs.addTab(self.tracking_tab, "Sat-Tracking")
        self.tabs.addTab(self.spectator_tab, "Spectator API")
        
        self.setCentralWidget(self.tabs)
        
        # Menu
        menubar = self.menuBar()
        file_menu = menubar.addMenu("Datei")
        exit_action = file_menu.addAction("Beenden")
        exit_action.triggered.connect(self.close)
        
        view_menu = menubar.addMenu("Ansicht")
        help_menu = menubar.addMenu("Hilfe")
        about_action = help_menu.addAction("Über SatMonitor")
        about_action.triggered.connect(self._show_about)
        
        # Status Bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Bereit")
        
        # Dark Theme
        self._apply_theme()
    
    def _apply_theme(self):
        self.setStyleSheet("""
            QMainWindow, QWidget { background-color: #1e1e1e; color: #e0e0e0; }
            QTabWidget::pane { border: 1px solid #444; background: #2a2a2a; }
            QTabBar::tab { background: #333; color: #e0e0e0; padding: 8px 20px; margin: 2px; border: 1px solid #555; }
            QTabBar::tab:selected { background: #0d7377; color: white; }
            QPushButton { background: #0d7377; color: white; border: none; padding: 8px 16px; border-radius: 4px; }
            QPushButton:hover { background: #14a1a8; }
            QPushButton:pressed { background: #0a5c5f; }
            QPushButton:disabled { background: #444; color: #888; }
            QLineEdit, QComboBox, QSpinBox { background: #333; color: #e0e0e0; border: 1px solid #555; padding: 6px; border-radius: 3px; }
            QTableWidget { background: #2a2a2a; color: #e0e0e0; gridline-color: #444; border: 1px solid #555; }
            QHeaderView::section { background: #333; color: #e0e0e0; padding: 6px; border: 1px solid #555; }
            QLabel { color: #e0e0e0; }
            QStatusBar { background: #252525; color: #0d7377; }
            QMenuBar { background: #2a2a2a; color: #e0e0e0; }
            QMenuBar::item:selected { background: #0d7377; }
            QMenu { background: #2a2a2a; color: #e0e0e0; border: 1px solid #555; }
            QMenu::item:selected { background: #0d7377; }
        """)
    
    def _show_about(self):
        QMessageBox.information(
            self,
            "Über SatMonitor",
            "SatMonitor v0.2.0\n\n"
            "Spektrum-Analyse (Simulation & RTL-SDR),\n"
            "lokales Sat-Tracking (SGP4/Skyfield) und\n"
            "Spectator-Earth-API-Integration.\n\n"
            "Integriert in EarthViewer 2.0"
        )


if __name__ == "__main__":
    from PyQt6.QtWidgets import QApplication
    import sys
    app = QApplication(sys.argv)
    window = SatMonitorWindow()
    window.show()
    sys.exit(app.exec())
