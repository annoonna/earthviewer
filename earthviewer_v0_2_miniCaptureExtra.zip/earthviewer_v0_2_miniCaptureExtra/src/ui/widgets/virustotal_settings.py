#!/usr/bin/env python3
from PyQt6 import QtWidgets, QtCore
from network.virustotal_analyzer import get_virustotal_analyzer


class VirusTotalSettingsWidget(QtWidgets.QWidget):
    """
    GUI für VirusTotal-Konfiguration:
    - API-Key Eingabe (mit Show/Hide)
    - Test-Button
    - Speichern-Button (validiert + speichert)
    - Auto-Scan-Checkbox
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.vt = get_virustotal_analyzer()
        self._key_visible = False
        self._setup_ui()
        self._load_initial_state()

    # ------------------------------------------------------------------ #
    # UI
    # ------------------------------------------------------------------ #
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        group = QtWidgets.QGroupBox("🔑 VirusTotal API Configuration")
        group.setStyleSheet(
            "QGroupBox { color: white; font-weight: bold; padding: 10px; }"
        )
        gl = QtWidgets.QVBoxLayout()
        gl.setSpacing(6)

        # Zeile: "API Key"
        api_label = QtWidgets.QLabel("API Key:")
        api_label.setStyleSheet("color: #cccccc;")

        self.api_input = QtWidgets.QLineEdit()
        self.api_input.setPlaceholderText("VirusTotal API Key...")
        self.api_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.api_input.setMinimumWidth(300)
        self.api_input.setStyleSheet(
            "QLineEdit { background: #202020; color: #ffffff; "
            "border: 1px solid #444444; border-radius: 4px; padding: 4px; }"
        )

        self.toggle_btn = QtWidgets.QToolButton()
        self.toggle_btn.setText("👁")
        self.toggle_btn.setToolTip("API-Key anzeigen/ausblenden")
        self.toggle_btn.setCheckable(True)
        self.toggle_btn.clicked.connect(self._toggle_visibility)

        self.test_btn = QtWidgets.QPushButton("Test")
        self.test_btn.setFixedWidth(70)
        self.test_btn.clicked.connect(self._test_key)

        self.save_btn = QtWidgets.QPushButton("Speichern")
        self.save_btn.setFixedWidth(90)
        self.save_btn.clicked.connect(self._save_key)

        api_row = QtWidgets.QHBoxLayout()
        api_row.addWidget(api_label)
        api_row.addWidget(self.api_input, 1)
        api_row.addWidget(self.toggle_btn)
        api_row.addWidget(self.test_btn)
        api_row.addWidget(self.save_btn)

        gl.addLayout(api_row)

        # Auto-Scan Checkbox
        self.auto_scan_cb = QtWidgets.QCheckBox("Automatisch alle neuen IPs scannen")
        self.auto_scan_cb.setStyleSheet("color: #cccccc;")
        self.auto_scan_cb.stateChanged.connect(self._on_auto_scan_changed)
        gl.addWidget(self.auto_scan_cb)

        # Status-Label
        self.status_label = QtWidgets.QLabel("Status: Kein API-Key konfiguriert")
        self.status_label.setStyleSheet("color: #f44336; padding: 4px;")
        gl.addWidget(self.status_label)

        group.setLayout(gl)
        layout.addWidget(group)

        # Platzhalter zum Strecken
        layout.addStretch(1)

    # ------------------------------------------------------------------ #
    # Initialzustand laden
    # ------------------------------------------------------------------ #
    def _load_initial_state(self):
        # API-Key aus Config anzeigen (falls vorhanden)
        key = self.vt.config.api_key or ""
        if key:
            self.api_input.setText(key)
            self._set_status("API-Key geladen.", ok=True)
        else:
            self._set_status("Kein API-Key konfiguriert.", ok=False)

        # Auto-Scan Checkbox
        self.auto_scan_cb.setChecked(bool(getattr(self.vt.config, "auto_scan_enabled", False)))

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    def _set_status(self, text: str, ok: bool | None = None):
        """Status-Label setzen, Farbe je nach ok-Flag."""
        if ok is True:
            color = "#4caf50"  # grün
        elif ok is False:
            color = "#f44336"  # rot
        else:
            color = "#ffeb3b"  # gelb
        self.status_label.setText(f"Status: {text}")
        self.status_label.setStyleSheet(f"color: {color}; padding: 4px;")

    # ------------------------------------------------------------------ #
    # Slots
    # ------------------------------------------------------------------ #
    def _toggle_visibility(self):
        """API-Key ein-/ausblenden."""
        self._key_visible = not self._key_visible
        if self._key_visible:
            self.api_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Normal)
        else:
            self.api_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)

    def _test_key(self):
        """API-Key testen, ohne zwangsweise zu speichern."""
        key = self.api_input.text().strip()
        if not key:
            self._set_status("Bitte zuerst einen API-Key eingeben.", ok=False)
            return

        # alten Key merken
        old_key = self.vt.config.api_key
        self.vt.config.api_key = key

        try:
            # interne Testfunktion benutzen
            if self.vt._test_api_key():
                self._set_status("API-Key ist gültig (Test OK).", ok=True)
            else:
                self._set_status("API-Key ist ungültig (Test fehlgeschlagen).", ok=False)
        except Exception as e:
            self._set_status(f"Fehler beim Test: {e}", ok=False)
        finally:
            # alten Zustand wiederherstellen (Test speichert NICHT)
            self.vt.config.api_key = old_key

    def _save_key(self):
        """API-Key validieren und speichern."""
        key = self.api_input.text().strip()
        if not key:
            self._set_status("Leerer API-Key kann nicht gespeichert werden.", ok=False)
            return

        # set_api_key validiert + speichert in settings.json
        if self.vt.set_api_key(key):
            self._set_status("API-Key gespeichert und validiert!", ok=True)
        else:
            self._set_status("Speichern fehlgeschlagen – API-Key ungültig.", ok=False)

    def _on_auto_scan_changed(self, state: int):
        """Auto-Scan-Option speichern."""
        enabled = state == QtCore.Qt.CheckState.Checked
        try:
            self.vt.enable_auto_scan(enabled)
            if enabled:
                self._set_status("Auto-Scan aktiviert.", ok=True)
            else:
                self._set_status("Auto-Scan deaktiviert.", ok=None)
        except Exception as e:
            self._set_status(f"Fehler beim Speichern der Auto-Scan-Einstellung: {e}", ok=False)

