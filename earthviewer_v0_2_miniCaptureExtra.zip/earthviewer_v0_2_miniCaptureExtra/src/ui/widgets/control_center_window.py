#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WLAN Control Center – Professional Edition
- WiFi Monitor
- Live Netzwerk-Statistiken
- VirusTotal- & WPA-Einstellungen
- Buttons für Netzwerk-Clients & Live WiFi-Capture
"""

from PyQt6 import QtWidgets, QtCore, QtGui

from ui.widgets.wifi_monitor_panel import WifiMonitorPanel
from ui.widgets.wifi_capture_window import WifiCaptureWindow
from ui.widgets.network_stats_widget import NetworkStatsWidget
from ui.widgets.virustotal_settings import VirusTotalSettingsWidget

from network.arp_scanner import get_scanner
from network.wifi_capture import get_wifi_capture
from network.virustotal_analyzer import get_virustotal_analyzer


# --------------------------------------------------------------------------- #
# Netzwerk-Clients-Fenster (lokale Geräte + VirusTotal-Spalte)
# --------------------------------------------------------------------------- #
class NetworkClientsWindow(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.scanner = get_scanner()
        self.vt_analyzer = get_virustotal_analyzer()
        self.setWindowTitle("🖧 Netzwerk-Clients")
        self.resize(900, 600)

        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)

        # Header
        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("🖧 Lokale Netzwerk-Geräte")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")
        header.addWidget(title)
        header.addStretch()

        self.scan_btn = QtWidgets.QPushButton("🔍 Netzwerk scannen")
        self.scan_btn.setStyleSheet(
            "padding: 8px 16px; background: #0d7377; color: white;"
            "border: none; border-radius: 4px;"
        )
        header.addWidget(self.scan_btn)
        layout.addLayout(header)

        self.progress = QtWidgets.QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

        # Tabelle
        self.table = QtWidgets.QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels(
            [
                "IP-Adresse",
                "MAC-Adresse",
                "Hostname",
                "Hersteller",
                "Traffic RX",
                "Traffic TX",
                "Signal",
                "VirusTotal",
            ]
        )
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(True)
        layout.addWidget(self.table)

        self.status = QtWidgets.QLabel("Bereit zum Scannen.")
        self.status.setStyleSheet("color: #888; font-size: 11px;")
        layout.addWidget(self.status)

    def _connect_signals(self):
        self.scan_btn.clicked.connect(self._start_scan)
        self.scanner.devices_found.connect(self._on_devices_found)
        self.scanner.scan_progress.connect(self._on_scan_progress)
        self.scanner.scan_finished.connect(self._on_scan_finished)
        self.table.cellDoubleClicked.connect(self._on_device_clicked)

        # VirusTotal-Signale
        if self.vt_analyzer is not None:
            self.vt_analyzer.scan_result.connect(self._on_virustotal_result)
            self.vt_analyzer.scan_error.connect(self._on_virustotal_error)

    # ---------------------- Scan-Steuerung ---------------------------------
    def _start_scan(self):
        self.table.setRowCount(0)
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.status.setText("Scanne Netzwerk …")
        self.scan_btn.setEnabled(False)
        self.scanner.start_scan()

    def _on_scan_progress(self, value: int):
        self.progress.setValue(value)

    def _on_scan_finished(self):
        self.progress.setVisible(False)
        self.scan_btn.setEnabled(True)

    # ---------------------- Geräte-Handling --------------------------------
    def _on_devices_found(self, devices):
        self.status.setText(f"{len(devices)} Geräte gefunden")

        for device in devices:
            row = self.table.rowCount()
            self.table.insertRow(row)

            # IP, MAC, Hostname, Vendor
            self.table.setItem(row, 0, QtWidgets.QTableWidgetItem(device.ip))

            mac_item = QtWidgets.QTableWidgetItem(device.mac)
            mac_item.setForeground(QtGui.QColor("#00acc1"))
            self.table.setItem(row, 1, mac_item)

            self.table.setItem(row, 2, QtWidgets.QTableWidgetItem(device.hostname))

            vendor_item = QtWidgets.QTableWidgetItem(device.vendor)
            if device.vendor and device.vendor != "Unknown":
                vendor_item.setForeground(QtGui.QColor("#4caf50"))
            self.table.setItem(row, 3, vendor_item)

            # Traffic RX/TX
            rx_text = self._format_bytes(device.traffic_rx)
            tx_text = self._format_bytes(device.traffic_tx)
            self.table.setItem(row, 4, QtWidgets.QTableWidgetItem(rx_text))
            self.table.setItem(row, 5, QtWidgets.QTableWidgetItem(tx_text))

            # Signalstärke
            if getattr(device, "signal_strength", None) is not None and device.signal_strength > -100:
                signal_text = f"{device.signal_strength} dBm"
            else:
                signal_text = "N/A"
            self.table.setItem(row, 6, QtWidgets.QTableWidgetItem(signal_text))

            # VirusTotal-Button
            vt_btn = QtWidgets.QPushButton("🔍 Scan")
            vt_btn.clicked.connect(
                lambda checked=False, ip=device.ip: self._scan_virustotal(ip)
            )
            self.table.setCellWidget(row, 7, vt_btn)

            # Auto-Scan, wenn konfiguriert
            if (
                self.vt_analyzer is not None
                and self.vt_analyzer.config.auto_scan_enabled
            ):
                self._scan_virustotal(device.ip, auto=True)

    def _on_device_clicked(self, row, col):
        ip = self.table.item(row, 0).text()
        mac = self.table.item(row, 1).text()
        hostname = self.table.item(row, 2).text()
        vendor = self.table.item(row, 3).text()
        details = f"IP: {ip}\nMAC: {mac}\nHostname: {hostname}\nHersteller: {vendor}"
        QtWidgets.QMessageBox.information(self, "Geräte-Details", details)

    # ---------------------- VirusTotal-Integration -------------------------
    def _scan_virustotal(self, ip: str, auto: bool = False):
        if self.vt_analyzer is None:
            QtWidgets.QMessageBox.warning(
                self,
                "VirusTotal",
                "VirusTotal-Analyzer nicht verfügbar.",
            )
            return

        if not self.vt_analyzer.config.api_key:
            if not auto:
                QtWidgets.QMessageBox.warning(
                    self,
                    "VirusTotal",
                    "Bitte API-Key in den WLAN-Einstellungen konfigurieren!",
                )
            return

        row = self._find_row_by_ip(ip)
        if row is not None:
            btn = self.table.cellWidget(row, 7)
            if isinstance(btn, QtWidgets.QPushButton):
                btn.setText("⏳ Scan …")
                btn.setEnabled(False)

        self.vt_analyzer.scan_ip(ip)

        if not auto:
            QtWidgets.QMessageBox.information(
                self,
                "VirusTotal",
                f"Scan für {ip} gestartet.\nErgebnis erscheint in Kürze.",
            )

    def _find_row_by_ip(self, ip: str):
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item and item.text() == ip:
                return row
        return None

    def _on_virustotal_result(self, resource: str, data: dict):
        row = self._find_row_by_ip(resource)
        if row is None:
            return

        btn = self.table.cellWidget(row, 7)
        if not isinstance(btn, QtWidgets.QPushButton):
            return

        summary = self.vt_analyzer.format_summary(data)
        tooltip = self.vt_analyzer.format_tooltip(data)
        level = self.vt_analyzer.get_threat_level(data)

        btn.setText(summary)
        btn.setEnabled(True)
        btn.setToolTip(tooltip)

        if level == "clean":
            btn.setStyleSheet("background: #2e7d32; color: white;")
        elif level == "suspicious":
            btn.setStyleSheet("background: #f9a825; color: black;")
        elif level == "malicious":
            btn.setStyleSheet("background: #c62828; color: white;")
        else:
            btn.setStyleSheet("")

    def _on_virustotal_error(self, resource: str, message: str):
        row = self._find_row_by_ip(resource)
        if row is None:
            return

        btn = self.table.cellWidget(row, 7)
        if isinstance(btn, QtWidgets.QPushButton):
            btn.setText("Fehler")
            btn.setEnabled(True)
            btn.setToolTip(message)
            btn.setStyleSheet("background: #c62828; color: white;")

    # ---------------------- Utils -----------------------------------------
    def _format_bytes(self, num_bytes: int) -> str:
        try:
            num = float(num_bytes)
        except Exception:
            return "0 B"

        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if num < 1024.0:
                return f"{num:.1f} {unit}"
            num /= 1024.0
        return f"{num:.1f} PB"


# --------------------------------------------------------------------------- #
# Hauptfenster: WLAN Control Center – Tabs + Buttons
# --------------------------------------------------------------------------- #
class ControlCenterWindow(QtWidgets.QDialog):
    def __init__(self, network_monitor, connection_tracker=None, parent=None):
        super().__init__(parent)
        self.monitor = network_monitor
        self.connection_tracker = connection_tracker

        self.capture_window: WifiCaptureWindow | None = None
        self.clients_window: NetworkClientsWindow | None = None
        self.wifi_capture = get_wifi_capture()

        self.setWindowTitle("WLAN Control Center – Erweiterte Ansicht")
        self.resize(1100, 700)

        self._setup_ui()

    # ---------------------- UI-Aufbau --------------------------------------
    def _setup_ui(self):
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(8)

        # Titelzeile
        header_layout = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("WLAN Control Center – Professional Edition")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: white;")
        header_layout.addWidget(title)

        header_layout.addStretch()

        self.status_label = QtWidgets.QLabel("Status: Bereit")
        self.status_label.setStyleSheet("color: #4caf50; font-weight: bold;")
        header_layout.addWidget(self.status_label)

        main_layout.addLayout(header_layout)

        # Tab-Leiste
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setTabPosition(QtWidgets.QTabWidget.TabPosition.North)
        self.tabs.setDocumentMode(True)
        self.tabs.setStyleSheet(
            """
            QTabWidget::pane {
                border: 1px solid #333;
                top: -0.5em;
            }
            QTabBar::tab {
                background: #222;
                color: #ccc;
                padding: 8px 16px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background: #0d7377;
                color: white;
            }
            """
        )
        main_layout.addWidget(self.tabs, 1)

        # --- Tab 1: WiFi Monitor ------------------------------------------------
        wifi_tab = QtWidgets.QWidget()
        wifi_layout = QtWidgets.QVBoxLayout(wifi_tab)
        self.monitor_panel = WifiMonitorPanel()
        wifi_layout.addWidget(self.monitor_panel)
        self.tabs.addTab(wifi_tab, "📡 WiFi Monitor")

        # --- Tab 2: Live Statistiken -------------------------------------------
        stats_tab = QtWidgets.QWidget()
        stats_layout = QtWidgets.QVBoxLayout(stats_tab)

        self.stats_widget = NetworkStatsWidget(self.monitor, parent=self)
        stats_layout.addWidget(self.stats_widget)

        info_label = QtWidgets.QLabel(
            "Hier siehst du Live-Statistiken zu Netzwerktraffic, "
            "Prozessen und Protokollen."
        )
        info_label.setStyleSheet("color: #888; font-size: 11px; padding: 4px;")
        stats_layout.addWidget(info_label)

        self.tabs.addTab(stats_tab, "📊 Live Statistiken")

        # --- Tab 3: Einstellungen (VirusTotal + WPA + Aktionen) ----------------
        settings_tab = QtWidgets.QWidget()
        settings_layout = QtWidgets.QVBoxLayout(settings_tab)

        # VirusTotal + WPA Settings
        self.vt_settings = VirusTotalSettingsWidget(parent=self)
        settings_layout.addWidget(self.vt_settings)

        # Abstand
        settings_layout.addSpacing(10)

        # Untere Aktionsbuttons
        actions_group = QtWidgets.QGroupBox("Aktionen")
        actions_group.setStyleSheet(
            "QGroupBox { color: white; font-weight: bold; }"
        )
        actions_layout = QtWidgets.QHBoxLayout(actions_group)

        self.clients_btn = QtWidgets.QPushButton("🖧 Netzwerk-Clients scannen")
        self.clients_btn.setStyleSheet(
            "padding: 10px 20px; background: #0d7377; color: white; "
            "border: none; border-radius: 4px; font-weight: bold;"
        )
        self.clients_btn.clicked.connect(self._open_clients_window)
        actions_layout.addWidget(self.clients_btn)

        self.capture_btn = QtWidgets.QPushButton("📡 Live WiFi-Capture starten")
        self.capture_btn.setStyleSheet(
            "padding: 10px 20px; background: #1976d2; color: white; "
            "border: none; border-radius: 4px; font-weight: bold;"
        )
        self.capture_btn.clicked.connect(self._open_capture_window)
        actions_layout.addWidget(self.capture_btn)

        actions_layout.addStretch()
        settings_layout.addWidget(actions_group)

        settings_layout.addStretch()
        self.tabs.addTab(settings_tab, "⚙️ Einstellungen")

        # Fußzeile / Hinweis
        footer = QtWidgets.QLabel(
            "Tipp: Du kannst das große Control Center auf einen zweiten Monitor legen "
            "und EarthViewer weiter normal bedienen."
        )
        footer.setStyleSheet("color: #777; font-size: 10px;")
        main_layout.addWidget(footer)

    # ---------------------- Aktionen ---------------------------------------
    def _open_capture_window(self):
        if self.capture_window is None:
            self.capture_window = WifiCaptureWindow(self.wifi_capture, parent=self)
        self.capture_window.show()
        self.capture_window.raise_()
        self.capture_window.activateWindow()

    def _open_clients_window(self):
        if self.clients_window is None:
            self.clients_window = NetworkClientsWindow(parent=self)
        self.clients_window.show()
        self.clients_window.raise_()
        self.clients_window.activateWindow()

