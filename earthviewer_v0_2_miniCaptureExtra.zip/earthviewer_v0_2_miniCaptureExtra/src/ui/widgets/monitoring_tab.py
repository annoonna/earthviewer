#!/usr/bin/env python3
"""Monitoring Tab"""
from PyQt6 import QtWidgets
from ui.widgets.network_stats_widget import NetworkStatsWidget

class MonitoringTab(QtWidgets.QWidget):
    def __init__(self, network_monitor, parent=None):
        super().__init__(parent)
        self.monitor = network_monitor
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(10)
        
        # Header
        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("📊 Live Network Monitoring")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: white;")
        header.addWidget(title)
        large_btn = QtWidgets.QPushButton("🔍 Große Ansicht öffnen")
        large_btn.setStyleSheet("padding: 10px 20px; background: #0d7377; color: white; border: none; border-radius: 6px; font-weight: bold;")
        large_btn.clicked.connect(self._open_large)
        header.addWidget(large_btn)
        header.addStretch()
        layout.addLayout(header)
        
        info = QtWidgets.QLabel("Live-Traffic von Apps, Hosts, Protokollen und Ländern")
        info.setStyleSheet("color: #888; font-size: 11px;")
        layout.addWidget(info)
        
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.HLine)
        line.setStyleSheet("background: #3a3a3a;")
        layout.addWidget(line)
        
        self.stats = NetworkStatsWidget(self.monitor, compact=True)
        layout.addWidget(self.stats, 1)
        
        # Buttons
        btns = QtWidgets.QHBoxLayout()
        self.pause_btn = QtWidgets.QPushButton("⏸️ Pausieren")
        self.pause_btn.setStyleSheet("padding: 8px; background: #3a3a3a; color: white; border: none; border-radius: 4px;")
        self.pause_btn.clicked.connect(self._toggle)
        btns.addWidget(self.pause_btn)
        btns.addStretch()
        layout.addLayout(btns)
    
    def _open_large(self):
        from ui.widgets.network_monitor_window import NetworkMonitorWindow
        if not hasattr(self, 'large_window') or not self.large_window.isVisible():
            self.large_window = NetworkMonitorWindow(self.monitor, self)
            self.large_window.show()
        else:
            self.large_window.raise_()
    
    def _toggle(self):
        if self.monitor.running:
            self.monitor.stop()
            self.pause_btn.setText("▶️ Fortsetzen")
        else:
            self.monitor.start()
            self.pause_btn.setText("⏸️ Pausieren")
