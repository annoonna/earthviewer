#!/usr/bin/env python3
from PyQt6 import QtWidgets, QtCore

class LiveConnectionsWindow(QtWidgets.QDialog):
    def __init__(self, connection_tracker, parent=None):
        super().__init__(parent)
        self.connection_tracker = connection_tracker
        self.setWindowTitle("🔴 Live Netzwerk Verbindungen - Große Ansicht")
        self.resize(1200, 700)
        self.setStyleSheet("background-color: #1e1e1e; color: white;")
        self._setup_ui()
        
        self.connection_tracker.connections_updated.connect(self._on_connections_updated)
        self._on_connections_updated(self.connection_tracker.get_active_connections())

    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        header_label = QtWidgets.QLabel("Alle aktiven Verbindungen (Live-Update)")
        header_label.setStyleSheet("font-size: 18px; font-weight: bold; padding: 10px;")
        layout.addWidget(header_label)
        
        self.connection_list = QtWidgets.QTreeWidget()
        self.connection_list.setHeaderLabels(["App", "Remote IP", "Ort", "Richtung", "Protokoll"])
        self.connection_list.setStyleSheet("QTreeWidget { font-size: 14px; } QHeaderView::section { padding: 8px; }")
        layout.addWidget(self.connection_list)
        
        close_btn = QtWidgets.QPushButton("Schließen")
        close_btn.clicked.connect(self.close)
        layout.addWidget(close_btn)

    def _on_connections_updated(self, connections):
        self.connection_list.clear()
        for conn in connections:
            direction = "📥 IN" if conn.is_incoming else "📤 OUT"
            item = QtWidgets.QTreeWidgetItem([conn.app_name, conn.remote_ip, f"{conn.city}, {conn.country}", direction, conn.protocol])
            self.connection_list.addTopLevelItem(item)

    def closeEvent(self, event):
        try:
            self.connection_tracker.connections_updated.disconnect(self._on_connections_updated)
        except TypeError:
            pass
        super().closeEvent(event)
