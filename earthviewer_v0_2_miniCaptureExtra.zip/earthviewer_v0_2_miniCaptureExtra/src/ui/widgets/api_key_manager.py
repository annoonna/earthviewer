#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API Key Manager Widget - Benutzerfreundliche Verwaltung
Mit Show/Hide, Test, Save und Auto-Load
"""

from PyQt6 import QtWidgets, QtCore, QtGui
import json
import os
import requests

class APIKeyManagerWidget(QtWidgets.QGroupBox):
    """Komplettes API-Key-Management mit GUI"""
    
    def __init__(self, title="VirusTotal API Configuration", parent=None):
        super().__init__(title, parent)
        self.settings_file = "settings.json"
        self.api_key = ""
        self._setup_ui()
        self._load_existing_key()
        
    def _setup_ui(self):
        """Erstellt die UI-Komponenten"""
        self.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 2px solid #444;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
        """)
        
        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(10)
        
        # Info Label
        info = QtWidgets.QLabel(
            "🔑 VirusTotal API Key für Malware-Scans\n"
            "Kostenlos registrieren auf virustotal.com"
        )
        info.setStyleSheet("color: #aaa; font-weight: normal;")
        layout.addWidget(info)
        
        # API Key Input Zeile
        input_layout = QtWidgets.QHBoxLayout()
        
        # Input Field
        self.key_input = QtWidgets.QLineEdit()
        self.key_input.setPlaceholderText("API Key hier eingeben oder einfügen...")
        self.key_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.key_input.setStyleSheet("""
            QLineEdit {
                padding: 8px;
                background: #2a2a2a;
                border: 1px solid #555;
                border-radius: 4px;
                color: white;
                font-family: monospace;
            }
            QLineEdit:focus {
                border: 1px solid #0d7377;
            }
        """)
        input_layout.addWidget(self.key_input, 1)
        
        # Show/Hide Button
        self.toggle_btn = QtWidgets.QPushButton("👁")
        self.toggle_btn.setFixedSize(40, 40)
        self.toggle_btn.setCheckable(True)
        self.toggle_btn.setStyleSheet("""
            QPushButton {
                background: #3a3a3a;
                border: 1px solid #555;
                border-radius: 4px;
                font-size: 16px;
            }
            QPushButton:hover {
                background: #4a4a4a;
            }
            QPushButton:checked {
                background: #0d7377;
            }
        """)
        self.toggle_btn.toggled.connect(self._toggle_visibility)
        self.toggle_btn.setToolTip("API Key anzeigen/verstecken")
        input_layout.addWidget(self.toggle_btn)
        
        layout.addLayout(input_layout)
        
        # Button Zeile
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.setSpacing(5)
        
        # Test Button
        self.test_btn = QtWidgets.QPushButton("🧪 Testen")
        self.test_btn.setStyleSheet(self._button_style("#1976d2"))
        self.test_btn.clicked.connect(self._test_key)
        self.test_btn.setToolTip("API Key bei VirusTotal testen")
        button_layout.addWidget(self.test_btn)
        
        # Save Button
        self.save_btn = QtWidgets.QPushButton("💾 Speichern")
        self.save_btn.setStyleSheet(self._button_style("#388e3c"))
        self.save_btn.clicked.connect(self._save_key)
        self.save_btn.setToolTip("API Key dauerhaft speichern")
        button_layout.addWidget(self.save_btn)
        
        # Clear Button
        self.clear_btn = QtWidgets.QPushButton("🗑️ Löschen")
        self.clear_btn.setStyleSheet(self._button_style("#d32f2f"))
        self.clear_btn.clicked.connect(self._clear_key)
        self.clear_btn.setToolTip("API Key entfernen")
        button_layout.addWidget(self.clear_btn)
        
        # Get Key Button
        self.get_key_btn = QtWidgets.QPushButton("🌐 Key holen")
        self.get_key_btn.setStyleSheet(self._button_style("#f57c00"))
        self.get_key_btn.clicked.connect(self._open_virustotal)
        self.get_key_btn.setToolTip("VirusTotal Website öffnen")
        button_layout.addWidget(self.get_key_btn)
        
        button_layout.addStretch()
        layout.addLayout(button_layout)
        
        # Status Label
        self.status_label = QtWidgets.QLabel("Status: Kein API Key konfiguriert")
        self.status_label.setStyleSheet("""
            QLabel {
                padding: 8px;
                background: #2a2a2a;
                border-radius: 4px;
                font-weight: normal;
            }
        """)
        layout.addWidget(self.status_label)
        
        # Advanced Options
        advanced_group = QtWidgets.QGroupBox("Erweiterte Optionen")
        advanced_group.setStyleSheet("font-weight: normal;")
        advanced_layout = QtWidgets.QVBoxLayout(advanced_group)
        
        self.auto_scan_cb = QtWidgets.QCheckBox("Automatisch alle neuen IPs scannen")
        self.auto_scan_cb.setStyleSheet("color: #ccc;")
        advanced_layout.addWidget(self.auto_scan_cb)
        
        self.cache_cb = QtWidgets.QCheckBox("Scan-Ergebnisse cachen (1 Stunde)")
        self.cache_cb.setChecked(True)
        self.cache_cb.setStyleSheet("color: #ccc;")
        advanced_layout.addWidget(self.cache_cb)
        
        layout.addWidget(advanced_group)
        
        # Keyboard Shortcuts
        self.key_input.returnPressed.connect(self._test_key)
        
    def _button_style(self, color):
        """Generiert Button-Style"""
        return f"""
            QPushButton {{
                padding: 8px 16px;
                background: {color};
                color: white;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background: {color}dd;
            }}
            QPushButton:pressed {{
                background: {color}aa;
            }}
        """
        
    def _toggle_visibility(self, checked):
        """Zeigt/Versteckt den API Key"""
        if checked:
            self.key_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Normal)
            self.toggle_btn.setText("🙈")
            self.toggle_btn.setToolTip("API Key verstecken")
        else:
            self.key_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
            self.toggle_btn.setText("👁")
            self.toggle_btn.setToolTip("API Key anzeigen")
            
    def _test_key(self):
        """Testet den API Key bei VirusTotal"""
        key = self.key_input.text().strip()
        if not key:
            self._set_status("⚠️ Bitte API Key eingeben", "#ff9800")
            return
            
        self._set_status("🔄 Teste API Key...", "#2196f3")
        self.test_btn.setEnabled(False)
        
        # Test in Thread ausführen
        self.test_thread = TestThread(key)
        self.test_thread.result.connect(self._on_test_result)
        self.test_thread.start()
        
    def _on_test_result(self, success, message):
        """Verarbeitet Test-Ergebnis"""
        self.test_btn.setEnabled(True)
        if success:
            self._set_status(f"✅ {message}", "#4caf50")
            self.save_btn.setStyleSheet(self._button_style("#4caf50"))
        else:
            self._set_status(f"❌ {message}", "#f44336")
            
    def _save_key(self):
        """Speichert den API Key"""
        key = self.key_input.text().strip()
        if not key:
            self._set_status("⚠️ Kein Key zum Speichern", "#ff9800")
            return
            
        try:
            # Settings laden oder erstellen
            settings = {}
            if os.path.exists(self.settings_file):
                with open(self.settings_file, 'r') as f:
                    settings = json.load(f)
                    
            # VirusTotal Config updaten
            settings['virustotal'] = {
                'api_key': key,
                'auto_scan': self.auto_scan_cb.isChecked(),
                'cache_enabled': self.cache_cb.isChecked()
            }
            
            # Speichern
            with open(self.settings_file, 'w') as f:
                json.dump(settings, f, indent=2)
                
            self.api_key = key
            self._set_status("✅ API Key gespeichert!", "#4caf50")
            
            # Optional: Signal aussenden dass Key gespeichert wurde
            if hasattr(self, 'key_saved'):
                self.key_saved.emit(key)
                
        except Exception as e:
            self._set_status(f"❌ Fehler beim Speichern: {str(e)}", "#f44336")
            
    def _clear_key(self):
        """Löscht den API Key"""
        reply = QtWidgets.QMessageBox.question(
            self, 
            "API Key löschen",
            "Wirklich den API Key löschen?",
            QtWidgets.QMessageBox.StandardButton.Yes | 
            QtWidgets.QMessageBox.StandardButton.No
        )
        
        if reply == QtWidgets.QMessageBox.StandardButton.Yes:
            self.key_input.clear()
            self.api_key = ""
            
            # Aus Settings entfernen
            try:
                if os.path.exists(self.settings_file):
                    with open(self.settings_file, 'r') as f:
                        settings = json.load(f)
                    if 'virustotal' in settings:
                        settings['virustotal']['api_key'] = ""
                    with open(self.settings_file, 'w') as f:
                        json.dump(settings, f, indent=2)
            except:
                pass
                
            self._set_status("🗑️ API Key gelöscht", "#757575")
            
    def _open_virustotal(self):
        """Öffnet VirusTotal Website"""
        import webbrowser
        webbrowser.open("https://www.virustotal.com/gui/join-us")
        self._set_status("🌐 VirusTotal Website geöffnet", "#2196f3")
        
    def _load_existing_key(self):
        """Lädt existierenden API Key aus Settings"""
        try:
            if os.path.exists(self.settings_file):
                with open(self.settings_file, 'r') as f:
                    settings = json.load(f)
                    vt_config = settings.get('virustotal', {})
                    key = vt_config.get('api_key', '')
                    
                    if key:
                        self.key_input.setText(key)
                        self.api_key = key
                        self._set_status("✅ API Key geladen", "#4caf50")
                        
                    self.auto_scan_cb.setChecked(vt_config.get('auto_scan', False))
                    self.cache_cb.setChecked(vt_config.get('cache_enabled', True))
        except:
            pass
            
    def _set_status(self, text, color="#757575"):
        """Setzt Status-Text mit Farbe"""
        self.status_label.setText(text)
        self.status_label.setStyleSheet(f"""
            QLabel {{
                padding: 8px;
                background: #2a2a2a;
                border-radius: 4px;
                color: {color};
                font-weight: normal;
            }}
        """)
        
    def get_api_key(self):
        """Gibt den aktuellen API Key zurück"""
        return self.key_input.text().strip()


class TestThread(QtCore.QThread):
    """Thread für API-Key-Test"""
    result = QtCore.pyqtSignal(bool, str)
    
    def __init__(self, api_key):
        super().__init__()
        self.api_key = api_key
        
    def run(self):
        """Führt den Test aus"""
        try:
            headers = {"x-apikey": self.api_key}
            response = requests.get(
                "https://www.virustotal.com/api/v3/users/current",
                headers=headers,
                timeout=5
            )
            
            if response.status_code == 200:
                data = response.json()
                user_data = data.get('data', {}).get('attributes', {})
                email = user_data.get('email', 'Unknown')
                self.result.emit(True, f"API Key gültig! (User: {email})")
            elif response.status_code == 401:
                self.result.emit(False, "API Key ungültig!")
            else:
                self.result.emit(False, f"Fehler: HTTP {response.status_code}")
                
        except requests.exceptions.Timeout:
            self.result.emit(False, "Timeout - Keine Verbindung")
        except Exception as e:
            self.result.emit(False, f"Fehler: {str(e)}")


# Für direkten Import
if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    
    window = QtWidgets.QWidget()
    window.setWindowTitle("API Key Manager Test")
    window.setStyleSheet("background: #1a1a1a;")
    
    layout = QtWidgets.QVBoxLayout(window)
    manager = APIKeyManagerWidget()
    layout.addWidget(manager)
    layout.addStretch()
    
    window.resize(600, 400)
    window.show()
    
    app.exec()
