#!/usr/bin/env python3
"""Host Detail Window - Detaillierte Host-Informationen"""
from PyQt6 import QtWidgets, QtCore
import socket
from utils.country_flags import get_flag

class HostDetailWindow(QtWidgets.QDialog):
    def __init__(self, host_ip, monitor, parent=None):
        super().__init__(parent)
        self.host_ip = host_ip
        self.monitor = monitor
        
        self.setWindowTitle(f"🖥️ Host Details - {host_ip}")
        self.resize(700, 500)
        self.setStyleSheet("""
            QDialog { background: #1e1e1e; }
            QLabel { color: white; }
            QTableWidget {
                background: #2b2b2b;
                color: white;
                border: 1px solid #555;
                gridline-color: #555;
            }
            QHeaderView::section {
                background: #0d7377;
                color: white;
                padding: 8px;
                font-weight: bold;
            }
        """)
        
        self._setup_ui()
        self._load_data()
        self._start_updates()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        header = QtWidgets.QLabel(f"🖥️ {self.host_ip}")
        header.setStyleSheet("font-size: 20px; font-weight: bold; padding: 10px;")
        layout.addWidget(header)
        
        # Info Grid
        info_widget = QtWidgets.QWidget()
        info_layout = QtWidgets.QGridLayout(info_widget)
        info_layout.setSpacing(10)
        
        self.hostname_label = QtWidgets.QLabel("Hostname: Lädt...")
        self.country_label = QtWidgets.QLabel("Land: Unbekannt")
        self.total_traffic_label = QtWidgets.QLabel("Total Traffic: 0 B")
        self.status_label = QtWidgets.QLabel("Status: 🟢 Active")
        self.connections_label = QtWidgets.QLabel("Verbindungen: 0")
        
        for label in [self.hostname_label, self.country_label, self.total_traffic_label, 
                     self.status_label, self.connections_label]:
            label.setStyleSheet("padding: 8px; background: #2b2b2b; border-radius: 4px;")
        
        info_layout.addWidget(self.hostname_label, 0, 0)
        info_layout.addWidget(self.country_label, 0, 1)
        info_layout.addWidget(self.total_traffic_label, 1, 0)
        info_layout.addWidget(self.status_label, 1, 1)
        info_layout.addWidget(self.connections_label, 2, 0, 1, 2)
        
        layout.addWidget(info_widget)
        
        # Traffic Table
        table_label = QtWidgets.QLabel("📊 Traffic Details")
        table_label.setStyleSheet("font-size: 14px; font-weight: bold; padding: 10px;")
        layout.addWidget(table_label)
        
        self.traffic_table = QtWidgets.QTableWidget(0, 3)
        self.traffic_table.setHorizontalHeaderLabels(["Zeit", "Bytes", "Protokoll"])
        self.traffic_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.traffic_table)
        
        # Close Button
        close_btn = QtWidgets.QPushButton("Schließen")
        close_btn.setStyleSheet("""
            QPushButton {
                padding: 10px;
                background: #0d7377;
                color: white;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover { background: #0e8388; }
        """)
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)
    
    def _load_data(self):
        # Reverse DNS Lookup
        try:
            hostname = socket.gethostbyaddr(self.host_ip)[0]
            self.hostname_label.setText(f"Hostname: {hostname}")
        except:
            self.hostname_label.setText("Hostname: Nicht verfügbar")
        
        # Get traffic data
        hosts = self.monitor.get_top_hosts(100)
        for host, traffic in hosts:
            if host == self.host_ip:
                self.total_traffic_label.setText(f"Total Traffic: {self._format_bytes(traffic)}")
                break
    
    def _start_updates(self):
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._update_traffic)
        self.timer.start(1000)
        self._update_traffic()
    
    def _update_traffic(self):
        # Simuliere Traffic-Updates
        import time
        current_time = QtCore.QTime.currentTime().toString("HH:mm:ss")
        
        hosts = self.monitor.get_top_hosts(100)
        for host, traffic in hosts:
            if host == self.host_ip:
                self.total_traffic_label.setText(f"Total Traffic: {self._format_bytes(traffic)}")
                
                # Füge neue Zeile hinzu
                row = self.traffic_table.rowCount()
                if row < 20:  # Limitiere auf 20 Einträge
                    self.traffic_table.insertRow(0)
                    self.traffic_table.setItem(0, 0, QtWidgets.QTableWidgetItem(current_time))
                    self.traffic_table.setItem(0, 1, QtWidgets.QTableWidgetItem(self._format_bytes(traffic/20)))
                    self.traffic_table.setItem(0, 2, QtWidgets.QTableWidgetItem("TCP"))
                break
    
    def _format_bytes(self, b):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if b < 1024:
                return f"{b:.1f} {unit}"
            b /= 1024
        return f"{b:.1f} TB"
    
    def closeEvent(self, event):
        self.timer.stop()
        super().closeEvent(event)
