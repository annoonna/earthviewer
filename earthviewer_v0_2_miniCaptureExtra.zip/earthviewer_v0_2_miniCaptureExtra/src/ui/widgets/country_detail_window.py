#!/usr/bin/env python3
"""Country Detail Window - Detaillierte Länder-Informationen"""
from PyQt6 import QtWidgets, QtCore
from utils.country_flags import get_flag

class CountryDetailWindow(QtWidgets.QDialog):
    def __init__(self, country_name, monitor, parent=None):
        super().__init__(parent)
        self.country_name = country_name
        self.monitor = monitor
        self._hostname_cache = {}  # IP -> Hostname Cache
        
        flag = self._get_flag(country_name)
        self.setWindowTitle(f"{flag} {country_name} - Details")
        self.resize(700, 500)
        self.setStyleSheet("""
            QDialog { background: #1e1e1e; }
            QLabel { color: white; }
            QTableWidget {
                background: #2b2b2b;
                color: white;
                border: 1px solid #555;
                gridline-color: #555;
            }
            QHeaderView::section {
                background: #0d7377;
                color: white;
                padding: 8px;
                font-weight: bold;
            }
        """)
        
        self._setup_ui()
        self._start_updates()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        flag = self._get_flag(self.country_name)
        header = QtWidgets.QLabel(f"{flag} {self.country_name}")
        header.setStyleSheet("font-size: 20px; font-weight: bold; padding: 10px;")
        layout.addWidget(header)
        
        # Stats
        stats_widget = QtWidgets.QWidget()
        stats_layout = QtWidgets.QGridLayout(stats_widget)
        
        self.total_traffic_label = QtWidgets.QLabel("Total Traffic: 0 B")
        self.percentage_label = QtWidgets.QLabel("Anteil: 0%")
        self.hosts_count_label = QtWidgets.QLabel("Hosts: 0")
        
        for label in [self.total_traffic_label, self.percentage_label, self.hosts_count_label]:
            label.setStyleSheet("padding: 10px; background: #2b2b2b; border-radius: 4px; font-size: 13px;")
        
        stats_layout.addWidget(self.total_traffic_label, 0, 0)
        stats_layout.addWidget(self.percentage_label, 0, 1)
        stats_layout.addWidget(self.hosts_count_label, 1, 0, 1, 2)
        
        layout.addWidget(stats_widget)
        
        # Hosts from this country
        hosts_label = QtWidgets.QLabel("🖥️ Hosts aus diesem Land")
        hosts_label.setStyleSheet("font-size: 14px; font-weight: bold; padding: 10px;")
        layout.addWidget(hosts_label)
        
        self.hosts_table = QtWidgets.QTableWidget(0, 3)
        self.hosts_table.setHorizontalHeaderLabels(["Host", "Traffic", "Apps"])
        self.hosts_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.hosts_table)
        
        # Close Button
        close_btn = QtWidgets.QPushButton("Schließen")
        close_btn.setStyleSheet("""
            QPushButton {
                padding: 10px;
                background: #0d7377;
                color: white;
                border: none;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover { background: #0e8388; }
        """)
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)
    
    def _start_updates(self):
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._update_stats)
        self.timer.start(1000)
        self._update_stats()
    
    def _update_stats(self):
        countries = self.monitor.get_top_countries(50)
        total_all = sum(t for _, t in countries)
        
        for country, traffic in countries:
            if country == self.country_name:
                self.total_traffic_label.setText(f"Total Traffic: {self._format_bytes(traffic)}")
                percentage = (traffic / total_all * 100) if total_all > 0 else 0
                self.percentage_label.setText(f"Anteil: {percentage:.1f}%")
                break
        
        # Simuliere Hosts
        hosts = self.monitor.get_top_hosts(100)
        self.hosts_count_label.setText(f"Hosts: {len(hosts)}")
        
        # Zeige Top 10 Hosts
        self.hosts_table.setRowCount(min(10, len(hosts)))
        for row, (host_ip, traffic) in enumerate(hosts[:10]):
            # Hostname lookup (cached)
            import socket
            if host_ip in self._hostname_cache:
                hostname = self._hostname_cache[host_ip]
            else:
                try:
                    hostname = socket.gethostbyaddr(host_ip)[0]
                    self._hostname_cache[host_ip] = hostname
                except:
                    hostname = host_ip
                    self._hostname_cache[host_ip] = host_ip
            
            # Host
            if hostname != host_ip:
                display_name = f"🌐 {hostname}"
            else:
                display_name = f"🌐 {host_ip}"
            
            self.hosts_table.setItem(row, 0, QtWidgets.QTableWidgetItem(display_name))
            
            # Traffic
            item = QtWidgets.QTableWidgetItem(self._format_bytes(traffic))
            item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
            self.hosts_table.setItem(row, 1, item)
            
            # Apps
            apps = self.monitor.get_apps_for_host(host_ip)
            app_icons = ""
            for app in apps[:3]:
                if "firefox" in app.lower():
                    app_icons += "🦊 "
                elif "chrome" in app.lower() or "chromium" in app.lower():
                    app_icons += "🌐 "
                elif "system" in app.lower():
                    app_icons += "⚙️ "
                else:
                    app_icons += "📱 "
            if len(apps) > 3:
                app_icons += f"+{len(apps)-3}"
            
            apps_item = QtWidgets.QTableWidgetItem(app_icons)
            apps_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            self.hosts_table.setItem(row, 2, apps_item)
    
    def _format_bytes(self, b):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if b < 1024:
                return f"{b:.1f} {unit}"
            b /= 1024
        return f"{b:.1f} TB"
    
    def _get_flag(self, country):
        """Benutze zentrale Flaggen-Datenbank"""
        return get_flag(country)
    
    def closeEvent(self, event):
        self.timer.stop()
        super().closeEvent(event)
