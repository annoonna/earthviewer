#!/usr/bin/env python3
"""
Sidebar Widget - Vollständige Version
"""
from PyQt6 import QtWidgets, QtCore
from core.config import PROJECT_ROOT
from ui.widgets.network_tab import NetworkTab
from ui.widgets.monitoring_tab import MonitoringTab
from ui.widgets.graph_tab import GraphTab
from ui.widgets.protection_tab import ProtectionTab
from ui.widgets.protocol_analysis_tab import ProtocolAnalysisTab
from ui.widgets.network_scanner_tab import NetworkScannerTab
import numpy as np


class Sidebar(QtWidgets.QWidget):
    """Erweiterte Sidebar mit Tabs"""

    search_requested = QtCore.pyqtSignal(str)

    def __init__(self, globe_widget, geo_manager, parent=None):
        super().__init__(parent)
        self.globe = globe_widget
        self.geo_manager = geo_manager

        self.setMinimumWidth(350)
        self.setMaximumWidth(500)
        self.setStyleSheet("background: #2b2b2b; color: white;")

        self._setup_ui()
        self._refresh_favorites()

    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        # Header
        header = QtWidgets.QLabel("🌍 EarthViewer 2.0")
        header.setStyleSheet(
            "font-size: 24px; font-weight: bold; color: #0d7377; padding-bottom: 10px;"
        )
        layout.addWidget(header)

        # Status
        self.status_label = QtWidgets.QLabel("Status: Bereit")
        self.status_label.setStyleSheet(
            "color: #0d7377; font-size: 12px; padding: 8px; "
            "background: #1e1e1e; border-radius: 4px;"
        )
        layout.addWidget(self.status_label)

        # Tabs
        tabs = QtWidgets.QTabWidget()
        tabs.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #555;
                background: #2b2b2b;
                border-radius: 4px;
            }
            QTabBar::tab {
                background: #3a3a3a;
                color: white;
                padding: 10px 15px;
                margin-right: 2px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }
            QTabBar::tab:selected {
                background: #0d7377;
            }
            QTabBar::tab:hover {
                background: #4a4a4a;
            }
        """)

        # Basis-Tabs
        tabs.addTab(self._create_control_tab(), "⚙️ Steuerung")
        tabs.addTab(self._create_search_tab(), "🔍 Suche")
        tabs.addTab(self._create_favorites_tab(), "⭐ Favoriten")

        # Netzwerk-Tab
        self.network_tab = NetworkTab(self.geo_manager, self.globe, self)
        tabs.addTab(self.network_tab, "🌐 Netzwerk")

        # Live Connections
        from ui.widgets.live_connections_tab import LiveConnectionsTab
        from network.connection_tracker import ConnectionTracker
        self.connection_tracker = ConnectionTracker(self.geo_manager)
        self.live_connections_tab = LiveConnectionsTab(
            self.globe, self.connection_tracker, self
        )
        tabs.addTab(self.live_connections_tab, "🔴 Live Verbindungen")

        # Monitoring
        self.monitoring_tab = MonitoringTab(self.network_tab.network_monitor)
        tabs.addTab(self.monitoring_tab, "📊 Monitoring")

        # Control Center (nur EINMAL!)
        from ui.widgets.control_center_tab import ControlCenterTab
        self.control_center_tab = ControlCenterTab(
            self.network_tab.network_monitor,
            self.connection_tracker,
            self
        )
        tabs.addTab(self.control_center_tab, "🖥️ Control Center")

        # Graph, Schutz, Protokoll, Scanner
        self.graph_tab = GraphTab(self.network_tab.network_monitor)
        tabs.addTab(self.graph_tab, "📈 Graph")

        self.protection_tab = ProtectionTab(self.network_tab.network_monitor)
        tabs.addTab(self.protection_tab, "🔒 Schützen")

        self.protocol_tab = ProtocolAnalysisTab(self.network_tab.network_monitor)
        tabs.addTab(self.protocol_tab, "📊 Protokoll Analyse")

        self.scanner_tab = NetworkScannerTab()
        tabs.addTab(self.scanner_tab, "🔍 Netzwerk Scanner")

        layout.addWidget(tabs)

        # Zoom Info
        self.zoom_label = QtWidgets.QLabel("Zoom: 1.0x")
        self.zoom_label.setStyleSheet(
            "color: #aaa; font-size: 12px; padding: 8px; "
            "background: #1e1e1e; border-radius: 4px;"
        )
        layout.addWidget(self.zoom_label)

    # --------------------------------------------------
    # Steuerungs-Tab
    # --------------------------------------------------
    def _create_control_tab(self):
        """Steuerungs-Tab"""
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)
        layout.setSpacing(10)

        # Navigation
        nav_label = QtWidgets.QLabel("🎮 Navigation")
        nav_label.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: white; padding: 5px;"
        )
        layout.addWidget(nav_label)

        rotation_grid = QtWidgets.QGridLayout()
        rotation_grid.setSpacing(8)

        btn_style = """
            QPushButton {
                padding: 18px;
                background: #3a3a3a;
                color: white;
                border: 2px solid #555;
                border-radius: 8px;
                font-size: 24px;
                font-weight: bold;
                min-width: 60px;
                min-height: 60px;
            }
            QPushButton:hover {
                background: #4a4a4a;
                border-color: #0d7377;
            }
            QPushButton:pressed {
                background: #0d7377;
            }
        """

        def make_btn(text, slot):
            btn = QtWidgets.QPushButton(text)
            btn.setStyleSheet(btn_style)
            btn.clicked.connect(slot)
            btn.setAutoRepeat(True)
            btn.setAutoRepeatInterval(50)
            return btn

        rotation_grid.addWidget(make_btn("↑", self.globe.rotate_up), 0, 1)
        rotation_grid.addWidget(make_btn("←", self.globe.rotate_left), 1, 0)
        rotation_grid.addWidget(make_btn("↓", self.globe.rotate_down), 1, 1)
        rotation_grid.addWidget(make_btn("→", self.globe.rotate_right), 1, 2)

        layout.addLayout(rotation_grid)

        # Funktionen
        func_label = QtWidgets.QLabel("🔧 Funktionen")
        func_label.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: white; padding: 5px; margin-top: 10px;"
        )
        layout.addWidget(func_label)

        func_btn_style = """
            QPushButton {
                padding: 12px;
                background: #3a3a3a;
                color: white;
                border: 1px solid #555;
                border-radius: 6px;
                font-size: 13px;
                font-weight: bold;
                text-align: left;
            }
            QPushButton:hover {
                background: #4a4a4a;
            }
            QPushButton:pressed {
                background: #0d7377;
            }
            QPushButton:checked {
                background: #d35400;
                border-color: #e67e22;
            }
        """

        auto_btn = QtWidgets.QPushButton("🔄 Auto-Rotation")
        auto_btn.setCheckable(True)
        auto_btn.setStyleSheet(func_btn_style)
        auto_btn.toggled.connect(
            lambda c: setattr(self.globe, "auto_rotate", c)
        )
        layout.addWidget(auto_btn)

        reset_btn = QtWidgets.QPushButton("↺ Zurücksetzen")
        reset_btn.setStyleSheet(func_btn_style)
        reset_btn.clicked.connect(self._reset_view)
        layout.addWidget(reset_btn)

        screenshot_btn = QtWidgets.QPushButton("📸 Screenshot")
        screenshot_btn.setStyleSheet(func_btn_style)
        screenshot_btn.clicked.connect(self._take_screenshot)
        layout.addWidget(screenshot_btn)

        # Ansicht
        view_label = QtWidgets.QLabel("👁️ Ansicht")
        view_label.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: white; padding: 5px; margin-top: 10px;"
        )
        layout.addWidget(view_label)

        self.align_combo = QtWidgets.QComboBox()
        self.align_combo.addItems(
            ["Deutschland", "Nordpol", "Südpol", "Äquator", "Ziel"]
        )
        self.align_combo.setStyleSheet("""
            QComboBox {
                padding: 10px;
                background: #3a3a3a;
                color: white;
                border: 1px solid #555;
                border-radius: 6px;
                font-size: 13px;
            }
            QComboBox:hover {
                background: #4a4a4a;
            }
            QComboBox QAbstractItemView {
                background: #3a3a3a;
                color: white;
                selection-background-color: #0d7377;
                border: 1px solid #555;
            }
        """)
        self.align_combo.currentTextChanged.connect(self.globe.align_view)
        layout.addWidget(self.align_combo)

        # Optionen
        opt_label = QtWidgets.QLabel("⚡ Optionen")
        opt_label.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: white; padding: 5px; margin-top: 10px;"
        )
        layout.addWidget(opt_label)

        checkbox_style = "color: white; padding: 8px; font-size: 13px;"

        marker_cb = QtWidgets.QCheckBox("🏷️ Marker anzeigen")
        marker_cb.setChecked(True)
        marker_cb.setStyleSheet(checkbox_style)
        marker_cb.stateChanged.connect(
            lambda s: self._toggle_markers(
                s == QtCore.Qt.CheckState.Checked.value
            )
        )
        layout.addWidget(marker_cb)

        label_cb = QtWidgets.QCheckBox("📝 Namen anzeigen")
        label_cb.setChecked(True)
        label_cb.setStyleSheet(checkbox_style)
        label_cb.stateChanged.connect(
            lambda s: self._toggle_labels(
                s == QtCore.Qt.CheckState.Checked.value
            )
        )
        layout.addWidget(label_cb)

        layout.addStretch()
        return widget

    # --------------------------------------------------
    # Such-Tab
    # --------------------------------------------------
    def _create_search_tab(self):
        """Such-Tab"""
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)
        layout.setSpacing(10)

        self.search_input = QtWidgets.QLineEdit()
        self.search_input.setPlaceholderText("Stadt, IP, Koordinaten...")
        self.search_input.setStyleSheet("""
            QLineEdit {
                padding: 12px;
                font-size: 14px;
                background: #1e1e1e;
                color: white;
                border: 1px solid #555;
                border-radius: 4px;
            }
            QLineEdit:focus {
                border: 1px solid #0d7377;
            }
        """)
        self.search_input.returnPressed.connect(self._on_search)
        layout.addWidget(self.search_input)

        search_btn = QtWidgets.QPushButton("🔍 Suchen")
        search_btn.setStyleSheet("""
            QPushButton {
                padding: 12px;
                background: #0d7377;
                color: white;
                font-weight: bold;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover {
                background: #0e8388;
            }
        """)
        search_btn.clicked.connect(self._on_search)
        layout.addWidget(search_btn)

        results_label = QtWidgets.QLabel("📍 Suchergebnisse")
        results_label.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: white; padding: 5px;"
        )
        layout.addWidget(results_label)

        self.result_list = QtWidgets.QListWidget()
        self.result_list.setStyleSheet("""
            QListWidget {
                background: #1e1e1e;
                color: white;
                border: 1px solid #555;
                border-radius: 6px;
                padding: 5px;
                font-size: 13px;
            }
            QListWidget::item {
                padding: 10px;
                border-radius: 4px;
                margin: 2px;
            }
            QListWidget::item:hover {
                background: #3a3a3a;
            }
            QListWidget::item:selected {
                background: #0d7377;
            }
        """)
        self.result_list.itemDoubleClicked.connect(self._on_result_clicked)
        layout.addWidget(self.result_list)

        return widget

    # --------------------------------------------------
    # Favoriten-Tab
    # --------------------------------------------------
    def _create_favorites_tab(self):
        """Favoriten-Tab"""
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)
        layout.setSpacing(10)

        self.favorites_list = QtWidgets.QListWidget()
        self.favorites_list.setStyleSheet("""
            QListWidget {
                background: #1e1e1e;
                color: white;
                border: 1px solid #555;
                border-radius: 6px;
                padding: 5px;
                font-size: 13px;
            }
            QListWidget::item {
                padding: 10px;
                border-radius: 4px;
                margin: 2px;
            }
            QListWidget::item:hover {
                background: #3a3a3a;
            }
            QListWidget::item:selected {
                background: #0d7377;
            }
        """)
        self.favorites_list.itemDoubleClicked.connect(self._on_favorite_clicked)
        layout.addWidget(self.favorites_list)

        add_btn = QtWidgets.QPushButton("➕ Aktuelle Suche speichern")
        add_btn.setStyleSheet("""
            QPushButton {
                padding: 12px;
                background: #3a3a3a;
                color: white;
                border: 1px solid #555;
                border-radius: 6px;
                font-size: 13px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #0d7377;
            }
        """)
        add_btn.clicked.connect(self._add_favorite)
        layout.addWidget(add_btn)

        return widget

    # --------------------------------------------------
    # Favoriten / Suche / Status / Zoom
    # --------------------------------------------------
    def _on_search(self):
        query = self.search_input.text().strip()
        if query:
            self.search_requested.emit(query)

    def _on_result_clicked(self, item):
        location = item.data(QtCore.Qt.ItemDataRole.UserRole)
        if location:
            self.globe.navigate_to(location)

    def _on_favorite_clicked(self, item):
        query = item.data(QtCore.Qt.ItemDataRole.UserRole)
        self.search_input.setText(query)
        self._on_search()

    def _add_favorite(self):
        query = self.search_input.text().strip()
        if not query:
            return

        fav_file = PROJECT_ROOT / "favorites.txt"
        favorites = []
        if fav_file.exists():
            with open(fav_file, "r", encoding="utf-8") as f:
                favorites = [line.strip() for line in f if line.strip()]

        if query not in favorites:
            favorites.append(query)
            with open(fav_file, "w", encoding="utf-8") as f:
                for fav in favorites:
                    f.write(fav + "\n")
            print(f"⭐ Favorit gespeichert: {query}")
            self._refresh_favorites()
        else:
            print(f"⚠️ '{query}' bereits in Favoriten")

    def _refresh_favorites(self):
        """Lädt und zeigt Favoriten"""
        self.favorites_list.clear()

        fav_file = PROJECT_ROOT / "favorites.txt"
        if not fav_file.exists():
            return

        with open(fav_file, "r", encoding="utf-8") as f:
            favorites = [line.strip() for line in f if line.strip()]

        for fav in favorites:
            item = QtWidgets.QListWidgetItem(f"⭐ {fav}")
            item.setData(QtCore.Qt.ItemDataRole.UserRole, fav)
            self.favorites_list.addItem(item)

    def _reset_view(self):
        self.globe.camera_distance = 2.8
        self.globe.clear_markers()
        self.result_list.clear()
        self.search_input.clear()
        self.align_combo.setCurrentText("Deutschland")
        self.globe.align_view("Deutschland")

    def _toggle_markers(self, show: bool):
        self.globe.show_markers = show
        self.globe.update()

    def _toggle_labels(self, show: bool):
        self.globe.show_labels = show
        self.globe.update()

    def _take_screenshot(self):
        """Screenshot erstellen"""
        from PyQt6 import QtWidgets as QW
        filename = self.globe.take_screenshot()

        msg = QW.QMessageBox(self)
        msg.setWindowTitle("Screenshot")
        msg.setText("Screenshot gespeichert!")
        msg.setInformativeText(str(filename))
        msg.setIcon(QW.QMessageBox.Icon.Information)
        msg.exec()

    def update_results(self, locations):
        """Aktualisiert Suchergebnisse"""
        self.result_list.clear()
        for loc in locations:
            icon = {"city": "🏙️", "ip": "🌐", "custom": "📍"}.get(
                loc.location_type, "📍"
            )
            country_text = f" [{loc.country}]" if loc.country else ""
            name_count = sum(1 for l in locations if l.name == loc.name)
            coord_text = (
                f" ({loc.lat:.1f}°, {loc.lon:.1f}°)" if name_count > 1 else ""
            )

            item = QtWidgets.QListWidgetItem(
                f"{icon} {loc.name}{country_text}{coord_text}"
            )
            item.setData(QtCore.Qt.ItemDataRole.UserRole, loc)
            self.result_list.addItem(item)

        if locations:
            self.result_list.setCurrentRow(0)

    def update_status(self, text: str):
        """Aktualisiert Status-Label"""
        self.status_label.setText(f"Status: {text}")

    def update_zoom(self, distance: float):
        """Aktualisiert Zoom-Anzeige"""
        zoom = 25.0 / max(0.1, distance)
        self.zoom_label.setText(f"Zoom: {zoom:.1f}x")
