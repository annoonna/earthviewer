#!/usr/bin/env python3
"""Network Stats Widget - 4 Spalten"""
from PyQt6 import QtWidgets, QtCore
from utils.country_flags import get_flag

class NetworkStatsWidget(QtWidgets.QWidget):
    def __init__(self, monitor, compact=False, parent=None):
        super().__init__(parent)
        self.monitor = monitor
        self.compact = compact
        # GeoManager für IP-Lookups
        from data.geo_manager import GeoDataManager
        self.geo_manager = GeoDataManager()
        self._hostname_cache = {}  # IP -> Hostname Cache
        self._hostname_cache = {}  # IP -> Hostname Cache
        self._hostname_cache = {}  # IP -> Hostname Cache
        self.monitor.stats_updated.connect(self.update_tables)
        self._setup_ui()
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_tables)
        self.timer.start(2000)
    
    def _setup_ui(self):
        layout = QtWidgets.QHBoxLayout(self)
        layout.setSpacing(5)
        layout.setContentsMargins(5, 5, 5, 5)
        
        self.apps_table = self._create_table("Apps 📱")
        self.apps_table.table.itemClicked.connect(lambda item: self._show_process_details(item, "Apps"))
        self.hosts_table = self._create_table("Hosts 🌐")
        self.hosts_table.table.itemClicked.connect(lambda item: self._show_host_details(item))
        self.protocols_table = self._create_table("Verkehr 🚦")
        self.countries_table = self._create_table("Länder 🌍")
        self.countries_table.table.itemClicked.connect(lambda item: self._show_country_details(item))
        
        layout.addWidget(self.apps_table)
        layout.addWidget(self.hosts_table)
        layout.addWidget(self.protocols_table)
        layout.addWidget(self.countries_table)
    
    def _create_table(self, title):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        
        label = QtWidgets.QLabel(title)
        label.setStyleSheet("font-weight: bold; font-size: 14px; padding: 5px; background: #2a2a2a; color: white;")
        layout.addWidget(label)
        
        table = QtWidgets.QTableWidget()
        table.setColumnCount(2)
        table.setHorizontalHeaderLabels(["Name", "Traffic"])
        table.horizontalHeader().setStretchLastSection(False)
        table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.Stretch)
        table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.setStyleSheet("""
            QTableWidget {
                background: #1e1e1e;
                color: white;
                gridline-color: #3a3a3a;
                border: 1px solid #3a3a3a;
            }
            QTableWidget::item { padding: 5px; }
            QTableWidget::item:selected { background: #0d7377; }
            QHeaderView::section {
                background: #2a2a2a;
                color: white;
                padding: 5px;
                border: none;
            }
        """)
        
        layout.addWidget(table)
        widget.table = table
        return widget
    
    def update_tables(self):
        limit = 10 if self.compact else 50
        self._update_apps_table(self.apps_table.table, self.monitor.get_top_apps(limit))
        self._update_hosts_table(self.hosts_table.table, self.monitor.get_top_hosts(limit))
        self._update_table(self.protocols_table.table, self.monitor.get_top_protocols(limit), add_flag=False)
        self._update_countries_table(self.countries_table.table, self.monitor.get_top_countries(limit))
    
    def _update_table(self, table, data, add_flag=False):
        table.setRowCount(len(data))
        for row, (name, traffic) in enumerate(data):
            # Name mit optionaler Flagge
            if add_flag:
                flag = get_flag(name)
                display_name = f"{flag} {name}"
            else:
                display_name = str(name)
            
            name_item = QtWidgets.QTableWidgetItem(display_name)
            table.setItem(row, 0, name_item)
            
            # Traffic
            t = self._format_bytes(traffic)
            item = QtWidgets.QTableWidgetItem(t)
            item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
            table.setItem(row, 1, item)
    
    def _show_process_details(self, item, table_type):
        """Zeigt Detail-Fenster für gewählten Prozess"""
        if table_type == "Apps" and item.column() == 0:
            process_name = item.text()
            from ui.widgets.process_detail_window import ProcessDetailWindow
            detail_window = ProcessDetailWindow(process_name, self.monitor, self)
            detail_window.exec()
    

    
    def _show_host_details(self, item):
        """Zeigt Detail-Fenster für gewählten Host"""
        if item.column() == 0:
            host_ip = item.text()
            from ui.widgets.host_detail_window import HostDetailWindow
            detail_window = HostDetailWindow(host_ip, self.monitor, self)
            detail_window.exec()
    
    def _show_country_details(self, item):
        """Zeigt Detail-Fenster für gewähltes Land"""
        if item.column() == 0:
            country_name = item.text()
            from ui.widgets.country_detail_window import CountryDetailWindow
            detail_window = CountryDetailWindow(country_name, self.monitor, self)
            detail_window.exec()


    
    def _update_apps_table(self, table, data):
        """Update Apps-Tabelle MIT dynamischen Flaggen basierend auf Haupt-Zielland"""
        table.setRowCount(len(data))
        
        # Hole aktuelle Connections
        import psutil
        
        for row, (app_name, traffic) in enumerate(data):
            # Finde Haupt-Zielland für diese App
            main_country = None
            country_traffic = {}
            
            try:
                for proc in psutil.process_iter(['pid', 'name']):
                    try:
                        if proc.info['name'] == app_name:
                            connections = proc.connections(kind='inet')
                            for conn in connections:
                                if conn.status == 'ESTABLISHED' and conn.raddr:
                                    try:
                                        loc = self.geo_manager.lookup_ip(conn.raddr.ip)
                                        if loc and loc.country:
                                            country = loc.country
                                            country_traffic[country] = country_traffic.get(country, 0) + 1
                                    except:
                                        pass
                    except:
                        pass
            except:
                pass
            
            # Finde Land mit meisten Connections
            if country_traffic:
                main_country = max(country_traffic, key=country_traffic.get)
            
            # Name mit Flagge
            if main_country:
                flag = get_flag(main_country)
                display_name = f"{flag} {app_name}"
            else:
                display_name = app_name
            
            name_item = QtWidgets.QTableWidgetItem(display_name)
            table.setItem(row, 0, name_item)
            
            # Traffic
            t = self._format_bytes(traffic)
            item = QtWidgets.QTableWidgetItem(t)
            item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
            table.setItem(row, 1, item)
    
    def _update_hosts_table(self, table, data):
        """Update Hosts-Tabelle MIT Hostnamen & App-Icons"""
        import socket
        table.setRowCount(len(data))
        for row, (host_ip, traffic) in enumerate(data):
            # Hostname lookup (cached)
            if host_ip in self._hostname_cache:
                hostname = self._hostname_cache[host_ip]
            else:
                try:
                    hostname = socket.gethostbyaddr(host_ip)[0]
                    self._hostname_cache[host_ip] = hostname
                except:
                    hostname = host_ip
                    self._hostname_cache[host_ip] = host_ip
            
            # Zeige Hostname statt IP
            if hostname != host_ip:
                display_name = f"🌐 {hostname}"
            else:
                display_name = f"🌐 {host_ip}"
            
            # App-Icons für diesen Host
            apps = self.monitor.get_apps_for_host(host_ip)
            app_icons = "  "
            for app in apps[:3]:
                if "firefox" in app.lower():
                    app_icons += "🦊"
                elif "chrome" in app.lower() or "chromium" in app.lower():
                    app_icons += "🌐"
                elif "system" in app.lower():
                    app_icons += "⚙️"
                else:
                    app_icons += "📱"
            
            if len(apps) > 3:
                app_icons += f" +{len(apps)-3}"
            
            # Name mit Apps
            name_item = QtWidgets.QTableWidgetItem(f"{display_name}{app_icons}")
            name_item.setData(QtCore.Qt.ItemDataRole.UserRole, host_ip)
            table.setItem(row, 0, name_item)
            
            t = self._format_bytes(traffic)
            item = QtWidgets.QTableWidgetItem(t)
            item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
            table.setItem(row, 1, item)
    
    def _update_countries_table(self, table, data):
        """Update Länder-Tabelle MIT Flaggen"""
        table.setRowCount(len(data))
        for row, (country, traffic) in enumerate(data):
            flag = get_flag(country)
            display_name = f"{flag} {country}"
            
            name_item = QtWidgets.QTableWidgetItem(display_name)
            table.setItem(row, 0, name_item)
            
            t = self._format_bytes(traffic)
            item = QtWidgets.QTableWidgetItem(t)
            item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
            table.setItem(row, 1, item)

    def _format_bytes(self, b):
        if b < 1024:
            return f"{b:.0f} B"
        elif b < 1024*1024:
            return f"{b/1024:.1f} KB"
        elif b < 1024*1024*1024:
            return f"{b/(1024*1024):.1f} MB"
        else:
            return f"{b/(1024*1024*1024):.2f} GB"
