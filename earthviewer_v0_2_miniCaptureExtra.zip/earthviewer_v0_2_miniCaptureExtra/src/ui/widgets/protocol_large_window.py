#!/usr/bin/env python3
"""Protocol Analysis Large Window"""
from PyQt6 import QtWidgets

class ProtocolLargeWindow(QtWidgets.QDialog):
    def __init__(self, monitor, parent=None):
        super().__init__(parent)
        self.monitor = monitor
        self.setWindowTitle("📊 Protokoll Analyse - Große Ansicht")
        self.resize(1200, 700)
        self.monitor.stats_updated.connect(self._update)
        self._setup_ui()
        self._update()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("📊 Protokoll Analyse - Detailansicht")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: white;")
        header.addWidget(title)
        header.addStretch()
        
        close_btn = QtWidgets.QPushButton("❌ Schließen")
        close_btn.setStyleSheet("padding: 8px 16px; background: #d32f2f; color: white; border: none; border-radius: 4px;")
        close_btn.clicked.connect(self.close)
        header.addWidget(close_btn)
        
        layout.addLayout(header)
        
        self.table = QtWidgets.QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Protokoll", "Traffic", "Pakete", "Anteil %"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setStyleSheet("background: #1e1e1e; color: white; font-size: 14px;")
        layout.addWidget(self.table, 1)
        
        self.setStyleSheet("QDialog { background: #1e1e1e; }")
    
    def _update(self):
        protocols = self.monitor.get_top_protocols(50)
        total = sum(t for _, t in protocols) if protocols else 1
        self.table.setRowCount(len(protocols))
        
        for row, (protocol, traffic) in enumerate(protocols):
            percentage = (traffic / total * 100) if total > 0 else 0
            self.table.setItem(row, 0, QtWidgets.QTableWidgetItem(protocol))
            self.table.setItem(row, 1, QtWidgets.QTableWidgetItem(f"{traffic/1024:.1f} KB"))
            self.table.setItem(row, 2, QtWidgets.QTableWidgetItem(f"{int(traffic/1024)}"))
            self.table.setItem(row, 3, QtWidgets.QTableWidgetItem(f"{percentage:.1f}%"))
