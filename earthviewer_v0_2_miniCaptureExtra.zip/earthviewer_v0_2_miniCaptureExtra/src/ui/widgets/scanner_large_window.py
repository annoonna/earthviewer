#!/usr/bin/env python3
"""Scanner Large Window"""
from PyQt6 import QtWidgets

class ScannerLargeWindow(QtWidgets.QDialog):
    def __init__(self, results_text, parent=None):
        super().__init__(parent)
        self.results = results_text
        self.setWindowTitle("🔍 Scanner - Große Ansicht")
        self.resize(1200, 700)
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("🔍 Netzwerk Scanner - Detaillierte Ergebnisse")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: white;")
        header.addWidget(title)
        header.addStretch()
        
        close_btn = QtWidgets.QPushButton("❌ Schließen")
        close_btn.setStyleSheet("padding: 8px 16px; background: #d32f2f; color: white; border: none; border-radius: 4px;")
        close_btn.clicked.connect(self.close)
        header.addWidget(close_btn)
        
        layout.addLayout(header)
        
        results_display = QtWidgets.QTextEdit()
        results_display.setReadOnly(True)
        results_display.setPlainText(self.results)
        results_display.setStyleSheet("background: #1e1e1e; color: #00ff00; font-family: monospace; font-size: 14px;")
        layout.addWidget(results_display, 1)
        
        self.setStyleSheet("QDialog { background: #1e1e1e; }")
