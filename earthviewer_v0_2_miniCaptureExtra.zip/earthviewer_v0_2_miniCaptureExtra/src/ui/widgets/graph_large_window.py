#!/usr/bin/env python3
"""Graph Large Window"""
from PyQt6 import QtWidgets, QtCore
import pyqtgraph as pg
from collections import deque
import time

class GraphLargeWindow(QtWidgets.QDialog):
    def __init__(self, monitor, parent=None):
        super().__init__(parent)
        self.monitor = monitor
        self.setWindowTitle("📈 Network Traffic Graph - Große Ansicht")
        self.resize(1400, 800)
        
        self.max_points = 600  # 10 Minuten
        self.time_data = deque(maxlen=self.max_points)
        self.upload_data = deque(maxlen=self.max_points)
        self.download_data = deque(maxlen=self.max_points)
        self.total_data = deque(maxlen=self.max_points)
        
        self.start_time = time.time()
        self._setup_ui()
        
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._update)
        self.timer.start(1000)
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("📈 Network Traffic - Live View (10 Minuten)")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: white;")
        header.addWidget(title)
        header.addStretch()
        
        close_btn = QtWidgets.QPushButton("❌ Schließen")
        close_btn.setStyleSheet("padding: 8px 16px; background: #d32f2f; color: white; border: none; border-radius: 4px;")
        close_btn.clicked.connect(self.close)
        header.addWidget(close_btn)
        
        layout.addLayout(header)
        
        self.status = QtWidgets.QLabel("🔴 Live")
        self.status.setStyleSheet("color: #4caf50; font-size: 14px;")
        layout.addWidget(self.status)
        
        # Graph
        pg.setConfigOption('background', '#1e1e1e')
        pg.setConfigOption('foreground', 'w')
        
        self.plot = pg.PlotWidget()
        self.plot.setLabel('left', 'Traffic', units='KB/s')
        self.plot.setLabel('bottom', 'Zeit', units='s')
        self.plot.showGrid(x=True, y=True, alpha=0.3)
        
        self.curve_total = self.plot.plot(pen=pg.mkPen(color='#ff69b4', width=3),
                                         fillLevel=0, brush=(255, 105, 180, 120))
        self.curve_download = self.plot.plot(pen=pg.mkPen(color='#ff8c00', width=3),
                                            fillLevel=0, brush=(255, 140, 0, 120))
        self.curve_upload = self.plot.plot(pen=pg.mkPen(color='#ffd700', width=3),
                                          fillLevel=0, brush=(255, 215, 0, 120))
        
        layout.addWidget(self.plot, 1)
        
        self.setStyleSheet("QDialog { background: #1e1e1e; }")
    
    def _update(self):
        current_time = time.time() - self.start_time
        
        upload = download = 0
        with self.monitor.stats.lock:
            for data in self.monitor.stats.apps.values():
                total = data.get("total", 0)
                download += total * 0.7
                upload += total * 0.3
        
        self.time_data.append(current_time)
        self.upload_data.append(upload / 1024)
        self.download_data.append(download / 1024)
        self.total_data.append((upload + download) / 1024)
        
        if len(self.time_data) > 0:
            times = list(self.time_data)
            self.curve_upload.setData(times, list(self.upload_data))
            self.curve_download.setData(times, list(self.download_data))
            self.curve_total.setData(times, list(self.total_data))
            
            max_val = max(max(self.total_data, default=100), 100)
            self.plot.setYRange(0, max_val * 1.2)
        
        self.status.setText(
            f"🔴 Live | ⬆️ {upload/1024:.1f} KB/s | ⬇️ {download/1024:.1f} KB/s"
        )
