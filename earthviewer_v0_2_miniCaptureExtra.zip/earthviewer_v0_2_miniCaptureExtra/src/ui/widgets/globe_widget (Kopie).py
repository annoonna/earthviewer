#!/usr/bin/env python3
"""
Globe Widget - 3D-OpenGL-Widget
"""
import numpy as np
import time
from PyQt6 import QtCore, QtGui
from PyQt6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL.GL import *
from typing import List, Optional
import math

from core.geo_location import GeoLocation
from core.config import get_theme_color
from core.config import (
    CAMERA_DISTANCE, CAMERA_FOV, CAMERA_NEAR, CAMERA_FAR,
    CAMERA_MIN_DISTANCE, CAMERA_MAX_DISTANCE, ROTATION_SENSITIVITY, ZOOM_FACTOR, EARTH_TEXTURE
)
from rendering.gl_renderer import GLRenderer
from utils.matrix_utils import create_rotation_matrix, create_projection_matrix, create_view_matrix

class GlobeWidget(QOpenGLWidget):
    """3D-Globus Widget"""
    
    def __init__(self, parent=None):
        # WICHTIG: Erst Format erstellen
        fmt = QtGui.QSurfaceFormat()
        fmt.setVersion(3, 3)  # OpenGL 3.3
        fmt.setProfile(QtGui.QSurfaceFormat.OpenGLContextProfile.CoreProfile)
        fmt.setDepthBufferSize(24)
        fmt.setStencilBufferSize(8)
        fmt.setSamples(4)
        
        # DANN super().__init__ aufrufen
        super().__init__(parent)
        
        # JETZT ERST setFormat() - nach super().__init__!
        self.setFormat(fmt)
        
        self.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)
        
        self.renderer = GLRenderer(EARTH_TEXTURE)
        self.rotation_matrix = create_rotation_matrix(90.0, np.array([1, 0, 0]))
        self.camera_distance = CAMERA_DISTANCE
        
        self.last_mouse_pos = None
        self.auto_rotate = False
        
        self.search_markers: List[GeoLocation] = []
        self.target_marker: Optional[GeoLocation] = None
        self.traceroute_markers: List[GeoLocation] = []
        self.traceroute_hop_info: List[dict] = []
        self.hovered_marker: Optional[tuple] = None
        
        self.show_markers = True
        self.show_labels = True
        from core.settings import settings
        self.auto_rotate_speed = settings.get("auto_rotate_speed", 0.3)
        self.show_labels = settings.get("show_labels", True)
        
        # NEU v0.2: Connection Lines für Live Connections
        self.connection_lines = []  # Liste von (start_loc, end_loc, color, timestamp)
        self.show_incoming_connections = True
        self.show_outgoing_connections = True
        self.animation_speed = 0.5
        self.animation_offset = 0.0
        
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._on_timer)
        self.timer.start(16)
    
    def _get_marker_offset(self):
        from core import config
        return getattr(config, 'MARKER_OFFSET', 0.02)

    def _on_timer(self):
        if self.auto_rotate:
            self.rotate(-0.3, np.array([0, 1, 0]))
    
    def initializeGL(self):
        """OpenGL Initialisierung mit robustem Context-Handling"""
        # SCHRITT 1: Context aktivieren
        self.makeCurrent()
        
        # SCHRITT 2: PyOpenGL für Qt6 konfigurieren (KRITISCH!)
        try:
            import OpenGL
            # Deaktiviere alle PyOpenGL Context-Validierungen
            OpenGL.ERROR_CHECKING = False
            OpenGL.ERROR_LOGGING = False
            OpenGL.FULL_LOGGING = False
            
            # Deaktiviere Context-Data Tracking (verhindert "no valid context" Fehler)
            from OpenGL import contextdata
            contextdata.getContext = lambda context=None: 1  # Dummy-Context für PyOpenGL
            
            print("🔧 PyOpenGL Context-Validation DEAKTIVIERT (Qt6-Kompatibilität)")
        except Exception as e:
            print(f"⚠️  PyOpenGL Config Warning: {e}")
        
        # SCHRITT 3: Context-Validierung
        try:
            from OpenGL.GL import glGetString, GL_VERSION
            version = glGetString(GL_VERSION)
            print(f"✅ OpenGL initialisiert: {version.decode() if version else 'Unknown'}")
        except Exception as e:
            print(f"⚠️  OpenGL Context Warning: {e}")
        
        # SCHRITT 4: Renderer initialisieren (sollte jetzt funktionieren)
        try:
            self.renderer.initialize()
            print("✅ Renderer erfolgreich initialisiert!")
        except Exception as e:
            print(f"❌ Renderer Initialisierung fehlgeschlagen: {e}")
            import traceback
            traceback.print_exc()
            raise  # Re-raise für besseres Debugging
    
    def resizeGL(self, w: int, h: int):
        glViewport(0, 0, w, h)
    
    def paintGL(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        
        self.renderer.render_earth(mvp, model)
        
        if self.show_markers:
            self.renderer.render_markers(mvp, self.search_markers, 
                                        self.target_marker, self.traceroute_markers)
        
        if self.traceroute_markers and len(self.traceroute_markers) > 1:
            self.renderer.render_line(mvp, self.traceroute_markers)
        
        # NEU v0.2: Rendere Connection Lines
        if self.connection_lines:
            self._render_connection_lines(mvp)
        
        if self.show_labels and (self.search_markers or self.target_marker or self.traceroute_markers):
            self._render_labels()
        
        if self.hovered_marker:
            self._render_hover_tooltip()
    
    def _get_matrices(self):
        aspect = self.width() / max(1.0, self.height())
        projection = create_projection_matrix(CAMERA_FOV, aspect, CAMERA_NEAR, CAMERA_FAR)
        view = create_view_matrix(self.camera_distance)
        model = self.rotation_matrix
        return projection, view, model
    
    def navigate_to(self, location: GeoLocation):
        self.target_marker = location
        self._align_to_location(location.lat, location.lon)
        self.update()
    
    def _align_to_location(self, lat: float, lon: float):
        base = create_rotation_matrix(90.0, np.array([1, 0, 0]))
        rot_y = create_rotation_matrix(-lon, np.array([0, 1, 0]))
        rot_x = create_rotation_matrix(lat - 90.0, np.array([1, 0, 0]))
        self.rotation_matrix = rot_x @ rot_y @ base
    
    def set_search_results(self, locations: List[GeoLocation]):
        self.search_markers = locations
        if locations:
            self.navigate_to(locations[0])
        else:
            self.update()
    
    def clear_markers(self):
        self.search_markers = []
        self.target_marker = None
        self.traceroute_markers = []
        self.traceroute_hop_info = []
        self.hovered_marker = None
        self.update()
    
    def rotate(self, angle: float, axis: np.ndarray):
        rotation = create_rotation_matrix(angle, axis)
        self.rotation_matrix = rotation @ self.rotation_matrix
        self.update()
    
    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.last_mouse_pos = event.position()
    
    def mouseMoveEvent(self, event):
        if not (event.buttons() & QtCore.Qt.MouseButton.LeftButton):
            self._check_hover(event.position())
        
        if self.last_mouse_pos and (event.buttons() & QtCore.Qt.MouseButton.LeftButton):
            delta_x = event.position().x() - self.last_mouse_pos.x()
            delta_y = event.position().y() - self.last_mouse_pos.y()
            
            rot_y = create_rotation_matrix(delta_x * ROTATION_SENSITIVITY, np.array([0, 1, 0]))
            rot_x = create_rotation_matrix(delta_y * ROTATION_SENSITIVITY, np.array([1, 0, 0]))
            
            self.rotation_matrix = rot_x @ rot_y @ self.rotation_matrix
            self.update()
        
        self.last_mouse_pos = event.position()
    
    def _check_hover(self, mouse_pos):
        if not self.traceroute_markers or not self.traceroute_hop_info:
            if self.hovered_marker:
                self.hovered_marker = None
                self.update()
            return
        
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        viewport = np.array([0, 0, self.width(), self.height()])
        
        closest_marker = None
        closest_info = None
        min_dist = 30
        
        for i, marker in enumerate(self.traceroute_markers):
            screen_pos = self._project_to_screen(marker, mvp, viewport)
            if screen_pos:
                dx = screen_pos[0] - mouse_pos.x()
                dy = screen_pos[1] - mouse_pos.y()
                dist = math.sqrt(dx*dx + dy*dy)
                
                if dist < min_dist:
                    min_dist = dist
                    closest_marker = marker
                    if i < len(self.traceroute_hop_info):
                        closest_info = self.traceroute_hop_info[i]
        
        new_hover = (closest_marker, closest_info) if closest_marker else None
        if new_hover != self.hovered_marker:
            self.hovered_marker = new_hover
            self.update()
    
    def mouseReleaseEvent(self, event):
        self.last_mouse_pos = None
    
    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        factor = ZOOM_FACTOR if delta > 0 else 1.0 / ZOOM_FACTOR
        
        self.camera_distance *= factor
        self.camera_distance = max(CAMERA_MIN_DISTANCE, min(CAMERA_MAX_DISTANCE, self.camera_distance))
        self.update()

    def rotate_up(self):
        self.rotate(5.0, np.array([1, 0, 0]))
    
    def rotate_down(self):
        self.rotate(-5.0, np.array([1, 0, 0]))
    
    def rotate_left(self):
        self.rotate(5.0, np.array([0, 1, 0]))
    
    def rotate_right(self):
        self.rotate(-5.0, np.array([0, 1, 0]))
    
    def align_view(self, mode: str):
        from utils.matrix_utils import create_rotation_matrix
        base = create_rotation_matrix(90.0, np.array([1, 0, 0]))
        
        if mode == "Deutschland":
            self._align_to_location(51.1657, 10.4515)
        elif mode == "Nordpol":
            self.rotation_matrix = create_rotation_matrix(180.0, np.array([1, 0, 0]))
        elif mode == "Südpol":
            self.rotation_matrix = np.identity(4, dtype=np.float32)
        elif mode == "Äquator":
            self.rotation_matrix = base
        elif mode == "Ziel" and self.target_marker:
            self._align_to_location(self.target_marker.lat, self.target_marker.lon)
        
        self.update()

    def _render_labels(self):
        """Rendert Labels mit Ländercodes (wie im Original)"""
        from PyQt6 import QtGui, QtCore
        from core.config import get_theme_color
        import math
        import numpy as np
        
        if not self.show_labels:
            return
        
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QtGui.QPainter.RenderHint.TextAntialiasing)
        
        # Schriftart
        font = QtGui.QFont("Arial", 9, QtGui.QFont.Weight.Bold)
        painter.setFont(font)
        
        # MVP Matrix
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        viewport = np.array([0, 0, self.width(), self.height()])
        
        labels_to_draw = []
        
        # ✅ TRACEROUTE-HOPS mit IP + Ländercode (wie im Original!)
        if self.traceroute_markers and self.traceroute_hop_info:
            for i, marker in enumerate(self.traceroute_markers):
                if i >= len(self.traceroute_hop_info):
                    break
                
                screen_pos = self._project_to_screen(marker, mvp, viewport)
                if not screen_pos:
                    continue
                
                hop_info = self.traceroute_hop_info[i]
                hop_num = hop_info['hop_num']
                ip = hop_info.get('ip', 'N/A')
                rtt = hop_info.get('rtt', 0)
                
                # ✅ EXAKT WIE IM ORIGINAL: "Hop 5: IP: 62.52.165.98, DE (36.5ms)"
                # Hole Ländercode (robust gegen verschiedene Formate)
                if hasattr(marker, 'country_code') and marker.country_code:
                    country_code = marker.country_code
                elif hasattr(marker, 'country') and marker.country:
                    # Nimm ersten 2 Buchstaben als Code
                    country_code = marker.country[:2].upper()
                else:
                    country_code = '??'
                
                text = f"Hop {hop_num}: IP: {ip}, {country_code} ({rtt:.1f}ms)"
                
                # Cyan für Traceroute (wie im Original)
                color = (0, 255, 255)  # Cyan
                
                labels_to_draw.append({
                    'text': text,
                    'pos': screen_pos,
                    'color': color,
                    'priority': hop_num,
                    'type': 'traceroute',
                    'hop_num': hop_num
                })
        
        # ✅ SUCH-MARKER (Gelb, wie im Original)
        if self.search_markers:
            center_x = viewport[2] / 2
            center_y = viewport[3] / 2
            
            for marker in self.search_markers:
                screen_pos = self._project_to_screen(marker, mvp, viewport)
                if not screen_pos:
                    continue
                
                dist = math.sqrt((screen_pos[0] - center_x)**2 + (screen_pos[1] - center_y)**2)
                
                labels_to_draw.append({
                    'text': marker.name,
                    'pos': screen_pos,
                    'color': (255, 220, 80),  # Gelb
                    'priority': 100 + dist / 1000.0,
                    'type': 'search'
                })
        
        if not labels_to_draw:
            painter.end()
            return
        
        # Sortiere nach Priorität
        labels_to_draw.sort(key=lambda x: x['priority'])
        
        # ✅ INTELLIGENTE LABEL-POSITIONIERUNG (verhindert Überlappung)
        occupied_rects = []
        rendered_labels = []
        max_labels = 50
        
        for label_data in labels_to_draw:
            if len(rendered_labels) >= max_labels:
                break
            
            text = label_data['text']
            screen_x, screen_y = label_data['pos']
            color = label_data['color']
            label_type = label_data.get('type', 'unknown')
            
            # Textgröße
            text_rect = painter.fontMetrics().boundingRect(text)
            padding = 4
            offset = 12
            
            # ✅ POSITIONIERUNG: Traceroute abwechselnd links/rechts
            if label_type == 'traceroute':
                hop_num = label_data.get('hop_num', 0)
                if hop_num % 2 == 0:
                    # Links
                    label_x = screen_x - text_rect.width() - offset - 2 * padding
                else:
                    # Rechts
                    label_x = screen_x + offset
            else:
                # Such-Marker: rechts
                label_x = screen_x + offset
            
            label_y = screen_y - text_rect.height() / 2 - padding
            
            label_rect = QtCore.QRectF(
                label_x,
                label_y,
                text_rect.width() + 2 * padding,
                text_rect.height() + 2 * padding
            )
            
            # Kollisionsprüfung
            has_collision = False
            for occupied in occupied_rects:
                if label_rect.intersects(occupied):
                    has_collision = True
                    break
            
            if has_collision:
                # Versuche andere Seite
                if label_type == 'traceroute':
                    hop_num = label_data.get('hop_num', 0)
                    if hop_num % 2 == 0:
                        label_x = screen_x + offset
                    else:
                        label_x = screen_x - text_rect.width() - offset - 2 * padding
                    
                    label_rect = QtCore.QRectF(
                        label_x,
                        label_y,
                        text_rect.width() + 2 * padding,
                        text_rect.height() + 2 * padding
                    )
                    
                    # Nochmal prüfen
                    has_collision = False
                    for occupied in occupied_rects:
                        if label_rect.intersects(occupied):
                            has_collision = True
                            break
            
            if has_collision:
                # Überspringe wenn immer noch Kollision
                continue
            
            # ✅ ZEICHNE LABEL
            # Halbtransparenter schwarzer Hintergrund
            bg_color = QtGui.QColor(0, 0, 0, 200)
            painter.fillRect(label_rect, bg_color)
            
            # Farbiger Rand (Neon-Effekt)
            pen_color = QtGui.QColor(*color)
            pen = QtGui.QPen(pen_color, 1)
            painter.setPen(pen)
            painter.drawRect(label_rect)
            
            # Text in Neon-Farbe
            painter.setPen(pen_color)
            painter.drawText(
                int(label_rect.x() + padding),
                int(label_rect.y() + padding + text_rect.height() * 0.8),
                text
            )
            
            occupied_rects.append(label_rect)
            rendered_labels.append(label_data)
        
        painter.end()

    def _render_hover_tooltip(self):
        if not self.hovered_marker:
            return
        
        marker, hop_info = self.hovered_marker
        if not hop_info:
            return
        
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        viewport = np.array([0, 0, self.width(), self.height()])
        
        screen_pos = self._project_to_screen(marker, mvp, viewport)
        if not screen_pos:
            painter.end()
            return
        
        lines = [
            f"🔹 Hop {hop_info['hop_num']}",
            f"📍 {marker.name}, {marker.country}",
            f"🌐 {hop_info['ip']}",
            f"⏱️  {hop_info['rtt']:.1f}ms"
        ]
        
        if 'hostname' in hop_info and hop_info['hostname'] != hop_info['ip']:
            lines.insert(3, f"🖥️  {hop_info['hostname']}")
        
        font = QtGui.QFont()
        font.setPixelSize(12)
        painter.setFont(font)
        
        max_width = max(painter.fontMetrics().horizontalAdvance(line) for line in lines)
        line_height = painter.fontMetrics().height()
        padding = 10
        
        tooltip_width = max_width + 2 * padding
        tooltip_height = len(lines) * line_height + 2 * padding
        
        tooltip_x = screen_pos[0] + 25
        tooltip_y = screen_pos[1] - tooltip_height / 2
        
        if tooltip_x + tooltip_width > viewport[2]:
            tooltip_x = screen_pos[0] - tooltip_width - 25
        if tooltip_y < 0:
            tooltip_y = 0
        if tooltip_y + tooltip_height > viewport[3]:
            tooltip_y = viewport[3] - tooltip_height
        
        painter.setPen(QtCore.Qt.PenStyle.NoPen)
        painter.setBrush(QtGui.QColor(0, 0, 0, 150))
        painter.drawRoundedRect(
            int(tooltip_x + 2), int(tooltip_y + 2),
            int(tooltip_width), int(tooltip_height), 6, 6
        )
        
        painter.setBrush(QtGui.QColor(30, 30, 30, 240))
        painter.drawRoundedRect(
            int(tooltip_x), int(tooltip_y),
            int(tooltip_width), int(tooltip_height), 6, 6
        )
        
        painter.setPen(QtGui.QColor(*get_theme_color('label_traceroute')))
        y = tooltip_y + padding + line_height
        for line in lines:
            painter.drawText(int(tooltip_x + padding), int(y), line)
            y += line_height
        
        painter.end()
    
    def _project_to_screen(self, marker, mvp, viewport):
        from core.config import SPHERE_RADIUS
        
        pos_3d = marker.to_cartesian(SPHERE_RADIUS + self._get_marker_offset())
        pos_homogeneous = np.array([pos_3d[0], pos_3d[1], pos_3d[2], 1.0])
        
        pos_clip = mvp @ pos_homogeneous
        
        if abs(pos_clip[3]) < 0.0001:
            return None
        
        pos_ndc = pos_clip[:3] / pos_clip[3]
        
        if pos_clip[3] < 0 or pos_ndc[2] > 1.0:
            return None
        
        screen_x = (pos_ndc[0] + 1.0) * 0.5 * viewport[2]
        screen_y = (1.0 - pos_ndc[1]) * 0.5 * viewport[3]
        
        margin = 50
        if -margin <= screen_x <= viewport[2] + margin and -margin <= screen_y <= viewport[3] + margin:
            return (screen_x, screen_y)
        
        return None

    # ========================================================================
    # NEUE METHODEN FÜR LIVE CONNECTIONS (V0.2)
    # ========================================================================
    
    def set_connection_filters(self, show_incoming: bool, show_outgoing: bool):
        """Setzt Filter für Connection-Anzeige"""
        self.show_incoming_connections = show_incoming
        self.show_outgoing_connections = show_outgoing
        self.update()
    
    def set_animation_speed(self, speed: float):
        """Setzt die Animations-Geschwindigkeit (0.1 - 1.0)"""
        self.animation_speed = max(0.1, min(1.0, speed))
    
    def update_connections(self, connections):
        """Aktualisiert die angezeigten Verbindungen"""
        from core.geo_location import GeoLocation
        
        # Hole lokale Position (vereinfacht: Deutschland als Default)
        local_location = GeoLocation(
            name="Local",
            lat=51.1657,
            lon=10.4515,
            country="Germany"
        )
        
        self.connection_lines = []
        current_time = time.time()
        
        for conn in connections:
            # Skip wenn Koordinaten ungültig
            if conn.lat == 0.0 and conn.lon == 0.0:
                continue
            
            # Filter anwenden
            if conn.is_incoming and not self.show_incoming_connections:
                continue
            if conn.is_outgoing and not self.show_outgoing_connections:
                continue
            
            # Remote Location erstellen
            remote_location = GeoLocation(
                name=conn.city,
                lat=conn.lat,
                lon=conn.lon,
                country=conn.country
            )
            
            # Farbe basierend auf Richtung
            if conn.is_incoming:
                color = (0.3, 0.65, 1.0, 0.8)  # Blau
            else:
                color = (0.3, 1.0, 0.53, 0.8)  # Grün
            
            # Linie hinzufügen
            self.connection_lines.append({
                'start': local_location,
                'end': remote_location,
                'color': color,
                'timestamp': current_time,
                'direction': 'incoming' if conn.is_incoming else 'outgoing'
            })
        
        self.update()
    
    def clear_connection_lines(self):
        """Löscht alle Connection Lines"""
        self.connection_lines = []
        self.update()
    
    def _render_connection_lines(self, mvp):
        """Rendert animierte Connection Lines"""
        if not self.connection_lines:
            return
        
        from core.config import SPHERE_RADIUS
        
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glLineWidth(2.0)
        
        current_time = time.time()
        self.animation_offset = (current_time * self.animation_speed) % 1.0
        
        for line_data in self.connection_lines:
            start_loc = line_data['start']
            end_loc = line_data['end']
            color = line_data['color']
            
            # Berechne 3D-Punkte auf der Kugel
            start_pos = np.array(start_loc.to_cartesian(SPHERE_RADIUS + 0.02))
            end_pos = np.array(end_loc.to_cartesian(SPHERE_RADIUS + 0.02))
            
            # Zeichne gebogene Linie (vereinfacht: Segmente)
            segments = 30
            glBegin(GL_LINE_STRIP)
            
            for i in range(segments + 1):
                t = i / segments
                
                # Slerp (spherical interpolation) für sanfte Bögen
                # Vereinfachte Version: lineare Interpolation + Projektion auf Kugel
                pos = start_pos * (1 - t) + end_pos * t
                
                # Normalisieren und auf Kugel projizieren
                length = np.linalg.norm(pos)
                if length > 0:
                    pos = pos / length * (SPHERE_RADIUS + 0.02)
                
                # Animation: Pulsierender Effekt
                anim_factor = abs((t + self.animation_offset) % 1.0 - 0.5) * 2.0
                alpha = color[3] * (0.3 + 0.7 * anim_factor)
                
                glColor4f(color[0], color[1], color[2], alpha)
                
                # Transformiere mit MVP
                pos_homogeneous = np.array([pos[0], pos[1], pos[2], 1.0])
                glVertex3f(pos[0], pos[1], pos[2])
            
            glEnd()
        
        glDisable(GL_BLEND)
        glLineWidth(1.0)

    def take_screenshot(self):
        from datetime import datetime
        from core.config import SCREENSHOT_DIR
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = SCREENSHOT_DIR / f"earth_viewer_{timestamp}.png"
        
        pixmap = self.grab()
        pixmap.save(str(filename))
        
        print(f"📸 Screenshot: {filename}")
        return filename
