#!/usr/bin/env python3
"""
Globe Widget - LABELS WITH COUNTRY FIX 🌍
- Zeigt jetzt "Stadt, Land" in den Labels an (z.B. "Hop 7: London, GB")
- Tooltips zeigen ebenfalls detailliertere Ortsangaben
- Alle vorherigen Fixes (Satelliten, Linien, Performance) sind enthalten
"""
import numpy as np
import time
import math
from typing import List, Optional, Dict

from PyQt6 import QtCore, QtGui
from PyQt6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL.GL import *

from core.geo_location import GeoLocation
from core.config import (
    get_theme_color, EARTH_TEXTURE, CAMERA_DISTANCE, CAMERA_FOV, 
    CAMERA_NEAR, CAMERA_FAR, CAMERA_MIN_DISTANCE, CAMERA_MAX_DISTANCE, 
    ROTATION_SENSITIVITY, ZOOM_FACTOR, SPHERE_RADIUS
)
from rendering.gl_renderer import GLRenderer
from rendering.orbit_renderer import SatelliteOrbitRenderer
from utils.matrix_utils import create_rotation_matrix, create_projection_matrix, create_view_matrix

# Verbesserte Farben für bessere Sichtbarkeit
# Verbesserte Farben für bessere Sichtbarkeit
SAT_COLORS = {
    "Starlink":       (0.0, 1.0, 1.0, 1.0),  # Cyan - hell sichtbar
    "GPS":            (1.0, 0.0, 0.0, 1.0),  # Rot - kräftig
    "Space Stations": (0.0, 1.0, 0.0, 1.0),  # Grün - leuchtend
    "Weather":        (1.0, 1.0, 0.0, 1.0),  # Gelb - hell
    "Unknown":        (0.5, 0.5, 1.0, 0.9)   # Blau - sichtbar
}

class GlobeWidget(QOpenGLWidget):
    def __init__(self, parent=None):
        fmt = QtGui.QSurfaceFormat()
        fmt.setVersion(3, 3)
        fmt.setProfile(QtGui.QSurfaceFormat.OpenGLContextProfile.CompatibilityProfile)
        fmt.setDepthBufferSize(24)
        fmt.setStencilBufferSize(8)
        fmt.setSamples(4)
        super().__init__(parent)
        self.setFormat(fmt)
        
        self.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)
        
        self.renderer = GLRenderer(EARTH_TEXTURE)
        self.rotation_matrix = create_rotation_matrix(90.0, np.array([1, 0, 0]))
        self.camera_distance = CAMERA_DISTANCE
        self.last_mouse_pos = None
        self.auto_rotate = False
        
        self.search_markers: List[GeoLocation] = []
        self.target_marker: Optional[GeoLocation] = None
        self.traceroute_markers: List[GeoLocation] = []
        self.traceroute_hop_info: List[dict] = []
        self.live_connection_markers: List[dict] = []
        self.connection_lines: List[dict] = []
        
        self._satellite_batches: Dict[str, np.ndarray] = {}
        self._satellite_data_objs: Dict[str, list] = {}
        self.show_satellites = True
        self.orbit_renderer = SatelliteOrbitRenderer()
        
        self.hovered_item: Optional[dict] = None
        self.selected_satellite: Optional[dict] = None  # Click-to-Select
        self.selected_satellite: Optional[dict] = None  # Angeklickter Satellit
        
        from core.settings import settings
        self.show_markers = settings.get("show_markers", True)
        self.show_labels = settings.get("show_labels", True)
        self.auto_rotate_speed = settings.get("auto_rotate_speed", 0.3)
        
        self.show_incoming_connections = True
        self.show_outgoing_connections = True
        self.animation_speed = 0.5
        self.animation_offset = 0.0
        
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._on_timer)
        self.timer.start(16)

    def _get_marker_offset(self):
        from core import config
        return getattr(config, 'MARKER_OFFSET', 0.02)

    def _on_timer(self):
        if self.auto_rotate:
            self.rotate(-self.auto_rotate_speed, np.array([0, 1, 0]))
        if self.connection_lines or self._satellite_batches:
            self.update()

    def initializeGL(self):
        try:
            self.makeCurrent()
            import OpenGL
            OpenGL.ERROR_CHECKING = False
            self.renderer.initialize()
            
            # Initialize orbit renderer shaders
            if hasattr(self, 'orbit_renderer'):
                self.orbit_renderer.initialize_shaders()
        except Exception as e:
            print(f"FEHLER in initializeGL: {e}")

    def resizeGL(self, w: int, h: int):
        glViewport(0, 0, w, h)

    def paintGL(self):
        try:
            glClearColor(0.02, 0.02, 0.05, 1.0)
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
            
            projection, view, model = self._get_matrices()
            mvp = projection @ view @ model
            
            self.renderer.render_earth(mvp, model)
            
            all_traceroute = self.traceroute_markers
            all_live = [item['marker'] for item in self.live_connection_markers]

            if self.show_markers:
                self.renderer.render_markers(mvp, self.search_markers, self.target_marker, all_traceroute + all_live)

            if self.traceroute_markers:
                self.renderer.render_line(mvp, self.traceroute_markers)
            
            if self.connection_lines:
                self._render_connection_lines(mvp)

            if self.show_satellites and self._satellite_batches:
                try:
                    from rendering.satellite_sprites import SatelliteSpriteRenderer
                    if not hasattr(self, "satellite_renderer"):
                        self.satellite_renderer = SatelliteSpriteRenderer()
                    
                    for category, positions in self._satellite_batches.items():
                        color = SAT_COLORS.get(category, SAT_COLORS["Unknown"])
                        self.satellite_renderer.render_satellites(mvp, positions, tint=color)
                except Exception:
                    pass

            # Render orbital visualizations
            if hasattr(self, "orbit_renderer"):
                self._update_old_orbits()  # Auto-Update alte Orbits
                self.orbit_renderer.render_all(mvp)  # Orbit rendering aktiviert!

            painter = QtGui.QPainter(self)
            if self.show_labels:
                self._render_labels(painter)
            if self.hovered_item:
                self._render_hover_tooltip(painter)
            if self.selected_satellite:
                self._render_selected_satellite_info(painter)
            painter.end()

        except Exception as e:
            print(f"Render error: {e}")

    def _update_old_orbits(self):
        """Update orbits that are older than update_interval"""
        if not hasattr(self, 'orbit_renderer') or not hasattr(self, 'satellite_manager'):
            return
        
        import time
        current_time = time.time()
        
        for sat_name, orbit_data in list(self.orbit_renderer.active_orbits.items()):
            last_update = orbit_data.get('last_update', 0)
            update_interval = orbit_data.get('update_interval', 10.0)
            
            # Orbit zu alt?
            if current_time - last_update > update_interval:
                tle_line1 = orbit_data.get('tle_line1')
                tle_line2 = orbit_data.get('tle_line2')
                
                if tle_line1 and tle_line2:
                    # Neu berechnen
                    new_orbit_data = self.satellite_manager.calculate_orbit(sat_name)
                    if new_orbit_data and 'points' in new_orbit_data:
                        new_points = new_orbit_data['points']
                        self.orbit_renderer.update_orbit(sat_name, new_points)

            

    def set_satellites(self, satellites):
        if not satellites:
            self._satellite_batches = {}
            self._satellite_data_objs = {}
            self.update()
            return

        from core.config import SPHERE_RADIUS, MARKER_OFFSET
        batches = {}
        data_objs = {}
        
        for sat in satellites:
            cat = sat.category if hasattr(sat, 'category') and sat.category else "Unknown"
            lat_rad = math.radians(sat.lat)
            lon_rad = math.radians(sat.lon)
            alt_factor = 1.0 + (MARKER_OFFSET * 3.0) + (sat.alt_m / 6371000.0 * 0.5) 
            radius = SPHERE_RADIUS * alt_factor
            x = radius * math.cos(lat_rad) * math.sin(lon_rad)
            y = radius * math.sin(lat_rad)
            z = radius * math.cos(lat_rad) * math.cos(lon_rad)
            if cat not in batches: batches[cat] = []; data_objs[cat] = []
            batches[cat].append((x, y, z))
            data_objs[cat].append(sat)
            
        self._satellite_batches = {}
        self._satellite_data_objs = data_objs
        for cat, points in batches.items():
            self._satellite_batches[cat] = np.array(points, dtype=np.float32)
        self.update()

    def update_connections(self, connections):
        from core.geo_location import GeoLocation
        local = GeoLocation(name="Local", lat=51.1657, lon=10.4515)
        self.connection_lines = []
        self.live_connection_markers = []
        
        for conn in connections:
            if (conn.is_incoming and not self.show_incoming_connections) or (not conn.is_outgoing and not self.show_outgoing_connections): continue
            remote = GeoLocation(name=conn.city, lat=conn.lat, lon=conn.lon, country=conn.country) # Country wichtig!
            color = (0.3, 0.65, 1.0) if conn.is_incoming else (0.3, 1.0, 0.53)
            
            self.connection_lines.append({'start': local, 'end': remote, 'color': color, 'data': conn})
            self.live_connection_markers.append({'marker': remote, 'info': {'app_name': conn.app_name, 'ip': conn.remote_ip}})
            
        self.update()

    # ---------------------------------------------------------
    # LABELS MIT LAND-INFO
    # ---------------------------------------------------------
    def _render_labels(self, painter):
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        font = QtGui.QFont("Arial", 10, QtGui.QFont.Weight.Bold)
        painter.setFont(font)
        
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        viewport = np.array([0, 0, self.width(), self.height()])
        
        labels = []
        C_TARGET = (255, 0, 128)
        C_TRACE  = (0, 255, 255)
        C_LIVE   = (0, 255, 100)
        C_SEARCH = (255, 255, 0)
        
        # Helper um "Stadt, Land" zu bauen
        def make_label_text(name, country):
            if country and country != "Unknown":
                return f"{name}, {country}"
            return name
        
        if self.target_marker:
            pos = self._project_to_screen(self.target_marker, mvp, viewport)
            txt = make_label_text(self.target_marker.name, self.target_marker.country)
            if pos: labels.append({'text': txt, 'pos': pos, 'color': C_TARGET, 'force': True})

        # Traceroute Hops
        for i, m in enumerate(self.traceroute_markers):
            pos = self._project_to_screen(m, mvp, viewport)
            if pos:
                # Stadt + Land
                loc_str = make_label_text(m.name, m.country)
                text = f"Hop {i+1}: {loc_str}"
                labels.append({'text': text, 'pos': pos, 'color': C_TRACE, 'force': True})

        # Live Connections
        for item in self.live_connection_markers:
            m = item['marker']
            pos = self._project_to_screen(m, mvp, viewport)
            if pos:
                txt = make_label_text(m.name, m.country)
                labels.append({'text': txt, 'pos': pos, 'color': C_LIVE, 'force': True})

        # Search Results
        center_x, center_y = viewport[2]/2, viewport[3]/2
        visible_markers = []
        for m in self.search_markers:
            pos = self._project_to_screen(m, mvp, viewport)
            if pos:
                dist = math.hypot(pos[0]-center_x, pos[1]-center_y)
                visible_markers.append((m, pos, dist))
        visible_markers.sort(key=lambda x: x[2])
        
        for m, pos, dist in visible_markers[:50]:
            txt = make_label_text(m.name, m.country)
            labels.append({'text': txt, 'pos': pos, 'color': C_SEARCH, 'force': False, 'prio': dist})

        labels.sort(key=lambda x: (not x.get('force', False), x.get('prio', 0)))
        occupied_rects = []
        
        for l in labels:
            text = l['text']
            x, y = l['pos']
            color_tuple = l['color']
            metrics = painter.fontMetrics()
            rect = metrics.boundingRect(text)
            w, h = rect.width() + 12, rect.height() + 6
            label_x = x + 10
            label_y = y - h/2
            current_rect = QtCore.QRectF(label_x, label_y, w, h)
            
            collision = False
            if not l.get('force', False):
                for occ in occupied_rects:
                    if current_rect.intersects(occ):
                        collision = True; break
            
            if not collision:
                painter.setPen(QtGui.QPen(QtGui.QColor(*color_tuple), 1))
                painter.setBrush(QtGui.QColor(10, 10, 15, 220))
                painter.drawRoundedRect(current_rect, 4, 4)
                painter.setPen(QtGui.QColor(*color_tuple))
                painter.drawText(current_rect, QtCore.Qt.AlignmentFlag.AlignCenter, text)
                occupied_rects.append(current_rect)

    def _check_satellite_click(self, mouse_pos):
        """Prüft ob ein Satellit an der Mouse-Position geklickt wurde"""
        if not self.show_satellites or not self._satellite_batches:
            return None
        
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        viewport = np.array([0, 0, self.width(), self.height()])
        
        min_dist = 20  # Klick-Toleranz in Pixeln
        closest_sat = None
        
        for cat, batch in self._satellite_batches.items():
            if len(batch) > 2000 and cat == "Starlink":
                continue  # Zu viele Starlink-Satelliten
            
            sat_objs = self._satellite_data_objs.get(cat, [])
            for i, point in enumerate(batch):
                p_h = np.array([*point, 1.0])
                clip = mvp @ p_h
                if clip[3] > 0:
                    ndc = clip[:3] / clip[3]
                    if -1 <= ndc[0] <= 1 and -1 <= ndc[1] <= 1:
                        sx = (ndc[0] + 1.0) * 0.5 * viewport[2]
                        sy = (1.0 - ndc[1]) * 0.5 * viewport[3]
                        dist = math.hypot(sx - mouse_pos.x(), sy - mouse_pos.y())
                        if dist < min_dist:
                            min_dist = dist
                            closest_sat = {
                                'type': 'satellite',
                                'obj': sat_objs[i] if i < len(sat_objs) else None,
                                'category': cat,
                                'screen_pos': (sx, sy)
                            }
        
        return closest_sat

    def _check_sat_click(self, mp):
        """Verbesserte Satelliten-Klick-Detection mit 60px Toleranz"""
        if not self.show_satellites or not self._satellite_batches:
            return None
        
        pj, v, md = self._get_matrices()
        mvp = pj @ v @ md
        vp = np.array([0, 0, self.width(), self.height()])
        
        # SEHR GROSSE Toleranz für einfacheres Klicken
        max_tolerance = 60
        min_d = max_tolerance
        best = None
        
        click_x, click_y = mp.x(), mp.y()
        
        for cat, batch in self._satellite_batches.items():
            objs = self._satellite_data_objs.get(cat, [])
            
            for i, pt in enumerate(batch):
                # Transformiere 3D-Position zu Screen-Space
                ph = np.array([*pt, 1.0])
                cp = mvp @ ph
                
                # Prüfe ob vor der Kamera
                if cp[3] <= 0:
                    continue
                
                # Normalized Device Coordinates
                ndc = cp[:3] / cp[3]
                
                # Prüfe ob im Sichtbereich
                if not (-1 <= ndc[0] <= 1 and -1 <= ndc[1] <= 1):
                    continue
                
                # Screen-Koordinaten
                sx = (ndc[0] + 1) * 0.5 * vp[2]
                sy = (1 - ndc[1]) * 0.5 * vp[3]
                
                # Distanz zum Klick
                dx = sx - click_x
                dy = sy - click_y
                d = (dx*dx + dy*dy)**0.5
                
                # Finde nächsten Satelliten
                if d < min_d:
                    min_d = d
                    best = {
                        'obj': objs[i] if i < len(objs) else None, 
                        'cat': cat,
                        'screen_x': sx,
                        'screen_y': sy,
                        'distance': d
                    }
        
        if best:
            print(f"✅ Satellit getroffen!")
            print(f"   Distanz: {best['distance']:.1f}px")
            print(f"   Kategorie: {best['cat']}")
            print(f"   Screen: ({best['screen_x']:.0f}, {best['screen_y']:.0f})")
            print(f"   Click: ({click_x:.0f}, {click_y:.0f})")
        else:
            print(f"❌ Kein Satellit in 60px Umkreis gefunden")
            print(f"   Click: ({click_x:.0f}, {click_y:.0f})")
        
        return best

    def _check_hover(self, mouse_pos):
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        viewport = np.array([0, 0, self.width(), self.height()])
        closest_item, min_dist = None, 25

        for i, marker in enumerate(self.traceroute_markers):
            screen_pos = self._project_to_screen(marker, mvp, viewport)
            if screen_pos:
                dist = math.hypot(screen_pos[0] - mouse_pos.x(), screen_pos[1] - mouse_pos.y())
                if dist < min_dist:
                    min_dist = dist
                    closest_item = {'type': 'marker', 'marker': marker, 'info': self.traceroute_hop_info[i] if i < len(self.traceroute_hop_info) else {}}

        # Satelliten-Hover ist deaktiviert - nutze Click-to-Select stattdessen
        # if self.show_satellites and not closest_item:
        #     ... (deaktiviert)

        if not closest_item and self.connection_lines:
            mx, my = mouse_pos.x(), mouse_pos.y()
            for line in self.connection_lines:
                p1 = self._project_to_screen(line['start'], mvp, viewport)
                p2 = self._project_to_screen(line['end'], mvp, viewport)
                if p1 and p2:
                    dist = self._dist_to_segment(mx, my, p1[0], p1[1], p2[0], p2[1])
                    if dist < 10:
                        closest_item = {'type': 'connection', 'data': line['data']}
                        break

        if closest_item != self.hovered_item:
            self.hovered_item = closest_item
            self.update()

    def _dist_to_segment(self, px, py, x1, y1, x2, y2):
        l2 = (x1-x2)**2 + (y1-y2)**2
        if l2 == 0: return math.hypot(px-x1, py-y1)
        t = ((px-x1)*(x2-x1) + (py-y1)*(y2-y1)) / l2
        t = max(0, min(1, t))
        proj_x = x1 + t * (x2-x1)
        proj_y = y1 + t * (y2-y1)
        return math.hypot(px-proj_x, py-proj_y)

    def _render_hover_tooltip(self, painter):
        if not self.hovered_item: return
        t = self.hovered_item['type']
        
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        viewport = np.array([0, 0, self.width(), self.height()])
        pos = None
        lines = []
        header_color = QtGui.QColor(255, 255, 255)

        if t == 'marker':
            marker = self.hovered_item['marker']
            info = self.hovered_item.get('info', {})
            pos = self._project_to_screen(marker, mvp, viewport)
            header_color = QtGui.QColor(0, 255, 255)
            lines.append(f"🔹 Hop {info.get('hop_num', '?')}")
            
            # LAND IN TOOLTIP
            loc_str = marker.name
            if marker.country and marker.country != "Unknown":
                loc_str += f", {marker.country}"
            lines.append(f"📍 {loc_str}")
            
            lines.append(f"🌐 {info.get('ip', 'N/A')}")
            lines.append(f"⏱️  {info.get('rtt', 0.0):.1f}ms")

        elif t == 'satellite':
            sat = self.hovered_item['obj']
            from core.config import SPHERE_RADIUS, MARKER_OFFSET
            r = SPHERE_RADIUS * (1.0 + (MARKER_OFFSET * 3.0) + (sat.alt_m / 6371000.0 * 0.5))
            temp = GeoLocation("temp", sat.lat, sat.lon)
            pos = self._project_to_screen(temp, mvp, viewport, override_radius=r)
            header_color = QtGui.QColor(255, 200, 50)
            lines.append(f"🛰️ {sat.name}")
            lines.append(f"Höhe: {sat.alt_m/1000:.0f} km")
            lines.append(f"Pos: {sat.lat:.2f}°, {sat.lon:.2f}°")

        elif t == 'connection':
            data = self.hovered_item['data']
            pos = (self.mapFromGlobal(QtGui.QCursor.pos()).x(), self.mapFromGlobal(QtGui.QCursor.pos()).y())
            if data.is_incoming:
                header_color = QtGui.QColor(100, 255, 100)
                lines.append(f"📥 Incoming: {data.app_name}")
            else:
                header_color = QtGui.QColor(100, 200, 255)
                lines.append(f"📤 Outgoing: {data.app_name}")
            lines.append(f"Remote: {data.remote_ip}")
            
            # LAND IN TOOLTIP
            loc_str = data.city
            if data.country and data.country != "Unknown":
                loc_str += f", {data.country}"
            lines.append(f"Ort: {loc_str}")
            
            lines.append(f"Proto: {data.protocol} Port: {data.remote_port}")

        if pos and lines:
            painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
            font = QtGui.QFont("Arial", 10)
            painter.setFont(font)
            fm = painter.fontMetrics()
            max_w = max([fm.horizontalAdvance(l) for l in lines])
            line_h = fm.height()
            w, h = max_w + 20, (len(lines) * line_h) + 20
            x, y = int(pos[0]+15), int(pos[1]+15)
            
            if x + w > self.width(): x -= w + 30
            if y + h > self.height(): y -= h + 30
            
            painter.setBrush(QtGui.QColor(30, 30, 35, 240))
            painter.setPen(QtGui.QPen(header_color, 1))
            painter.drawRoundedRect(x, y, w, h, 6, 6)
            
            for i, line in enumerate(lines):
                painter.setPen(header_color if i == 0 else QtGui.QColor(220, 220, 220))
                painter.drawText(x+10, y + 20 + (i * line_h), line)

    def _render_selected_satellite_info(self, painter):
        """Rendert die Info-Box für den selektierten Satelliten, die sich mitbewegt"""
        if not self.selected_satellite:
            return
        
        sat = self.selected_satellite.get('obj')
        if not sat:
            return
        
        # Berechne aktuelle Position des Satelliten
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        viewport = np.array([0, 0, self.width(), self.height()])
        
        from core.config import SPHERE_RADIUS, MARKER_OFFSET
        from core.geo_location import GeoLocation
        
        r = SPHERE_RADIUS * (1.0 + (MARKER_OFFSET * 3.0) + (sat.alt_m / 6371000.0 * 0.5))
        temp_loc = GeoLocation("temp", sat.lat, sat.lon)
        pos = self._project_to_screen(temp_loc, mvp, viewport, override_radius=r)
        
        if not pos:
            return
        
        # Info-Box Inhalt
        sat_name = sat.name if hasattr(sat, 'name') else "Unknown"
        sat_alt = f"{sat.alt_m/1000:.0f} km" if hasattr(sat, 'alt_m') else "N/A"
        sat_lat = f"{sat.lat:.2f}°" if hasattr(sat, 'lat') else "N/A"
        sat_lon = f"{sat.lon:.2f}°" if hasattr(sat, 'lon') else "N/A"
        category = self.selected_satellite.get('category', 'Unknown')
        
        lines = [
            f"🛰️ {sat_name}",
            f"📂 Kategorie: {category}",
            f"📏 Höhe: {sat_alt}",
            f"🌐 Position: {sat_lat}, {sat_lon}"
        ]
        
        # Berechne Box-Größe
        font = QtGui.QFont("Arial", 10, QtGui.QFont.Weight.Bold)
        painter.setFont(font)
        metrics = QtGui.QFontMetrics(font)
        
        max_width = max(metrics.horizontalAdvance(line) for line in lines) + 20
        line_height = metrics.height()
        box_height = len(lines) * (line_height + 4) + 16
        
        # Position der Box (mit Offset vom Satelliten)
        box_x = int(pos[0]) + 15
        box_y = int(pos[1]) - box_height // 2
        
        # Halte Box im sichtbaren Bereich
        if box_x + max_width > self.width():
            box_x = int(pos[0]) - max_width - 15
        if box_y < 0:
            box_y = 0
        if box_y + box_height > self.height():
            box_y = self.height() - box_height
        
        # Zeichne Umrandung um Satelliten (großer Kreis)
        painter.setPen(QtGui.QPen(QtGui.QColor(0, 255, 0), 3))  # Grüner Rahmen
        painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
        painter.drawEllipse(QtCore.QPoint(int(pos[0]), int(pos[1])), 12, 12)
        
        # Zeichne Verbindungslinie
        painter.setPen(QtGui.QPen(QtGui.QColor(0, 255, 0, 150), 2))
        painter.drawLine(int(pos[0]), int(pos[1]), box_x, box_y + box_height // 2)
        
        # Zeichne Info-Box Hintergrund
        box_rect = QtCore.QRect(box_x, box_y, max_width, box_height)
        painter.setPen(QtGui.QPen(QtGui.QColor(0, 255, 0), 2))  # Grüner Rahmen
        painter.setBrush(QtGui.QColor(0, 0, 0, 200))  # Halbtransparenter schwarzer Hintergrund
        painter.drawRoundedRect(box_rect, 8, 8)
        
        # Zeichne Text
        painter.setPen(QtGui.QColor(255, 255, 255))  # Weißer Text
        y_offset = box_y + line_height + 4
        
        for i, line in enumerate(lines):
            if i == 0:
                # Header in Kategorie-Farbe
                color_rgba = SAT_COLORS.get(category, SAT_COLORS["Unknown"])
                color = QtGui.QColor(
                    int(color_rgba[0] * 255),
                    int(color_rgba[1] * 255),
                    int(color_rgba[2] * 255)
                )
                painter.setPen(color)
                painter.drawText(box_x + 10, y_offset, line)
                painter.setPen(QtGui.QColor(255, 255, 255))  # Zurück zu weiß
            else:
                painter.drawText(box_x + 10, y_offset, line)
            y_offset += line_height + 4

    def _render_selected_sat(self, painter):
        """Rendert Info für selektierten Satelliten"""
        if not self.selected_satellite:
            return
        sat = self.selected_satellite.get('obj')
        if not sat:
            return
        from core.config import SPHERE_RADIUS, MARKER_OFFSET
        from core.geo_location import GeoLocation
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        vp = np.array([0, 0, self.width(), self.height()])
        r = SPHERE_RADIUS * (1.0 + (MARKER_OFFSET * 3.0) + (sat.alt_m / 6371000.0 * 0.5))
        loc = GeoLocation("t", sat.lat, sat.lon)
        pos = self._project_to_screen(loc, mvp, vp, override_radius=r)
        if not pos:
            return
        name = sat.name if hasattr(sat, 'name') else "Unknown"
        alt = f"{sat.alt_m/1000:.0f} km" if hasattr(sat, 'alt_m') else "N/A"
        lat = f"{sat.lat:.2f}°" if hasattr(sat, 'lat') else "N/A"
        lon = f"{sat.lon:.2f}°" if hasattr(sat, 'lon') else "N/A"
        cat = self.selected_satellite.get('cat', 'Unknown')
        lines = [f"🛰️ {name}", f"📂 {cat}", f"📏 {alt}", f"🌐 {lat}, {lon}"]
        font = QtGui.QFont("Arial", 10, QtGui.QFont.Weight.Bold)
        painter.setFont(font)
        fm = QtGui.QFontMetrics(font)
        w = max(fm.horizontalAdvance(l) for l in lines) + 20
        h = len(lines) * (fm.height() + 4) + 16
        bx = int(pos[0]) + 15
        by = int(pos[1]) - h // 2
        if bx + w > self.width():
            bx = int(pos[0]) - w - 15
        if by < 0:
            by = 0
        if by + h > self.height():
            by = self.height() - h
        painter.setPen(QtGui.QPen(QtGui.QColor(0, 255, 0), 3))
        painter.setBrush(QtCore.Qt.BrushStyle.NoBrush)
        painter.drawEllipse(QtCore.QPoint(int(pos[0]), int(pos[1])), 12, 12)
        painter.setPen(QtGui.QPen(QtGui.QColor(0, 255, 0, 150), 2))
        painter.drawLine(int(pos[0]), int(pos[1]), bx, by + h // 2)
        painter.setPen(QtGui.QPen(QtGui.QColor(0, 255, 0), 2))
        painter.setBrush(QtGui.QColor(0, 0, 0, 200))
        painter.drawRoundedRect(QtCore.QRect(bx, by, w, h), 8, 8)
        painter.setPen(QtGui.QColor(255, 255, 255))
        y = by + fm.height() + 4
        for i, l in enumerate(lines):
            if i == 0:
                c = SAT_COLORS.get(cat, SAT_COLORS["Unknown"])
                painter.setPen(QtGui.QColor(int(c[0]*255), int(c[1]*255), int(c[2]*255)))
                painter.drawText(bx + 10, y, l)
                painter.setPen(QtGui.QColor(255, 255, 255))
            else:
                painter.drawText(bx + 10, y, l)
            y += fm.height() + 4

    def _render_sel_sat(self, ptr):
        """Verbesserte Info-Box mit größerem Rahmen"""
        if not self.selected_satellite:
            return
        st = self.selected_satellite.get('obj')
        if not st:
            return
        
        from core.config import SPHERE_RADIUS, MARKER_OFFSET
        from core.geo_location import GeoLocation
        
        pj, v, md = self._get_matrices()
        mvp = pj @ v @ md
        vp = np.array([0, 0, self.width(), self.height()])
        
        r = SPHERE_RADIUS * (1 + (MARKER_OFFSET * 3) + (st.alt_m / 6371000 * 0.5))
        loc = GeoLocation("t", st.lat, st.lon)
        pos = self._project_to_screen(loc, mvp, vp, override_radius=r)
        
        if not pos:
            return
        
        # Info zusammenstellen
        nm = st.name if hasattr(st, 'name') else "Unknown"
        alt = f"{st.alt_m/1000:.0f} km" if hasattr(st, 'alt_m') else "N/A"
        cat = st.category if hasattr(st, 'category') else self.selected_satellite.get('cat', 'Unknown')
        lat = f"{st.lat:.2f}°" if hasattr(st, 'lat') else "N/A"
        lon = f"{st.lon:.2f}°" if hasattr(st, 'lon') else "N/A"
        
        lines = [
            f"🛰️  {nm}",
            f"📂  {cat}",
            f"📏  Höhe: {alt}",
            f"🌐  Lat: {lat}",
            f"🌐  Lon: {lon}"
        ]
        
        # Größere, besser lesbare Schrift
        ft = QtGui.QFont("Arial", 12, QtGui.QFont.Weight.Bold)
        ptr.setFont(ft)
        fm = QtGui.QFontMetrics(ft)
        
        # Berechne Box-Größe mit mehr Padding
        w = max(fm.horizontalAdvance(l) for l in lines) + 30
        h = len(lines) * (fm.height() + 6) + 25
        
        # Position mit besserem Abstand
        bx = int(pos[0]) + 25
        by = int(pos[1]) - h // 2
        
        # Halte im Bildschirm
        if bx + w > self.width() - 10:
            bx = int(pos[0]) - w - 25
        if by < 10:
            by = 10
        if by + h > self.height() - 10:
            by = self.height() - h - 10
        
        # GROSSER Selektions-Kreis (20px statt 15px)
        ptr.setPen(QtGui.QPen(QtGui.QColor(0, 255, 0), 4))
        ptr.setBrush(QtCore.Qt.BrushStyle.NoBrush)
        ptr.drawEllipse(QtCore.QPoint(int(pos[0]), int(pos[1])), 20, 20)
        
        # Verbindungslinie
        ptr.setPen(QtGui.QPen(QtGui.QColor(0, 255, 0, 200), 3))
        line_end_x = bx if bx > pos[0] else bx + w
        ptr.drawLine(int(pos[0]), int(pos[1]), line_end_x, by + h // 2)
        
        # Info-Box mit dickerem Rahmen
        ptr.setPen(QtGui.QPen(QtGui.QColor(0, 255, 0), 3))
        ptr.setBrush(QtGui.QColor(0, 0, 0, 230))
        ptr.drawRoundedRect(QtCore.QRect(bx, by, w, h), 12, 12)
        
        # Text zeichnen
        y = by + fm.height() + 10
        for i, l in enumerate(lines):
            if i == 0:
                # Name in Kategorie-Farbe
                cc = SAT_COLORS.get(cat, SAT_COLORS["Unknown"])
                ptr.setPen(QtGui.QColor(int(cc[0]*255), int(cc[1]*255), int(cc[2]*255)))
            else:
                ptr.setPen(QtGui.QColor(255, 255, 255))
            
            ptr.drawText(bx + 15, y, l)
            y += fm.height() + 6

    def _project_to_screen(self, marker, mvp, viewport, override_radius=None):
        from core.config import SPHERE_RADIUS
        r = override_radius or (SPHERE_RADIUS + self._get_marker_offset())
        pos_3d = marker.to_cartesian(r)
        pos_hom = np.array([*pos_3d, 1.0])
        pos_clip = mvp @ pos_hom
        if abs(pos_clip[3]) < 1e-6: return None
        pos_ndc = pos_clip[:3] / pos_clip[3]
        if not (-1.2 <= pos_ndc[0] <= 1.2 and -1.2 <= pos_ndc[1] <= 1.2): return None
        if pos_clip[3] < 0: return None
        _, view, model = self._get_matrices()
        norm_view = ((view @ model) @ np.array([*(pos_3d / np.linalg.norm(pos_3d)), 0.0]))[:3]
        if norm_view[2] < 0.0: return None 
        return ((pos_ndc[0] + 1.0) * 0.5 * viewport[2], (1.0 - pos_ndc[1]) * 0.5 * viewport[3])

    def _get_matrices(self):
        aspect = self.width() / max(1.0, self.height())
        projection = create_projection_matrix(CAMERA_FOV, aspect, CAMERA_NEAR, CAMERA_FAR)
        view = create_view_matrix(self.camera_distance)
        return projection, view, self.rotation_matrix

    def navigate_to(self, location: GeoLocation):
        self.target_marker = location
        self._align_to_location(location.lat, location.lon)
        self.update()

    def _align_to_location(self, lat: float, lon: float):
        base = create_rotation_matrix(90.0, np.array([1, 0, 0]))
        rot_y = create_rotation_matrix(-lon, np.array([0, 1, 0]))
        rot_x = create_rotation_matrix(lat - 90.0, np.array([1, 0, 0]))
        self.rotation_matrix = rot_x @ rot_y @ base

    def set_search_results(self, locations: List[GeoLocation]):
        self.search_markers = locations
        if locations: self.navigate_to(locations[0])
        else: self.update()

    def clear_markers(self):
        self.search_markers, self.target_marker, self.traceroute_markers = [], None, []
        self.update()

    def rotate(self, angle: float, axis: np.ndarray):
        self.rotation_matrix = create_rotation_matrix(angle, axis) @ self.rotation_matrix
        self.update()

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            # Prüfe ob ein Satellit geklickt wurde
            clicked_sat = self._check_satellite_click(event.position())
            
            if clicked_sat:
                # Toggle: Wenn gleicher Satellit -> deselektieren, sonst selektieren
                if self.selected_satellite and self.selected_satellite.get('obj') == clicked_sat.get('obj'):
                    self.selected_satellite = None
                    print("🛰️ Satellit deselektiert")
                else:
                    self.selected_satellite = clicked_sat
                    sat_name = clicked_sat['obj'].name if hasattr(clicked_sat['obj'], 'name') else "Unknown"
                    print(f"🛰️ Satellit selektiert: {sat_name}")
                self.update()
            else:
                # Normales Drag-Verhalten
                self.last_mouse_pos = event.position()

    def mouseMoveEvent(self, event):
        if not (event.buttons() & QtCore.Qt.MouseButton.LeftButton):
            self._check_hover(event.position())
        if self.last_mouse_pos and (event.buttons() & QtCore.Qt.MouseButton.LeftButton):
            delta = event.position() - self.last_mouse_pos
            rot_y = create_rotation_matrix(delta.x() * ROTATION_SENSITIVITY, np.array([0, 1, 0]))
            rot_x = create_rotation_matrix(delta.y() * ROTATION_SENSITIVITY, np.array([1, 0, 0]))
            self.rotation_matrix = rot_x @ rot_y @ self.rotation_matrix
            self.update()
        self.last_mouse_pos = event.position()

    def mouseReleaseEvent(self, event): self.last_mouse_pos = None
    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        factor = ZOOM_FACTOR if delta > 0 else 1.0 / ZOOM_FACTOR
        self.camera_distance = max(CAMERA_MIN_DISTANCE, min(CAMERA_MAX_DISTANCE, self.camera_distance * factor))
        self.update()
    
    def rotate_up(self): self.rotate(5.0, np.array([1, 0, 0]))
    def rotate_down(self): self.rotate(-5.0, np.array([1, 0, 0]))
    def rotate_left(self): self.rotate(5.0, np.array([0, 1, 0]))
    def rotate_right(self): self.rotate(-5.0, np.array([0, 1, 0]))
    
    def align_view(self, mode: str):
        base = create_rotation_matrix(90.0, np.array([1, 0, 0]))
        if mode == "Deutschland": self._align_to_location(51.1657, 10.4515)
        elif mode == "Nordpol": self.rotation_matrix = create_rotation_matrix(180.0, np.array([1, 0, 0]))
        elif mode == "Südpol": self.rotation_matrix = np.identity(4, dtype=np.float32)
        elif mode == "Äquator": self.rotation_matrix = base
        elif mode == "Ziel" and self.target_marker: self._align_to_location(self.target_marker.lat, self.target_marker.lon)
        self.update()

    def set_connection_filters(self, show_incoming, show_outgoing): 
        self.show_incoming_connections, self.show_outgoing_connections = show_incoming, show_outgoing
    
    def set_animation_speed(self, speed): self.animation_speed = speed
    
    def clear_connection_lines(self): self.connection_lines = []

    
    def _create_arc_points(self, start_geo, end_geo, num_segments: int = 64,
    
                           height_factor: float = 0.15) -> np.ndarray:
    
        """Erzeugt eine gekrümmte Verbindung (Great-Circle-Arc) zwischen zwei GeoLocation-Punkten."""
    
        from core import config
    
    
    
        base_radius = config.SPHERE_RADIUS + getattr(config, "MARKER_OFFSET", 0.02) * 1.5
    
    
    
        s = np.array(start_geo.to_cartesian(base_radius), dtype=np.float64)
    
        e = np.array(end_geo.to_cartesian(base_radius), dtype=np.float64)
    
    
    
        s_n = s / np.linalg.norm(s)
    
        e_n = e / np.linalg.norm(e)
    
    
    
        dot = float(np.clip(np.dot(s_n, e_n), -1.0, 1.0))
    
        if dot > 0.9999:
    
            return np.array([s, e], dtype=np.float32)
    
    
    
        omega = np.arccos(dot)
    
        sin_omega = np.sin(omega)
    
    
    
        points = []
    
        for i in range(num_segments + 1):
    
            t = i / num_segments
    
            factor_s = np.sin((1.0 - t) * omega) / sin_omega
    
            factor_e = np.sin(t * omega) / sin_omega
    
            p = factor_s * s_n + factor_e * e_n
    
    
    
            lift = np.sin(np.pi * t) * height_factor
    
            p = p * (1.0 + lift)
    
    
    
            points.append(p * base_radius)
    
    
    
        return np.array(points, dtype=np.float32)

    
    def _render_connection_lines(self, mvp):

    
        """Rendert Live-Verbindungen als gekrümmte Bögen über der Erdoberfläche."""

    
        if not self.connection_lines:

    
            return

    
    

    
        self.animation_offset = (time.time() * self.animation_speed * 0.5) % 1.0

    
    

    
        glEnable(GL_BLEND)

    
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

    
    

    
        for line in self.connection_lines:

    
            start_geo = line["start"]

    
            end_geo = line["end"]

    
    

    
            arc_points = self._create_arc_points(

    
                start_geo,

    
                end_geo,

    
                num_segments=72,

    
                height_factor=0.18

    
            )

    
    

    
            self.renderer.render_line(

    
                mvp,

    
                arc_points,

    
                color=line.get("color", (0.3, 0.65, 1.0))

    
            )

    
    

    
        glDisable(GL_BLEND)
    
    # ========== ORBIT VISUALIZATION METHODS ==========
    
    def toggle_satellite_orbit(self, sat, show):
        """Toggle Orbit-Linie mit Berechnung"""
        if not hasattr(self, 'orbit_renderer'):
            return
        
        if show:
            # Berechne Orbit-Punkte
            if hasattr(self, 'satellite_manager'):
                orbit_data = self.satellite_manager.calculate_orbit(sat.name)
                if orbit_data and 'points' in orbit_data:
                    orbit_points = orbit_data['points']
                    if len(orbit_points) > 0:
                        print(f"🎯 Orbit berechnet: {len(orbit_points)} Punkte für {sat.name}")
                        # Hole TLE-Daten
                        tle_line1, tle_line2 = sat.tle_line1, sat.tle_line2
                        self.orbit_renderer.add_orbit(sat.name, orbit_points, tle_line1, tle_line2)
                    else:
                        print(f"⚠️ Orbit-Array leer für {sat.name}")
                else:
                    print(f"⚠️ Keine Orbit-Daten für {sat.name}")
            else:
                print("⚠️ Kein satellite_manager!")
        else:
            self.orbit_renderer.remove_orbit(sat.name)
        
        self.update()
    
    def toggle_satellite_velocity(self, sat, show):
        """Toggle Bewegungsrichtung"""
        if hasattr(self, 'orbit_renderer'):
            self.orbit_renderer.toggle_velocity(sat, show)
            self.update()
    
    def toggle_satellite_trail(self, sat, show):
        """Toggle Trail"""
        if hasattr(self, 'orbit_renderer'):
            self.orbit_renderer.toggle_trail(sat, show)
            self.update()
    
    def toggle_satellite_ground_track(self, sat, show):
        """Toggle Ground Track"""
        if hasattr(self, 'orbit_renderer'):
            self.orbit_renderer.toggle_ground_track(sat, show)
            self.update()
    
    # =================================================
    
def take_screenshot(self):
        from datetime import datetime; from core.config import SCREENSHOT_DIR
        filename = SCREENSHOT_DIR / f"earth_viewer_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        self.grab().save(str(filename)); return filename
