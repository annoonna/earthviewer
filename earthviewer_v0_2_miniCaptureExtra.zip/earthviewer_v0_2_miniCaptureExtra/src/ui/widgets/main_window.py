#!/usr/bin/env python3
"""
Main Window - Vollständige Version mit Top-Bar, Zahnrad und Marker-Einstellungen
"""
from PyQt6 import QtWidgets, QtGui, QtCore
from ui.widgets.globe_widget import GlobeWidget
from ui.widgets.sidebar import Sidebar
from data.geo_manager import GeoDataManager
from core.settings import settings
from core.config import (
    WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT,
    PROJECT_ROOT, MARKER_OFFSET
)

class MainWindow(QtWidgets.QMainWindow):
    """Hauptfenster"""
    
    def __init__(self):
        super().__init__()
        self.resize(WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setMinimumSize(WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT)
        
        self.geo_manager = GeoDataManager()
        
        # Lade gespeicherte Einstellungen
        from core import config
        config.MARKER_OFFSET = settings.get("marker_offset", 0.02)
        print(f"📐 Marker-Höhe geladen: {config.MARKER_OFFSET:.3f}")
        self.favorites = []
        
        self._setup_ui()
        self._apply_theme()
        
        self.ui_timer = QtCore.QTimer(self)
        self.ui_timer.timeout.connect(self._update_ui)
        self.ui_timer.start(100)
    
    def _setup_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        
        main_layout = QtWidgets.QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # TOP-BAR
        top_bar = QtWidgets.QFrame()
        top_bar.setStyleSheet("""
            QFrame {
                background: #1e1e1e;
                padding: 10px;
                border-bottom: 2px solid #0d7377;
            }
        """)
        
        top_layout = QtWidgets.QHBoxLayout(top_bar)
        
        icon_label = QtWidgets.QLabel("🔍")
        icon_label.setStyleSheet("color: white; font-size: 18px;")
        top_layout.addWidget(icon_label)
        
        self.search_input = QtWidgets.QLineEdit()
        self.search_input.setPlaceholderText("Stadt, Land, IP oder mehrere Städte (z.B. 'berlin leipzig koblenz' oder '52.52, 13.405')")
        self.search_input.setStyleSheet("""
            QLineEdit {
                padding: 12px;
                font-size: 14px;
                background: #2b2b2b;
                color: white;
                border: 1px solid #555;
                border-radius: 4px;
            }
            QLineEdit:focus {
                border: 1px solid #0d7377;
            }
        """)
        self.search_input.returnPressed.connect(self._on_search_from_topbar)
        top_layout.addWidget(self.search_input, 1)
        
        search_btn = QtWidgets.QPushButton("Suchen")
        search_btn.setStyleSheet("""
            QPushButton {
                padding: 12px 30px;
                background: #0d7377;
                color: white;
                font-weight: bold;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover { background: #0e8388; }
            QPushButton:pressed { background: #0a5d5f; }
        """)
        search_btn.clicked.connect(self._on_search_from_topbar)
        top_layout.addWidget(search_btn)
        
        settings_btn = QtWidgets.QPushButton("⚙️")
        settings_btn.setToolTip("Erweiterte Einstellungen")
        settings_btn.setStyleSheet("""
            QPushButton {
                padding: 12px 15px;
                background: #3a3a3a;
                color: white;
                font-size: 16px;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover { background: #4a4a4a; }
        """)
        settings_btn.clicked.connect(self._show_settings)
        top_layout.addWidget(settings_btn)

        # 🎨 THEME BUTTON
        theme_btn = QtWidgets.QPushButton("🎨")
        theme_btn.setToolTip("Theme & Farben anpassen")
        theme_btn.setStyleSheet("""
            QPushButton {
                padding: 12px 15px;
                background: #3a3a3a;
                color: white;
                font-size: 16px;
                border: none;
                border-radius: 4px;
                margin-left: 5px;
            }
            QPushButton:hover { background: #4a4a4a; }
        """)
        theme_btn.clicked.connect(self._show_theme_dialog)
        top_layout.addWidget(theme_btn)
        
        main_layout.addWidget(top_bar)
        
        # CONTENT
        splitter = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
        
        self.globe = GlobeWidget(self)
        splitter.addWidget(self.globe)
        
        self.sidebar = Sidebar(self.globe, self.geo_manager, self)
        self.sidebar.search_requested.connect(self._on_search)
        self.sidebar.result_list.itemDoubleClicked.connect(self._on_result_clicked)
        splitter.addWidget(self.sidebar)
        
        splitter.setStretchFactor(0, 7)
        splitter.setStretchFactor(1, 3)
        
        main_layout.addWidget(splitter)
    
    def _apply_theme(self):
        palette = QtGui.QPalette()
        palette.setColor(QtGui.QPalette.ColorRole.Window, QtGui.QColor(43, 43, 43))
        palette.setColor(QtGui.QPalette.ColorRole.WindowText, QtGui.QColor(255, 255, 255))
        palette.setColor(QtGui.QPalette.ColorRole.Base, QtGui.QColor(30, 30, 30))
        palette.setColor(QtGui.QPalette.ColorRole.Text, QtGui.QColor(255, 255, 255))
        palette.setColor(QtGui.QPalette.ColorRole.Highlight, QtGui.QColor(13, 115, 119))
        self.setPalette(palette)
    
    def _on_search_from_topbar(self):
        self._on_search(self.search_input.text())
    
    def _on_search(self, query: str):
        query = query.strip()
        if not query:
            return
        
        self.sidebar.result_list.clear()
        self.globe.clear_markers()
        
        results = self.geo_manager.search(query)
        
        if results:
            self.sidebar.update_results(results)
            self.globe.set_search_results(results)
            self.sidebar.update_status(f"{len(results)} Ergebnisse gefunden")
        else:
            item = QtWidgets.QListWidgetItem("❌ Keine Ergebnisse gefunden")
            item.setFlags(QtCore.Qt.ItemFlag.NoItemFlags)
            self.sidebar.result_list.addItem(item)
            self.sidebar.update_status("Keine Ergebnisse")
    
    def _on_result_clicked(self, item):
        location = item.data(QtCore.Qt.ItemDataRole.UserRole)
        if location:
            self.globe.navigate_to(location)
    
    def _show_theme_dialog(self):
        """Zeigt Theme-Auswahl"""
        from ui.theme_dialog import ThemeDialog
        
        dialog = ThemeDialog(self)
        dialog.theme_changed.connect(self._on_theme_changed)
        dialog.exec()
    
    def _on_theme_changed(self, theme_name: str):
        """Theme wurde geändert"""
        print(f"🎨 Theme gewechselt zu: {theme_name}")
        self.globe.update()

    def _show_settings(self):
        """Zeigt Einstellungs-Dialog MIT MARKER-EINSTELLUNGEN"""
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("⚙️ Erweiterte Einstellungen")
        dialog.setMinimumWidth(500)
        dialog.setStyleSheet("""
            QDialog {
                background: #2b2b2b;
                color: white;
            }
            QLabel {
                color: white;
                padding: 5px;
            }
            QGroupBox {
                color: white;
                font-weight: bold;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 15px 10px 10px 10px;
                margin-top: 10px;
            }
            QSlider::groove:horizontal {
                height: 6px;
                background: #555;
                border-radius: 3px;
            }
            QSlider::handle:horizontal {
                background: #0d7377;
                width: 16px;
                margin: -5px 0;
                border-radius: 8px;
            }
            QDoubleSpinBox {
                background: #3a3a3a;
                color: white;
                border: 1px solid #555;
                padding: 5px;
                border-radius: 3px;
            }
        """)
        
        layout = QtWidgets.QVBoxLayout(dialog)
        
        # ANIMATIONEN
        anim_group = QtWidgets.QGroupBox("🎬 Animationen")
        anim_layout = QtWidgets.QFormLayout(anim_group)
        
        speed_layout = QtWidgets.QHBoxLayout()
        speed_slider = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
        speed_slider.setMinimum(1)
        speed_slider.setMaximum(100)
        speed_slider.setValue(int(self.globe.auto_rotate_speed * 100))
        speed_label = QtWidgets.QLabel(f"{self.globe.auto_rotate_speed:.2f}°/Frame")
        
        def on_speed_change(value):
            self.globe.auto_rotate_speed = value / 100.0
            settings.set("auto_rotate_speed", value / 100.0)
            speed_label.setText(f"{self.globe.auto_rotate_speed:.2f}°/Frame")
        
        speed_slider.valueChanged.connect(on_speed_change)
        speed_layout.addWidget(speed_slider)
        speed_layout.addWidget(speed_label)
        anim_layout.addRow("Rotations-Geschwindigkeit:", speed_layout)
        
        layout.addWidget(anim_group)
        
        # MARKER-EINSTELLUNGEN
        marker_group = QtWidgets.QGroupBox("🏷️ Marker")
        marker_layout = QtWidgets.QFormLayout(marker_group)
        
        offset_spin = QtWidgets.QDoubleSpinBox()
        offset_spin.setMinimum(0.001)
        offset_spin.setMaximum(0.1)
        offset_spin.setValue(MARKER_OFFSET)
        offset_spin.setSingleStep(0.005)
        offset_spin.setDecimals(3)
        
        def on_offset_change(value):
            from core import config
            config.MARKER_OFFSET = value
            settings.set("marker_offset", value)
            # Force refresh der Marker
            current_markers = self.globe.search_markers.copy()
            self.globe.clear_markers()
            self.globe.search_markers = current_markers
            self.globe.update()
        
        offset_spin.valueChanged.connect(on_offset_change)
        marker_layout.addRow("Marker-Höhe:", offset_spin)
        
        layout.addWidget(marker_group)
        
        # SCHLIESSEN-BUTTON
        button_layout = QtWidgets.QHBoxLayout()
        
        apply_btn = QtWidgets.QPushButton("✓ Schließen")
        apply_btn.setStyleSheet("""
            QPushButton {
                padding: 10px 20px;
                background: #0d7377;
                color: white;
                font-weight: bold;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover { background: #0e8388; }
        """)
        apply_btn.clicked.connect(dialog.accept)
        
        button_layout.addWidget(apply_btn)
        layout.addLayout(button_layout)
        
        dialog.exec()
    
    def _update_ui(self):
        self.sidebar.update_zoom(self.globe.camera_distance)
