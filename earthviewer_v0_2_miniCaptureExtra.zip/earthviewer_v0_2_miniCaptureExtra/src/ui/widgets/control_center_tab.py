#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Control Center Tab – Launcher für die große Control-Center-Ansicht
"""

from PyQt6 import QtWidgets
from ui.widgets.control_center_window import ControlCenterWindow


class ControlCenterTab(QtWidgets.QWidget):
    """
    Leichter Tab, der nur die große Control-Center-Ansicht öffnet.
    """

    def __init__(self, network_monitor, connection_tracker=None, parent=None):
        super().__init__(parent)
        self.monitor = network_monitor
        self.connection_tracker = connection_tracker
        self.window = None
        self._setup_ui()

    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        title = QtWidgets.QLabel("🖥️ WLAN Control Center")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: white;")
        layout.addWidget(title)

        desc = QtWidgets.QLabel(
            "Hier kannst du das vollständige WLAN Control Center in einer großen Ansicht öffnen.\n"
            "Die große Ansicht enthält das WLAN-Monitor-Panel, Live-Statistiken und Verbindungsübersicht."
        )
        desc.setWordWrap(True)
        desc.setStyleSheet("color: #cccccc; font-size: 11px;")
        layout.addWidget(desc)

        layout.addSpacing(10)

        open_btn = QtWidgets.QPushButton("🔍 Große Ansicht öffnen")
        open_btn.setStyleSheet(
            "padding: 12px 18px; background: #00838f; color: white; "
            "border: none; border-radius: 6px; font-weight: bold; font-size: 14px;"
        )
        open_btn.clicked.connect(self._open_window)
        layout.addWidget(open_btn)

        layout.addStretch()

        hint = QtWidgets.QLabel(
            "Tipp: Du kannst das große Control Center auf einen zweiten Monitor legen\n"
            "und EarthViewer weiter normal bedienen."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #777777; font-size: 10px;")
        layout.addWidget(hint)

        self.setStyleSheet("background-color: #202020; color: white;")

    def _open_window(self):
        if self.window is None or not self.window.isVisible():
            self.window = ControlCenterWindow(self.monitor, self.connection_tracker, self)
            self.window.show()
        else:
            self.window.raise_()
            self.window.activateWindow()
