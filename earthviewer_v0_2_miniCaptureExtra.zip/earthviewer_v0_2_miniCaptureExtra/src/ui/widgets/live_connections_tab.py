#!/usr/bin/env python3
"""
Live Connections Tab - Zeigt animierte Netzwerkverbindungen auf dem Globus
+ VirusTotal-Integration pro Remote-IP
"""

from PyQt6 import QtWidgets, QtCore, QtGui
from typing import Dict, List

# VirusTotal optional einbinden
try:
    from network.virustotal_analyzer import get_virustotal_analyzer
except Exception:  # z.B. wenn Modul fehlt
    get_virustotal_analyzer = None


class LiveConnectionsTab(QtWidgets.QWidget):
    """Tab für Live-Verbindungsanzeige"""

    # Spaltenindex für die VirusTotal-Spalte
    VT_COL_INDEX = 3  # ["Stadt/Land", "Richtung", "Protokoll", "VirusTotal"]

    def __init__(self, globe_widget, connection_tracker, parent=None):
        super().__init__(parent)
        self.globe_widget = globe_widget
        self.connection_tracker = connection_tracker

        # VirusTotal
        self.vt = get_virustotal_analyzer() if get_virustotal_analyzer else None
        self._ip_item_map: Dict[str, List[QtWidgets.QTreeWidgetItem]] = {}
        self._scanned_ips: set[str] = set()

        self._setup_ui()

        # Verbindungs-Signal vom ConnectionTracker
        self.connection_tracker.connections_updated.connect(
            self._on_connections_updated
        )

        # VT-Signale anbinden (falls vorhanden)
        if self.vt is not None:
            if hasattr(self.vt, "scan_result"):
                self.vt.scan_result.connect(self._on_virustotal_result)
            if hasattr(self.vt, "scan_error"):
                self.vt.scan_error.connect(self._on_virustotal_error)

        # interner Zustand
        self.is_tracking = False

    # ------------------------------------------------------------------ #
    # UI
    # ------------------------------------------------------------------ #
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)

        # Button für große Ansicht
        large_view_btn = QtWidgets.QPushButton("📈 Große Live-Analyse öffnen")
        large_view_btn.setStyleSheet(
            "padding: 8px 14px; background: #0d7377; color: white; "
            "border-radius: 6px; font-weight: bold;"
        )
        large_view_btn.clicked.connect(self._open_large_view)
        layout.addWidget(large_view_btn)

        # Header
        title = QtWidgets.QLabel("🌐 Live Verbindungen")
        title.setStyleSheet(
            "font-size: 16px; font-weight: bold; color: white; padding: 4px 0;"
        )
        layout.addWidget(title)

        info = QtWidgets.QLabel(
            "Zeigt alle aktiven Netzwerkverbindungen in Echtzeit auf dem Globus.\n"
            "VirusTotal-Status wird pro Remote-IP angezeigt (wenn API-Key konfiguriert)."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color: #aaaaaa; font-size: 11px;")
        layout.addWidget(info)

        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.HLine)
        line.setStyleSheet("background: #333333;")
        layout.addWidget(line)

        # --- Control Panel ------------------------------------------------
        control_group = QtWidgets.QGroupBox("⚙️ Anzeigeoptionen")
        control_group.setStyleSheet(
            "QGroupBox { color: white; font-weight: bold; padding: 6px; }"
        )
        control_layout = QtWidgets.QVBoxLayout()

        # Start / Stop Tracking
        tracking_layout = QtWidgets.QHBoxLayout()
        self.tracking_btn = QtWidgets.QPushButton("▶️  Tracking starten")
        self.tracking_btn.setStyleSheet(
            "padding: 8px 18px; background: #0d7377; color: white; "
            "border: none; border-radius: 6px; font-weight: bold;"
        )
        self.tracking_btn.clicked.connect(self._toggle_tracking)
        tracking_layout.addWidget(self.tracking_btn)

        self.clear_btn = QtWidgets.QPushButton("🗑️  Löschen")
        self.clear_btn.setStyleSheet(
            "padding: 8px 18px; background: #8b4513; color: white; "
            "border: none; border-radius: 6px; font-weight: bold;"
        )
        self.clear_btn.clicked.connect(self._clear_connections)
        tracking_layout.addWidget(self.clear_btn)

        tracking_layout.addStretch()
        control_layout.addLayout(tracking_layout)

        # Filter
        filter_layout = QtWidgets.QHBoxLayout()
        self.show_incoming_cb = QtWidgets.QCheckBox("📥 Incoming (Blau)")
        self.show_incoming_cb.setChecked(True)
        self.show_incoming_cb.setStyleSheet("color: #4da6ff; font-weight: bold;")
        self.show_incoming_cb.stateChanged.connect(self._update_filters)
        filter_layout.addWidget(self.show_incoming_cb)

        self.show_outgoing_cb = QtWidgets.QCheckBox("📤 Outgoing (Grün)")
        self.show_outgoing_cb.setChecked(True)
        self.show_outgoing_cb.setStyleSheet("color: #4dff88; font-weight: bold;")
        self.show_outgoing_cb.stateChanged.connect(self._update_filters)
        filter_layout.addWidget(self.show_outgoing_cb)

        filter_layout.addStretch()
        control_layout.addLayout(filter_layout)

        # Animations-Geschwindigkeit
        speed_layout = QtWidgets.QHBoxLayout()
        speed_layout.addWidget(QtWidgets.QLabel("🎬 Animations-Geschwindigkeit:"))
        self.speed_slider = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
        self.speed_slider.setRange(1, 10)
        self.speed_slider.setValue(5)
        self.speed_slider.setStyleSheet(
            "QSlider::groove:horizontal { background: #3a3a3a; height: 6px; } "
            "QSlider::handle:horizontal { background: #0d7377; width: 16px; "
            "margin: -4px 0; border-radius: 8px; }"
        )
        self.speed_slider.valueChanged.connect(self._update_animation_speed)
        speed_layout.addWidget(self.speed_slider)

        self.speed_label = QtWidgets.QLabel("5")
        self.speed_label.setStyleSheet("color: white; font-weight: bold; min-width: 20px;")
        speed_layout.addWidget(self.speed_label)

        control_layout.addLayout(speed_layout)
        control_group.setLayout(control_layout)
        layout.addWidget(control_group)

        # --- Statistiken --------------------------------------------------
        stats_group = QtWidgets.QGroupBox("📊 Statistiken")
        stats_group.setStyleSheet(
            "QGroupBox { color: white; font-weight: bold; padding: 6px; }"
        )
        stats_layout = QtWidgets.QVBoxLayout()

        self.total_label = QtWidgets.QLabel("Gesamt: 0")
        self.total_label.setStyleSheet("color: white; padding: 2px;")
        stats_layout.addWidget(self.total_label)

        self.incoming_label = QtWidgets.QLabel("📥 Incoming: 0")
        self.incoming_label.setStyleSheet("color: #4da6ff; padding: 2px;")
        stats_layout.addWidget(self.incoming_label)

        self.outgoing_label = QtWidgets.QLabel("📤 Outgoing: 0")
        self.outgoing_label.setStyleSheet("color: #4dff88; padding: 2px;")
        stats_layout.addWidget(self.outgoing_label)

        stats_group.setLayout(stats_layout)
        layout.addWidget(stats_group)

        # --- Liste der Verbindungen --------------------------------------
        list_label = QtWidgets.QLabel("📋 Aktive Verbindungen")
        list_label.setStyleSheet("font-weight: bold; color: white; padding-top: 6px;")
        layout.addWidget(list_label)

        self.connection_list = QtWidgets.QTreeWidget()
        self.connection_list.setHeaderLabels(
            ["Stadt/Land", "Richtung", "Protokoll", "VirusTotal"]
        )
        self.connection_list.setRootIsDecorated(False)
        self.connection_list.setAlternatingRowColors(True)
        self.connection_list.setStyleSheet(
            """
            QTreeWidget {
                background: #1e1e1e;
                color: white;
                border: 1px solid #3a3a3a;
                font-family: monospace;
                font-size: 11px;
            }
            QTreeWidget::item:selected {
                background: #0d7377;
            }
            """
        )
        self.connection_list.itemClicked.connect(self._on_connection_clicked)
        layout.addWidget(self.connection_list, 1)

    # ------------------------------------------------------------------ #
    # Steuerung
    # ------------------------------------------------------------------ #
    def _toggle_tracking(self):
        if not self.is_tracking:
            self.connection_tracker.start()
            self.tracking_btn.setText("⏸️  Tracking pausieren")
            self.tracking_btn.setStyleSheet(
                "padding: 8px 18px; background: #d9534f; color: white; "
                "border: none; border-radius: 6px; font-weight: bold;"
            )
            self.is_tracking = True
        else:
            self.connection_tracker.stop()
            self.tracking_btn.setText("▶️  Tracking starten")
            self.tracking_btn.setStyleSheet(
                "padding: 8px 18px; background: #0d7377; color: white; "
                "border: none; border-radius: 6px; font-weight: bold;"
            )
            self.is_tracking = False

    def _clear_connections(self):
        self.connection_list.clear()
        self._ip_item_map.clear()
        self._scanned_ips.clear()
        try:
            self.globe_widget.clear_connection_lines()
        except Exception:
            pass
        self.total_label.setText("Gesamt: 0")
        self.incoming_label.setText("📥 Incoming: 0")
        self.outgoing_label.setText("📤 Outgoing: 0")

    def _update_filters(self):
        show_incoming = self.show_incoming_cb.isChecked()
        show_outgoing = self.show_outgoing_cb.isChecked()
        try:
            self.connection_tracker.set_filters(show_incoming, show_outgoing)
        except Exception:
            pass
        try:
            self.globe_widget.set_connection_filters(show_incoming, show_outgoing)
        except Exception:
            pass

    def _update_animation_speed(self, value: int):
        self.speed_label.setText(str(value))
        try:
            self.globe_widget.set_animation_speed(value / 10.0)
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # Daten-Update vom ConnectionTracker
    # ------------------------------------------------------------------ #
    def _on_connections_updated(self, connections):
        """Wird aufgerufen, wenn der ConnectionTracker neue Daten liefert."""
        self.connection_list.clear()
        self._ip_item_map.clear()

        incoming_count = 0
        outgoing_count = 0

        # connections ist typischerweise eine Liste von Objekten mit:
        # app_name, remote_ip, city, country, protocol, is_incoming, lat, lon
        for conn in connections:
            # Richtung
            direction_icon = "📥" if getattr(conn, "is_incoming", False) else "📤"
            direction_text = f"{direction_icon} {'IN' if conn.is_incoming else 'OUT'}"

            if conn.is_incoming:
                incoming_count += 1
            else:
                outgoing_count += 1

            # Stadt/Land
            city = getattr(conn, "city", "") or "Unknown"
            country = getattr(conn, "country", "") or "Unknown"
            location_text = f"{city}, {country}"

            protocol = getattr(conn, "protocol", "") or "?"

            item = QtWidgets.QTreeWidgetItem(
                [location_text, direction_text, protocol, "–"]
            )

            # Grundfarbe
            for col in range(4):
                item.setForeground(col, QtGui.QBrush(QtGui.QColor("#ffffff")))

            # Richtung farblich hervorheben
            if conn.is_incoming:
                item.setForeground(1, QtGui.QBrush(QtGui.QColor("#4da6ff")))
            else:
                item.setForeground(1, QtGui.QBrush(QtGui.QColor("#4dff88")))

            # Tooltip mit Details
            tooltip = f"App: {getattr(conn, 'app_name', 'Unknown')}\nIP: {getattr(conn, 'remote_ip', '')}"
            item.setToolTip(0, tooltip)

            # Verbindung-Objekt speichern
            item.setData(0, QtCore.Qt.ItemDataRole.UserRole, conn)

            # Map IP -> Items
            remote_ip = getattr(conn, "remote_ip", "") or ""
            if remote_ip:
                self._ip_item_map.setdefault(remote_ip, []).append(item)

            self.connection_list.addTopLevelItem(item)

        total = len(connections)
        self.total_label.setText(f"Gesamt: {total}")
        self.incoming_label.setText(f"📥 Incoming: {incoming_count}")
        self.outgoing_label.setText(f"📤 Outgoing: {outgoing_count}")

        # Globus updaten
        try:
            self.globe_widget.update_connections(connections)
        except Exception:
            pass

        # Auto-VirusTotal-Scan für jede neue Remote-IP
        if self.vt is not None and hasattr(self.vt, "is_auto_scan_enabled"):
            if self.vt.is_auto_scan_enabled():
                for ip in self._ip_item_map.keys():
                    if ip and ip not in self._scanned_ips:
                        self._start_virustotal_scan(ip)

    # ------------------------------------------------------------------ #
    # VirusTotal
    # ------------------------------------------------------------------ #
    def _start_virustotal_scan(self, ip: str):
        if self.vt is None:
            return
        ip = (ip or "").strip()
        if not ip:
            return

        self._scanned_ips.add(ip)
        items = self._ip_item_map.get(ip, [])

        for it in items:
            it.setText(self.VT_COL_INDEX, "⏳ Scan…")
            it.setForeground(
                self.VT_COL_INDEX, QtGui.QBrush(QtGui.QColor("#aaaaaa"))
            )
            it.setToolTip(self.VT_COL_INDEX, "VirusTotal-Scan läuft...")

        try:
            self.vt.scan_ip(ip)
        except Exception as e:
            print(f"[LiveConnectionsTab] Fehler beim Starten des VT-Scans: {e}")

    def _on_virustotal_result(self, target: str, result: dict):
        """Callback vom VirusTotalAnalyzer bei Erfolg."""
        if not target or target not in self._ip_item_map:
            return

        items = self._ip_item_map.get(target, [])
        if not items:
            return

        text = "ℹ️ Keine Daten"
        tooltip = ""
        level = "unknown"

        if self.vt is not None:
            try:
                if hasattr(self.vt, "format_summary"):
                    text = self.vt.format_summary(result)
                if hasattr(self.vt, "format_tooltip"):
                    tooltip = self.vt.format_tooltip(result)
                if hasattr(self.vt, "get_threat_level"):
                    level = self.vt.get_threat_level(result)
            except Exception as e:
                print(f"[LiveConnectionsTab] Fehler bei VT-Auswertung: {e}")

        # Farbe je nach Level
        if level == "danger":
            color = QtGui.QColor("#ff4444")
        elif level == "warning":
            color = QtGui.QColor("#ffcc33")
        elif level == "ok":
            color = QtGui.QColor("#55dd55")
        else:
            color = QtGui.QColor("#cccccc")

        for it in items:
            it.setText(self.VT_COL_INDEX, text)
            it.setForeground(self.VT_COL_INDEX, QtGui.QBrush(color))
            if tooltip:
                it.setToolTip(self.VT_COL_INDEX, tooltip)

    def _on_virustotal_error(self, target: str, message: str):
        """Callback vom VirusTotalAnalyzer bei Fehlern."""
        if not target or target not in self._ip_item_map:
            return

        items = self._ip_item_map.get(target, [])
        for it in items:
            it.setText(self.VT_COL_INDEX, "⚠️ Fehler")
            it.setForeground(
                self.VT_COL_INDEX, QtGui.QBrush(QtGui.QColor("#ffcc33"))
            )
            it.setToolTip(self.VT_COL_INDEX, message or "VirusTotal-Fehler")

    # ------------------------------------------------------------------ #
    # Item-Klick / Navigation
    # ------------------------------------------------------------------ #
    def _on_connection_clicked(self, item: QtWidgets.QTreeWidgetItem, column: int):
        conn = item.data(0, QtCore.Qt.ItemDataRole.UserRole)
        if not conn:
            return

        # Globus zentrieren
        try:
            from core.geo_location import GeoLocation

            location = GeoLocation(
                name=f"{getattr(conn, 'city', '')}, {getattr(conn, 'country', '')}",
                lat=getattr(conn, "lat", 0.0),
                lon=getattr(conn, "lon", 0.0),
                country=getattr(conn, "country", ""),
            )
            self.globe_widget.navigate_to(location)
        except Exception:
            pass

        # Falls Auto-Scan aus ist: Klick startet manuell einen Scan
        if self.vt is not None and hasattr(self.vt, "is_auto_scan_enabled"):
            if not self.vt.is_auto_scan_enabled():
                ip = getattr(conn, "remote_ip", "") or ""
                if ip:
                    self._start_virustotal_scan(ip)

    def _open_large_view(self):
        """Öffnet das große Live-Analyse-Fenster."""
        try:
            from .live_connections_window import LiveConnectionsWindow

            self.large_window = LiveConnectionsWindow(self.connection_tracker, self)
            self.large_window.show()
        except Exception as e:
            print(f"[LiveConnectionsTab] Fehler beim Öffnen der großen Ansicht: {e}")
