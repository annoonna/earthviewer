#!/usr/bin/env python3
"""Process Detail Window - OHNE SUDO mit Monitor-Daten + VirusTotal"""

from PyQt6 import QtWidgets, QtCore, QtGui
from utils.country_flags import get_flag
import psutil
import os
from typing import Dict, Optional

# VirusTotal optional einbinden
try:
    from network.virustotal_analyzer import get_virustotal_analyzer
except Exception:  # falls Modul fehlt oder Import-Fehler
    get_virustotal_analyzer = None


class ProcessDetailWindow(QtWidgets.QDialog):
    def __init__(self, process_name, monitor, parent=None):
        super().__init__(parent)
        self.process_name = process_name
        self.monitor = monitor

        from data.geo_manager import GeoDataManager
        self.geo_manager = GeoDataManager()

        # VirusTotal-Integration
        self.vt_analyzer = None
        self.vt_enabled = False      # nur True, wenn Analyzer + API-Key
        self.vt_results: Dict[str, dict] = {}  # ip -> VT-Result
        self.vt_known_ips: set[str] = set()    # bereits angefragte IPs

        if get_virustotal_analyzer is not None:
            try:
                self.vt_analyzer = get_virustotal_analyzer()
                # Nur aktiv, wenn API-Key gesetzt ist
                if self.vt_analyzer and self.vt_analyzer.config.api_key:
                    self.vt_analyzer.scan_result.connect(self._on_vt_result)
                    self.vt_analyzer.scan_error.connect(self._on_vt_error)
                    self.vt_enabled = True
            except Exception as e:
                print(f"⚠️ VirusTotal im ProcessDetailWindow deaktiviert: {e}")
                self.vt_analyzer = None
                self.vt_enabled = False

        self.setWindowTitle(f"📊 {process_name} - Details")
        self.resize(800, 600)
        self._setup_ui()
        self._start_updates()

    # ------------------------------------------------------------------ #
    #   UI
    # ------------------------------------------------------------------ #
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(15, 15, 15, 15)

        # Header
        header = QtWidgets.QHBoxLayout()

        icon_label = QtWidgets.QLabel("🦊")
        icon_label.setStyleSheet("font-size: 48px;")
        header.addWidget(icon_label)

        name_label = QtWidgets.QLabel(self.process_name)
        name_label.setStyleSheet("font-size: 24px; font-weight: bold; color: white;")
        header.addWidget(name_label)
        header.addStretch()

        close_btn = QtWidgets.QPushButton("❌ Schließen")
        close_btn.setStyleSheet(
            "padding: 8px 16px; background: #d32f2f; color: white; "
            "border: none; border-radius: 4px;"
        )
        close_btn.clicked.connect(self.close)
        header.addWidget(close_btn)

        layout.addLayout(header)

        # Tabs
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane { background: #1e1e1e; border: 1px solid #3a3a3a; }
            QTabBar::tab { background: #2a2a2a; color: white; padding: 10px 20px; margin-right: 2px; }
            QTabBar::tab:selected { background: #0d7377; }
        """)

        self.info_tab = self._create_info_tab()
        self.tabs.addTab(self.info_tab, "ℹ️ Info")

        self.hosts_tab = self._create_hosts_tab()
        self.tabs.addTab(self.hosts_tab, "🌐 Hosts")

        self.alarms_tab = self._create_alarms_tab()
        self.tabs.addTab(self.alarms_tab, "⚠️ Alarme")

        layout.addWidget(self.tabs)
        self.setStyleSheet("QDialog { background: #1e1e1e; }")

    def _create_info_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        # Bandbreite
        bandwidth_group = QtWidgets.QGroupBox("📊 Bandbreite")
        bandwidth_group.setStyleSheet("QGroupBox { color: white; font-weight: bold; }")
        bandwidth_layout = QtWidgets.QHBoxLayout()

        self.download_label = QtWidgets.QLabel("↓ 0 B")
        self.download_label.setStyleSheet("color: #4caf50; font-size: 16px; padding: 10px;")
        bandwidth_layout.addWidget(self.download_label)

        self.upload_label = QtWidgets.QLabel("↑ 0 B")
        self.upload_label.setStyleSheet("color: #ff9800; font-size: 16px; padding: 10px;")
        bandwidth_layout.addWidget(self.upload_label)

        bandwidth_group.setLayout(bandwidth_layout)
        layout.addWidget(bandwidth_group)

        # Details
        details_group = QtWidgets.QGroupBox("📋 Details")
        details_group.setStyleSheet("QGroupBox { color: white; font-weight: bold; }")
        details_layout = QtWidgets.QFormLayout()
        details_layout.setLabelAlignment(QtCore.Qt.AlignmentFlag.AlignRight)

        self.name_value = QtWidgets.QLabel(self.process_name)
        self.name_value.setStyleSheet("color: white; padding: 5px;")
        details_layout.addRow("Name:", self.name_value)

        self.path_value = QtWidgets.QLabel("Lädt...")
        self.path_value.setStyleSheet("color: white; padding: 5px;")
        self.path_value.setWordWrap(True)
        details_layout.addRow("Pfad:", self.path_value)

        self.version_value = QtWidgets.QLabel("N/A")
        self.version_value.setStyleSheet("color: white; padding: 5px;")
        details_layout.addRow("Version:", self.version_value)

        self.publisher_value = QtWidgets.QLabel("Lädt...")
        self.publisher_value.setStyleSheet("color: white; padding: 5px;")
        details_layout.addRow("Herausgeber:", self.publisher_value)

        # VirusTotal-Status für diese App (aggregiert über alle Hosts)
        self.virus_value = QtWidgets.QLabel("–")
        self.virus_value.setStyleSheet("color: #9e9e9e; padding: 5px;")
        self.virus_value.setToolTip(
            "VirusTotal-Status für alle Remote-IP-Adressen dieses Prozesses.\n"
            "Automatische Analysen werden über das WLAN Control Center gesteuert."
        )
        details_layout.addRow("VirusTotal:", self.virus_value)

        details_group.setLayout(details_layout)
        layout.addWidget(details_group)
        layout.addStretch()
        return widget

    def _create_hosts_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        info = QtWidgets.QLabel("Verbundene Hosts für diesen Prozess")
        info.setStyleSheet("color: #888; padding: 5px;")
        layout.addWidget(info)

        self.hosts_table = QtWidgets.QTableWidget()
        self.hosts_table.setColumnCount(3)
        self.hosts_table.setHorizontalHeaderLabels(["Host", "Port", "Traffic"])
        self.hosts_table.horizontalHeader().setStretchLastSection(True)
        self.hosts_table.verticalHeader().setVisible(False)
        self.hosts_table.setStyleSheet("""
            QTableWidget { background: #1e1e1e; color: white; gridline-color: #3a3a3a; }
            QHeaderView::section { background: #2a2a2a; color: white; padding: 8px; font-weight: bold; }
        """)
        layout.addWidget(self.hosts_table)
        return widget

    def _create_alarms_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        info = QtWidgets.QLabel("Verdächtige Aktivitäten und Warnungen")
        info.setStyleSheet("color: #888; padding: 5px;")
        layout.addWidget(info)

        self.alarms_list = QtWidgets.QListWidget()
        self.alarms_list.setStyleSheet("""
            QListWidget { background: #1e1e1e; color: white; border: 1px solid #3a3a3a; }
            QListWidget::item { padding: 10px; border-bottom: 1px solid #3a3a3a; }
        """)
        layout.addWidget(self.alarms_list)
        return widget

    # ------------------------------------------------------------------ #
    #   Update-Loop
    # ------------------------------------------------------------------ #
    def _start_updates(self):
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._update_all_data)
        self.timer.start(1000)
        self._update_all_data()

    def _update_all_data(self):
        """Aktualisiert ALLE Daten - OHNE SUDO aus Monitor-Daten!"""
        import re

        # Flagge aus Prozessnamen entfernen (z.B. "🇺🇸 firefox-esr")
        clean_process_name = re.sub(r'^[^\w\s]+\s+', '', self.process_name)

        # -------------------------------------------------------------- #
        # Pfad & Publisher
        # -------------------------------------------------------------- #
        for proc in psutil.process_iter(['name', 'exe']):
            try:
                if proc.info['name'] == clean_process_name:
                    exe_path = proc.info['exe'] or "Unbekannt"
                    self.path_value.setText(exe_path)

                    if 'mozilla' in exe_path.lower():
                        self.publisher_value.setText("Mozilla Corporation")
                    elif 'google' in exe_path.lower() or 'chromium' in exe_path.lower():
                        self.publisher_value.setText("Google LLC / Chromium")
                    else:
                        self.publisher_value.setText("Unknown")
                    break
            except Exception:
                pass

        # -------------------------------------------------------------- #
        # Bandbreite vom Monitor
        # -------------------------------------------------------------- #
        apps = self.monitor.get_top_apps(100)
        for app, traffic in apps:
            if app == clean_process_name:
                download = int(traffic * 0.6)
                upload = int(traffic * 0.4)
                self.download_label.setText(f"↓ {self._format_bytes(download)}")
                self.upload_label.setText(f"↑ {self._format_bytes(upload)}")
                break

        # -------------------------------------------------------------- #
        # Hosts-Tabelle
        # -------------------------------------------------------------- #
        hosts_data = self.monitor.get_hosts_for_app(clean_process_name, limit=50)
        self.hosts_table.setRowCount(len(hosts_data))

        current_ips = set()

        for i, (host_ip, traffic) in enumerate(hosts_data):
            current_ips.add(host_ip)

            # Host + Flagge
            try:
                loc = self.geo_manager.lookup_ip(host_ip)
                if loc and loc.country:
                    flag = get_flag(loc.country)
                    display_name = f"{flag} {host_ip}"
                else:
                    display_name = f"🌐 {host_ip}"
            except Exception:
                display_name = f"🌐 {host_ip}"

            self.hosts_table.setItem(i, 0, QtWidgets.QTableWidgetItem(display_name))

            port_item = QtWidgets.QTableWidgetItem("N/A")
            port_item.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            self.hosts_table.setItem(i, 1, port_item)

            traffic_item = QtWidgets.QTableWidgetItem(self._format_bytes(traffic))
            traffic_item.setTextAlignment(
                QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter
            )
            self.hosts_table.setItem(i, 2, traffic_item)

        # -------------------------------------------------------------- #
        # VirusTotal: neue IPs scannen (abhängig von Auto-Scan-Einstellung)
        # -------------------------------------------------------------- #
        if self.vt_enabled and self.vt_analyzer:
            try:
                auto = bool(self.vt_analyzer.is_auto_scan_enabled())
            except Exception:
                auto = False

            if auto:
                # Nur IPs scannen, die wir noch nicht kennen
                for ip in current_ips:
                    if ip not in self.vt_known_ips:
                        self.vt_known_ips.add(ip)
                        self.vt_analyzer.scan_ip(ip, force=False)

        # Anzeige aus bereits vorhandenen Ergebnissen aktualisieren
        self._update_virus_label()

        # -------------------------------------------------------------- #
        # Alarme
        # -------------------------------------------------------------- #
        self.alarms_list.clear()
        if len(hosts_data) > 10:
            self.alarms_list.addItem("⚠️ Ungewöhnlich viele Verbindungen")
        elif len(hosts_data) == 0:
            self.alarms_list.addItem("ℹ️ Sammle Daten... (Monitor läuft)")
        else:
            self.alarms_list.addItem("✅ Keine Alarme")

    # ------------------------------------------------------------------ #
    #   VirusTotal-Helfer
    # ------------------------------------------------------------------ #
    def _on_vt_result(self, target: str, data: dict):
        """Callback, wenn ein VirusTotal-Scan fertig ist."""
        if not target:
            return
        self.vt_results[target] = data or {}
        self._update_virus_label()

    def _on_vt_error(self, target: str, message: str):
        # Optional: Fehler im Log ausgeben – UI nicht vollspammen
        print(f"⚠️ VirusTotal-Fehler für {target}: {message}")

    def _extract_stats(self, data: dict) -> Dict[str, int]:
        """Stats aus VT-Response holen (malicious, suspicious, ...)."""
        try:
            attrs = data.get("data", {}).get("attributes", {}) or {}
            stats = attrs.get("last_analysis_stats", {}) or {}
            return {
                "harmless": int(stats.get("harmless", 0)),
                "malicious": int(stats.get("malicious", 0)),
                "suspicious": int(stats.get("suspicious", 0)),
                "undetected": int(stats.get("undetected", 0)),
                "timeout": int(stats.get("timeout", 0)),
            }
        except Exception:
            return {}

    def _update_virus_label(self):
        """Aggregierten VirusTotal-Status für diese App anzeigen."""
        if not self.vt_enabled or not self.vt_results:
            self.virus_value.setText("ℹ️ Keine Daten")
            self.virus_value.setStyleSheet("color: #9e9e9e; padding: 5px;")
            return

        total_pos = 0  # malicious + suspicious
        total_all = 0
        worst_level = "ok"

        level_prio = {"unknown": 0, "ok": 1, "warning": 2, "danger": 3}

        lines = ["VirusTotal-Analyse für alle Remote-IPs dieses Prozesses:", ""]

        for ip, res in self.vt_results.items():
            stats = self._extract_stats(res)
            if stats:
                m = stats.get("malicious", 0)
                s = stats.get("suspicious", 0)
                total_pos += m + s
                total_all += sum(stats.values())

            # beste Einstufung aus Analyzer holen (wenn vorhanden)
            level = "unknown"
            if self.vt_analyzer is not None:
                try:
                    level = self.vt_analyzer.get_threat_level(res)
                except Exception:
                    level = "unknown"

            if level_prio.get(level, 0) > level_prio.get(worst_level, 0):
                worst_level = level

            # Zeile für Tooltip
            try:
                if self.vt_analyzer is not None:
                    summary = self.vt_analyzer.format_summary(res)
                else:
                    summary = "Ergebnis vorhanden"
            except Exception:
                summary = "Ergebnis vorhanden"
            lines.append(f"- {ip}: {summary}")

        if total_all == 0:
            total_text = "keine Daten"
        else:
            total_text = f"{total_pos}/{total_all}"

        if worst_level == "danger":
            icon = "🛑"
            color = "#f44336"
            label = "Malicious"
        elif worst_level == "warning":
            icon = "⚠️"
            color = "#ff9800"
            label = "Suspicious"
        elif worst_level == "ok":
            icon = "✅"
            color = "#4caf50"
            label = "Clean"
        else:
            icon = "ℹ️"
            color = "#9e9e9e"
            label = "Unbekannt"

        self.virus_value.setText(f"{icon} {label} ({total_text})")
        self.virus_value.setStyleSheet(f"color: {color}; padding: 5px;")
        self.virus_value.setToolTip("\n".join(lines))

    # ------------------------------------------------------------------ #
    #   Utils
    # ------------------------------------------------------------------ #
    def _format_bytes(self, b):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if b < 1024:
                return f"{b:.0f} {unit}" if b < 10 else f"{b:.1f} {unit}"
            b /= 1024
        return f"{b:.1f} TB"

    def closeEvent(self, event):
        if hasattr(self, 'timer'):
            self.timer.stop()
        super().closeEvent(event)


