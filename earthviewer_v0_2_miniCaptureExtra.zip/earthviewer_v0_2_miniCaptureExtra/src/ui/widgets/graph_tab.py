#!/usr/bin/env python3
"""Professional Graph Tab mit PyQtGraph"""
from PyQt6 import QtWidgets, QtCore
import pyqtgraph as pg
from collections import deque
import time

class GraphTab(QtWidgets.QWidget):
    def __init__(self, network_monitor, parent=None):
        super().__init__(parent)
        self.monitor = network_monitor
        
        # Daten für Graph (letzte 300 Sekunden = 5 Minuten)
        self.max_points = 300
        self.time_data = deque(maxlen=self.max_points)
        self.upload_data = deque(maxlen=self.max_points)
        self.download_data = deque(maxlen=self.max_points)
        self.total_data = deque(maxlen=self.max_points)
        
        self.start_time = time.time()
        self._setup_ui()
        
        # Update Timer
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._update_graph)
        self.timer.start(1000)  # Jede Sekunde
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(10)
        
        # Header
        header = QtWidgets.QHBoxLayout()
        
        title = QtWidgets.QLabel("📈 Network Traffic Graph")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: white; padding: 10px;")
        header.addWidget(title)
        
        header.addStretch()
        
        large_btn = QtWidgets.QPushButton("🔍 Große Ansicht öffnen")
        large_btn.setStyleSheet("padding: 10px 20px; background: #0d7377; color: white; border: none; border-radius: 6px; font-weight: bold;")
        large_btn.clicked.connect(self._open_large)
        header.addWidget(large_btn)
        
        layout.addLayout(header)
        
        # Info
        self.info_label = QtWidgets.QLabel("Live Traffic Monitoring - Letzte 5 Minuten")
        self.info_label.setStyleSheet("color: #888; font-size: 11px; padding: 5px;")
        layout.addWidget(self.info_label)
        
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.HLine)
        line.setStyleSheet("background: #3a3a3a;")
        layout.addWidget(line)
        
        # PyQtGraph Widget
        pg.setConfigOption('background', '#1e1e1e')
        pg.setConfigOption('foreground', 'w')
        
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setLabel('left', 'Traffic', units='KB/s')
        self.plot_widget.setLabel('bottom', 'Zeit', units='s')
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        self.plot_widget.setYRange(0, 1000)
        
        # Curves (Area Stacked Style)
        self.curve_total = self.plot_widget.plot(pen=pg.mkPen(color='#ff69b4', width=2), 
                                                  fillLevel=0, brush=(255, 105, 180, 100))
        self.curve_download = self.plot_widget.plot(pen=pg.mkPen(color='#ff8c00', width=2),
                                                     fillLevel=0, brush=(255, 140, 0, 100))
        self.curve_upload = self.plot_widget.plot(pen=pg.mkPen(color='#ffd700', width=2),
                                                   fillLevel=0, brush=(255, 215, 0, 100))
        
        layout.addWidget(self.plot_widget, 1)
        
        # Legend
        legend = QtWidgets.QHBoxLayout()
        legend.addWidget(self._create_legend_item("🟡 Upload", "#ffd700"))
        legend.addWidget(self._create_legend_item("🟠 Download", "#ff8c00"))
        legend.addWidget(self._create_legend_item("💗 Total", "#ff69b4"))
        legend.addStretch()
        layout.addLayout(legend)
        
        # Controls
        controls = QtWidgets.QHBoxLayout()
        
        self.pause_btn = QtWidgets.QPushButton("⏸️ Pausieren")
        self.pause_btn.setStyleSheet("padding: 8px; background: #3a3a3a; color: white; border: none; border-radius: 4px;")
        self.pause_btn.clicked.connect(self._toggle_pause)
        controls.addWidget(self.pause_btn)
        
        clear_btn = QtWidgets.QPushButton("🗑️ Löschen")
        clear_btn.setStyleSheet("padding: 8px; background: #3a3a3a; color: white; border: none; border-radius: 4px;")
        clear_btn.clicked.connect(self._clear_graph)
        controls.addWidget(clear_btn)
        
        controls.addStretch()
        layout.addLayout(controls)
    
    def _create_legend_item(self, text, color):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(widget)
        layout.setContentsMargins(5, 5, 5, 5)
        
        color_box = QtWidgets.QLabel()
        color_box.setFixedSize(20, 20)
        color_box.setStyleSheet(f"background: {color}; border-radius: 3px;")
        layout.addWidget(color_box)
        
        label = QtWidgets.QLabel(text)
        label.setStyleSheet("color: white; font-size: 12px;")
        layout.addWidget(label)
        
        return widget
    
    def _update_graph(self):
        current_time = time.time() - self.start_time
        
        # Hole Traffic Stats
        upload = 0
        download = 0
        
        with self.monitor.stats.lock:
            for app_data in self.monitor.stats.apps.values():
                total = app_data.get("total", 0)
                download += total * 0.7  # Schätzung
                upload += total * 0.3
        
        total = upload + download
        
        # Konvertiere zu KB/s
        upload_kb = upload / 1024
        download_kb = download / 1024
        total_kb = total / 1024
        
        # Füge Daten hinzu
        self.time_data.append(current_time)
        self.upload_data.append(upload_kb)
        self.download_data.append(download_kb)
        self.total_data.append(total_kb)
        
        # Update Curves
        if len(self.time_data) > 0:
            times = list(self.time_data)
            self.curve_upload.setData(times, list(self.upload_data))
            self.curve_download.setData(times, list(self.download_data))
            self.curve_total.setData(times, list(self.total_data))
            
            # Auto-scale Y axis
            max_val = max(max(self.total_data, default=100), 100)
            self.plot_widget.setYRange(0, max_val * 1.2)
        
        # Update Info
        self.info_label.setText(
            f"⬆️ {upload_kb:.1f} KB/s | ⬇️ {download_kb:.1f} KB/s | 📊 {total_kb:.1f} KB/s | "
            f"Datenpunkte: {len(self.time_data)}/{self.max_points}"
        )
    
    def _open_large(self):
        from ui.widgets.graph_large_window import GraphLargeWindow
        if not hasattr(self, 'large_window') or not self.large_window.isVisible():
            self.large_window = GraphLargeWindow(self.monitor, self)
            self.large_window.show()
        else:
            self.large_window.raise_()
    
    def _toggle_pause(self):
        if self.timer.isActive():
            self.timer.stop()
            self.pause_btn.setText("▶️ Fortsetzen")
        else:
            self.timer.start(1000)
            self.pause_btn.setText("⏸️ Pausieren")
    
    def _clear_graph(self):
        self.time_data.clear()
        self.upload_data.clear()
        self.download_data.clear()
        self.total_data.clear()
        self.start_time = time.time()
        self.curve_upload.clear()
        self.curve_download.clear()
        self.curve_total.clear()
