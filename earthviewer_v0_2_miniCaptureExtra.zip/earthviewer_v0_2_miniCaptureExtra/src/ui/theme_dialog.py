#!/usr/bin/env python3
"""
Theme-Auswahl und Custom-Editor Dialog
"""
from PyQt6 import QtWidgets, QtCore, QtGui
from core.config import THEMES
from core.settings import settings

class ThemeDialog(QtWidgets.QDialog):
    """Theme-Auswahl Dialog"""
    
    theme_changed = QtCore.pyqtSignal(str)  # Signal wenn Theme geändert
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🎨 Theme-Auswahl")
        self.setMinimumWidth(600)
        self.setMinimumHeight(500)
        
        self.custom_colors = {}
        self._setup_ui()
        self._load_current_theme()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        # Header
        header = QtWidgets.QLabel("🎨 Wähle dein Theme")
        header.setStyleSheet("font-size: 20px; font-weight: bold; color: #0d7377; padding: 10px;")
        layout.addWidget(header)
        
        # Theme-Liste
        self.theme_list = QtWidgets.QListWidget()
        self.theme_list.setStyleSheet("""
            QListWidget {
                background: #2b2b2b;
                color: white;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 5px;
            }
            QListWidget::item {
                padding: 15px;
                border-radius: 4px;
                margin: 3px;
            }
            QListWidget::item:hover {
                background: #3a3a3a;
            }
            QListWidget::item:selected {
                background: #0d7377;
            }
        """)
        
        # Themes hinzufügen
        for theme_name, theme_data in THEMES.items():
            item = QtWidgets.QListWidgetItem()
            item.setText(f"{theme_name}\n{theme_data['description']}")
            item.setData(QtCore.Qt.ItemDataRole.UserRole, theme_name)
            self.theme_list.addItem(item)
        
        # Custom Theme
        custom_item = QtWidgets.QListWidgetItem()
        custom_item.setText("Custom\nErstelle dein eigenes Theme")
        custom_item.setData(QtCore.Qt.ItemDataRole.UserRole, "Custom")
        self.theme_list.addItem(custom_item)
        
        self.theme_list.currentItemChanged.connect(self._on_theme_selected)
        layout.addWidget(self.theme_list)
        
        # Custom-Editor (standardmäßig versteckt)
        self.custom_editor = self._create_custom_editor()
        layout.addWidget(self.custom_editor)
        self.custom_editor.hide()
        
        # Vorschau
        preview_label = QtWidgets.QLabel("Vorschau:")
        preview_label.setStyleSheet("font-weight: bold; color: white; margin-top: 10px;")
        layout.addWidget(preview_label)
        
        self.preview_widget = QtWidgets.QWidget()
        self.preview_widget.setMinimumHeight(80)
        self.preview_widget.setStyleSheet("background: #1e1e1e; border-radius: 4px;")
        preview_layout = QtWidgets.QHBoxLayout(self.preview_widget)
        
        self.preview_labels = {}
        for label_type in ["Search", "Traceroute", "Target"]:
            label = QtWidgets.QLabel(f"● {label_type}")
            label.setStyleSheet("font-size: 14px; font-weight: bold;")
            self.preview_labels[label_type.lower()] = label
            preview_layout.addWidget(label)
        
        layout.addWidget(self.preview_widget)
        
        # Buttons
        button_layout = QtWidgets.QHBoxLayout()
        
        apply_btn = QtWidgets.QPushButton("✅ Anwenden")
        apply_btn.setStyleSheet("""
            QPushButton {
                padding: 10px 20px;
                background: #0d7377;
                color: white;
                font-weight: bold;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover { background: #0e8388; }
        """)
        apply_btn.clicked.connect(self._apply_theme)
        
        cancel_btn = QtWidgets.QPushButton("❌ Abbrechen")
        cancel_btn.setStyleSheet("""
            QPushButton {
                padding: 10px 20px;
                background: #555;
                color: white;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover { background: #666; }
        """)
        cancel_btn.clicked.connect(self.reject)
        
        button_layout.addWidget(apply_btn)
        button_layout.addWidget(cancel_btn)
        layout.addLayout(button_layout)
    
    def _create_custom_editor(self):
        """Erstellt Custom-Theme-Editor"""
        widget = QtWidgets.QGroupBox("⚙️ Custom Theme Editor")
        widget.setStyleSheet("""
            QGroupBox {
                color: white;
                font-weight: bold;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 15px;
                margin-top: 10px;
            }
        """)
        
        layout = QtWidgets.QGridLayout(widget)
        
        self.color_buttons = {}
        color_types = [
            ("search_marker", "🔍 Such-Marker"),
            ("traceroute_marker", "📍 Traceroute-Marker"),
            ("traceroute_line", "━ Traceroute-Linie"),
            ("target_marker", "🎯 Ziel-Marker"),
            ("label_search", "📝 Such-Label"),
            ("label_traceroute", "📝 Traceroute-Label"),
        ]
        
        for i, (color_key, label_text) in enumerate(color_types):
            label = QtWidgets.QLabel(label_text)
            label.setStyleSheet("color: white;")
            
            btn = QtWidgets.QPushButton("Farbe wählen")
            btn.setStyleSheet("""
                QPushButton {
                    padding: 8px;
                    background: #3a3a3a;
                    color: white;
                    border: 1px solid #555;
                    border-radius: 4px;
                }
                QPushButton:hover { background: #4a4a4a; }
            """)
            btn.clicked.connect(lambda checked, k=color_key: self._pick_color(k))
            
            self.color_buttons[color_key] = btn
            
            layout.addWidget(label, i, 0)
            layout.addWidget(btn, i, 1)
        
        return widget
    
    def _pick_color(self, color_key: str):
        """Öffnet Color-Picker"""
        current_color = self.custom_colors.get(color_key, (255, 255, 255))
        qcolor = QtGui.QColor(*current_color)
        
        color = QtWidgets.QColorDialog.getColor(qcolor, self, f"Farbe für {color_key}")
        
        if color.isValid():
            self.custom_colors[color_key] = (color.red(), color.green(), color.blue())
            self._update_button_color(color_key, self.custom_colors[color_key])
            self._update_preview()
    
    def _update_button_color(self, color_key: str, rgb: tuple):
        """Aktualisiert Button-Farbe"""
        btn = self.color_buttons[color_key]
        btn.setStyleSheet(f"""
            QPushButton {{
                padding: 8px;
                background: rgb({rgb[0]}, {rgb[1]}, {rgb[2]});
                color: {"white" if sum(rgb) < 400 else "black"};
                border: 2px solid #555;
                border-radius: 4px;
                font-weight: bold;
            }}
        """)
    
    def _on_theme_selected(self, current, previous):
        """Theme ausgewählt"""
        if not current:
            return
        
        theme_name = current.data(QtCore.Qt.ItemDataRole.UserRole)
        
        if theme_name == "Custom":
            self.custom_editor.show()
            # Lade gespeicherte Custom-Colors
            saved_custom = settings.get("custom_theme_colors", {})
            for key, value in saved_custom.items():
                if isinstance(value, list):
                    value = tuple(value)
                self.custom_colors[key] = value
                self._update_button_color(key, value)
        else:
            self.custom_editor.hide()
        
        self._update_preview()
    
    def _update_preview(self):
        """Aktualisiert Vorschau"""
        current_item = self.theme_list.currentItem()
        if not current_item:
            return
        
        theme_name = current_item.data(QtCore.Qt.ItemDataRole.UserRole)
        
        if theme_name == "Custom":
            colors = self.custom_colors
        elif theme_name in THEMES:
            colors = THEMES[theme_name]["colors"]
        else:
            return
        
        # Aktualisiere Preview-Labels
        for label_type, label_widget in self.preview_labels.items():
            color_key = f"{label_type}_marker" if label_type != "target" else "target_marker"
            if label_type == "traceroute":
                color_key = "traceroute_marker"
            elif label_type == "search":
                color_key = "search_marker"
            
            if color_key in colors:
                rgb = colors[color_key]
                label_widget.setStyleSheet(f"""
                    color: rgb({rgb[0]}, {rgb[1]}, {rgb[2]});
                    font-size: 14px;
                    font-weight: bold;
                """)
    
    def _load_current_theme(self):
        """Lädt aktuelles Theme"""
        current_theme = settings.get("theme", "Classic Cyber")
        
        for i in range(self.theme_list.count()):
            item = self.theme_list.item(i)
            if item.data(QtCore.Qt.ItemDataRole.UserRole) == current_theme:
                self.theme_list.setCurrentItem(item)
                break
    
    def _apply_theme(self):
        """Wendet Theme an"""
        current_item = self.theme_list.currentItem()
        if not current_item:
            return
        
        theme_name = current_item.data(QtCore.Qt.ItemDataRole.UserRole)
        
        settings.set("theme", theme_name)
        
        if theme_name == "Custom":
            settings.set("custom_theme_colors", self.custom_colors)
        
        settings.save()
        
        self.theme_changed.emit(theme_name)
        self.accept()
