#!/usr/bin/env python3
import numpy as np
import math
from skyfield.api import load, wgs84, EarthSatellite
from datetime import datetime, timedelta

class OrbitCalculator:
    def __init__(self):
        self.ts = load.timescale()
    
    def calculate_orbit_points(self, tle_line1, tle_line2, sat_name="Satellite", num_points=100, time_span_minutes=100, start_time=None):
        try:
            satellite = EarthSatellite(tle_line1, tle_line2, sat_name, self.ts)
            now = start_time if start_time else datetime.utcnow()
            
            # FIX: Einzelne Zeitpunkte, nicht Array
            points = []
            for i in range(num_points):
                dt = now + timedelta(minutes=i * time_span_minutes / num_points)
                t = self.ts.utc(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second)
                geocentric = satellite.at(t)
                pos = geocentric.position.km
                points.append([pos[0], pos[1], pos[2]])
            
            points = np.array(points)
            EARTH_RADIUS_KM = 6371.0
            points = points / EARTH_RADIUS_KM
            
            period_minutes = self._estimate_period(satellite)
            return {'points': points, 'current_index': 0, 'period_minutes': period_minutes, 'num_points': num_points}
        except Exception as e:
            print(f"❌ Orbit: {e}")
            import traceback; traceback.print_exc()
            return None
    
    def _estimate_period(self, satellite):
        try:
            mean_motion = satellite.model.no_kozai * 1440.0 / (2 * np.pi)
            return 1440.0 / mean_motion
        except:
            return 90.0
    
    def calculate_ground_track(self, tle_line1, tle_line2, sat_name="Satellite", num_points=100, time_span_minutes=100):
        try:
            satellite = EarthSatellite(tle_line1, tle_line2, sat_name, self.ts)
            now = datetime.utcnow()
            points = []
            for i in range(num_points):
                dt = now + timedelta(minutes=i * time_span_minutes / num_points)
                t = self.ts.utc(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second)
                geocentric = satellite.at(t)
                subpoint = wgs84.subpoint(geocentric)
                lat, lon = subpoint.latitude.radians, subpoint.longitude.radians
                x = 1.01 * math.cos(lat) * math.cos(lon)
                y = 1.01 * math.cos(lat) * math.sin(lon)
                z = 1.01 * math.sin(lat)
                points.append([x, y, z])
            return np.array(points)
        except Exception as e:
            print(f"❌ Ground: {e}")
            return None
    
    def calculate_velocity_vector(self, tle_line1, tle_line2, sat_name="Satellite"):
        try:
            satellite = EarthSatellite(tle_line1, tle_line2, sat_name, self.ts)
            now = datetime.utcnow()
            t = self.ts.utc(now.year, now.month, now.day, now.hour, now.minute, now.second)
            geocentric = satellite.at(t)
            pos, vel = geocentric.position.km, geocentric.velocity.km_per_s
            EARTH_RADIUS_KM = 6371.0
            position = np.array([pos[0], pos[1], pos[2]]) / EARTH_RADIUS_KM
            velocity = np.array([vel[0], vel[1], vel[2]])
            velocity = velocity / np.linalg.norm(velocity) * 0.3
            return {'position': position, 'velocity': velocity, 'speed_km_s': np.linalg.norm(vel)}
        except Exception as e:
            print(f"❌ Vel: {e}")
            return None
