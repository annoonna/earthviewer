#!/usr/bin/env python3
"""
Matrix-Utilities für 3D-Transformationen
"""
import math
import numpy as np

def create_rotation_matrix(angle_deg: float, axis: np.ndarray) -> np.ndarray:
    """Erstellt 4x4 Rotationsmatrix um beliebige Achse"""
    angle_rad = math.radians(angle_deg)
    c = math.cos(angle_rad)
    s = math.sin(angle_rad)
    t = 1.0 - c
    
    axis = axis / np.linalg.norm(axis)
    x, y, z = axis
    
    return np.array([
        [t*x*x + c,   t*x*y - z*s, t*x*z + y*s, 0],
        [t*x*y + z*s, t*y*y + c,   t*y*z - x*s, 0],
        [t*x*z - y*s, t*y*z + x*s, t*z*z + c,   0],
        [0,           0,           0,           1]
    ], dtype=np.float32)

def create_projection_matrix(fov_deg: float, aspect: float, near: float, far: float) -> np.ndarray:
    """Erstellt Perspektiv-Projektionsmatrix"""
    f = 1.0 / math.tan(math.radians(fov_deg) / 2.0)
    
    return np.array([
        [f / aspect, 0, 0, 0],
        [0, f, 0, 0],
        [0, 0, (far + near) / (near - far), (2 * far * near) / (near - far)],
        [0, 0, -1, 0]
    ], dtype=np.float32)

def create_view_matrix(distance: float) -> np.ndarray:
    """Erstellt View-Matrix (Kamera-Position)"""
    view = np.identity(4, dtype=np.float32)
    view[2, 3] = -distance
    return view

def create_translation_matrix(x: float, y: float, z: float) -> np.ndarray:
    """Erstellt Translationsmatrix"""
    return np.array([
        [1, 0, 0, x],
        [0, 1, 0, y],
        [0, 0, 1, z],
        [0, 0, 0, 1]
    ], dtype=np.float32)
