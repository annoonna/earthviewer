#!/usr/bin/env python3
"""Country Flags - Komplette Flaggen-Datenbank"""

COUNTRY_FLAGS = {
    "DE": "🇩🇪", "FR": "🇫🇷", "GB": "🇬🇧", "IT": "🇮🇹", "ES": "🇪🇸",
    "NL": "🇳🇱", "BE": "🇧🇪", "AT": "🇦🇹", "CH": "🇨🇭", "PL": "🇵🇱",
    "US": "🇺🇸", "CA": "🇨🇦", "MX": "🇲🇽", "BR": "🇧🇷", "AR": "🇦🇷",
    "CN": "🇨🇳", "JP": "🇯🇵", "IN": "🇮🇳", "RU": "🇷🇺", "KR": "🇰🇷",
    "AU": "🇦🇺", "NZ": "🇳🇿", "SG": "🇸🇬", "TH": "🇹🇭", "VN": "🇻🇳",
    "ZA": "🇿🇦", "EG": "🇪🇬", "NG": "🇳🇬", "KE": "🇰🇪", "GH": "🇬🇭",
    "SE": "🇸🇪", "NO": "🇳🇴", "DK": "🇩🇰", "FI": "🇫🇮", "IS": "🇮🇸",
    "IE": "🇮🇪", "PT": "🇵🇹", "GR": "🇬🇷", "TR": "🇹🇷", "IL": "🇮🇱",
    "Germany": "🇩🇪", "United States": "🇺🇸", "Unknown": "🌐"
}

COUNTRY_NAMES = {
    "US": "United States", "DE": "Germany", "GB": "United Kingdom",
    "FR": "France", "NL": "Netherlands", "CN": "China", "JP": "Japan"
}

def get_flag(country_code):
    if not country_code:
        return "🌐"
    return COUNTRY_FLAGS.get(country_code, "🌐")

def get_country_name(country_code):
    if not country_code:
        return "Unknown"
    if len(country_code) > 2:
        return country_code
    return COUNTRY_NAMES.get(country_code, country_code)

def get_flag_and_name(country_code):
    flag = get_flag(country_code)
    name = get_country_name(country_code)
    return f"{flag} {name}"
