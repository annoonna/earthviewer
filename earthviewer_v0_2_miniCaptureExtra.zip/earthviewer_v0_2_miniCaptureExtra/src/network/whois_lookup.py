#!/usr/bin/env python3
"""
WHOIS-Lookup
"""
import socket

class WhoisLookup:
    """WHOIS-Abfragen"""
    
    def lookup(self, ip: str) -> str:
        """Führt WHOIS-Lookup aus"""
        try:
            whois_server = "whois.iana.org"
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect((whois_server, 43))
            sock.send(f"{ip}\r\n".encode())
            
            response = b""
            while True:
                data = sock.recv(4096)
                if not data:
                    break
                response += data
            
            sock.close()
            
            return response.decode('utf-8', errors='ignore')
            
        except Exception as e:
            return f"❌ WHOIS-Fehler: {e}"
