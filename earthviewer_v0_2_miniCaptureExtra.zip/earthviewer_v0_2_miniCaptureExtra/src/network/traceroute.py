#!/usr/bin/env python3
"""
Traceroute-Funktionalität
"""
import subprocess
import re
import platform
from typing import List, Optional
from core.geo_location import GeoLocation
from data.geo_manager import GeoDataManager

class TracerouteHop:
    """Ein Hop im Traceroute"""
    def __init__(self, hop_num: int, ip: str, hostname: str, rtt: float):
        self.hop_num = hop_num
        self.ip = ip
        self.hostname = hostname
        self.rtt = rtt
        self.location: Optional[GeoLocation] = None

class Traceroute:
    """Führt Traceroute aus und lokalisiert Hops"""
    
    def __init__(self, geo_manager: GeoDataManager):
        self.geo_manager = geo_manager
        self.is_windows = platform.system() == "Windows"
    
    def trace(self, target: str, max_hops: int = 30) -> List[TracerouteHop]:
        """Führt Traceroute aus"""
        hops = []
        
        try:
            if self.is_windows:
                cmd = ["tracert", "-h", str(max_hops), "-w", "2000", target]
            else:
                cmd = ["traceroute", "-m", str(max_hops), "-w", "2", target]
            
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            for line in process.stdout:
                hop = self._parse_line(line)
                if hop:
                    hop.location = self.geo_manager.lookup_ip(hop.ip)
                    hops.append(hop)
                    yield hop
            
            process.wait()
            
        except Exception as e:
            print(f"❌ Traceroute-Fehler: {e}")
        
        return hops
    
    def _parse_line(self, line: str) -> Optional[TracerouteHop]:
        """Parsed eine Zeile der Traceroute-Ausgabe"""
        line = line.strip()
        
        if self.is_windows:
            match = re.match(r'\s*(\d+)\s+([\d\s*]+ms)\s+([\d\s*]+ms)\s+([\d\s*]+ms)\s+(\S+)', line)
            if match:
                hop_num = int(match.group(1))
                rtt_str = match.group(4).replace('ms', '').strip()
                try:
                    rtt = float(rtt_str) if rtt_str != '*' else 0.0
                except:
                    rtt = 0.0
                
                target = match.group(5)
                
                ip_match = re.search(r'\[(\d+\.\d+\.\d+\.\d+)\]', target)
                if ip_match:
                    ip = ip_match.group(1)
                    hostname = target.split('[')[0].strip()
                else:
                    ip = target
                    hostname = target
                
                return TracerouteHop(hop_num, ip, hostname, rtt)
        else:
            match = re.match(r'\s*(\d+)\s+(\S+)\s+\((\d+\.\d+\.\d+\.\d+)\)\s+([\d.]+)\s*ms', line)
            if match:
                hop_num = int(match.group(1))
                hostname = match.group(2)
                ip = match.group(3)
                rtt = float(match.group(4))
                
                return TracerouteHop(hop_num, ip, hostname, rtt)
        
        return None
