#!/usr/bin/env python3
"""Network Monitor - Live Traffic Monitoring

Sammelt laufend Verbindungsdaten über psutil und baut Statistiken auf:
- pro Host (IP)
- pro Anwendung (Prozess)
- pro Protokoll (TCP/UDP/OTHER)
- pro Land (GeoIP über GeoDataManager.lookup_ip)

Die Stats liegen in self.stats und werden über das Signal stats_updated
an die UI (Graph, Monitoring-Tab, Live-Tab, Process-Details) gesendet.
"""

import threading
import time
import socket
from collections import defaultdict

import psutil
from PyQt6.QtCore import QObject, pyqtSignal


class NetworkStats:
    """Container für aggregierte Netzwerkstatistiken."""

    def __init__(self):
        # app_name -> {"total": bytes}
        self.apps = defaultdict(lambda: {"total": 0.0})
        # host_ip -> {"total": bytes}
        self.hosts = defaultdict(lambda: {"total": 0.0})
        # app_name -> host_ip -> {"total": bytes}
        self.app_hosts = defaultdict(lambda: defaultdict(lambda: {"total": 0.0}))
        # protocol (TCP/UDP/OTHER) -> {"total": bytes}
        self.protocols = defaultdict(lambda: {"total": 0.0})
        # country_code / name -> {"total": bytes}
        self.countries = defaultdict(lambda: {"total": 0.0})
        # für Thread-Sicherheit
        self.lock = threading.Lock()


class NetworkMonitor(QObject):
    """
    Überwacht laufend das System mit psutil und aktualisiert NetworkStats.
    Andere Teile der UI (Graph, Monitoring, Live-Verbindungen-Tab,
    ProcessDetailWindow) hängen sich an stats_updated an und lesen self.stats.
    """

    stats_updated = pyqtSignal()

    def __init__(self, geo_manager):
        super().__init__()
        self.geo_manager = geo_manager
        self.stats = NetworkStats()
        self.running = False
        self.thread = None
        self._last_io = {}
        # host_ip -> set(app_names) – nützlich für UI (z.B. Live-Tab)
        self.host_apps = {}  # type: dict[str, set[str]]

    # ------------------------------------------------------------------ #
    # Steuerung
    # ------------------------------------------------------------------ #
    def start(self):
        """Startet den Monitoring-Thread (idempotent)."""
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.thread.start()

    def stop(self):
        """Stoppt den Monitoring-Thread (sanft)."""
        self.running = False

    # ------------------------------------------------------------------ #
    # Hauptloop
    # ------------------------------------------------------------------ #
    def _monitor_loop(self):
        while self.running:
            try:
                self._collect_stats()
                # UI informieren, dass neue Daten da sind
                self.stats_updated.emit()
                time.sleep(1)
            except Exception:
                # wir wollen nicht, dass ein Fehler den Thread killt
                time.sleep(1)

    # ------------------------------------------------------------------ #
    # Kernlogik: Stats einsammeln
    # ------------------------------------------------------------------ #
    def _collect_stats(self):
        """
        Liest aktuelle Verbindungen + IO-Counter und verteilt die seit
        der letzten Messung übertragenen Bytes grob auf die aktiven
        Verbindungen.

        Das ist kein perfekter Traffic-Analyzer, aber ausreichend für
        Graphen, Top-Hosts, Top-Apps und Live-Ansichten.
        """
        try:
            connections = psutil.net_connections(kind="inet")
            io = psutil.net_io_counters(pernic=False)
        except Exception:
            return

        current = {"sent": io.bytes_sent, "recv": io.bytes_recv}

        # Beim allerersten Lauf nur Referenz setzen
        if not self._last_io:
            self._last_io = current
            return

        # Differenz seit letzter Messung
        diff_total = (
            (current["sent"] + current["recv"])
            - (self._last_io["sent"] + self._last_io["recv"])
        )
        self._last_io = current

        # Nichts oder weniger als 0 (z.B. Reset) -> abbrechen
        if diff_total <= 0:
            return

        # Nur etablierte Verbindungen mit Remote-Adresse zählen
        active_conns = [
            c for c in connections
            if c.status == psutil.CONN_ESTABLISHED and c.raddr
        ]
        if not active_conns:
            return

        # Grobe Verteilung: jede aktive Verbindung bekommt denselben Anteil
        per_conn_bytes = diff_total / float(len(active_conns))

        with self.stats.lock:
            for conn in active_conns:
                remote_ip = None
                try:
                    remote_ip = conn.raddr.ip if hasattr(conn.raddr, "ip") else conn.raddr[0]
                except Exception:
                    continue
                if not remote_ip:
                    continue

                # Prozess / App herausfinden
                app_name = "unknown"
                if conn.pid:
                    try:
                        p = psutil.Process(conn.pid)
                        app_name = p.name() or f"pid-{conn.pid}"
                    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                        app_name = f"pid-{conn.pid}"

                # Protokoll bestimmen
                if conn.type == socket.SOCK_STREAM:
                    proto = "TCP"
                elif conn.type == socket.SOCK_DGRAM:
                    proto = "UDP"
                else:
                    proto = "OTHER"

                # Geo-Infos (Land) holen
                country_key = "Unknown"
                if self.geo_manager is not None:
                    try:
                        loc = self.geo_manager.lookup_ip(remote_ip)
                        if loc and loc.country:
                            country_key = loc.country
                    except Exception:
                        pass

                bytes_val = float(per_conn_bytes)

                # Hosts
                self.stats.hosts[remote_ip]["total"] += bytes_val

                # Apps
                self.stats.apps[app_name]["total"] += bytes_val

                # Zuordnung App -> Host
                self.stats.app_hosts[app_name][remote_ip]["total"] += bytes_val

                # Protokolle
                self.stats.protocols[proto]["total"] += bytes_val

                # Länder
                self.stats.countries[country_key]["total"] += bytes_val

                # host_apps Mapping pflegen
                if remote_ip not in self.host_apps:
                    self.host_apps[remote_ip] = set()
                self.host_apps[remote_ip].add(app_name)

    # ------------------------------------------------------------------ #
    # Helfer für UI (Top-Listen etc.)
    # Rückgaben sind (key, float_total), KEINE dicts.
    # ------------------------------------------------------------------ #
    def get_top_hosts(self, limit: int = 20):
        """Gibt eine Liste (ip, bytes_total) sortiert nach Traffic zurück."""
        with self.stats.lock:
            items = [(ip, data["total"]) for ip, data in self.stats.hosts.items()]
        items.sort(key=lambda x: x[1], reverse=True)
        return items[:limit]

    def get_top_apps(self, limit: int = 20):
        """Gibt eine Liste (app_name, bytes_total) sortiert nach Traffic zurück."""
        with self.stats.lock:
            items = [(app, data["total"]) for app, data in self.stats.apps.items()]
        items.sort(key=lambda x: x[1], reverse=True)
        return items[:limit]

    def get_top_countries(self, limit: int = 20):
        """Gibt eine Liste (country, bytes_total) sortiert nach Traffic zurück."""
        with self.stats.lock:
            items = [(country, data["total"]) for country, data in self.stats.countries.items()]
        items.sort(key=lambda x: x[1], reverse=True)
        return items[:limit]

    def get_top_protocols(self, limit: int = 10):
        """Gibt eine Liste (proto, bytes_total) sortiert nach Traffic zurück."""
        with self.stats.lock:
            items = [(proto, data["total"]) for proto, data in self.stats.protocols.items()]
        items.sort(key=lambda x: x[1], reverse=True)
        return items[:limit]

    # ------------------------------------------------------------------ #
    # Apps zu einem Host (für network_stats_widget)
    # ------------------------------------------------------------------ #
    def get_apps_for_host(self, host_ip: str, limit: int = 5):
        """
        Gibt eine Liste von App-Namen zurück, die Traffic zu diesem Host haben,
        sortiert nach übertragenen Bytes (absteigend).

        Rückgabe: List[str]
        """
        with self.stats.lock:
            app_totals = []
            for app_name, hosts_dict in self.stats.app_hosts.items():
                total = hosts_dict.get(host_ip, {}).get("total", 0.0)
                if total > 0:
                    app_totals.append((app_name, total))

        app_totals.sort(key=lambda x: x[1], reverse=True)
        return [name for name, _ in app_totals[:limit]]

    # ------------------------------------------------------------------ #
    # Hosts zu einer App (für ProcessDetailWindow)
    # ------------------------------------------------------------------ #
    def get_hosts_for_app(self, app_name: str, limit: int = 50):
        """
        Gibt eine Liste (host_ip, bytes_total) für eine bestimmte App zurück,
        sortiert nach Traffic (absteigend).

        Wird von ProcessDetailWindow verwendet.
        """
        with self.stats.lock:
            hosts_dict = self.stats.app_hosts.get(app_name, {})
            items = [(host_ip, data["total"]) for host_ip, data in hosts_dict.items()]

        items.sort(key=lambda x: x[1], reverse=True)
        return items[:limit]

