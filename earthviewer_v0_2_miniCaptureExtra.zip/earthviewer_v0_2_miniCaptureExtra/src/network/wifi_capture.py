#!/usr/bin/env python3
"""
WiFi Packet Capture mit pyshark
Unterstützt Monitor-Mode und WPA-Decryption
"""

import threading
import time
from typing import Optional, List, Dict
from PyQt6.QtCore import QObject, pyqtSignal

try:
    import pyshark
    PYSHARK_AVAILABLE = True
except ImportError:
    PYSHARK_AVAILABLE = False
    print("⚠️ pyshark nicht installiert - WiFi-Capture deaktiviert")

class WiFiPacket:
    """Repräsentiert ein WiFi-Paket"""
    
    def __init__(self):
        self.timestamp = time.time()
        self.src_mac = ""
        self.dst_mac = ""
        self.bssid = ""
        self.ssid = ""
        self.channel = 0
        self.signal_strength = -100
        self.packet_type = ""
        self.data_rate = 0.0
        self.frequency = 0
        self.encrypted = False
        self.src_ip = None
        self.dst_ip = None
        self.protocol = ""
        self.info = ""

class WiFiCapture(QObject):
    """
    WiFi Packet Capture Engine
    Nutzt pyshark (tshark wrapper) für Monitor-Mode und WPA-Decryption
    """
    
    packet_captured = pyqtSignal(WiFiPacket)
    stats_updated = pyqtSignal(dict)
    error_occurred = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.capturing = False
        self.interface = "wlan0mon"
        self.capture_thread = None
        self.capture = None
        self.packet_count = 0
        self.stats = {
            "total_packets": 0,
            "data_packets": 0,
            "management_packets": 0,
            "control_packets": 0,
            "encrypted_packets": 0,
            "decrypted_packets": 0
        }
        self.devices = {}  # MAC -> DeviceStats
        
    def start_capture(self, interface: str = "wlan0mon", 
                     decrypt: bool = False, 
                     wpa_password: str = None,
                     filter_expr: str = None):
        """Startet die Paket-Erfassung"""
        
        if not PYSHARK_AVAILABLE:
            self.error_occurred.emit("pyshark nicht installiert!")
            return False
        
        if self.capturing:
            self.error_occurred.emit("Capture läuft bereits")
            return False
        
        self.interface = interface
        self.capturing = True
        
        # Start capture thread
        self.capture_thread = threading.Thread(
            target=self._capture_worker,
            args=(interface, decrypt, wpa_password, filter_expr),
            daemon=True
        )
        self.capture_thread.start()
        return True
    
    def stop_capture(self):
        """Stoppt die Paket-Erfassung"""
        self.capturing = False
        if self.capture:
            try:
                self.capture.close()
            except:
                pass
        
    def _capture_worker(self, interface: str, decrypt: bool, 
                       wpa_password: str, filter_expr: str):
        """Worker-Thread für Packet Capture"""
        try:
            # Decryption options
            decryption_key = None
            if decrypt and wpa_password:
                decryption_key = f"wpa-pwd:{wpa_password}"
            
            # Create capture
            if decryption_key:
                self.capture = pyshark.LiveCapture(
                    interface=interface,
                    display_filter=filter_expr,
                    decryption_key=decryption_key,
                    encryption_type='wpa-pwd',
                    output_file=None
                )
            else:
                self.capture = pyshark.LiveCapture(
                    interface=interface,
                    display_filter=filter_expr,
                    output_file=None
                )
            
            # Continuous capture
            for packet in self.capture.sniff_continuously():
                if not self.capturing:
                    break
                
                self._process_packet(packet)
                
        except Exception as e:
            self.error_occurred.emit(f"Capture-Fehler: {str(e)}")
        finally:
            self.capturing = False
    
    def _process_packet(self, packet):
        """Verarbeitet ein erfasstes Paket"""
        try:
            wifi_packet = WiFiPacket()
            wifi_packet.timestamp = float(packet.sniff_timestamp)
            
            # WiFi Layer
            if 'WLAN' in packet:
                wlan = packet['WLAN']
                
                # MAC Addresses
                wifi_packet.src_mac = str(getattr(wlan, 'sa', '')).upper()
                wifi_packet.dst_mac = str(getattr(wlan, 'da', '')).upper()
                wifi_packet.bssid = str(getattr(wlan, 'bssid', '')).upper()
                
                # Signal Strength
                if hasattr(wlan, 'signal_dbm'):
                    wifi_packet.signal_strength = int(wlan.signal_dbm)
                
                # Channel
                if hasattr(wlan, 'channel'):
                    wifi_packet.channel = int(wlan.channel)
                
                # Data Rate
                if hasattr(wlan, 'data_rate'):
                    wifi_packet.data_rate = float(wlan.data_rate)
                
                # Frame Type
                fc_type = int(str(getattr(wlan, 'fc_type', 0)), 0) if str(getattr(wlan, 'fc_type', 0)).startswith('0x') else int(getattr(wlan, 'fc_type', 0))
                fc_subtype = int(str(getattr(wlan, 'fc_type_subtype', 0)), 0) if str(getattr(wlan, 'fc_type_subtype', 0)).startswith('0x') else int(getattr(wlan, 'fc_type_subtype', 0))
                
                if fc_type == 0:  # Management
                    wifi_packet.packet_type = "Management"
                    self.stats["management_packets"] += 1
                    
                    # Extract SSID from Beacon/Probe
                    if fc_subtype in [0x08, 0x04]:  # Beacon or Probe Request
                        if 'WLAN_MGT' in packet:
                            mgmt = packet['WLAN_MGT']
                            if hasattr(mgmt, 'ssid'):
                                wifi_packet.ssid = str(mgmt.ssid)
                                
                elif fc_type == 1:  # Control
                    wifi_packet.packet_type = "Control"
                    self.stats["control_packets"] += 1
                    
                elif fc_type == 2:  # Data
                    wifi_packet.packet_type = "Data"
                    self.stats["data_packets"] += 1
                    
                    # Check encryption
                    if hasattr(wlan, 'wep') or hasattr(wlan, 'wpa'):
                        wifi_packet.encrypted = True
                        self.stats["encrypted_packets"] += 1
            
            # IP Layer (if decrypted)
            if 'IP' in packet:
                ip = packet['IP']
                wifi_packet.src_ip = str(ip.src)
                wifi_packet.dst_ip = str(ip.dst)
                wifi_packet.protocol = str(ip.proto)
                self.stats["decrypted_packets"] += 1
            
            # Update device stats
            if wifi_packet.src_mac:
                self._update_device_stats(wifi_packet.src_mac, wifi_packet)
            
            # Update total count
            self.stats["total_packets"] += 1
            self.packet_count += 1
            
            # Emit signals
            self.packet_captured.emit(wifi_packet)
            
            if self.packet_count % 100 == 0:
                self.stats_updated.emit(self.stats)
                
        except Exception as e:
            print(f"Packet processing error: {e}")
    
    def _update_device_stats(self, mac: str, packet: WiFiPacket):
        """Aktualisiert Geräte-Statistiken"""
        if mac not in self.devices:
            self.devices[mac] = {
                "first_seen": packet.timestamp,
                "last_seen": packet.timestamp,
                "packet_count": 0,
                "signal_strength": [],
                "ssids": set(),
                "data_sent": 0,
                "data_received": 0
            }
        
        device = self.devices[mac]
        device["last_seen"] = packet.timestamp
        device["packet_count"] += 1
        
        if packet.signal_strength > -100:
            device["signal_strength"].append(packet.signal_strength)
        
        if packet.ssid:
            device["ssids"].add(packet.ssid)
    
    def get_device_list(self) -> List[Dict]:
        """Gibt Liste aller erkannten Geräte zurück"""
        device_list = []
        
        for mac, stats in self.devices.items():
            avg_signal = -100
            if stats["signal_strength"]:
                avg_signal = sum(stats["signal_strength"]) / len(stats["signal_strength"])
            
            device_list.append({
                "mac": mac,
                "first_seen": stats["first_seen"],
                "last_seen": stats["last_seen"],
                "packets": stats["packet_count"],
                "avg_signal": avg_signal,
                "ssids": list(stats["ssids"])
            })
        
        return sorted(device_list, key=lambda x: x["packets"], reverse=True)

# Singleton
_capture_instance = None

def get_wifi_capture() -> WiFiCapture:
    global _capture_instance
    if _capture_instance is None:
        _capture_instance = WiFiCapture()
    return _capture_instance
