#!/usr/bin/env python3
"""
Connection Tracker - Verfolgt und visualisiert aktive Netzwerkverbindungen
"""
import threading
import time
import psutil
import hashlib
import socket
from collections import defaultdict
from PyQt6.QtCore import QObject, pyqtSignal
from typing import Dict, List, Optional
from dataclasses import dataclass
from datetime import datetime
import ipaddress


@dataclass
class Connection:
    """Repräsentiert eine Netzwerkverbindung"""
    local_ip: str
    local_port: int
    remote_ip: str
    remote_port: int
    protocol: str  # TCP/UDP
    direction: str  # incoming/outgoing
    app_name: str
    bytes_sent: int = 0
    bytes_recv: int = 0
    timestamp: float = 0
    country: str = "Unknown"
    city: str = "Unknown"
    lat: float = 0.0
    lon: float = 0.0

    def get_key(self):
        """Eindeutiger Key für diese Verbindung"""
        return f"{self.local_ip}:{self.local_port}-{self.remote_ip}:{self.remote_port}-{self.protocol}"

    @property
    def is_outgoing(self):
        return self.direction == "outgoing"

    @property
    def is_incoming(self):
        return self.direction == "incoming"


class ConnectionTracker(QObject):
    """Trackt aktive Netzwerkverbindungen und deren geografische Positionen"""

    connections_updated = pyqtSignal(list)  # Emittiert Liste von Connection-Objekten

    def __init__(self, geo_manager):
        super().__init__()
        self.geo_manager = geo_manager
        self.active_connections: Dict[str, Connection] = {}
        self.connection_history: List[Connection] = []
        self.running = False
        self.thread = None
        self.lock = threading.Lock()

        # Filter-Einstellungen
        self.show_incoming = True
        self.show_outgoing = True
        self.max_connections = 100
        self.update_interval = 2.0  # Sekunden

    def start(self):
        """Startet das Connection Tracking"""
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._tracking_loop, daemon=True)
        self.thread.start()
        print("🔄 Connection Tracker gestartet")

    def stop(self):
        """Stoppt das Connection Tracking"""
        self.running = False
        print("⏹️  Connection Tracker gestoppt")

    def set_filters(self, show_incoming: bool, show_outgoing: bool):
        """Setzt die Anzeigefilter"""
        with self.lock:
            self.show_incoming = show_incoming
            self.show_outgoing = show_outgoing

    def _tracking_loop(self):
        """Haupt-Loop für Connection Tracking"""
        while self.running:
            try:
                self._update_connections()

                # Gefilterte Verbindungen abrufen
                with self.lock:
                    filtered_conns = []
                    for conn in self.active_connections.values():
                        if conn.is_incoming and not self.show_incoming:
                            continue
                        if conn.is_outgoing and not self.show_outgoing:
                            continue
                        filtered_conns.append(conn)

                # Signal emittieren
                self.connections_updated.emit(filtered_conns)

                time.sleep(self.update_interval)
            except Exception as e:
                print(f"❌ Connection Tracker Error: {e}")
                time.sleep(self.update_interval)

    def _update_connections(self):
        """Aktualisiert die Liste der aktiven Verbindungen"""
        try:
            # Hole alle Netzwerkverbindungen
            connections = psutil.net_connections(kind='inet')
            current_keys = set()

            # Hole I/O Counters (aktuell nicht pro Verbindung genutzt,
            # könnte später für Bytes-Statistik verwendet werden)
            io_counters = psutil.net_io_counters(pernic=False)

            with self.lock:
                for conn in connections:
                    # Nur etablierte Verbindungen mit Remote-Adresse
                    if conn.status != 'ESTABLISHED' or not conn.raddr:
                        continue

                    try:
                        # Verbindungsinformationen extrahieren
                        local_ip = conn.laddr.ip if conn.laddr else "0.0.0.0"
                        local_port = conn.laddr.port if conn.laddr else 0
                        remote_ip = conn.raddr.ip
                        remote_port = conn.raddr.port

                        # Protokoll bestimmen
                        protocol = "TCP" if conn.type == socket.SOCK_STREAM else "UDP"

                        # App-Name ermitteln
                        try:
                            proc = psutil.Process(conn.pid) if conn.pid else None
                            app_name = proc.name() if proc else "System"
                        except Exception:
                            app_name = "Unknown"

                        # Richtung bestimmen (visuelle 50/50-Heuristik)
                        # Ziel:
                        # - Für die Visualisierung ungefähr gleich viele blaue (IN) und grüne (OUT) Linien
                        # - Die Richtung ist hier rein optisch, nicht technisch exakt.
                        conn_key = f"{local_ip}:{local_port}->{remote_ip}:{remote_port}"
                        try:
                            h = int(hashlib.md5(conn_key.encode("utf-8")).hexdigest(), 16)
                        except Exception:
                            h = hash(conn_key)
                        if h % 2 == 0:
                            direction = "incoming"
                        else:
                            direction = "outgoing"

                        # Geografische Daten abrufen
                        country, city, lat, lon = "Unknown", "Unknown", 0.0, 0.0
                        try:
                            loc = self.geo_manager.lookup_ip(remote_ip)
                            if loc:
                                country = loc.country or "Unknown"
                                city = loc.name or "Unknown"
                                lat = loc.lat
                                lon = loc.lon
                        except Exception:
                            pass

                        # Connection-Objekt erstellen oder aktualisieren
                        connection = Connection(
                            local_ip=local_ip,
                            local_port=local_port,
                            remote_ip=remote_ip,
                            remote_port=remote_port,
                            protocol=protocol,
                            direction=direction,
                            app_name=app_name,
                            timestamp=time.time(),
                            country=country,
                            city=city,
                            lat=lat,
                            lon=lon,
                        )

                        key = connection.get_key()
                        current_keys.add(key)

                        if key not in self.active_connections:
                            self.active_connections[key] = connection
                            self.connection_history.append(connection)
                            if len(self.connection_history) > 1000:
                                self.connection_history = self.connection_history[-1000:]
                        else:
                            self.active_connections[key].timestamp = time.time()

                    except Exception:
                        continue

                # Alte/geschlossene Verbindungen entfernen (älter als 10 Sekunden)
                current_time = time.time()
                keys_to_remove = []
                for key, conn in self.active_connections.items():
                    if key not in current_keys or (current_time - conn.timestamp) > 10:
                        keys_to_remove.append(key)

                for key in keys_to_remove:
                    del self.active_connections[key]

        except Exception as e:
            print(f"❌ Connection update error: {e}")

    def get_active_connections(self) -> List[Connection]:
        """Gibt die Liste der aktiven Verbindungen zurück"""
        with self.lock:
            return list(self.active_connections.values())

    def get_connection_count(self) -> tuple:
        """Gibt (incoming_count, outgoing_count) zurück"""
        with self.lock:
            incoming = sum(1 for c in self.active_connections.values() if c.is_incoming)
            outgoing = sum(1 for c in self.active_connections.values() if c.is_outgoing)
            return incoming, outgoing

    def get_stats(self) -> dict:
        """Gibt Statistiken über die Verbindungen zurück"""
        with self.lock:
            total = len(self.active_connections)
            incoming, outgoing = self.get_connection_count()

            # Top Countries
            country_counts = defaultdict(int)
            for conn in self.active_connections.values():
                country_counts[conn.country] += 1

            # Top Apps
            app_counts = defaultdict(int)
            for conn in self.active_connections.values():
                app_counts[conn.app_name] += 1

            return {
                "total": total,
                "incoming": incoming,
                "outgoing": outgoing,
                "top_countries": sorted(country_counts.items(), key=lambda x: x[1], reverse=True)[:5],
                "top_apps": sorted(app_counts.items(), key=lambda x: x[1], reverse=True)[:5],
            }

    # ------------------------------------------------------------------
    # Neu: Flows aus WLAN-Sniffer (tcpdump) klassifizieren
    # ------------------------------------------------------------------
    def add_sniffed_flow(self, src_ip: str, dst_ip: str, protocol: str = "UNKNOWN", length: int = 0):
        """
        Nimmt einen Flow aus dem WLAN-Sniffer entgegen und klassifiziert ihn.

        src_ip / dst_ip: IP-Adressen ohne Port.
        Rückgabe: direction-String
            - "incoming"
            - "outgoing"
            - "local"     (intern ↔ intern)
            - "external"  (extern ↔ extern, z.B. VPN)
        """

        # 1) Validierung
        try:
            src = ipaddress.ip_address(src_ip)
            dst = ipaddress.ip_address(dst_ip)
        except Exception:
            return None

        # 2) interne Netzbereiche
        private_ranges = [
            ipaddress.ip_network("10.0.0.0/8"),
            ipaddress.ip_network("172.16.0.0/12"),
            ipaddress.ip_network("192.168.0.0/16"),
        ]

        def is_internal(ip):
            return any(ip in net for net in private_ranges)

        src_internal = is_internal(src)
        dst_internal = is_internal(dst)

        # 3) Richtung bestimmen
        if src_internal and dst_internal:
            direction = "local"
        elif src_internal and not dst_internal:
            direction = "outgoing"
        elif not src_internal and dst_internal:
            direction = "incoming"
        else:
            direction = "external"

        # 4) vorerst nur Debug – später: echtes Connection-Objekt anlegen
        print(f"[Sniffer] {direction.upper():9} {src_ip} -> {dst_ip} | {protocol} | {length} B")

        return direction

    def classify_ip(self, ip: str) -> str:
        """
        Klassifiziert eine IP-Adresse als:
        - 'internal' (privates LAN)
        - 'external' (öffentliches Internet)
        - 'multicast'
        - 'broadcast'
        - 'invalid'

        Wird später genutzt für:
        - Geräte-Tab
        - Geo-Lines
        - Graph-Farben
        - LAN/WAN-Erkennung
        """

        if not ip:
            return "invalid"

        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return "invalid"

        # Broadcast
        if ip == "255.255.255.255":
            return "broadcast"

        # Multicast (224.0.0.0 – 239.255.255.255)
        if addr.is_multicast:
            return "multicast"

        # Private LAN (RFC1918)
        if addr.is_private:
            return "internal"

        # Ansonsten extern → Internet
        return "external"

