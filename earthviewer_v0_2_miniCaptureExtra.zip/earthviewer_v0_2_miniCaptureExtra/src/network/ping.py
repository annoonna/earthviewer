#!/usr/bin/env python3
"""
Ping-Funktionalität - Fixed für Linux & Windows
"""
import subprocess
import re
import platform
from typing import Optional

class PingResult:
    """Ergebnis eines Pings"""
    def __init__(self, success: bool, rtt: float, ttl: int):
        self.success = success
        self.rtt = rtt
        self.ttl = ttl

class Ping:
    """Führt Ping aus"""
    
    def __init__(self):
        self.is_windows = platform.system() == "Windows"
    
    def ping(self, target: str, count: int = 4) -> list:
        """Führt Ping aus und verarbeitet die Ausgabe live."""
        results = []
        
        try:
            # Command zusammenbauen
            if self.is_windows:
                cmd = ["ping", "-n", str(count), target]
            else:
                # -O sorgt manchmal für bessere Output-Informationen, ist aber optional
                cmd = ["ping", "-c", str(count), target]
            
            # Popen mit bufsize=1 (Zeilen-Buffer) für Live-Output
            process = subprocess.Popen(
                cmd, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT, 
                text=True, 
                bufsize=1
            )
            
            # Zeile für Zeile lesen
            for line in iter(process.stdout.readline, ''):
                if not line:
                    break
                    
                result = self._parse_line(line)
                if result:
                    results.append(result)
                    yield result # Yield für Live-Update im UI
            
            process.stdout.close()
            process.wait()
            
        except Exception as e:
            print(f"❌ Ping-Fehler: {e}")
        
        return results
    
    def _parse_line(self, line: str) -> Optional[PingResult]:
        """Parsed Ping-Ausgabe robust (egal welche Reihenfolge)"""
        line = line.strip()
        if not line: return None

        # Suche nach time=X ms
        # Windows: time=10ms, Linux: time=10.5 ms
        time_match = re.search(r'time[=<]([\d.]+)\s*ms', line, re.IGNORECASE)
        
        # Suche nach TTL=X
        ttl_match = re.search(r'ttl=(\d+)', line, re.IGNORECASE)
        
        if time_match and ttl_match:
            try:
                rtt = float(time_match.group(1))
                ttl = int(ttl_match.group(1))
                return PingResult(True, rtt, ttl)
            except ValueError:
                pass
                
        return None
