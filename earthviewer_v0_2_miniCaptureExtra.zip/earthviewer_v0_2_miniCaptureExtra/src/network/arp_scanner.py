#!/usr/bin/env python3
"""
ARP Scanner - Entdeckt lokale Netzwerkgeräte
Mit MAC-Vendor-Lookup und Hostname-Resolution
"""

import threading
import socket
import struct
import time
from typing import Dict, List, Tuple
from PyQt6.QtCore import QObject, pyqtSignal

try:
    from scapy.all import ARP, Ether, srp, conf
    import netifaces
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False
    print("⚠️ Scapy nicht installiert - ARP-Scanning deaktiviert")

class DeviceInfo:
    def __init__(self, ip: str, mac: str, hostname: str = None, vendor: str = None):
        self.ip = ip
        self.mac = mac
        self.hostname = hostname or "Unknown"
        self.vendor = vendor or self._lookup_vendor(mac)
        self.last_seen = time.time()
        self.traffic_rx = 0
        self.traffic_tx = 0
        self.signal_strength = -50  # Dummy für WLAN-Geräte
    
    def _lookup_vendor(self, mac: str) -> str:
        """MAC-Vendor-Lookup über OUI-Datenbank"""
        oui = mac.upper()[:8]
        vendors = {
            "00:50:56": "VMware",
            "00:0C:29": "VMware", 
            "00:1B:21": "Intel",
            "00:1E:67": "Intel",
            "00:23:14": "Intel",
            "3C:5A:B4": "Google",
            "94:65:2D": "OnePlus",
            "AC:DE:48": "Apple",
            "00:03:93": "Apple",
            "00:17:F2": "Apple",
            "00:1B:63": "Apple",
            "00:1E:C2": "Apple",
            "00:25:BC": "Apple",
            "00:26:BB": "Apple",
            "D4:9A:20": "Samsung",
            "E8:50:8B": "Samsung",
            "20:6E:9C": "Samsung",
            "C4:73:1E": "Samsung",
            "78:40:E4": "Samsung",
            "F0:5C:77": "Samsung",
            "14:4F:8A": "TP-Link",
            "EC:08:6B": "TP-Link",
            "50:C7:BF": "TP-Link",
            "B0:4E:26": "TP-Link",
            "98:DA:C4": "TP-Link",
            "08:00:27": "VirtualBox",
            "52:54:00": "QEMU/KVM",
            "00:1C:42": "Parallels",
            "00:05:69": "VMware",
            "DC:A6:32": "Raspberry Pi",
            "B8:27:EB": "Raspberry Pi",
            "E4:5F:01": "Raspberry Pi",
            "28:CD:C1": "Raspberry Pi",
            "2C:CF:67": "Raspberry Pi",
            "00:09:BF": "Nintendo",
            "00:1A:E9": "Nintendo",
            "00:1B:EA": "Nintendo",
            "00:1C:BE": "Nintendo",
            "00:1D:BC": "Nintendo",
            "00:1E:35": "Nintendo",
            "00:1E:A9": "Nintendo",
            "00:1F:32": "Nintendo",
            "00:1F:C5": "Nintendo",
            "00:21:47": "Nintendo",
            "34:AF:2C": "Nintendo",
            "00:15:5D": "Microsoft Hyper-V",
            "00:50:F2": "Microsoft",
            "00:17:FA": "Microsoft Xbox",
            "00:22:48": "Microsoft",
            "00:24:D7": "Intel",
            "00:21:6A": "Intel",
            "08:C5:E1": "Samsung",
            "34:23:87": "Hon Hai/Foxconn",
            "64:A2:F9": "OnePlus",
            "AC:CF:85": "Huawei",
            "00:E0:4C": "Realtek",
            "00:13:D4": "ASUSTeK",
            "38:2C:4A": "ASUSTeK",
            "00:04:61": "EPSON",
            "00:1B:11": "D-Link",
            "14:D6:4D": "D-Link",
            "C8:BE:19": "D-Link",
            "00:24:01": "D-Link",
            "00:80:77": "Brother",
            "00:1B:A9": "Brother",
            "00:80:92": "Brother",
            "A0:AB:51": "WEIFENG",
            "3C:06:30": "Xiaomi",
            "64:CC:2E": "Xiaomi",
            "38:A4:ED": "Xiaomi",
            "3C:BD:D8": "Xiaomi",
            "78:02:B7": "Xiaomi",
            "7C:B2:32": "Xiaomi",
            "50:8F:4C": "Xiaomi",
            "7C:1D:D9": "Xiaomi",
            "AC:C1:EE": "Xiaomi",
        }
        
        # Suche nach Vendor
        for prefix, vendor in vendors.items():
            if oui.startswith(prefix):
                return vendor
        
        # Weitere Hersteller-Identifikation
        if oui.startswith("00:16:3E"):
            return "Xen Virtual"
        elif oui.startswith("FA:16:3E"):
            return "OpenStack"
        
        return "Unknown"

class ARPScanner(QObject):
    """Scannt das lokale Netzwerk nach Geräten"""
    
    devices_found = pyqtSignal(list)  # List[DeviceInfo]
    scan_progress = pyqtSignal(int)   # 0-100
    scan_finished = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.devices: Dict[str, DeviceInfo] = {}
        self.scanning = False
        self._lock = threading.Lock()
        
        if not SCAPY_AVAILABLE:
            print("⚠️ ARP-Scanner deaktiviert - installiere scapy!")
    
    def start_scan(self, interface: str = None):
        """Startet einen ARP-Scan im Hintergrund"""
        if not SCAPY_AVAILABLE:
            print("❌ Scapy nicht verfügbar!")
            return
        
        if self.scanning:
            print("⚠️ Scan läuft bereits")
            return
        
        self.scanning = True
        thread = threading.Thread(
            target=self._scan_network,
            args=(interface,),
            daemon=False
        )
        thread.start()
    
    def _get_network_range(self, interface: str = None) -> str:
        """Ermittelt den Netzwerk-Range (z.B. 192.168.1.0/24)"""
        try:
            if not interface:
                # Finde Standard-Interface
                gws = netifaces.gateways()
                interface = gws['default'][netifaces.AF_INET][1]
            
            addrs = netifaces.ifaddresses(interface)
            if netifaces.AF_INET in addrs:
                ip_info = addrs[netifaces.AF_INET][0]
                ip = ip_info['addr']
                netmask = ip_info['netmask']
                
                # Berechne Netzwerk-Range
                ip_int = struct.unpack('>I', socket.inet_aton(ip))[0]
                mask_int = struct.unpack('>I', socket.inet_aton(netmask))[0]
                network_int = ip_int & mask_int
                network_ip = socket.inet_ntoa(struct.pack('>I', network_int))
                
                # CIDR-Notation
                cidr = bin(mask_int).count('1')
                return f"{network_ip}/{cidr}"
        except Exception as e:
            print(f"❌ Netzwerk-Range-Fehler: {e}")
            return "192.168.1.0/24"  # Fallback
    
    def _scan_network(self, interface: str = None):
        """Führt den eigentlichen ARP-Scan durch"""
        try:
            # Setze Scapy auf leise
            conf.verb = 0
            
            network = self._get_network_range(interface)
            print(f"🔍 Scanne Netzwerk: {network}")
            self.scan_progress.emit(10)
            
            # ARP-Request erstellen
            arp = ARP(pdst=network)
            ether = Ether(dst="ff:ff:ff:ff:ff:ff")
            packet = ether/arp
            
            # Sende Pakete und empfange Antworten
            self.scan_progress.emit(30)
            result = srp(packet, timeout=2, retry=2, verbose=False)[0]
            
            self.scan_progress.emit(60)
            
            # Verarbeite Antworten
            new_devices = []
            for sent, received in result:
                ip = received.psrc
                mac = received.hwsrc.upper()
                
                # Hostname-Resolution
                hostname = self._resolve_hostname(ip)
                
                # Device-Info erstellen
                device = DeviceInfo(ip, mac, hostname)
                
                with self._lock:
                    self.devices[ip] = device
                    new_devices.append(device)
            
            self.scan_progress.emit(90)
            
            # Zusätzlich: Eigene IP hinzufügen
            try:
                hostname = socket.gethostname()
                local_ip = socket.gethostbyname(hostname)
                if local_ip not in self.devices:
                    import uuid
                    mac = ':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff) 
                                  for ele in range(0,48,8)][::-1]).upper()
                    self.devices[local_ip] = DeviceInfo(local_ip, mac, hostname, "This Device")
                    new_devices.append(self.devices[local_ip])
            except:
                pass
            
            self.scan_progress.emit(100)
            self.devices_found.emit(new_devices)
            
            print(f"✅ {len(new_devices)} Geräte gefunden!")
            
        except Exception as e:
            print(f"❌ Scan-Fehler: {e}")
        finally:
            self.scanning = False
            self.scan_finished.emit()
    
    def _resolve_hostname(self, ip: str) -> str:
        """Versucht den Hostname einer IP zu ermitteln"""
        try:
            return socket.gethostbyaddr(ip)[0]
        except:
            return None
    
    def get_all_devices(self) -> List[DeviceInfo]:
        """Gibt alle gefundenen Geräte zurück"""
        with self._lock:
            return list(self.devices.values())
    
    def update_traffic(self, ip: str, rx_bytes: int, tx_bytes: int):
        """Aktualisiert Traffic-Statistiken für ein Gerät"""
        with self._lock:
            if ip in self.devices:
                self.devices[ip].traffic_rx = rx_bytes
                self.devices[ip].traffic_tx = tx_bytes
                self.devices[ip].last_seen = time.time()

# Singleton-Instance
_scanner_instance = None

def get_scanner() -> ARPScanner:
    """Gibt die globale Scanner-Instanz zurück"""
    global _scanner_instance
    if _scanner_instance is None:
        _scanner_instance = ARPScanner()
    return _scanner_instance
