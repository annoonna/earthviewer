#!/usr/bin/env python3
"""
VirusTotal Integration - Analysiert IPs und Domains
Benötigt API-Key von virustotal.com (v3 API).

Funktionen:
  - Konfiguration via set_api_key (prüft erst, speichert dann)
  - Scans (scan_ip) mit Caching
  - GUI-Helpers (format_summary, format_tooltip)
"""
from __future__ import annotations
import json
import threading
import time
from typing import Dict, Optional, Tuple
import requests
from PyQt6.QtCore import QObject, pyqtSignal

VT_API_BASE = "https://www.virustotal.com/api/v3"
DEFAULT_MIN_INTERVAL = 16.0

class VirusTotalConfig:
    """Konfiguration für VirusTotal (wird in settings.json gespeichert)."""
    def __init__(self) -> None:
        self.api_key: str = ""
        self.auto_scan_enabled: bool = False
        self.manual_scan_enabled: bool = True
        self.min_interval: float = DEFAULT_MIN_INTERVAL
        self._load_config()

    def _load_config(self) -> None:
        try:
            with open("settings.json", "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
        
        vt_cfg = data.get("virustotal", {}) or {}
        self.api_key = (vt_cfg.get("api_key") or "").strip()
        self.auto_scan_enabled = bool(vt_cfg.get("auto_scan", False))
        self.manual_scan_enabled = bool(vt_cfg.get("manual_scan", True))
        self.min_interval = float(vt_cfg.get("min_interval", DEFAULT_MIN_INTERVAL)) or DEFAULT_MIN_INTERVAL

    def save_config(self) -> bool:
        try:
            try:
                with open("settings.json", "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = {}
            
            data["virustotal"] = {
                "api_key": self.api_key,
                "auto_scan": self.auto_scan_enabled,
                "manual_scan": self.manual_scan_enabled,
                "min_interval": self.min_interval,
            }
            with open("settings.json", "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"❌ VirusTotalConfig: Fehler beim Speichern: {e}")
            return False

    def as_headers(self) -> Dict[str, str]:
        return {"x-apikey": self.api_key} if self.api_key else {}


class VirusTotalAnalyzer(QObject):
    scan_result = pyqtSignal(str, dict)
    scan_error = pyqtSignal(str, str)

    def __init__(self, parent: Optional[QObject] = None) -> None:
        super().__init__(parent)
        self.config = VirusTotalConfig()
        self._cache: Dict[str, Dict] = {}
        self._queue: list[Tuple[str, str]] = []
        self._queue_lock = threading.Lock()
        self._scan_thread: Optional[threading.Thread] = None
        self._running = False

    # ------------------------------------------------------------------
    #       Konfiguration / API-Key
    # ------------------------------------------------------------------
    def set_api_key(self, api_key: str) -> bool:
        """
        Setzt den API-Key. Prüft ihn VOR dem Speichern.
        """
        api_key = (api_key or "").strip()
        
        # Temporäre Config für den Test erstellen
        temp_config = VirusTotalConfig() 
        temp_config.api_key = api_key

        if not api_key:
            self.config.api_key = ""
            self.config.save_config()
            print("⚠️ VirusTotal: Leerer API-Key gesetzt – Integration deaktiviert.")
            return False

        # Wir nutzen die interne Helper-Methode für den Test
        is_valid = self._check_api_configuration(temp_config)

        if is_valid:
            self.config.api_key = api_key
            self.config.save_config()
            print("✅ VirusTotal: API-Key erfolgreich validiert und gespeichert.")
            return True
        else:
            print("❌ VirusTotal: API-Key ungültig (401/403). Nicht gespeichert.")
            return False

    def _check_api_configuration(self, config_obj: VirusTotalConfig) -> bool:
        """
        Interne Methode: Prüft eine BESTIMMTE Konfiguration.
        """
        if not config_obj.api_key:
            return False
        try:
            # Wir fragen /users/me ab (leichtgewichtig)
            resp = requests.get(
                f"{VT_API_BASE}/users/me",
                headers=config_obj.as_headers(),
                timeout=8,
            )
            
            if resp.status_code == 200:
                return True
            
            # Explizite Ablehnung durch API
            if resp.status_code in (401, 403):
                print(f"❌ VirusTotal API Check: Ungültig (HTTP {resp.status_code})")
                return False

            # Rate Limit (429) oder Serverfehler gelten als "OK" (wir wollen nicht blockieren)
            if resp.status_code == 429:
                print("⚠️ VirusTotal: Rate Limit erreicht, aber Key ist gültig.")
                return True

            return True # Im Zweifel für den Angeklagten (Netzwerkfehler etc.)

        except Exception as e:
            print(f"⚠️ VirusTotal Check Exception: {e}")
            return True

    def _test_api_key(self) -> bool:
        """
        API-Kompatibilität für die GUI:
        Testet den AKTUELL GENUTZTEN Key (self.config).
        Nimmt KEINE Argumente, da die GUI das so erwartet.
        """
        return self._check_api_configuration(self.config)

    def enable_auto_scan(self, enable: bool) -> None:
        self.config.auto_scan_enabled = bool(enable)
        self.config.save_config()

    def is_auto_scan_enabled(self) -> bool:
        return bool(self.config.auto_scan_enabled)

    # ------------------------------------------------------------------
    #       Scanning Logic
    # ------------------------------------------------------------------
    def _make_cache_key(self, kind: str, value: str) -> str:
        return f"{kind}:{value}"

    def scan_ip(self, ip_address: str, force: bool = False) -> None:
        ip_address = (ip_address or "").strip()
        if not ip_address: return
        if not self.config.api_key:
            self.scan_error.emit(ip_address, "Kein VirusTotal-API-Key konfiguriert.")
            return

        cache_key = self._make_cache_key("ip", ip_address)
        if not force and cache_key in self._cache:
            entry = self._cache[cache_key]
            if (time.time() - entry.get("timestamp", 0)) < 3600:
                self.scan_result.emit(ip_address, entry["data"])
                return

        with self._queue_lock:
            self._queue.append(("ip", ip_address))
        self._ensure_thread()

    def scan_domain(self, domain: str, force: bool = False) -> None:
        domain = (domain or "").strip()
        if not domain: return
        if not self.config.api_key:
            self.scan_error.emit(domain, "Kein VirusTotal-API-Key konfiguriert.")
            return

        cache_key = self._make_cache_key("domain", domain)
        if not force and cache_key in self._cache:
            entry = self._cache[cache_key]
            if (time.time() - entry.get("timestamp", 0)) < 3600:
                self.scan_result.emit(domain, entry["data"])
                return

        with self._queue_lock:
            self._queue.append(("domain", domain))
        self._ensure_thread()

    def _ensure_thread(self) -> None:
        if self._scan_thread and self._scan_thread.is_alive():
            return
        self._running = True
        self._scan_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self._scan_thread.start()

    def _worker_loop(self) -> None:
        while self._running:
            with self._queue_lock:
                job = self._queue.pop(0) if self._queue else None
            if not job:
                self._running = False
                return

            kind, value = job
            try:
                if kind == "ip":
                    data = self._request_vt(f"ip_addresses/{value}")
                elif kind == "domain":
                    data = self._request_vt(f"domains/{value}")
                else:
                    continue

                self._cache[self._make_cache_key(kind, value)] = {
                    "timestamp": time.time(),
                    "data": data
                }
                self.scan_result.emit(value, data)
            except Exception as e:
                print(f"[VirusTotal] Fehler: {e}")
                self.scan_error.emit(value, str(e))
            
            time.sleep(self.config.min_interval)

    def _request_vt(self, endpoint: str) -> Dict:
        url = f"{VT_API_BASE}/{endpoint}"
        r = requests.get(url, headers=self.config.as_headers(), timeout=30)
        if r.status_code == 401: raise RuntimeError("API-Key ungültig (401)")
        if r.status_code == 404: return {"not_found": True, "data": None}
        if r.status_code != 200: raise RuntimeError(f"HTTP {r.status_code}")
        return r.json()

    # ------------------------------------------------------------------
    #       Formatierung
    # ------------------------------------------------------------------
    def _extract_stats(self, data: Dict) -> Dict[str, int]:
        try:
            return data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
        except:
            return {}

    def get_threat_level(self, data: Dict) -> str:
        stats = self._extract_stats(data)
        if not stats: return "unknown"
        if stats.get("malicious", 0) > 0: return "danger"
        if stats.get("suspicious", 0) > 0: return "warning"
        return "ok"

    def format_summary(self, data: Dict) -> str:
        if not data or data.get("not_found"): return "ℹ️ Keine Daten"
        stats = self._extract_stats(data)
        if not stats: return "ℹ️ Keine Daten"
        mal = stats.get("malicious", 0)
        susp = stats.get("suspicious", 0)
        tot = sum(stats.values())
        if mal > 0: return f"🛑 Malicious ({mal}/{tot})"
        if susp > 0: return f"⚠️ Suspicious ({susp}/{tot})"
        return f"✅ Clean ({mal+susp}/{tot})"

    def format_tooltip(self, data: Dict) -> str:
        if not data: return "Keine Daten"
        stats = self._extract_stats(data)
        lines = ["VirusTotal Ergebnis:", ""]
        for k, v in stats.items():
            lines.append(f"{k.capitalize()}: {v}")
        link = data.get("data", {}).get("links", {}).get("self")
        if link: lines.append(f"\nLink: {link}")
        return "\n".join(lines)

_vt_instance: Optional[VirusTotalAnalyzer] = None
def get_virustotal_analyzer() -> VirusTotalAnalyzer:
    global _vt_instance
    if _vt_instance is None:
        _vt_instance = VirusTotalAnalyzer()
    return _vt_instance
