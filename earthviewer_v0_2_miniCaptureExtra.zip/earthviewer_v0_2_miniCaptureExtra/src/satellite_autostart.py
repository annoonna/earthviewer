#!/usr/bin/env python3
"""
Satellite Autostart
-------------------

Monkeypatcht MainWindow.__init__, um nach der normalen Initialisierung
automatisch die Satelliten-Integration zu aktivieren.

Dadurch musst du main_window.py nicht anfassen – es reicht, dieses
Modul (satellite_autostart) frühzeitig zu importieren (z.B. aus main.py).
"""

from __future__ import annotations

import logging
import traceback

from ui.widgets.main_window import MainWindow
from ui.widgets.satellite_integration import setup_satellites_on_mainwindow


logger = logging.getLogger(__name__)

_original_init = MainWindow.__init__


def _patched_init(self, *args, **kwargs):
    # Erst die originale Initialisierung
    _original_init(self, *args, **kwargs)

    # Danach Satelliten-Integration versuchen
    try:
        setup_satellites_on_mainwindow(self)
    except Exception as exc:
        logger.warning("Fehler bei setup_satellites_on_mainwindow: %s", exc)
        traceback.print_exc()


MainWindow.__init__ = _patched_init

logger.info("satellite_autostart: MainWindow.__init__ wurde gepatcht (Satelliten-Autostart aktiviert).")
