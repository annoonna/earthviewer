"""
Satellite Tracker Engine with Offline TLE Support
"""
import requests
from dataclasses import dataclass
from typing import List, Dict, Optional
from datetime import datetime, timezone
import math

try:
    from sgp4.api import Satrec
    HAVE_SGP4 = True
except ImportError:
    HAVE_SGP4 = False

try:
    from utils.orbit_calculator import OrbitCalculator
    HAVE_ORBIT_CALC = True
except ImportError:
    HAVE_ORBIT_CALC = False

TLE_SOURCES = {
    "Space Stations": "https://celestrak.org/NORAD/elements/gp.php?GROUP=stations&FORMAT=tle",
    "Weather": "https://celestrak.org/NORAD/elements/gp.php?GROUP=weather&FORMAT=tle",
    "Starlink": "https://celestrak.org/NORAD/elements/gp.php?GROUP=starlink&FORMAT=tle",
    "GPS": "https://celestrak.org/NORAD/elements/gp.php?GROUP=gps-ops&FORMAT=tle",
}

OFFLINE_TLES = {
    "Space Stations": [
        ("ISS (ZARYA)", 
         "1 25544U 98067A   25339.25291940  .00014736  00000+0  27197-3 0  9993",
         "2 25544  51.6297 179.5463 0003585 206.2517 153.8291 15.49328184541690"),
    ]
}

@dataclass
class SatelliteInfo:
    name: str
    tle1: str
    tle2: str
    catalog_number: Optional[int] = None

@dataclass
class LocalSatPosition:
    name: str
    lat: float
    lon: float
    alt_km: float

class SatelliteTrackerEngine:
    def __init__(self):
        self.satellites: Dict[str, List[SatelliteInfo]] = {}
        self._sgp4_objects: Dict[str, Satrec] = {}
        self.orbit_calc = OrbitCalculator() if HAVE_ORBIT_CALC else None
    
    def fetch_tles(self, category: str) -> int:
        if category not in TLE_SOURCES:
            return 0
        
        url = TLE_SOURCES[category]
        self.satellites[category] = []
        
        try:
            resp = requests.get(url, timeout=30)
            resp.raise_for_status()
            lines = resp.text.strip().split('\n')
            new_sats = []
            i = 0
            while i < len(lines):
                if i + 2 >= len(lines):
                    break
                name = lines[i].strip()
                l1 = lines[i+1].strip()
                l2 = lines[i+2].strip()
                if l1.startswith("1 ") and l2.startswith("2 "):
                    sat = SatelliteInfo(name=name, tle1=l1, tle2=l2)
                    new_sats.append(sat)
                    if HAVE_SGP4:
                        try:
                            self._sgp4_objects[name] = Satrec.twoline2rv(l1, l2)
                        except:
                            pass
                    i += 3
                else:
                    i += 1
            self.satellites[category] = new_sats
            print(f"✅ {len(new_sats)} Satelliten für '{category}' geladen.")
            return len(new_sats)
        except Exception as e:
            print(f"❌ Fehler beim Laden der TLEs: {e}")
            if category in OFFLINE_TLES:
                self.satellites[category] = []
                print(f"   → Verwende Offline-TLEs für {category}")
                for name, tle1, tle2 in OFFLINE_TLES[category]:
                    sat = SatelliteInfo(name=name, tle1=tle1, tle2=tle2)
                    if HAVE_SGP4:
                        try:
                            self._sgp4_objects[name] = Satrec.twoline2rv(tle1, tle2)
                        except:
                            pass
                    self.satellites[category].append(sat)
                print(f"✅ {len(self.satellites[category])} Satelliten (OFFLINE) für '{category}' geladen.")
                return len(self.satellites[category])
            return 0
    

    def calculate_orbit(self, sat_name: str, num_points: int = 100) -> List[tuple]:
        """Calculate orbit points for satellite"""
        if not self.orbit_calc:
            print(f"⚠️ OrbitCalculator nicht verfügbar!")
            return []
        
        # Find satellite in all categories
        for category, sats in self.satellites.items():
            for sat in sats:
                if sat.name == sat_name:
                    if sat.tle1 and sat.tle2:
                        # Verwende die GLEICHE Zeit wie für Satelliten-Positionen
                        from datetime import datetime
                        current_time = datetime.utcnow()
                        result = self.orbit_calc.calculate_orbit_points(
                            sat.tle1, sat.tle2, sat_name, num_points, start_time=current_time
                        )
                        if result and 'points' in result:
                            points = result['points']
                            print(f"🎯 Orbit berechnet: {len(points)} Punkte für {sat_name}, Periode: {result.get('period_minutes', 0):.1f} min")
                            # Return the full dictionary (not just list)
                            return result
                    else:
                        print(f"⚠️ Keine TLE-Daten für {sat_name}")
                        return []
        
        print(f"⚠️ Satellit {sat_name} nicht gefunden!")
        return []

    def compute_positions(self, category: str = None) -> List[LocalSatPosition]:
        if not HAVE_SGP4:
            return []
        results = []
        now = datetime.now(timezone.utc)
        jd = self._datetime_to_jd(now)
        fr = (jd - int(jd))
        categories_to_process = [category] if category else self.satellites.keys()
        for cat in categories_to_process:
            if cat not in self.satellites:
                continue
            for sat in self.satellites[cat]:
                if sat.name not in self._sgp4_objects:
                    continue
                satrec = self._sgp4_objects[sat.name]
                e, r, v = satrec.sgp4(jd, fr * 1440.0)
                if e == 0:
                    x, y, z = r
                    r_km = math.sqrt(x*x + y*y + z*z)
                    lon = math.atan2(y, x) - self._gst(now)
                    lon = (lon + 3*math.pi) % (2*math.pi) - math.pi
                    lat = math.atan2(z, math.sqrt(x*x + y*y))
                    results.append(LocalSatPosition(
                        name=sat.name,
                        lat=math.degrees(lat),
                        lon=math.degrees(lon),
                        alt_km=r_km - 6371.0
                    ))
        return results
    
    def _datetime_to_jd(self, dt: datetime) -> float:
        a = (14 - dt.month) // 12
        y = dt.year + 4800 - a
        m = dt.month + 12 * a - 3
        jdn = dt.day + (153 * m + 2) // 5 + 365 * y + y // 4 - y // 100 + y // 400 - 32045
        jd = jdn + (dt.hour - 12) / 24.0 + dt.minute / 1440.0 + dt.second / 86400.0
        jd += dt.microsecond / 86400000000.0
        return jd
    
    def _gst(self, dt: datetime) -> float:
        jd = self._datetime_to_jd(dt)
        t = (jd - 2451545.0) / 36525.0
        gst = 280.46061837 + 360.98564736629 * (jd - 2451545.0) + 0.000387933 * t * t - t * t * t / 38710000.0
        return math.radians(gst % 360.0)
