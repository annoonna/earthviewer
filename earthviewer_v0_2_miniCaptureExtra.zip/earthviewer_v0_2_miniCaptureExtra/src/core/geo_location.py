#!/usr/bin/env python3
"""
GeoLocation - Geografische Position mit Metadaten
"""
import math
import numpy as np
from dataclasses import dataclass, field
from typing import Tuple, Dict, Any

@dataclass
class GeoLocation:
    """Geografische Position"""
    name: str
    lat: float
    lon: float
    country: str = ""
    location_type: str = "city"
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_cartesian(self, radius: float = 1.0) -> np.ndarray:
        """Konvertiert Lat/Lon zu 3D-Kartesischen Koordinaten"""
        lat_rad = math.radians(self.lat)
        lon_rad = math.radians(self.lon)
        
        x = radius * math.cos(lat_rad) * math.sin(lon_rad)
        y = radius * math.sin(lat_rad)
        z = radius * math.cos(lat_rad) * math.cos(lon_rad)
        
        return np.array([x, y, z], dtype=np.float32)
    
    def to_uv(self) -> Tuple[float, float]:
        """Konvertiert Lat/Lon zu Textur UV-Koordinaten"""
        u = (self.lon + 180.0) / 360.0
        v = (90.0 - self.lat) / 180.0
        return u, v
    
    def distance_to(self, other: 'GeoLocation') -> float:
        """Berechnet Distanz zu anderem Punkt (Haversine, in km)"""
        R = 6371.0
        
        lat1, lon1 = math.radians(self.lat), math.radians(self.lon)
        lat2, lon2 = math.radians(other.lat), math.radians(other.lon)
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a))
        
        return R * c
