#!/usr/bin/env python3
"""
Settings Manager - Speichert Einstellungen persistent
"""
import json
from pathlib import Path
from core.config import PROJECT_ROOT

class SettingsManager:
    """Verwaltet persistente Einstellungen"""
    
    def __init__(self):
        self.settings_file = PROJECT_ROOT / "settings.json"
        self.settings = self._load()
    
    def _load(self):
        """Lädt Einstellungen"""
        if self.settings_file.exists():
            try:
                with open(self.settings_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return self._defaults()
    
    def _defaults(self):
        """Standard-Einstellungen"""
        return {
            "marker_offset": 0.02,
            "auto_rotate_speed": 0.3,
            "show_markers": True,
            "show_labels": True
        }
    
    def save(self):
        """Speichert Einstellungen"""
        try:
            with open(self.settings_file, 'w') as f:
                json.dump(self.settings, f, indent=2)
            print(f"✅ Einstellungen gespeichert")
            return True
        except Exception as e:
            print(f"⚠️ Fehler beim Speichern: {e}")
            return False
    
    def get(self, key, default=None):
        """Holt Einstellung"""
        return self.settings.get(key, default)
    
    def set(self, key, value):
        """Setzt Einstellung"""
        self.settings[key] = value
        self.save()

# Globale Instanz
settings = SettingsManager()
