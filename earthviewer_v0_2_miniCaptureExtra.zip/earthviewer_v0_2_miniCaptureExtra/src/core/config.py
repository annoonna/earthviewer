#!/usr/bin/env python3
"""
Zentrale Konfiguration für EarthViewer
"""
from pathlib import Path

# Projekt-Pfade
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DATA_DIR = PROJECT_ROOT / "data"
GEODATA_DIR = DATA_DIR / "geodata"
TEXTURE_DIR = DATA_DIR / "textures"
SCREENSHOT_DIR = PROJECT_ROOT / "screenshots"
LOG_DIR = PROJECT_ROOT / "logs"
SESSION_DIR = PROJECT_ROOT / "sessions"

# Erstelle Verzeichnisse
for directory in [SCREENSHOT_DIR, LOG_DIR, SESSION_DIR]:
    directory.mkdir(exist_ok=True, parents=True)

# Fenster-Einstellungen
WINDOW_TITLE = "🌍 EarthViewer 2.0"
WINDOW_WIDTH = 1400
WINDOW_HEIGHT = 900
WINDOW_MIN_WIDTH = 1000
WINDOW_MIN_HEIGHT = 600

# Rendering
SPHERE_RADIUS = 1.0
MARKER_OFFSET = 0.02
SPHERE_STACKS = 64
SPHERE_SLICES = 128

# Kamera
CAMERA_FOV = 45.0
CAMERA_NEAR = 0.1
CAMERA_FAR = 100.0
CAMERA_DISTANCE = 2.8
CAMERA_MIN_DISTANCE = 1.2
CAMERA_MAX_DISTANCE = 25.0

# Animation
AUTO_ROTATE_SPEED = 0.3
ROTATION_SENSITIVITY = 0.3
ZOOM_FACTOR = 0.9

# Marker-Farben (RGB)
MARKER_COLOR_SEARCH = (1.0, 0.9, 0.2)
MARKER_COLOR_TARGET = (1.0, 0.1, 0.1)
MARKER_COLOR_TRACEROUTE = (0.2, 0.8, 1.0)
MARKER_COLOR_PING = (0.2, 1.0, 0.2)

# Marker-Größen
MARKER_SIZE_SEARCH = 12.0
MARKER_SIZE_TARGET = 18.0
MARKER_SIZE_TRACEROUTE = 10.0

# Netzwerk
TRACEROUTE_MAX_HOPS = 30
TRACEROUTE_TIMEOUT = 2.0
PING_COUNT = 4
PING_INTERVAL = 1.0
WHOIS_TIMEOUT = 10.0

# Texturen
EARTH_TEXTURE = TEXTURE_DIR / "earth_map.jpg"

# Theme-Farben
COLOR_BACKGROUND = "#1e1e1e"
COLOR_SURFACE = "#2b2b2b"
COLOR_PRIMARY = "#0d7377"
COLOR_PRIMARY_HOVER = "#0e8388"
COLOR_SURFACE_VARIANT = "#3a3a3a"
COLOR_BORDER = "#555555"
COLOR_TEXT = "#ffffff"
COLOR_TEXT_SECONDARY = "#aaaaaa"


# ============================================================================
# THEME-SYSTEM
# ============================================================================

THEMES = {
    "Classic Cyber": {
        "name": "Classic Cyber",
        "description": "Original Theme mit Cyan-Akzenten",
        "colors": {
            "search_marker": (255, 220, 80),      # Gelb
            "traceroute_marker": (0, 255, 255),   # Cyan
            "traceroute_line": (0, 255, 255),     # Cyan
            "target_marker": (255, 100, 100),     # Rot
            "label_search": (255, 220, 80),       # Gelb
            "label_traceroute": (0, 255, 255),    # Cyan
            "label_target": (255, 100, 100),      # Rot
            "background": (0, 0, 5),              # Dunkelblau
        }
    },
    
    "Matrix": {
        "name": "Matrix",
        "description": "Neon-Grün Matrix-Style",
        "colors": {
            "search_marker": (100, 255, 100),
            "traceroute_marker": (57, 255, 20),
            "traceroute_line": (57, 255, 20),
            "target_marker": (255, 80, 80),
            "label_search": (100, 255, 100),
            "label_traceroute": (57, 255, 20),
            "label_target": (255, 80, 80),
            "background": (0, 0, 0),
        }
    },
    
    "Cyberpunk": {
        "name": "Cyberpunk",
        "description": "Pink/Purple Cyberpunk-Vibes",
        "colors": {
            "search_marker": (138, 43, 226),      # Lila
            "traceroute_marker": (255, 0, 255),   # Neon-Pink
            "traceroute_line": (255, 0, 255),     # Neon-Pink
            "target_marker": (255, 20, 147),      # Deep Pink
            "label_search": (138, 43, 226),
            "label_traceroute": (255, 0, 255),
            "label_target": (255, 20, 147),
            "background": (10, 0, 20),            # Dunkel-Lila
        }
    },
    
    "Hacker": {
        "name": "Hacker",
        "description": "Grün/Orange Hacker-Style",
        "colors": {
            "search_marker": (0, 255, 0),         # Lime
            "traceroute_marker": (255, 128, 0),   # Neon-Orange
            "traceroute_line": (255, 165, 0),     # Orange
            "target_marker": (255, 50, 50),       # Rot
            "label_search": (0, 255, 0),
            "label_traceroute": (255, 128, 0),
            "label_target": (255, 50, 50),
            "background": (0, 10, 0),             # Dunkel-Grün
        }
    },
    
    "Night Vision": {
        "name": "Night Vision",
        "description": "Militär-Style Grüntöne",
        "colors": {
            "search_marker": (150, 255, 150),
            "traceroute_marker": (100, 200, 100),
            "traceroute_line": (80, 180, 80),
            "target_marker": (200, 255, 100),
            "label_search": (150, 255, 150),
            "label_traceroute": (100, 200, 100),
            "label_target": (200, 255, 100),
            "background": (0, 20, 0),
        }
    },
    
    "Synthwave": {
        "name": "Synthwave",
        "description": "80s Retro Pink/Cyan",
        "colors": {
            "search_marker": (255, 0, 128),       # Hot Pink
            "traceroute_marker": (0, 255, 255),   # Cyan
            "traceroute_line": (255, 0, 255),     # Magenta
            "target_marker": (255, 128, 0),       # Orange
            "label_search": (255, 0, 128),
            "label_traceroute": (0, 255, 255),
            "label_target": (255, 128, 0),
            "background": (20, 0, 40),            # Dunkel-Lila
        }
    },
}

# Aktuelles Theme (wird in settings.json gespeichert)
CURRENT_THEME = "Classic Cyber"  # Standard: Gelb/Cyan wie Original  # Standard: Gelb/Cyan wie Original

def get_theme_color(element: str) -> tuple:
    """Holt Farbe für Element aus aktuellem Theme"""
    from core.settings import settings
    theme_name = settings.get("theme", CURRENT_THEME)
    
    if theme_name == "Custom":
        # Custom Theme aus Settings
        custom_colors = settings.get("custom_theme_colors", {})
        if element in custom_colors:
            return tuple(custom_colors[element])
    
    # Standard-Theme
    if theme_name in THEMES:
        colors = THEMES[theme_name]["colors"]
        if element in colors:
            return colors[element]
    
    # Fallback auf Classic Cyber
    return THEMES["Classic Cyber"]["colors"].get(element, (255, 255, 255))
