#!/usr/bin/env python3
"""
Satellite Sprite Renderer
-------------------------

Zeichnet Satelliten als texturierte Point-Sprites (Billboards), die
ein PNG-Icon (z.B. satellite_icon.png) verwenden.

Nutzung:
    renderer = SatelliteSpriteRenderer()
    renderer.render_satellites(mvp_matrix, positions_ndarray)

wobei `positions_ndarray` ein (N, 3) Numpy-Array von 3D-Koordinaten ist.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import numpy as np
from OpenGL.GL import *
from OpenGL.GL import shaders
from PIL import Image

from core.config import TEXTURE_DIR


logger = logging.getLogger(__name__)


VERTEX_SHADER_SRC = """
#version 330 core
layout(location = 0) in vec3 aPos;

uniform mat4 mvp;
uniform float baseSize;

void main()
{
    gl_Position = mvp * vec4(aPos, 1.0);
    gl_PointSize = baseSize;
}
"""

FRAGMENT_SHADER_SRC = """
#version 330 core
out vec4 FragColor;

uniform sampler2D tex;
uniform vec4 tint;

void main()
{
    // gl_PointCoord gibt die Texturkoordinaten innerhalb des Punktes (0..1)
    vec2 uv = gl_PointCoord;
    vec4 texColor = texture(tex, uv);

    // Premultiplied Alpha / Tint
    vec4 color = texColor * tint;

    // Sehr transparente Pixel verwerfen (saubere Kanten)
    if (color.a < 0.1)
        discard;

    FragColor = color;
}
"""


class SatelliteSpriteRenderer:
    """
    Rendert Satelliten als texturierte Punkte mit einem PNG-Icon.

    - Initialisiert Shader und Textur bei der ersten Nutzung.
    - Erwartet, dass bereits ein gültiger OpenGL-Kontext existiert
      (d.h. innerhalb von QOpenGLWidget.paintGL aufgerufen wird).
    """

    def __init__(
        self,
        icon_path: Optional[Path] = None,
        base_size: float = 32.0,  # Kleinere Sprites für weniger Überlappung
    ) -> None:
        self.icon_path = icon_path or (TEXTURE_DIR / "satellites" / "satellite_icon.png")
        self.base_size = base_size

        self._initialized = False
        self._program: Optional[int] = None
        self._texture_id: Optional[int] = None

    # ------------------------------------------------------------------
    # Initialisierung
    # ------------------------------------------------------------------

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return

        if not self.icon_path.exists():
            logger.warning("SatelliteSpriteRenderer: Icon-Datei existiert nicht: %s", self.icon_path)

        # Shader kompiliieren
        try:
            vs = shaders.compileShader(VERTEX_SHADER_SRC, GL_VERTEX_SHADER)
            fs = shaders.compileShader(FRAGMENT_SHADER_SRC, GL_FRAGMENT_SHADER)
            program = shaders.compileProgram(vs, fs)
        except Exception as exc:
            logger.exception("Fehler beim Kompilieren der Satelliten-Shader: %s", exc)
            raise

        self._program = program

        # Textur laden
        self._texture_id = self._load_texture(self.icon_path)

        self._initialized = True
        logger.info("SatelliteSpriteRenderer initialisiert (Programm=%s, Textur=%s)", self._program, self._texture_id)

    def _load_texture(self, path: Path) -> int:
        """
        Lädt eine 2D-Textur aus einer PNG-Datei und gibt die OpenGL-Textur-ID zurück.
        """
        try:
            img = Image.open(path).convert("RGBA")
        except Exception as exc:
            logger.error("Konnte Satelliten-Icon nicht laden (%s): %s", path, exc)
            # Dummy-Textur (1x1 weiß)
            data = bytes([255, 255, 255, 255])
            tex_id = glGenTextures(1)
            glBindTexture(GL_TEXTURE_2D, tex_id)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, data)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
            glBindTexture(GL_TEXTURE_2D, 0)
            return tex_id

        img_data = img.tobytes("raw", "RGBA")
        width, height = img.size

        tex_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, tex_id)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img_data)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
        glGenerateMipmap(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, 0)

        return tex_id

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def render_satellites(self, mvp: np.ndarray, positions: np.ndarray, tint=(1.0, 1.0, 1.0, 1.0)) -> None:
        """
        Rendert Satellitenpositionen als Icons.

        Parameter:
            mvp: 4x4-Matrix (numpy float32) – ModelViewProjection
            positions: (N, 3) float32-Array mit 3D-Koordinaten
            tint: RGBA-Farb-Multiplikator (float 0..1)
        """
        if positions is None or len(positions) == 0:
            return

        self._ensure_initialized()
        if self._program is None or self._texture_id is None:
            return

        # Sicherheit: Typ/Shape prüfen
        positions = np.asarray(positions, dtype=np.float32)
        if positions.ndim != 2 or positions.shape[1] != 3:
            raise ValueError("render_satellites: positions muss ein (N, 3) Array sein")

        # OpenGL-Setup
        glUseProgram(self._program)

        # MVP-Matrix
        loc_mvp = glGetUniformLocation(self._program, "mvp")
        glUniformMatrix4fv(loc_mvp, 1, GL_FALSE, mvp.astype(np.float32))

        # Basisgröße der Icons
        loc_size = glGetUniformLocation(self._program, "baseSize")
        glUniform1f(loc_size, float(self.base_size))

        # Tint-Farbe
        loc_tint = glGetUniformLocation(self._program, "tint")
        glUniform4f(loc_tint, float(tint[0]), float(tint[1]), float(tint[2]), float(tint[3]))

        # Textur binden
        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_2D, self._texture_id)
        loc_tex = glGetUniformLocation(self._program, "tex")
        glUniform1i(loc_tex, 0)

        # Point-Sprite-States
        glEnable(GL_PROGRAM_POINT_SIZE)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        
        # WICHTIG: Depth-Testing damit Satelliten hinter Erde verschwinden
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LEQUAL)
        
        # WICHTIG: Depth-Testing damit Satelliten hinter Erde verschwinden
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LEQUAL)
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LEQUAL)
        
        # WICHTIG: Depth-Testing damit Satelliten hinter Erde verschwinden
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LEQUAL)

        # VAO/VBO für die Satellitenpositionen
        vao = glGenVertexArrays(1)
        vbo = glGenBuffers(1)

        glBindVertexArray(vao)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, positions.nbytes, positions, GL_DYNAMIC_DRAW)

        glEnableVertexAttribArray(0)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)

        # Zeichnen
        glDrawArrays(GL_POINTS, 0, len(positions))

        # Aufräumen
        glBindBuffer(GL_ARRAY_BUFFER, 0)
        glBindVertexArray(0)
        glDeleteBuffers(1, [vbo])
        glDeleteVertexArrays(1, [vao])

        glDisable(GL_BLEND)
        glDisable(GL_PROGRAM_POINT_SIZE)
        glDisable(GL_DEPTH_TEST)

        glBindTexture(GL_TEXTURE_2D, 0)
        glUseProgram(0)


if __name__ == "__main__":
    print("SatelliteSpriteRenderer-Modul geladen.")
