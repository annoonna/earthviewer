#!/usr/bin/env python3
"""
OpenGL Shader-Programme
"""

EARTH_VERTEX_SHADER = """
#version 330 core
layout(location = 0) in vec3 position;
layout(location = 1) in vec2 texCoord;
layout(location = 2) in vec3 normal;

uniform mat4 mvp;
uniform mat4 model;
uniform vec3 lightPos;

out vec2 fragTexCoord;
out float lightIntensity;

void main() {
    gl_Position = mvp * vec4(position, 1.0);
    fragTexCoord = texCoord;
    
    vec3 worldPos = (model * vec4(position, 1.0)).xyz;
    vec3 worldNormal = normalize(mat3(model) * normal);
    vec3 lightDir = normalize(lightPos - worldPos);
    
    float diffuse = max(dot(worldNormal, lightDir), 0.0);
    lightIntensity = 0.3 + 0.7 * diffuse;
}
"""

EARTH_FRAGMENT_SHADER = """
#version 330 core
in vec2 fragTexCoord;
in float lightIntensity;

out vec4 outColor;

uniform sampler2D earthTexture;

void main() {
    vec4 texColor = texture(earthTexture, fragTexCoord);
    outColor = vec4(texColor.rgb * lightIntensity, texColor.a);
}
"""

MARKER_VERTEX_SHADER = """
#version 330 core
layout(location = 0) in vec3 position;

uniform mat4 mvp;
uniform float pointSize;

void main() {
    gl_Position = mvp * vec4(position, 1.0);
    gl_PointSize = pointSize;
}
"""

MARKER_FRAGMENT_SHADER = """
#version 330 core
out vec4 outColor;

uniform vec3 markerColor;

void main() {
    vec2 coord = gl_PointCoord - vec2(0.5);
    if (length(coord) > 0.5) {
        discard;
    }
    outColor = vec4(markerColor, 1.0);
}
"""

LINE_VERTEX_SHADER = """
#version 330 core
layout(location = 0) in vec3 position;

uniform mat4 mvp;

void main() {
    gl_Position = mvp * vec4(position, 1.0);
}
"""

LINE_FRAGMENT_SHADER = """
#version 330 core
out vec4 outColor;

uniform vec3 lineColor;
uniform float alpha;

void main() {
    outColor = vec4(lineColor, alpha);
}
"""
