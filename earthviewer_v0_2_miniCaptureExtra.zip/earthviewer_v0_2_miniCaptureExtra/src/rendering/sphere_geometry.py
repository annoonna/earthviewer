#!/usr/bin/env python3
"""
Sphere-Geometrie Generator
"""
import math
import numpy as np
from typing import Tuple

class SphereGeometry:
    """Erzeugt UV-Sphere Geometrie"""
    
    @staticmethod
    def generate(radius: float = 1.0, stacks: int = 64, slices: int = 128):
        """Erzeugt Vertices, Textur-Koordinaten, Normalen und Indices"""
        vertices = []
        tex_coords = []
        normals = []
        indices = []
        
        for stack in range(stacks + 1):
            lat = 90.0 - (stack / stacks) * 180.0
            lat_rad = math.radians(lat)
            
            for slice in range(slices + 1):
                lon = (slice / slices) * 360.0 - 180.0
                lon_rad = math.radians(lon)
                
                x = radius * math.cos(lat_rad) * math.sin(lon_rad)
                y = radius * math.sin(lat_rad)
                z = radius * math.cos(lat_rad) * math.cos(lon_rad)
                
                vertices.extend([x, y, z])
                
                u = (lon + 180.0) / 360.0
                v = (90.0 - lat) / 180.0
                tex_coords.extend([u, v])
                
                normal = np.array([x, y, z])
                norm_length = np.linalg.norm(normal)
                if norm_length > 0:
                    normal = normal / norm_length
                normals.extend(normal)
        
        for stack in range(stacks):
            for slice in range(slices):
                first = stack * (slices + 1) + slice
                second = first + slices + 1
                
                indices.extend([first, second, first + 1])
                indices.extend([second, second + 1, first + 1])
        
        return (
            np.array(vertices, dtype=np.float32),
            np.array(tex_coords, dtype=np.float32),
            np.array(normals, dtype=np.float32),
            np.array(indices, dtype=np.uint32)
        )
