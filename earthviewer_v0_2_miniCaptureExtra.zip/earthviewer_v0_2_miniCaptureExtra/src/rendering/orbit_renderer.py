from OpenGL.GL import *
from OpenGL.GL.shaders import compileProgram, compileShader
import numpy as np
from typing import List, Tuple

class SatelliteOrbitRenderer:
    def __init__(self):
        self.active_orbits = {}
        self.shader_program = None
        self.mvp_location = None
        self.color_location = None

    def _get_orbit_color(self, sat_name):
        """Bestimme Orbit-Farbe basierend auf Satelliten-Typ"""
        # Crew-Fahrzeuge (Rot)
        if any(x in sat_name.upper() for x in ['DRAGON', 'SOYUZ', 'CREW']):
            return (1.0, 0.2, 0.2)  # Rot
        
        # Cargo-Fahrzeuge (Grün)
        elif any(x in sat_name.upper() for x in ['PROGRESS', 'CYGNUS', 'HTV', 'CARGO']):
            return (0.2, 1.0, 0.2)  # Grün
        
        # ISS Module (Blau)
        elif any(x in sat_name.upper() for x in ['ZARYA', 'NAUKA', 'ZVEZDA', 'ISS']):
            return (0.2, 0.5, 1.0)  # Blau
        
        # Debris/Schrott (Gelb)
        elif 'DEB' in sat_name.upper():
            return (1.0, 1.0, 0.0)  # Gelb
        
        # Standard (Cyan)
        else:
            return (0.0, 1.0, 1.0)  # Cyan

    def add_orbit(self, sat_name: str, orbit_points: List[Tuple[float, float, float]], tle_line1=None, tle_line2=None):
        """Add orbit visualization for satellite"""
        import time
        self.active_orbits[sat_name] = {
            'points': orbit_points,
            'vao': None,
            'vbo': None,
            'count': len(orbit_points),
            'needs_init': True,
            'color': self._get_orbit_color(sat_name),
            'last_update': time.time(),
            'tle_line1': tle_line1,
            'tle_line2': tle_line2,
            'update_interval': 10.0  # Sekunden
        }
        print(f"🛰️  Orbit hinzugefügt: {sat_name} ({len(orbit_points)} Punkte)")

    def remove_orbit(self, sat_name: str):
        """Remove orbit visualization"""
        if sat_name in self.active_orbits:
            orbit_data = self.active_orbits[sat_name]
            if orbit_data.get('vao') is not None:
                glDeleteVertexArrays(1, [orbit_data['vao']])
            if orbit_data.get('vbo') is not None:
                glDeleteBuffers(1, [orbit_data['vbo']])
            del self.active_orbits[sat_name]
            print(f"🗑️  Orbit entfernt: {sat_name}")

    def update_orbit(self, sat_name: str, orbit_points: List[Tuple[float, float, float]]):
        """Update existing orbit with new points"""
        if sat_name not in self.active_orbits:
            return
        
        orbit = self.active_orbits[sat_name]
        orbit['points'] = orbit_points
        orbit['count'] = len(orbit_points)
        orbit['needs_init'] = True  # VAO neu erstellen
        
        # Altes VAO/VBO löschen
        if orbit.get('vao') is not None:
            from OpenGL.GL import glDeleteVertexArrays, glDeleteBuffers
            glDeleteVertexArrays(1, [orbit['vao']])
            glDeleteBuffers(1, [orbit['vbo']])
            orbit['vao'] = None
            orbit['vbo'] = None
        
        import time
        orbit['last_update'] = time.time()
        print(f"🔄 Orbit aktualisiert: {sat_name} ({len(orbit_points)} Punkte)")

    def _create_orbit_buffers(self, sat_name: str):
        """Create VAO/VBO for orbit in current OpenGL context"""
        orbit = self.active_orbits.get(sat_name)
        if not orbit:
            return
        
        points = orbit.get('points')
        if points is None or len(points) == 0:
            return

        vertices = np.array(orbit['points'], dtype=np.float32)
        
        # Create VAO and VBO
        vao = glGenVertexArrays(1)
        vbo = glGenBuffers(1)
        
        if vao == 0 or vbo == 0:
            print(f"❌ FEHLER: VAO/VBO Erstellung fehlgeschlagen für {sat_name}")
            return

        glBindVertexArray(vao)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, vertices.nbytes, vertices, GL_STATIC_DRAW)
        
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
        glEnableVertexAttribArray(0)
        
        # Store VAO/VBO
        orbit['vao'] = vao
        orbit['vbo'] = vbo
        
        glBindVertexArray(0)
        print(f"✅ VAO {vao} erfolgreich für {sat_name} erstellt")

    def initialize_shaders(self):
        """Initialize OpenGL shaders for orbit rendering"""
        vertex_shader = """
        #version 330 core
        layout(location = 0) in vec3 position;
        uniform mat4 mvp;
        
        void main() {
            gl_Position = mvp * vec4(position, 1.0);
        }
        """
        
        fragment_shader = """
        #version 330 core
        uniform vec3 orbit_color;
        out vec4 fragColor;
        
        void main() {
            fragColor = vec4(orbit_color, 1.0);
        }
        """
        
        try:
            self.shader_program = compileProgram(
                compileShader(vertex_shader, GL_VERTEX_SHADER),
                compileShader(fragment_shader, GL_FRAGMENT_SHADER)
            )
            
            self.mvp_location = glGetUniformLocation(self.shader_program, "mvp")
            self.color_location = glGetUniformLocation(self.shader_program, "orbit_color")
            
            print(f"✅ Orbit Shader kompiliert (Program: {self.shader_program})")
            print(f"   MVP Location: {self.mvp_location}")
            print(f"   Color Location: {self.color_location}")
            
        except Exception as e:
            print(f"❌ Shader-Kompilierung fehlgeschlagen: {e}")
            self.shader_program = None

    def render_all(self, mvp_matrix: np.ndarray):
        """Render all active orbits"""
        if not self.shader_program:
            return
        
        if len(self.active_orbits) == 0:
            return

        glUseProgram(self.shader_program)
        glUniformMatrix4fv(self.mvp_location, 1, GL_TRUE, mvp_matrix)

        # Render all orbits
        for sat_name, orbit_data in self.active_orbits.items():
            # Lazy initialization: Create VAO/VBO if needed
            if orbit_data.get('needs_init', False) or orbit_data.get('vao') is None:
                self._create_orbit_buffers(sat_name)
                orbit_data['needs_init'] = False

            if "vao" not in orbit_data or "count" not in orbit_data:
                continue

            # Setze Orbit-Farbe
            color = orbit_data.get('color', (0.0, 1.0, 1.0))
            glUniform3f(self.color_location, color[0], color[1], color[2])
            
            # Render orbit
            glBindVertexArray(orbit_data["vao"])
            glDrawArrays(GL_LINE_LOOP, 0, orbit_data["count"])
            glBindVertexArray(0)

    def cleanup(self):
        """Clean up all OpenGL resources"""
        for sat_name in list(self.active_orbits.keys()):
            self.remove_orbit(sat_name)
        
        if self.shader_program:
            glDeleteProgram(self.shader_program)
            self.shader_program = None
