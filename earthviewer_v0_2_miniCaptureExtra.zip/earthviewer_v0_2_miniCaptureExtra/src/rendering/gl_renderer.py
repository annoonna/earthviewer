#!/usr/bin/env python3
"""
OpenGL Renderer - FINAL FIX für Marker-Sichtbarkeit
"""
import numpy as np
from OpenGL.GL import *
from OpenGL.GL import shaders
from PIL import Image
import ctypes
from typing import List, Tuple, Optional
from pathlib import Path

from core.geo_location import GeoLocation
from core.config import get_theme_color
from core.config import (
    SPHERE_RADIUS, SPHERE_STACKS, SPHERE_SLICES,
    MARKER_SIZE_SEARCH, MARKER_SIZE_TARGET, MARKER_SIZE_TRACEROUTE
)
from rendering.shaders import (
    EARTH_VERTEX_SHADER, EARTH_FRAGMENT_SHADER,
    MARKER_VERTEX_SHADER, MARKER_FRAGMENT_SHADER,
    LINE_VERTEX_SHADER, LINE_FRAGMENT_SHADER
)
from rendering.sphere_geometry import SphereGeometry

class GLRenderer:
    """OpenGL Renderer"""
    
    def __init__(self, texture_path: Path):
        self.texture_path = texture_path
        self.earth_shader = None
        self.marker_shader = None
        self.line_shader = None
        self.sphere_vao = None
        self.sphere_index_count = 0
        self.texture_id = None
        self._initialized = False
    
    def initialize(self):
        if self._initialized: return
        
        # PyOpenGL Context Fixes für Wayland/X11
        import OpenGL
        OpenGL.ERROR_CHECKING = False
        from OpenGL import platform
        try:
            platform.CurrentContextIsValid = lambda: True
            from OpenGL import contextdata
            contextdata.getContext = lambda context=None: 1
        except Exception: pass
        
        glEnable(GL_DEPTH_TEST)
        # WICHTIG: Erlaubt dem Shader, die Punktgröße zu setzen
        glEnable(GL_PROGRAM_POINT_SIZE)
        glEnable(GL_CULL_FACE)
        
        # Hintergrundfarbe aus Theme
        bg = get_theme_color('background')
        glClearColor(bg[0]/255.0, bg[1]/255.0, bg[2]/255.0, 1.0)
        
        self.earth_shader = self._compile_shader_program(EARTH_VERTEX_SHADER, EARTH_FRAGMENT_SHADER)
        self.marker_shader = self._compile_shader_program(MARKER_VERTEX_SHADER, MARKER_FRAGMENT_SHADER)
        self.line_shader = self._compile_shader_program(LINE_VERTEX_SHADER, LINE_FRAGMENT_SHADER)
        
        self.texture_id = self._load_texture()
        self._setup_sphere_geometry()
        self._initialized = True
    
    def _compile_shader_program(self, vertex_src: str, fragment_src: str):
        return shaders.compileProgram(
            shaders.compileShader(vertex_src, GL_VERTEX_SHADER),
            shaders.compileShader(fragment_src, GL_FRAGMENT_SHADER)
        )
    
    def _load_texture(self) -> int:
        try:
            img = Image.open(self.texture_path).convert('RGB')
        except FileNotFoundError:
            # Fallback Textur (Dunkelblau) falls Bild fehlt
            img = Image.new('RGB', (2048, 1024), (0, 20, 50))
        
        texture_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img.width, img.height, 0, GL_RGB, GL_UNSIGNED_BYTE, img.tobytes())
        glGenerateMipmap(GL_TEXTURE_2D)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        return texture_id
    
    def _setup_sphere_geometry(self):
        v, t, n, i = SphereGeometry.generate(SPHERE_RADIUS, SPHERE_STACKS, SPHERE_SLICES)
        self.sphere_index_count = len(i)
        self.sphere_vao = glGenVertexArrays(1)
        glBindVertexArray(self.sphere_vao)
        vbo = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, v.nbytes + t.nbytes + n.nbytes, None, GL_STATIC_DRAW)
        glBufferSubData(GL_ARRAY_BUFFER, 0, v.nbytes, v)
        glBufferSubData(GL_ARRAY_BUFFER, v.nbytes, t.nbytes, t)
        glBufferSubData(GL_ARRAY_BUFFER, v.nbytes + t.nbytes, n.nbytes, n)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(0))
        glEnableVertexAttribArray(0)
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(v.nbytes))
        glEnableVertexAttribArray(1)
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(v.nbytes + t.nbytes))
        glEnableVertexAttribArray(2)
        ibo = glGenBuffers(1)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, i.nbytes, i, GL_STATIC_DRAW)
    
    def render_earth(self, mvp: np.ndarray, model: np.ndarray):
        glUseProgram(self.earth_shader)
        glUniformMatrix4fv(glGetUniformLocation(self.earth_shader, "mvp"), 1, GL_TRUE, mvp)
        glUniformMatrix4fv(glGetUniformLocation(self.earth_shader, "model"), 1, GL_TRUE, model)
        glUniform3f(glGetUniformLocation(self.earth_shader, "lightPos"), 5.0, 3.0, 5.0)
        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_2D, self.texture_id)
        glBindVertexArray(self.sphere_vao)
        glDrawElements(GL_TRIANGLES, self.sphere_index_count, GL_UNSIGNED_INT, None)
    
    def render_markers(self, mvp: np.ndarray, search: list, target: Optional[GeoLocation], traceroute: list):
        # FIX: Point Size sicherstellen
        glEnable(GL_PROGRAM_POINT_SIZE)
        
        glDepthFunc(GL_LEQUAL)
        glUseProgram(self.marker_shader)
        glUniformMatrix4fv(glGetUniformLocation(self.marker_shader, "mvp"), 1, GL_TRUE, mvp)
        
        # FIX: Nutze get_theme_color (liefert 0-255 Tuples) statt Float-Konstanten
        if search: 
            self._draw_marker_batch(search, get_theme_color('search_marker'), MARKER_SIZE_SEARCH)
        
        if traceroute: 
            self._draw_marker_batch(traceroute, get_theme_color('traceroute_marker'), MARKER_SIZE_TRACEROUTE)
        
        if target: 
            self._draw_marker_batch([target], get_theme_color('target_marker'), MARKER_SIZE_TARGET)
            
        glDepthFunc(GL_LESS)
    
    def _draw_marker_batch(self, locations: list, color: tuple, size: float):
        if not locations: return
        
        from core import config
        # Lade Offset, falls definiert, sonst Default
        marker_offset = getattr(config, 'MARKER_OFFSET', 0.02)
        radius = SPHERE_RADIUS + marker_offset
        
        pos = np.array([loc.to_cartesian(radius) for loc in locations], dtype=np.float32)
        
        vao = glGenVertexArrays(1); glBindVertexArray(vao)
        vbo = glGenBuffers(1); glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, pos.nbytes, pos, GL_STREAM_DRAW)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None); glEnableVertexAttribArray(0)
        
        # FIX: Umrechnung von 0-255 (Theme) zu 0.0-1.0 (OpenGL)
        # Wenn color schon floats wären, würde das zu fast 0 (schwarz) führen.
        # Da wir oben get_theme_color nutzen, sind es Ints, also ist /255.0 korrekt.
        glUniform3f(glGetUniformLocation(self.marker_shader, "markerColor"), *[c/255.0 for c in color])
        
        glUniform1f(glGetUniformLocation(self.marker_shader, "pointSize"), size)
        
        glDrawArrays(GL_POINTS, 0, len(pos))
        glBindVertexArray(0); glDeleteBuffers(1, [vbo]); glDeleteVertexArrays(1, [vao])

    def render_line(self, mvp: np.ndarray, points: list, color: tuple = None, alpha: float = 0.6):
        if len(points) < 2: return
        
        points_3d = None
        if isinstance(points, np.ndarray):
            points_3d = points
        elif isinstance(points[0], GeoLocation):
            from core import config
            offset = getattr(config, 'MARKER_OFFSET', 0.02)
            radius = SPHERE_RADIUS + offset * 1.5 
            points_3d = np.array([loc.to_cartesian(radius) for loc in points], dtype=np.float32)
        
        if points_3d is None: return

        if color is None: 
            raw_color = get_theme_color('traceroute_line')
            color = tuple(c/255.0 for c in raw_color)

        glUseProgram(self.line_shader)
        glUniformMatrix4fv(glGetUniformLocation(self.line_shader, "mvp"), 1, GL_TRUE, mvp)
        
        vao = glGenVertexArrays(1); glBindVertexArray(vao)
        vbo = glGenBuffers(1); glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, points_3d.nbytes, points_3d, GL_STREAM_DRAW)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None); glEnableVertexAttribArray(0)
        
        glUniform3f(glGetUniformLocation(self.line_shader, "lineColor"), *color)
        glUniform1f(glGetUniformLocation(self.line_shader, "alpha"), alpha)
        
        glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glLineWidth(1.0)
        
        glDrawArrays(GL_LINE_STRIP, 0, len(points_3d))
        glDisable(GL_BLEND)
        
        glBindVertexArray(0); glDeleteBuffers(1, [vbo]); glDeleteVertexArrays(1, [vao])
