#!/usr/bin/env python3
"""
OpenGL Renderer für Erde und Marker
"""
import numpy as np
from OpenGL.GL import *
from OpenGL.GL import shaders
from PIL import Image
import ctypes
from typing import List, Tuple, Optional
from pathlib import Path

# KRITISCH: PyOpenGL Context-Checking deaktivieren für Qt6-Kompatibilität
# Dies verhindert "Attempt to retrieve context when no valid context" Fehler
import OpenGL
OpenGL.ERROR_CHECKING = False
OpenGL.ERROR_ON_COPY = False
OpenGL.ERROR_LOGGING = False

from core.geo_location import GeoLocation
from core.config import get_theme_color
from core.config import (
    SPHERE_RADIUS, MARKER_OFFSET, SPHERE_STACKS, SPHERE_SLICES,
    MARKER_COLOR_SEARCH, MARKER_COLOR_TARGET, MARKER_COLOR_TRACEROUTE,
    MARKER_SIZE_SEARCH, MARKER_SIZE_TARGET, MARKER_SIZE_TRACEROUTE
)
from rendering.shaders import (
    EARTH_VERTEX_SHADER, EARTH_FRAGMENT_SHADER,
    MARKER_VERTEX_SHADER, MARKER_FRAGMENT_SHADER,
    LINE_VERTEX_SHADER, LINE_FRAGMENT_SHADER
)
from rendering.sphere_geometry import SphereGeometry

class GLRenderer:
    """OpenGL Renderer"""
    
    def __init__(self, texture_path: Path):
        self.texture_path = texture_path
        self.earth_shader = None
        self.marker_shader = None
        self.line_shader = None
        self.sphere_vao = None
        self.sphere_index_count = 0
        self.texture_id = None
        self._initialized = False
    
    def initialize(self):
        """Initialisiert OpenGL-Ressourcen"""
        if self._initialized:
            return
        
        # KRITISCH: PyOpenGL Platform-Fix für Qt6-Kompatibilität
        # Ohne dies gibt es "no valid context" Fehler bei glVertexAttribPointer
        import OpenGL
        OpenGL.ERROR_CHECKING = False  # Deaktiviere Context-Checks
        OpenGL.ERROR_LOGGING = False
        OpenGL.FULL_LOGGING = False
        OpenGL.ERROR_ON_COPY = False
        
        from OpenGL import platform
        # Force PyOpenGL to accept Qt's OpenGL context
        try:
            original_func = platform.CurrentContextIsValid
            platform.CurrentContextIsValid = lambda: True
            
            # ZUSÄTZLICHER KRITISCHER FIX: Context-Data überschreiben
            from OpenGL import contextdata
            contextdata.getContext = lambda context=None: 1  # Dummy-Context
            
            print("🔧 PyOpenGL Context-Validation VOLLSTÄNDIG deaktiviert (Qt6-Fix)")
        except Exception as e:
            print(f"⚠️  PyOpenGL Platform-Patch Warning: {e}")
        
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_PROGRAM_POINT_SIZE)
        glEnable(GL_CULL_FACE)
        glCullFace(GL_BACK)
        glFrontFace(GL_CCW)
        glClearColor(0.0, 0.0, 0.05, 1.0)
        
        self.earth_shader = self._compile_shader_program(EARTH_VERTEX_SHADER, EARTH_FRAGMENT_SHADER)
        self.marker_shader = self._compile_shader_program(MARKER_VERTEX_SHADER, MARKER_FRAGMENT_SHADER)
        self.line_shader = self._compile_shader_program(LINE_VERTEX_SHADER, LINE_FRAGMENT_SHADER)
        
        self.texture_id = self._load_texture()
        self._setup_sphere_geometry()
        
        self._initialized = True
        print("✅ OpenGL initialisiert")
    
    def _compile_shader_program(self, vertex_src: str, fragment_src: str):
        vertex_shader = shaders.compileShader(vertex_src, GL_VERTEX_SHADER)
        fragment_shader = shaders.compileShader(fragment_src, GL_FRAGMENT_SHADER)
        return shaders.compileProgram(vertex_shader, fragment_shader)
    
    def _load_texture(self) -> int:
        if self.texture_path.exists():
            img = Image.open(self.texture_path).convert('RGB')
        else:
            img = Image.new('RGB', (2048, 1024), (30, 80, 150))
        
        texture_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img.width, img.height, 0, GL_RGB, GL_UNSIGNED_BYTE, img.tobytes())
        glGenerateMipmap(GL_TEXTURE_2D)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        
        return texture_id
    
    def _setup_sphere_geometry(self):
        vertices, tex_coords, normals, indices = SphereGeometry.generate(
            radius=SPHERE_RADIUS, stacks=SPHERE_STACKS, slices=SPHERE_SLICES
        )
        
        self.sphere_index_count = len(indices)
        self.sphere_vao = glGenVertexArrays(1)
        glBindVertexArray(self.sphere_vao)
        
        vbo = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        total_size = vertices.nbytes + tex_coords.nbytes + normals.nbytes
        glBufferData(GL_ARRAY_BUFFER, total_size, None, GL_STATIC_DRAW)
        
        offset = 0
        glBufferSubData(GL_ARRAY_BUFFER, offset, vertices.nbytes, vertices)
        offset += vertices.nbytes
        glBufferSubData(GL_ARRAY_BUFFER, offset, tex_coords.nbytes, tex_coords)
        offset += tex_coords.nbytes
        glBufferSubData(GL_ARRAY_BUFFER, offset, normals.nbytes, normals)
        
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(0))
        glEnableVertexAttribArray(0)
        
        offset = vertices.nbytes
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(offset))
        glEnableVertexAttribArray(1)
        
        offset += tex_coords.nbytes
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(offset))
        glEnableVertexAttribArray(2)
        
        ibo = glGenBuffers(1)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.nbytes, indices, GL_STATIC_DRAW)
    
    def render_earth(self, mvp: np.ndarray, model: np.ndarray):
        glUseProgram(self.earth_shader)
        
        mvp_loc = glGetUniformLocation(self.earth_shader, "mvp")
        glUniformMatrix4fv(mvp_loc, 1, GL_TRUE, mvp)
        
        model_loc = glGetUniformLocation(self.earth_shader, "model")
        glUniformMatrix4fv(model_loc, 1, GL_TRUE, model)
        
        light_loc = glGetUniformLocation(self.earth_shader, "lightPos")
        glUniform3f(light_loc, 5.0, 3.0, 5.0)
        
        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_2D, self.texture_id)
        
        glBindVertexArray(self.sphere_vao)
        glDrawElements(GL_TRIANGLES, self.sphere_index_count, GL_UNSIGNED_INT, None)
    
    def render_markers(self, mvp: np.ndarray, search_markers: List[GeoLocation],
                      target_marker: Optional[GeoLocation] = None,
                      traceroute_markers: List[GeoLocation] = None):
        glDepthFunc(GL_LEQUAL)
        glUseProgram(self.marker_shader)
        
        mvp_loc = glGetUniformLocation(self.marker_shader, "mvp")
        glUniformMatrix4fv(mvp_loc, 1, GL_TRUE, mvp)
        
        if search_markers:
            color = tuple(c/255.0 for c in get_theme_color('search_marker'))
            self._draw_marker_batch(search_markers, color, MARKER_SIZE_SEARCH)
        
        if traceroute_markers:
            color = tuple(c/255.0 for c in get_theme_color('traceroute_marker'))
            self._draw_marker_batch(traceroute_markers, color, MARKER_SIZE_TRACEROUTE)
        
        if target_marker:
            color = tuple(c/255.0 for c in get_theme_color('target_marker'))
            self._draw_marker_batch([target_marker], color, MARKER_SIZE_TARGET)
        
        glDepthFunc(GL_LESS)
    
    def _draw_marker_batch(self, locations: List[GeoLocation], color: Tuple[float, float, float], size: float):
        if not locations:
            return
        
        # Dynamischer Marker-Offset
        from core import config
        marker_offset = getattr(config, 'MARKER_OFFSET', 0.02)
        radius = SPHERE_RADIUS + marker_offset
        positions = np.array([loc.to_cartesian(radius) for loc in locations], dtype=np.float32)
        
        vao = glGenVertexArrays(1)
        glBindVertexArray(vao)
        
        vbo = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, positions.nbytes, positions, GL_STREAM_DRAW)
        
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
        glEnableVertexAttribArray(0)
        
        color_loc = glGetUniformLocation(self.marker_shader, "markerColor")
        glUniform3f(color_loc, *color)
        
        size_loc = glGetUniformLocation(self.marker_shader, "pointSize")
        glUniform1f(size_loc, size)
        
        glDrawArrays(GL_POINTS, 0, len(positions))
        
        glBindVertexArray(0)
        glDeleteBuffers(1, [vbo])
        glDeleteVertexArrays(1, [vao])
    
    def render_line(self, mvp: np.ndarray, points: List[GeoLocation],
                   color: Tuple[float, float, float] = None, alpha: float = 0.6):
        if len(points) < 2:
            return
        
        # Hole Farbe aus Theme wenn nicht angegeben
        if color is None:
            theme_color = get_theme_color('traceroute_line')
            color = tuple(c/255.0 for c in theme_color)
        
        glUseProgram(self.line_shader)
        
        mvp_loc = glGetUniformLocation(self.line_shader, "mvp")
        glUniformMatrix4fv(mvp_loc, 1, GL_TRUE, mvp)
        
        from core import config
        marker_offset = getattr(config, 'MARKER_OFFSET', 0.02)
        radius = SPHERE_RADIUS + marker_offset * 1.5
        positions = np.array([loc.to_cartesian(radius) for loc in points], dtype=np.float32)
        
        vao = glGenVertexArrays(1)
        glBindVertexArray(vao)
        
        vbo = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, positions.nbytes, positions, GL_STREAM_DRAW)
        
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
        glEnableVertexAttribArray(0)
        
        color_loc = glGetUniformLocation(self.line_shader, "lineColor")
        glUniform3f(color_loc, *color)
        
        alpha_loc = glGetUniformLocation(self.line_shader, "alpha")
        glUniform1f(alpha_loc, alpha)
        
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glLineWidth(3.0)
        
        glDrawArrays(GL_LINE_STRIP, 0, len(positions))
        
        glDisable(GL_BLEND)
        glBindVertexArray(0)
        glDeleteBuffers(1, [vbo])
        glDeleteVertexArrays(1, [vao])
