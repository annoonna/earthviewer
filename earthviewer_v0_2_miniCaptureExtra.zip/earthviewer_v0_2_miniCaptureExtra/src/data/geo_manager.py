#!/usr/bin/env python3
"""
GeoDataManager - Verwaltet geografische Daten
"""
import csv
from pathlib import Path
from typing import List, Optional

from core.geo_location import GeoLocation
from core.config import GEODATA_DIR

try:
    import geoip2.database
    import ipaddress
    GEOIP_AVAILABLE = True
except ImportError:
    GEOIP_AVAILABLE = False

class GeoDataManager:
    """Verwaltet alle geografischen Daten"""
    
    def __init__(self, data_root: Path = GEODATA_DIR):
        self.data_root = Path(data_root)
        self.locations: List[GeoLocation] = []
        self.geoip_reader = None
        
        self._load_csv_data()
        self._load_geoip_database()
        
        print(f"✅ {len(self.locations)} Orte geladen")
        if self.geoip_reader:
            print("✅ GeoIP-Datenbank aktiv")
    
    def _load_csv_data(self):
        """Lädt Stadt-Daten aus CSV"""
        if not self.data_root.exists():
            print(f"⚠️ Geodaten-Ordner nicht gefunden: {self.data_root}")
            return
        
        for csv_file in self.data_root.rglob("*.csv"):
            try:
                with open(csv_file, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    country = csv_file.parent.name
                    
                    for row in reader:
                        try:
                            name = row.get('name') or row.get('city')
                            if not name or not name.strip():
                                continue
                            
                            lat = float(row.get('lat', 0))
                            lon = float(row.get('lon') or row.get('lng', 0))
                            
                            if lon > 180:
                                lon -= 360
                            
                            self.locations.append(GeoLocation(
                                name=name,
                                lat=lat,
                                lon=lon,
                                country=country,
                                location_type='city'
                            ))
                        except (ValueError, TypeError):
                            continue
            except Exception as e:
                print(f"⚠️ Fehler: {csv_file.name}: {e}")
    
    def _load_geoip_database(self):
        """Lädt GeoIP MMDB-Datenbank"""
        if not GEOIP_AVAILABLE:
            return
        
        for mmdb_file in self.data_root.rglob("*.mmdb"):
            if "city" in mmdb_file.name.lower():
                try:
                    self.geoip_reader = geoip2.database.Reader(str(mmdb_file))
                    return
                except Exception as e:
                    print(f"⚠️ GeoIP-Fehler: {e}")
    
    def search(self, query: str) -> List[GeoLocation]:
        """Universelle Suchfunktion"""
        query = query.strip()
        if not query:
            return []
        
        results = []
        
        # 1. Koordinaten
        if ',' in query and len(query.split(',')) == 2:
            try:
                parts = query.split(',')
                lat = float(parts[0].strip())
                lon = float(parts[1].strip())
                if -90 <= lat <= 90 and -180 <= lon <= 180:
                    return [GeoLocation(
                        name=f"Koordinaten: {lat:.4f}, {lon:.4f}",
                        lat=lat,
                        lon=lon,
                        location_type='custom'
                    )]
            except ValueError:
                pass
        
        # 2. IP-Adresse
        if self.geoip_reader:
            try:
                ip_addr = ipaddress.ip_address(query)
                response = self.geoip_reader.city(str(ip_addr))
                
                if response.location.latitude and response.location.longitude:
                    return [GeoLocation(
                        name=response.city.name or f"IP: {query}",
                        lat=response.location.latitude,
                        lon=response.location.longitude,
                        country=response.country.iso_code or "",
                        location_type='ip'
                    )]
            except:
                pass
        
        # 3. Text-Suche
        search_terms = query.lower().split()
        
        if len(search_terms) > 1:
            for term in search_terms:
                if len(term) < 3:
                    continue
                
                term_results = [
                    loc for loc in self.locations
                    if (loc.name and term in loc.name.lower()) or 
                       (loc.country and term in loc.country.lower())
                ]
                
                term_results.sort(key=lambda x: len(x.name) if x.name else 999)
                results.extend(term_results[:10])
        else:
            query_lower = query.lower()
            results = [
                loc for loc in self.locations
                if (loc.name and query_lower in loc.name.lower()) or 
                   (loc.country and query_lower in loc.country.lower())
            ]
            results.sort(key=lambda x: len(x.name) if x.name else 999)
        
        # Duplikate entfernen
        unique_results = []
        seen_positions = set()
        for loc in results:
            pos_key = (round(loc.lat, 1), round(loc.lon, 1))
            if pos_key not in seen_positions:
                unique_results.append(loc)
                seen_positions.add(pos_key)
        
        return unique_results[:50]
    
    def lookup_ip(self, ip: str) -> Optional[GeoLocation]:
        """Schlägt IP-Adresse nach"""
        if not self.geoip_reader:
            return None
        
        try:
            response = self.geoip_reader.city(ip)
            if response.location.latitude and response.location.longitude:
                return GeoLocation(
                    name=response.city.name or f"IP: {ip}",
                    lat=response.location.latitude,
                    lon=response.location.longitude,
                    country=response.country.iso_code or "",
                    location_type='ip',
                    metadata={'ip': ip}
                )
        except:
            pass
        
        return None
