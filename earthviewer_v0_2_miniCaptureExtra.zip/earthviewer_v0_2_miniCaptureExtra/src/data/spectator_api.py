"""
Spectator Earth API Client
--------------------------

Kapselt alle HTTP-Requests zur Spectator-API in einer Klasse,
damit wir sie bequem im Globe, Tabs usw. verwenden können.

Dokumentation:
    https://api.spectator.earth/

ACHTUNG:
    Trage deinen API-Key NICHT im Code ein. Übergib ihn von außen
    oder speichere ihn (später) über Settings / UI.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

import requests


logger = logging.getLogger(__name__)


BASE_URL = "https://api.spectator.earth"


class SpectatorApiError(Exception):
    """Generische Exception für alle Fehler der Spectator-API."""

    def __init__(self, message: str, status_code: Optional[int] = None, url: Optional[str] = None):
        super().__init__(message)
        self.status_code = status_code
        self.url = url


@dataclass
class ImagerySearchResult:
    page: int
    total_pages: int
    next: Optional[str]
    previous: Optional[str]
    results: List[Dict[str, Any]]


class SpectatorClient:
    """
    Einfacher HTTP-Client für die Spectator-API.

    Typische Nutzung:
        client = SpectatorClient(api_key="DEIN_API_KEY")
        sat = client.get_satellite(1)
        traj = client.get_trajectory(1)
        images = client.search_imagery(bbox=(lon_min, lat_min, lon_max, lat_max))
    """

    def __init__(self, api_key: str, timeout: float = 10.0):
        if not api_key:
            raise ValueError("SpectatorClient: API-Key darf nicht leer sein.")
        self.api_key = api_key
        self.timeout = timeout
        self.session = requests.Session()
        # Optional: User-Agent setzen, damit Spectator sieht, was wir sind
        self.session.headers.update({"User-Agent": "EarthViewer/0.2 (+https://example.local)"})

    # ------------------------------------------------------------------
    # interne Hilfsmethode
    # ------------------------------------------------------------------
    def _get(self, path: str, params: Optional[Dict[str, Any]] = None, stream: bool = False) -> requests.Response:
        """
        Führt einen GET-Request aus, hängt automatisch den API-Key an
        und behandelt Standard-Fehler.
        """
        url = BASE_URL.rstrip("/") + "/" + path.lstrip("/")
        params = dict(params or {})
        params["api_key"] = self.api_key

        try:
            resp = self.session.get(url, params=params, timeout=self.timeout, stream=stream)
        except requests.RequestException as exc:
            logger.error("Spectator API Request fehlgeschlagen: %s", exc)
            raise SpectatorApiError(f"Netzwerkfehler beim Zugriff auf {url}: {exc}") from exc

        if not resp.ok:
            text = ""
            try:
                text = resp.text[:500]
            except Exception:
                text = "<no response text>"
            logger.error("Spectator API Error %s für URL %s: %s", resp.status_code, resp.url, text)
            raise SpectatorApiError(
                f"Spectator API Fehler ({resp.status_code}) bei {resp.url}: {text}",
                status_code=resp.status_code,
                url=str(resp.url),
            )
        return resp

    # ------------------------------------------------------------------
    # Satelliten
    # ------------------------------------------------------------------
    def get_satellite(self, satellite_id: int) -> Dict[str, Any]:
        """
        Holt die aktuellen Informationen zu einem Satelliten.

        API:
            GET /satellite/{id}/
        """
        path = f"/satellite/{int(satellite_id)}/"
        resp = self._get(path)
        return resp.json()

    def get_trajectory(self, satellite_id: int) -> Dict[str, Any]:
        """
        Holt die Trajektorie (einen vollen Orbit) eines Satelliten.

        API:
            GET /satellite/{id}/trajectory/
        """
        path = f"/satellite/{int(satellite_id)}/trajectory/"
        resp = self._get(path)
        return resp.json()

    # ------------------------------------------------------------------
    # Acquisition Plan
    # ------------------------------------------------------------------
    def get_acquisition_plan(
        self,
        satellites: Optional[str] = None,
        datetime_str: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Holt den Acquisition-Plan (Sentinel-1/2, Landsat-8/9).

        API:
            GET /acquisition-plan/

        Parameter:
            satellites: z.B. "Sentinel-2A,Sentinel-2B,Landsat-8"
            datetime_str: ISO-String, z.B. "2023-04-17"
        """
        params: Dict[str, Any] = {}
        if satellites:
            params["satellites"] = satellites
        if datetime_str:
            params["datetime"] = datetime_str

        resp = self._get("/acquisition-plan/", params=params)
        return resp.json()

    # ------------------------------------------------------------------
    # Imagery
    # ------------------------------------------------------------------
    def search_imagery(
        self,
        bbox: Optional[Tuple[float, float, float, float]] = None,
        geometry: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        satellites: Optional[str] = None,
        cc: Optional[float] = None,
        cc_more_than: Optional[float] = None,
        cc_less_than: Optional[float] = None,
        product_type: Optional[str] = None,
        page: Optional[int] = None,
    ) -> ImagerySearchResult:
        """
        Sucht nach Bildern über einer Area-of-Interest.

        API:
            GET /imagery/

        Mindestens einer von `bbox` oder `geometry` muss gesetzt sein.
        BBOX-Format: (lon_min, lat_min, lon_max, lat_max)
        """
        if not bbox and not geometry:
            raise ValueError("search_imagery: Entweder 'bbox' oder 'geometry' muss angegeben werden.")

        params: Dict[str, Any] = {}
        if bbox:
            lon_min, lat_min, lon_max, lat_max = bbox
            params["bbox"] = f"{lon_min},{lat_min},{lon_max},{lat_max}"
        if geometry:
            params["geometry"] = geometry
        if date_from:
            params["date_from"] = date_from
        if date_to:
            params["date_to"] = date_to
        if satellites:
            params["satellites"] = satellites
        if cc is not None:
            params["cc"] = cc
        if cc_more_than is not None:
            params["cc_more_than"] = cc_more_than
        if cc_less_than is not None:
            params["cc_less_than"] = cc_less_than
        if product_type:
            params["product_type"] = product_type
        if page is not None:
            params["page"] = page

        resp = self._get("/imagery/", params=params)
        data = resp.json()
        return ImagerySearchResult(
            page=data.get("page", 1),
            total_pages=data.get("total_pages", 1),
            next=data.get("next"),
            previous=data.get("previous"),
            results=data.get("results", []),
        )

    def get_imagery_files(self, imagery_id: int) -> List[Dict[str, Any]]:
        """
        Holt die Datei-Liste (Bänder) für ein Image.

        API:
            GET /imagery/{id}/files/
        """
        path = f"/imagery/{int(imagery_id)}/files/"
        resp = self._get(path)
        return resp.json()

    def get_imagery_preview_url(
        self,
        imagery_id: int,
        bands: Tuple[int, int, int] = (4, 3, 2),
        bbox: Optional[Tuple[float, float, float, float]] = None,
        width: Optional[int] = None,
        height: Optional[int] = None,
    ) -> str:
        """
        Baut eine URL für die High-Res-Preview eines Bildes.

        API:
            GET /imagery/{id}/preview/?bands=4,3,2&bbox=...&width=...&height=...

        Wir liefern hier bewusst NUR die URL zurück – Laden und Anzeigen
        passiert in der GUI/anderen Modulen.
        """
        # Basis-URL ohne Query
        base = f"{BASE_URL.rstrip('/')}/imagery/{int(imagery_id)}/preview/"
        params: Dict[str, Any] = {"api_key": self.api_key, "bands": f"{bands[0]},{bands[1]},{bands[2]}"}

        if bbox:
            lon_min, lat_min, lon_max, lat_max = bbox
            params["bbox"] = f"{lon_min},{lat_min},{lon_max},{lat_max}"
        if width is not None:
            params["width"] = int(width)
        if height is not None:
            params["height"] = int(height)

        # Manuell Querystring aufbauen, damit wir keinen Request machen müssen
        from urllib.parse import urlencode

        return f"{base}?{urlencode(params)}"

    # ------------------------------------------------------------------
    # Map Tiles
    # ------------------------------------------------------------------
    def get_tile_url(
        self,
        imagery_id: int,
        z: int,
        x: int,
        y: int,
        bands_formula: str = "b04,b03,b02",
        tilesize: int = 512,
        rescale: Optional[Tuple[int, int]] = None,
    ) -> str:
        """
        Baut die URL für einen Map-Tile.

        API:
            GET /imagery/{id}/tiles/{z}/{x}/{y}/?bands_formula=...&tilesize=...&api_key=...

        Auch hier: nur URL, kein direkter Download.
        """
        base = f"{BASE_URL.rstrip('/')}/imagery/{int(imagery_id)}/tiles/{z}/{x}/{y}/"
        from urllib.parse import urlencode

        params: Dict[str, Any] = {
            "api_key": self.api_key,
            "bands_formula": bands_formula,
            "tilesize": int(tilesize),
        }
        if rescale is not None:
            params["rescale"] = f"{rescale[0]},{rescale[1]}"

        return f"{base}?{urlencode(params)}"

    # ------------------------------------------------------------------
    # Overpasses
    # ------------------------------------------------------------------
    def get_overpasses(
        self,
        bbox: Optional[Tuple[float, float, float, float]] = None,
        geometry: Optional[str] = None,
        satellites: Optional[str] = None,
        days_before: int = 0,
        days_after: int = 7,
    ) -> Dict[str, Any]:
        """
        Holt Überflüge (Overpasses) über einer Area-of-Interest.

        API:
            GET /overpass/

        Mindestens einer von `bbox` oder `geometry` muss gesetzt sein.
        """
        if not bbox and not geometry:
            raise ValueError("get_overpasses: Entweder 'bbox' oder 'geometry' muss angegeben werden.")

        params: Dict[str, Any] = {
            "days_before": int(days_before),
            "days_after": int(days_after),
        }
        if bbox:
            lon_min, lat_min, lon_max, lat_max = bbox
            params["bbox"] = f"{lon_min},{lat_min},{lon_max},{lat_max}"
        if geometry:
            params["geometry"] = geometry
        if satellites:
            params["satellites"] = satellites

        resp = self._get("/overpass/", params=params)
        return resp.json()


# Optional: kleiner Self-Test, wenn Modul direkt aufgerufen wird
if __name__ == "__main__":
    import os
    logging.basicConfig(level=logging.INFO)

    api_key = os.environ.get("SPECTATOR_API_KEY", "").strip()
    if not api_key:
        print("Bitte Umgebungsvariable SPECTATOR_API_KEY setzen, z.B.:")
        print("  export SPECTATOR_API_KEY='DEIN_API_KEY_HIER'")
        raise SystemExit(1)

    client = SpectatorClient(api_key=api_key)

    # Minimaler Test: Sentinel-1A hat ID 1 laut Doku
    sat = client.get_satellite(1)
    print("Satellite 1:", sat.get("properties", {}).get("name"), sat.get("geometry", {}))

    traj = client.get_trajectory(1)
    coords = traj.get("geometry", {}).get("coordinates", [])
    print("Trajectory points:", len(coords))

