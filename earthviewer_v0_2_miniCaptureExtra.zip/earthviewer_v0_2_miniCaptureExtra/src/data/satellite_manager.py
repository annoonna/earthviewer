
"""
Satellite Manager (Enhanced)
"""
from __future__ import annotations
import logging
from PyQt6.QtCore import QObject, QTimer, pyqtSignal
from .spectator_api import SpectatorClient
from core.satellite_tracker_engine import SatelliteTrackerEngine, LocalSatPosition

logger = logging.getLogger(__name__)

class SatellitePosition:
    def __init__(self, name, lat, lon, alt_m, sat_id=0, category="Unknown", tle_line1=None, tle_line2=None):
        self.name = name
        self.lat = lat
        self.lon = lon
        self.alt_m = alt_m
        self.satellite_id = sat_id
        self.category = category
        self.tle_line1 = tle_line1
        self.tle_line2 = tle_line2

class SatelliteManager(QObject):
    satellites_updated = pyqtSignal(list)

    def __init__(self, client: SpectatorClient, parent=None, update_interval_ms=10000):
        super().__init__(parent)
        self._client = client
        self.engine = SatelliteTrackerEngine()
        self.active_categories = set()
        self.use_local_engine = True
        self._timer = QTimer(self)
        self._timer.setInterval(update_interval_ms)
        self._timer.timeout.connect(self.update_positions)

    def add_category(self, category: str):
        if category not in self.active_categories:
            self.engine.fetch_tles(category)
            self.active_categories.add(category)
            self.update_positions()

    def remove_category(self, category: str):
        if category in self.active_categories:
            self.active_categories.remove(category)
            self.update_positions()

    def add_satellite(self, id, category=None):
        pass

    def start_auto_update(self):
        self._timer.start()

    def stop_auto_update(self):
        self._timer.stop()

    def update_positions(self):
        all_sats = []
        for cat in self.active_categories:
            local_positions = self.engine.compute_positions(cat)
            tle_sats = self.engine.satellites.get(cat, [])
            tle_dict = {s.name: (s.tle1, s.tle2) for s in tle_sats}
            for p in local_positions:
                tle1, tle2 = tle_dict.get(p.name, (None, None))
                all_sats.append(SatellitePosition(
                    name=p.name, lat=p.lat, lon=p.lon, alt_m=p.alt_km * 1000,
                    category=cat, tle_line1=tle1, tle_line2=tle2
                ))
        self.satellites_updated.emit(all_sats)

    def get_positions(self):
        # FIX: GENAU WIE update_positions - MIT TLE-DATEN!
        all_sats = []
        for cat in self.active_categories:
            local_positions = self.engine.compute_positions(cat)
            tle_sats = self.engine.satellites.get(cat, [])
            tle_dict = {s.name: (s.tle1, s.tle2) for s in tle_sats}
            for p in local_positions:
                tle1, tle2 = tle_dict.get(p.name, (None, None))
                all_sats.append(SatellitePosition(
                    name=p.name, lat=p.lat, lon=p.lon, alt_m=p.alt_km * 1000,
                    category=cat, tle_line1=tle1, tle_line2=tle2
                ))
        return all_sats
    def calculate_orbit(self, sat_name):
        """Berechne Orbit-Punkte für einen Satelliten"""
        # Nutze die ENGINE-Methode, aber konvertiere zu Dictionary
        orbit_points = self.engine.calculate_orbit(sat_name, num_points=100)
        
        if orbit_points and len(orbit_points) > 0:
            # Konvertiere Liste zu Dictionary-Format
            import numpy as np
            points_array = np.array(orbit_points, dtype=np.float32)
            return {
                'points': points_array,
                'period_minutes': 92.9,  # Wird vom engine berechnet
                'num_points': len(orbit_points),
                'current_index': 0
            }
        return None

