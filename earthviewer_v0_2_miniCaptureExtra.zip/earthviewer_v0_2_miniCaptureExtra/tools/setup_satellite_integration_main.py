#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT / "src"
UI_WIDGETS_DIR = SRC_DIR / "ui" / "widgets"
MAIN_FILE = ROOT / "main.py"

SATELLITE_INTEGRATION_FILE = UI_WIDGETS_DIR / "satellite_integration.py"
SATELLITE_AUTOSTART_FILE = SRC_DIR / "satellite_autostart.py"


def write_satellite_integration():
    code = r'''#!/usr/bin/env python3
"""
Satellite Integration for MainWindow
------------------------------------

Stellt eine Hilfsfunktion bereit, die auf einem bestehenden MainWindow:

- einen SpectatorClient + SatelliteManager erzeugt,
- die Satelliten-Updates mit GlobeWidget.set_satellites verbindet,
- ein paar Beispiel-Satelliten (Sentinel-1/2) registriert.

Die Funktion wird später automatisch durch satellite_autostart.py
aus MainWindow.__init__ heraus aufgerufen.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

from data.satellite_manager import SatelliteManager
from data.spectator_api import SpectatorClient

logger = logging.getLogger(__name__)


def _get_api_key_from_env() -> Optional[str]:
    api_key = os.environ.get("SPECTATOR_API_KEY", "").strip()
    if not api_key:
        logger.warning(
            "Kein Spectator API-Key gefunden. Bitte Umgebungsvariable "
            "SPECTATOR_API_KEY setzen oder die Integration anpassen."
        )
        return None
    return api_key


def setup_satellites_on_mainwindow(main_window, api_key: Optional[str] = None) -> None:
    """
    Richtet SatelliteManager + Live-Satellitenanzeige auf einem MainWindow ein.

    Erwartet:
        - main_window.globe_widget : GlobeWidget
    """
    api_key = (api_key or "").strip() or _get_api_key_from_env()
    if not api_key:
        return

    if not hasattr(main_window, "globe_widget"):
        logger.warning("MainWindow hat kein Attribut 'globe_widget' – Satelliten-Integration abgebrochen.")
        return

    globe = main_window.globe_widget

    try:
        client = SpectatorClient(api_key=api_key)
    except Exception as exc:
        logger.exception("Konnte SpectatorClient nicht initialisieren: %s", exc)
        return

    manager = SatelliteManager(client, parent=main_window, update_interval_ms=10_000)

    # Attribute am MainWindow hinterlegen (falls später gebraucht)
    main_window.spectator_client = client
    main_window.satellite_manager = manager

    # Satelliten-Updates an den Globus weitergeben
    try:
        manager.satellites_updated.connect(globe.set_satellites)
    except Exception as exc:
        logger.exception("Konnte satellites_updated nicht mit globe.set_satellites verbinden: %s", exc)
        return

    # Beispiel-Satelliten (kannst du später im UI konfigurierbar machen)
    manager.add_satellite(1, category="Sentinel-1")  # Sentinel-1A
    manager.add_satellite(2, category="Sentinel-2")  # Sentinel-2A

    manager.start_auto_update()

    logger.info("Satelliten-Integration für MainWindow eingerichtet (Sentinel-1/2, Auto-Update aktiv).")
'''
    SATELLITE_INTEGRATION_FILE.write_text(code, encoding="utf-8")
    print(f"[OK] satellite_integration.py geschrieben: {SATELLITE_INTEGRATION_FILE}")


def write_satellite_autostart():
    code = r'''#!/usr/bin/env python3
"""
Satellite Autostart
-------------------

Monkeypatcht MainWindow.__init__, um nach der normalen Initialisierung
automatisch die Satelliten-Integration zu aktivieren.

Dadurch musst du main_window.py nicht anfassen – es reicht, dieses
Modul (satellite_autostart) frühzeitig zu importieren (z.B. aus main.py).
"""

from __future__ import annotations

import logging
import traceback

from ui.widgets.main_window import MainWindow
from ui.widgets.satellite_integration import setup_satellites_on_mainwindow


logger = logging.getLogger(__name__)

_original_init = MainWindow.__init__


def _patched_init(self, *args, **kwargs):
    # Erst die originale Initialisierung
    _original_init(self, *args, **kwargs)

    # Danach Satelliten-Integration versuchen
    try:
        setup_satellites_on_mainwindow(self)
    except Exception as exc:
        logger.warning("Fehler bei setup_satellites_on_mainwindow: %s", exc)
        traceback.print_exc()


MainWindow.__init__ = _patched_init

logger.info("satellite_autostart: MainWindow.__init__ wurde gepatcht (Satelliten-Autostart aktiviert).")
'''
    SATELLITE_AUTOSTART_FILE.write_text(code, encoding="utf-8")
    print(f"[OK] satellite_autostart.py geschrieben: {SATELLITE_AUTOSTART_FILE}")


def patch_main_import():
    if not MAIN_FILE.exists():
        print(f"[FEHLER] main.py nicht gefunden: {MAIN_FILE}")
        sys.exit(1)

    text = MAIN_FILE.read_text(encoding="utf-8")
    if "import satellite_autostart" in text:
        print("[INFO] main.py enthält bereits 'import satellite_autostart' – überspringe Patch.")
        return

    lines = text.splitlines()
    new_lines = []
    inserted = False

    # Future-Imports (falls vorhanden) beibehalten, danach unser Import
    i = 0
    while i < len(lines) and lines[i].strip().startswith("from __future__ import"):
        new_lines.append(lines[i])
        i += 1

    if not inserted:
        new_lines.append("import satellite_autostart")
        inserted = True

    # Rest anhängen
    new_lines.extend(lines[i:])

    MAIN_FILE.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    print(f"[OK] main.py gepatcht: 'import satellite_autostart' hinzugefügt.")


def main():
    write_satellite_integration()
    write_satellite_autostart()
    patch_main_import()
    print("== Satelliten-Integration für MainWindow eingerichtet. ==")
    print("Hinweis: API-Key muss weiterhin über SPECTATOR_API_KEY gesetzt sein.")


if __name__ == "__main__":
    main()
