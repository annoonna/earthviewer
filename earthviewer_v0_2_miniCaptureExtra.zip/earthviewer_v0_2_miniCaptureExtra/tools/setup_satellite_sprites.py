#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

print("== EarthViewer Satelliten-Sprites Setup ==")

ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT / "src"
RENDERING_DIR = SRC_DIR / "rendering"
UI_WIDGETS_DIR = SRC_DIR / "ui" / "widgets"
TEXTURES_DIR = ROOT / "data" / "textures" / "satellites"

GLOBE_WIDGET_FILE = UI_WIDGETS_DIR / "globe_widget.py"
SATELLITE_SPRITES_FILE = RENDERING_DIR / "satellite_sprites.py"
ICON_FILE = TEXTURES_DIR / "satellite_icon.png"


def ensure_icon():
    TEXTURES_DIR.mkdir(parents=True, exist_ok=True)
    if ICON_FILE.exists():
        print(f"[OK] Icon existiert bereits: {ICON_FILE}")
        return

    print(f"[INFO] Erzeuge Platzhalter-Icon: {ICON_FILE}")
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        print("[WARN] Pillow ist nicht installiert, kann kein Icon erzeugen.")
        return

    img = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Einfaches Satellit-Icon: Körper + Solarpanels
    cx, cy = 64, 64
    # Körper
    draw.rectangle([cx - 12, cy - 10, cx + 12, cy + 10], fill=(200, 200, 255, 255))
    # Panels
    draw.rectangle([cx - 38, cy - 8, cx - 14, cy + 8], fill=(120, 180, 255, 220))
    draw.rectangle([cx + 14, cy - 8, cx + 38, cy + 8], fill=(120, 180, 255, 220))
    # Antenne
    draw.line([cx, cy + 10, cx, cy + 30], fill=(255, 255, 255, 255), width=2)
    draw.ellipse([cx - 3, cy + 28, cx + 3, cy + 34], fill=(255, 255, 255, 255))

    img.save(ICON_FILE)
    print(f"[OK] Platzhalter-Icon gespeichert unter {ICON_FILE}")


def write_satellite_sprites():
    RENDERING_DIR.mkdir(parents=True, exist_ok=True)
    code = r'''#!/usr/bin/env python3
"""
Satellite Sprite Renderer
-------------------------

Zeichnet Satelliten als texturierte Point-Sprites (Billboards), die
ein PNG-Icon (z.B. satellite_icon.png) verwenden.

Nutzung:
    renderer = SatelliteSpriteRenderer()
    renderer.render_satellites(mvp_matrix, positions_ndarray)

wobei `positions_ndarray` ein (N, 3) Numpy-Array von 3D-Koordinaten ist.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import numpy as np
from OpenGL.GL import *
from OpenGL.GL import shaders
from PIL import Image

from core.config import TEXTURE_DIR


logger = logging.getLogger(__name__)


VERTEX_SHADER_SRC = """
#version 330 core
layout(location = 0) in vec3 aPos;

uniform mat4 mvp;
uniform float baseSize;

void main()
{
    gl_Position = mvp * vec4(aPos, 1.0);
    gl_PointSize = baseSize;
}
"""

FRAGMENT_SHADER_SRC = """
#version 330 core
out vec4 FragColor;

uniform sampler2D tex;
uniform vec4 tint;

void main()
{
    // gl_PointCoord gibt die Texturkoordinaten innerhalb des Punktes (0..1)
    vec2 uv = gl_PointCoord;
    vec4 texColor = texture(tex, uv);

    // Premultiplied Alpha / Tint
    vec4 color = texColor * tint;

    // Sehr transparente Pixel verwerfen (saubere Kanten)
    if (color.a < 0.1)
        discard;

    FragColor = color;
}
"""


class SatelliteSpriteRenderer:
    """
    Rendert Satelliten als texturierte Punkte mit einem PNG-Icon.

    - Initialisiert Shader und Textur bei der ersten Nutzung.
    - Erwartet, dass bereits ein gültiger OpenGL-Kontext existiert
      (d.h. innerhalb von QOpenGLWidget.paintGL aufgerufen wird).
    """

    def __init__(
        self,
        icon_path: Optional[Path] = None,
        base_size: float = 48.0,
    ) -> None:
        self.icon_path = icon_path or (TEXTURE_DIR / "satellites" / "satellite_icon.png")
        self.base_size = base_size

        self._initialized = False
        self._program: Optional[int] = None
        self._texture_id: Optional[int] = None

    # ------------------------------------------------------------------
    # Initialisierung
    # ------------------------------------------------------------------

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return

        if not self.icon_path.exists():
            logger.warning("SatelliteSpriteRenderer: Icon-Datei existiert nicht: %s", self.icon_path)

        # Shader kompiliieren
        try:
            vs = shaders.compileShader(VERTEX_SHADER_SRC, GL_VERTEX_SHADER)
            fs = shaders.compileShader(FRAGMENT_SHADER_SRC, GL_FRAGMENT_SHADER)
            program = shaders.compileProgram(vs, fs)
        except Exception as exc:
            logger.exception("Fehler beim Kompilieren der Satelliten-Shader: %s", exc)
            raise

        self._program = program

        # Textur laden
        self._texture_id = self._load_texture(self.icon_path)

        self._initialized = True
        logger.info("SatelliteSpriteRenderer initialisiert (Programm=%s, Textur=%s)", self._program, self._texture_id)

    def _load_texture(self, path: Path) -> int:
        """
        Lädt eine 2D-Textur aus einer PNG-Datei und gibt die OpenGL-Textur-ID zurück.
        """
        try:
            img = Image.open(path).convert("RGBA")
        except Exception as exc:
            logger.error("Konnte Satelliten-Icon nicht laden (%s): %s", path, exc)
            # Dummy-Textur (1x1 weiß)
            data = bytes([255, 255, 255, 255])
            tex_id = glGenTextures(1)
            glBindTexture(GL_TEXTURE_2D, tex_id)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, data)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
            glBindTexture(GL_TEXTURE_2D, 0)
            return tex_id

        img_data = img.tobytes("raw", "RGBA")
        width, height = img.size

        tex_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, tex_id)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img_data)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
        glGenerateMipmap(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, 0)

        return tex_id

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def render_satellites(self, mvp: np.ndarray, positions: np.ndarray, tint=(1.0, 1.0, 1.0, 1.0)) -> None:
        """
        Rendert Satellitenpositionen als Icons.

        Parameter:
            mvp: 4x4-Matrix (numpy float32) – ModelViewProjection
            positions: (N, 3) float32-Array mit 3D-Koordinaten
            tint: RGBA-Farb-Multiplikator (float 0..1)
        """
        if positions is None or len(positions) == 0:
            return

        self._ensure_initialized()
        if self._program is None or self._texture_id is None:
            return

        # Sicherheit: Typ/Shape prüfen
        positions = np.asarray(positions, dtype=np.float32)
        if positions.ndim != 2 or positions.shape[1] != 3:
            raise ValueError("render_satellites: positions muss ein (N, 3) Array sein")

        # OpenGL-Setup
        glUseProgram(self._program)

        # MVP-Matrix
        loc_mvp = glGetUniformLocation(self._program, "mvp")
        glUniformMatrix4fv(loc_mvp, 1, GL_FALSE, mvp.astype(np.float32))

        # Basisgröße der Icons
        loc_size = glGetUniformLocation(self._program, "baseSize")
        glUniform1f(loc_size, float(self.base_size))

        # Tint-Farbe
        loc_tint = glGetUniformLocation(self._program, "tint")
        glUniform4f(loc_tint, float(tint[0]), float(tint[1]), float(tint[2]), float(tint[3]))

        # Textur binden
        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_2D, self._texture_id)
        loc_tex = glGetUniformLocation(self._program, "tex")
        glUniform1i(loc_tex, 0)

        # Point-Sprite-States
        glEnable(GL_PROGRAM_POINT_SIZE)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

        # VAO/VBO für die Satellitenpositionen
        vao = glGenVertexArrays(1)
        vbo = glGenBuffers(1)

        glBindVertexArray(vao)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, positions.nbytes, positions, GL_DYNAMIC_DRAW)

        glEnableVertexAttribArray(0)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)

        # Zeichnen
        glDrawArrays(GL_POINTS, 0, len(positions))

        # Aufräumen
        glBindBuffer(GL_ARRAY_BUFFER, 0)
        glBindVertexArray(0)
        glDeleteBuffers(1, [vbo])
        glDeleteVertexArrays(1, [vao])

        glDisable(GL_BLEND)
        glDisable(GL_PROGRAM_POINT_SIZE)

        glBindTexture(GL_TEXTURE_2D, 0)
        glUseProgram(0)


if __name__ == "__main__":
    print("SatelliteSpriteRenderer-Modul geladen.")
'''
    SATELLITE_SPRITES_FILE.write_text(code, encoding="utf-8")
    print(f"[OK] satellite_sprites.py geschrieben: {SATELLITE_SPRITES_FILE}")


def patch_globe_widget():
    if not GLOBE_WIDGET_FILE.exists():
        print(f"[FEHLER] globe_widget.py nicht gefunden: {GLOBE_WIDGET_FILE}")
        sys.exit(1)

    text = GLOBE_WIDGET_FILE.read_text(encoding="utf-8")

    # 1) set_satellites-Methode per Monkeypatch anhängen, falls noch nicht vorhanden
    if "_globewidget_set_satellites" not in text:
        patch = r'''

def _globewidget_set_satellites(self, satellites):
    """
    Nimmt eine Liste von SatellitePosition-Objekten (aus SatelliteManager)
    und konvertiert sie in 3D-Koordinaten für die Darstellung.
    """
    from core.geo_location import GeoLocation
    from core.config import SPHERE_RADIUS, MARKER_OFFSET
    import numpy as np

    # Standard: Satellitenanzeige aktivieren, falls noch nicht gesetzt
    if not hasattr(self, "show_satellites"):
        self.show_satellites = True

    positions = []
    for sat in satellites:
        # Satellit ein klein wenig über der Erdoberfläche positionieren
        radius = SPHERE_RADIUS + MARKER_OFFSET * 3.0
        loc = GeoLocation(name=sat.name, lat=sat.lat, lon=sat.lon)
        x, y, z = loc.to_cartesian(radius)
        positions.append((x, y, z))

    if positions:
        self._satellite_positions_3d = np.array(positions, dtype=np.float32)
    else:
        self._satellite_positions_3d = None

    # Flag setzen, falls noch nicht existiert
    if not hasattr(self, "show_satellites"):
        self.show_satellites = True

    self.update()

# Monkeypatch der Methode in GlobeWidget
try:
    GlobeWidget.set_satellites = _globewidget_set_satellites
except NameError:
    # Falls GlobeWidget hier noch nicht definiert ist, ist etwas mit dem
    # Import-Order anders als erwartet.
    pass
'''
        text += patch
        print("[OK] set_satellites-Monkeypatch an globe_widget.py angehängt.")
    else:
        print("[INFO] set_satellites-Patch bereits vorhanden, überspringe.")

    # 2) paintGL patchen: vor QtGui.QPainter die Satelliten rendern
    if "SatelliteSpriteRenderer" in text and "render_satellites(mvp" in text:
        print("[INFO] paintGL scheint bereits gepatcht zu sein, überspringe.")
    else:
        pattern = r"(\s*)painter = QtGui\.QPainter\(self\)"
        match = re.search(pattern, text)
        if not match:
            print("[WARN] Konnte 'painter = QtGui.QPainter(self)' in globe_widget.py nicht finden.")
        else:
            indent = match.group(1)
            block = (
                f"{indent}# Satelliten-Icons rendern (falls vorhanden)\n"
                f"{indent}if getattr(self, \"show_satellites\", False) and getattr(self, \"_satellite_positions_3d\", None) is not None:\n"
                f"{indent}    try:\n"
                f"{indent}        from rendering.satellite_sprites import SatelliteSpriteRenderer\n"
                f"{indent}        if not hasattr(self, \"satellite_renderer\"):\n"
                f"{indent}            self.satellite_renderer = SatelliteSpriteRenderer()\n"
                f"{indent}        self.satellite_renderer.render_satellites(mvp, self._satellite_positions_3d)\n"
                f"{indent}    except Exception:\n"
                f"{indent}        import traceback\n"
                f"{indent}        traceback.print_exc()\n"
                f"{indent}painter = QtGui.QPainter(self)"
            )
            text = re.sub(pattern, block, text, count=1)
            print("[OK] paintGL in globe_widget.py gepatcht (Satelliten-Rendering eingefügt).")

    GLOBE_WIDGET_FILE.write_text(text, encoding="utf-8")
    print(f"[OK] globe_widget.py aktualisiert: {GLOBE_WIDGET_FILE}")


def main():
    ensure_icon()
    write_satellite_sprites()
    patch_globe_widget()
    print("== Setup abgeschlossen. Du kannst jetzt im Hauptprogramm set_satellites() verwenden. ==")


if __name__ == "__main__":
    main()
