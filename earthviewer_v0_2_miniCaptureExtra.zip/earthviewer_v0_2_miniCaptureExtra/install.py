#!/usr/bin/env python3
"""
EarthViewer 2.0 - Installation Script
Teil 1/4: Basis-Setup und Konfiguration

Führe dieses Script aus um die komplette Projektstruktur zu erstellen
"""
import os
import sys
from pathlib import Path

print("=" * 70)
print("🌍 EarthViewer 2.0 - Installation")
print("=" * 70)

# Basis-Verzeichnis
BASE_DIR = Path(__file__).parent.resolve()

# Projekt-Struktur
STRUCTURE = {
    "src": {
        "core": ["__init__.py", "config.py", "geo_location.py"],
        "data": ["__init__.py", "geo_manager.py"],
        "rendering": ["__init__.py", "shaders.py", "sphere_geometry.py", "gl_renderer.py"],
        "network": ["__init__.py", "traceroute.py", "ping.py", "whois_lookup.py"],
        "ui": {
            "widgets": ["__init__.py", "main_window.py", "globe_widget.py", "sidebar.py"],
            "__init__.py": None
        },
        "utils": ["__init__.py", "matrix_utils.py"],
        "__init__.py": None
    },
    "data": {
        "geodata": {},
        "textures": {}
    },
    "screenshots": {},
    "logs": {},
    "sessions": {},
    "tests": ["__init__.py", "test_geo_location.py"],
    "main.py": None,
    "requirements.txt": None,
    "README.md": None
}

def create_structure(base_path: Path, structure: dict):
    """Erstellt die Verzeichnisstruktur"""
    for name, content in structure.items():
        path = base_path / name
        
        if isinstance(content, dict):
            # Verzeichnis
            path.mkdir(exist_ok=True)
            print(f"📁 {path.relative_to(BASE_DIR)}")
            create_structure(path, content)
        elif isinstance(content, list):
            # Verzeichnis mit Dateien
            path.mkdir(exist_ok=True)
            print(f"📁 {path.relative_to(BASE_DIR)}")
            for file in content:
                file_path = path / file
                if not file_path.exists():
                    file_path.touch()
                    print(f"   📄 {file}")
        elif content is None:
            # Einzelne Datei
            if not path.exists():
                path.touch()
                print(f"📄 {path.relative_to(BASE_DIR)}")

print("\n🔨 Erstelle Projektstruktur...")
create_structure(BASE_DIR, STRUCTURE)

print("\n✅ Struktur erstellt!\n")

# ============================================================================
# DATEI-INHALTE - TEIL 1: CORE MODULE
# ============================================================================

print("📝 Schreibe Core-Module...")

# --- src/core/config.py ---
CONFIG_PY = '''#!/usr/bin/env python3
"""
Zentrale Konfiguration für EarthViewer
"""
from pathlib import Path

# Projekt-Pfade
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DATA_DIR = PROJECT_ROOT / "data"
GEODATA_DIR = DATA_DIR / "geodata"
TEXTURE_DIR = DATA_DIR / "textures"
SCREENSHOT_DIR = PROJECT_ROOT / "screenshots"
LOG_DIR = PROJECT_ROOT / "logs"
SESSION_DIR = PROJECT_ROOT / "sessions"

# Erstelle Verzeichnisse
for directory in [SCREENSHOT_DIR, LOG_DIR, SESSION_DIR]:
    directory.mkdir(exist_ok=True, parents=True)

# Fenster-Einstellungen
WINDOW_TITLE = "🌍 EarthViewer 2.0"
WINDOW_WIDTH = 1400
WINDOW_HEIGHT = 900
WINDOW_MIN_WIDTH = 1000
WINDOW_MIN_HEIGHT = 600

# Rendering
SPHERE_RADIUS = 1.0
MARKER_OFFSET = 0.02
SPHERE_STACKS = 64
SPHERE_SLICES = 128

# Kamera
CAMERA_FOV = 45.0
CAMERA_NEAR = 0.1
CAMERA_FAR = 100.0
CAMERA_DISTANCE = 2.8
CAMERA_MIN_DISTANCE = 1.2
CAMERA_MAX_DISTANCE = 25.0

# Animation
AUTO_ROTATE_SPEED = 0.3
ROTATION_SENSITIVITY = 0.3
ZOOM_FACTOR = 0.9

# Marker-Farben (RGB)
MARKER_COLOR_SEARCH = (1.0, 0.9, 0.2)
MARKER_COLOR_TARGET = (1.0, 0.1, 0.1)
MARKER_COLOR_TRACEROUTE = (0.2, 0.8, 1.0)
MARKER_COLOR_PING = (0.2, 1.0, 0.2)

# Marker-Größen
MARKER_SIZE_SEARCH = 12.0
MARKER_SIZE_TARGET = 18.0
MARKER_SIZE_TRACEROUTE = 10.0

# Netzwerk
TRACEROUTE_MAX_HOPS = 30
TRACEROUTE_TIMEOUT = 2.0
PING_COUNT = 4
PING_INTERVAL = 1.0
WHOIS_TIMEOUT = 10.0

# Texturen
EARTH_TEXTURE = TEXTURE_DIR / "earth_map.jpg"

# Theme-Farben
COLOR_BACKGROUND = "#1e1e1e"
COLOR_SURFACE = "#2b2b2b"
COLOR_PRIMARY = "#0d7377"
COLOR_PRIMARY_HOVER = "#0e8388"
COLOR_SURFACE_VARIANT = "#3a3a3a"
COLOR_BORDER = "#555555"
COLOR_TEXT = "#ffffff"
COLOR_TEXT_SECONDARY = "#aaaaaa"
'''

with open(BASE_DIR / "src" / "core" / "config.py", "w", encoding="utf-8") as f:
    f.write(CONFIG_PY)
print("   ✅ config.py")

# --- src/core/geo_location.py ---
GEO_LOCATION_PY = '''#!/usr/bin/env python3
"""
GeoLocation - Geografische Position mit Metadaten
"""
import math
import numpy as np
from dataclasses import dataclass, field
from typing import Tuple, Dict, Any

@dataclass
class GeoLocation:
    """Geografische Position"""
    name: str
    lat: float
    lon: float
    country: str = ""
    location_type: str = "city"
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_cartesian(self, radius: float = 1.0) -> np.ndarray:
        """Konvertiert Lat/Lon zu 3D-Kartesischen Koordinaten"""
        lat_rad = math.radians(self.lat)
        lon_rad = math.radians(self.lon)
        
        x = radius * math.cos(lat_rad) * math.sin(lon_rad)
        y = radius * math.sin(lat_rad)
        z = radius * math.cos(lat_rad) * math.cos(lon_rad)
        
        return np.array([x, y, z], dtype=np.float32)
    
    def to_uv(self) -> Tuple[float, float]:
        """Konvertiert Lat/Lon zu Textur UV-Koordinaten"""
        u = (self.lon + 180.0) / 360.0
        v = (90.0 - self.lat) / 180.0
        return u, v
    
    def distance_to(self, other: 'GeoLocation') -> float:
        """Berechnet Distanz zu anderem Punkt (Haversine, in km)"""
        R = 6371.0
        
        lat1, lon1 = math.radians(self.lat), math.radians(self.lon)
        lat2, lon2 = math.radians(other.lat), math.radians(other.lon)
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a))
        
        return R * c
'''

with open(BASE_DIR / "src" / "core" / "geo_location.py", "w", encoding="utf-8") as f:
    f.write(GEO_LOCATION_PY)
print("   ✅ geo_location.py")

# --- src/utils/matrix_utils.py ---
MATRIX_UTILS_PY = '''#!/usr/bin/env python3
"""
Matrix-Utilities für 3D-Transformationen
"""
import math
import numpy as np

def create_rotation_matrix(angle_deg: float, axis: np.ndarray) -> np.ndarray:
    """Erstellt 4x4 Rotationsmatrix um beliebige Achse"""
    angle_rad = math.radians(angle_deg)
    c = math.cos(angle_rad)
    s = math.sin(angle_rad)
    t = 1.0 - c
    
    axis = axis / np.linalg.norm(axis)
    x, y, z = axis
    
    return np.array([
        [t*x*x + c,   t*x*y - z*s, t*x*z + y*s, 0],
        [t*x*y + z*s, t*y*y + c,   t*y*z - x*s, 0],
        [t*x*z - y*s, t*y*z + x*s, t*z*z + c,   0],
        [0,           0,           0,           1]
    ], dtype=np.float32)

def create_projection_matrix(fov_deg: float, aspect: float, near: float, far: float) -> np.ndarray:
    """Erstellt Perspektiv-Projektionsmatrix"""
    f = 1.0 / math.tan(math.radians(fov_deg) / 2.0)
    
    return np.array([
        [f / aspect, 0, 0, 0],
        [0, f, 0, 0],
        [0, 0, (far + near) / (near - far), (2 * far * near) / (near - far)],
        [0, 0, -1, 0]
    ], dtype=np.float32)

def create_view_matrix(distance: float) -> np.ndarray:
    """Erstellt View-Matrix (Kamera-Position)"""
    view = np.identity(4, dtype=np.float32)
    view[2, 3] = -distance
    return view

def create_translation_matrix(x: float, y: float, z: float) -> np.ndarray:
    """Erstellt Translationsmatrix"""
    return np.array([
        [1, 0, 0, x],
        [0, 1, 0, y],
        [0, 0, 1, z],
        [0, 0, 0, 1]
    ], dtype=np.float32)
'''

with open(BASE_DIR / "src" / "utils" / "matrix_utils.py", "w", encoding="utf-8") as f:
    f.write(MATRIX_UTILS_PY)
print("   ✅ matrix_utils.py")

print("\n✅ Core-Module geschrieben!\n")

# ENDE TEIL 1
# Fortsetzung in Teil 2...
# ============================================================================
# TEIL 2/4: DATA & RENDERING MODULE
# Füge diesen Teil direkt nach Teil 1 ein
# ============================================================================

print("📝 Schreibe Data-Module...")

# --- src/data/geo_manager.py ---
GEO_MANAGER_PY = '''#!/usr/bin/env python3
"""
GeoDataManager - Verwaltet geografische Daten
"""
import csv
from pathlib import Path
from typing import List, Optional

from core.geo_location import GeoLocation
from core.config import GEODATA_DIR

try:
    import geoip2.database
    import ipaddress
    GEOIP_AVAILABLE = True
except ImportError:
    GEOIP_AVAILABLE = False

class GeoDataManager:
    """Verwaltet alle geografischen Daten"""
    
    def __init__(self, data_root: Path = GEODATA_DIR):
        self.data_root = Path(data_root)
        self.locations: List[GeoLocation] = []
        self.geoip_reader = None
        
        self._load_csv_data()
        self._load_geoip_database()
        
        print(f"✅ {len(self.locations)} Orte geladen")
        if self.geoip_reader:
            print("✅ GeoIP-Datenbank aktiv")
    
    def _load_csv_data(self):
        """Lädt Stadt-Daten aus CSV"""
        if not self.data_root.exists():
            print(f"⚠️ Geodaten-Ordner nicht gefunden: {self.data_root}")
            return
        
        for csv_file in self.data_root.rglob("*.csv"):
            try:
                with open(csv_file, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    country = csv_file.parent.name
                    
                    for row in reader:
                        try:
                            name = row.get('name') or row.get('city')
                            if not name or not name.strip():
                                continue
                            
                            lat = float(row.get('lat', 0))
                            lon = float(row.get('lon') or row.get('lng', 0))
                            
                            if lon > 180:
                                lon -= 360
                            
                            self.locations.append(GeoLocation(
                                name=name,
                                lat=lat,
                                lon=lon,
                                country=country,
                                location_type='city'
                            ))
                        except (ValueError, TypeError):
                            continue
            except Exception as e:
                print(f"⚠️ Fehler: {csv_file.name}: {e}")
    
    def _load_geoip_database(self):
        """Lädt GeoIP MMDB-Datenbank"""
        if not GEOIP_AVAILABLE:
            return
        
        for mmdb_file in self.data_root.rglob("*.mmdb"):
            if "city" in mmdb_file.name.lower():
                try:
                    self.geoip_reader = geoip2.database.Reader(str(mmdb_file))
                    return
                except Exception as e:
                    print(f"⚠️ GeoIP-Fehler: {e}")
    
    def search(self, query: str) -> List[GeoLocation]:
        """Universelle Suchfunktion"""
        query = query.strip()
        if not query:
            return []
        
        results = []
        
        # 1. Koordinaten
        if ',' in query and len(query.split(',')) == 2:
            try:
                parts = query.split(',')
                lat = float(parts[0].strip())
                lon = float(parts[1].strip())
                if -90 <= lat <= 90 and -180 <= lon <= 180:
                    return [GeoLocation(
                        name=f"Koordinaten: {lat:.4f}, {lon:.4f}",
                        lat=lat,
                        lon=lon,
                        location_type='custom'
                    )]
            except ValueError:
                pass
        
        # 2. IP-Adresse
        if self.geoip_reader:
            try:
                ip_addr = ipaddress.ip_address(query)
                response = self.geoip_reader.city(str(ip_addr))
                
                if response.location.latitude and response.location.longitude:
                    return [GeoLocation(
                        name=response.city.name or f"IP: {query}",
                        lat=response.location.latitude,
                        lon=response.location.longitude,
                        country=response.country.iso_code or "",
                        location_type='ip'
                    )]
            except:
                pass
        
        # 3. Text-Suche
        search_terms = query.lower().split()
        
        if len(search_terms) > 1:
            for term in search_terms:
                if len(term) < 3:
                    continue
                
                term_results = [
                    loc for loc in self.locations
                    if (loc.name and term in loc.name.lower()) or 
                       (loc.country and term in loc.country.lower())
                ]
                
                term_results.sort(key=lambda x: len(x.name) if x.name else 999)
                results.extend(term_results[:10])
        else:
            query_lower = query.lower()
            results = [
                loc for loc in self.locations
                if (loc.name and query_lower in loc.name.lower()) or 
                   (loc.country and query_lower in loc.country.lower())
            ]
            results.sort(key=lambda x: len(x.name) if x.name else 999)
        
        # Duplikate entfernen
        unique_results = []
        seen_positions = set()
        for loc in results:
            pos_key = (round(loc.lat, 1), round(loc.lon, 1))
            if pos_key not in seen_positions:
                unique_results.append(loc)
                seen_positions.add(pos_key)
        
        return unique_results[:50]
    
    def lookup_ip(self, ip: str) -> Optional[GeoLocation]:
        """Schlägt IP-Adresse nach"""
        if not self.geoip_reader:
            return None
        
        try:
            response = self.geoip_reader.city(ip)
            if response.location.latitude and response.location.longitude:
                return GeoLocation(
                    name=response.city.name or f"IP: {ip}",
                    lat=response.location.latitude,
                    lon=response.location.longitude,
                    country=response.country.iso_code or "",
                    location_type='ip',
                    metadata={'ip': ip}
                )
        except:
            pass
        
        return None
'''

with open(BASE_DIR / "src" / "data" / "geo_manager.py", "w", encoding="utf-8") as f:
    f.write(GEO_MANAGER_PY)
print("   ✅ geo_manager.py")

print("\n📝 Schreibe Rendering-Module...")

# --- src/rendering/shaders.py ---
SHADERS_PY = '''#!/usr/bin/env python3
"""
OpenGL Shader-Programme
"""

EARTH_VERTEX_SHADER = """
#version 330 core
layout(location = 0) in vec3 position;
layout(location = 1) in vec2 texCoord;
layout(location = 2) in vec3 normal;

uniform mat4 mvp;
uniform mat4 model;
uniform vec3 lightPos;

out vec2 fragTexCoord;
out float lightIntensity;

void main() {
    gl_Position = mvp * vec4(position, 1.0);
    fragTexCoord = texCoord;
    
    vec3 worldPos = (model * vec4(position, 1.0)).xyz;
    vec3 worldNormal = normalize(mat3(model) * normal);
    vec3 lightDir = normalize(lightPos - worldPos);
    
    float diffuse = max(dot(worldNormal, lightDir), 0.0);
    lightIntensity = 0.3 + 0.7 * diffuse;
}
"""

EARTH_FRAGMENT_SHADER = """
#version 330 core
in vec2 fragTexCoord;
in float lightIntensity;

out vec4 outColor;

uniform sampler2D earthTexture;

void main() {
    vec4 texColor = texture(earthTexture, fragTexCoord);
    outColor = vec4(texColor.rgb * lightIntensity, texColor.a);
}
"""

MARKER_VERTEX_SHADER = """
#version 330 core
layout(location = 0) in vec3 position;

uniform mat4 mvp;
uniform float pointSize;

void main() {
    gl_Position = mvp * vec4(position, 1.0);
    gl_PointSize = pointSize;
}
"""

MARKER_FRAGMENT_SHADER = """
#version 330 core
out vec4 outColor;

uniform vec3 markerColor;

void main() {
    vec2 coord = gl_PointCoord - vec2(0.5);
    if (length(coord) > 0.5) {
        discard;
    }
    outColor = vec4(markerColor, 1.0);
}
"""

LINE_VERTEX_SHADER = """
#version 330 core
layout(location = 0) in vec3 position;

uniform mat4 mvp;

void main() {
    gl_Position = mvp * vec4(position, 1.0);
}
"""

LINE_FRAGMENT_SHADER = """
#version 330 core
out vec4 outColor;

uniform vec3 lineColor;
uniform float alpha;

void main() {
    outColor = vec4(lineColor, alpha);
}
"""
'''

with open(BASE_DIR / "src" / "rendering" / "shaders.py", "w", encoding="utf-8") as f:
    f.write(SHADERS_PY)
print("   ✅ shaders.py")

# --- src/rendering/sphere_geometry.py ---
SPHERE_GEOMETRY_PY = '''#!/usr/bin/env python3
"""
Sphere-Geometrie Generator
"""
import math
import numpy as np
from typing import Tuple

class SphereGeometry:
    """Erzeugt UV-Sphere Geometrie"""
    
    @staticmethod
    def generate(radius: float = 1.0, stacks: int = 64, slices: int = 128):
        """Erzeugt Vertices, Textur-Koordinaten, Normalen und Indices"""
        vertices = []
        tex_coords = []
        normals = []
        indices = []
        
        for stack in range(stacks + 1):
            lat = 90.0 - (stack / stacks) * 180.0
            lat_rad = math.radians(lat)
            
            for slice in range(slices + 1):
                lon = (slice / slices) * 360.0 - 180.0
                lon_rad = math.radians(lon)
                
                x = radius * math.cos(lat_rad) * math.sin(lon_rad)
                y = radius * math.sin(lat_rad)
                z = radius * math.cos(lat_rad) * math.cos(lon_rad)
                
                vertices.extend([x, y, z])
                
                u = (lon + 180.0) / 360.0
                v = (90.0 - lat) / 180.0
                tex_coords.extend([u, v])
                
                normal = np.array([x, y, z])
                norm_length = np.linalg.norm(normal)
                if norm_length > 0:
                    normal = normal / norm_length
                normals.extend(normal)
        
        for stack in range(stacks):
            for slice in range(slices):
                first = stack * (slices + 1) + slice
                second = first + slices + 1
                
                indices.extend([first, second, first + 1])
                indices.extend([second, second + 1, first + 1])
        
        return (
            np.array(vertices, dtype=np.float32),
            np.array(tex_coords, dtype=np.float32),
            np.array(normals, dtype=np.float32),
            np.array(indices, dtype=np.uint32)
        )
'''

with open(BASE_DIR / "src" / "rendering" / "sphere_geometry.py", "w", encoding="utf-8") as f:
    f.write(SPHERE_GEOMETRY_PY)
print("   ✅ sphere_geometry.py")

print("\n✅ Data & Rendering-Module geschrieben!\n")

# ENDE TEIL 2
# Fortsetzung in Teil 3...
# ============================================================================
# TEIL 3/4: GL RENDERER & NETWORK MODULE
# Füge diesen Teil direkt nach Teil 2 ein
# ============================================================================

# --- src/rendering/gl_renderer.py ---
GL_RENDERER_PY = '''#!/usr/bin/env python3
"""
OpenGL Renderer für Erde und Marker
"""
import numpy as np
from OpenGL.GL import *
from OpenGL.GL import shaders
from PIL import Image
import ctypes
from typing import List, Tuple, Optional
from pathlib import Path

from core.geo_location import GeoLocation
from core.config import (
    SPHERE_RADIUS, MARKER_OFFSET, SPHERE_STACKS, SPHERE_SLICES,
    MARKER_COLOR_SEARCH, MARKER_COLOR_TARGET, MARKER_COLOR_TRACEROUTE,
    MARKER_SIZE_SEARCH, MARKER_SIZE_TARGET, MARKER_SIZE_TRACEROUTE
)
from rendering.shaders import (
    EARTH_VERTEX_SHADER, EARTH_FRAGMENT_SHADER,
    MARKER_VERTEX_SHADER, MARKER_FRAGMENT_SHADER,
    LINE_VERTEX_SHADER, LINE_FRAGMENT_SHADER
)
from rendering.sphere_geometry import SphereGeometry

class GLRenderer:
    """OpenGL Renderer"""
    
    def __init__(self, texture_path: Path):
        self.texture_path = texture_path
        self.earth_shader = None
        self.marker_shader = None
        self.line_shader = None
        self.sphere_vao = None
        self.sphere_index_count = 0
        self.texture_id = None
        self._initialized = False
    
    def initialize(self):
        """Initialisiert OpenGL-Ressourcen"""
        if self._initialized:
            return
        
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_PROGRAM_POINT_SIZE)
        glEnable(GL_CULL_FACE)
        glCullFace(GL_BACK)
        glFrontFace(GL_CCW)
        glClearColor(0.0, 0.0, 0.05, 1.0)
        
        self.earth_shader = self._compile_shader_program(EARTH_VERTEX_SHADER, EARTH_FRAGMENT_SHADER)
        self.marker_shader = self._compile_shader_program(MARKER_VERTEX_SHADER, MARKER_FRAGMENT_SHADER)
        self.line_shader = self._compile_shader_program(LINE_VERTEX_SHADER, LINE_FRAGMENT_SHADER)
        
        self.texture_id = self._load_texture()
        self._setup_sphere_geometry()
        
        self._initialized = True
        print("✅ OpenGL initialisiert")
    
    def _compile_shader_program(self, vertex_src: str, fragment_src: str):
        vertex_shader = shaders.compileShader(vertex_src, GL_VERTEX_SHADER)
        fragment_shader = shaders.compileShader(fragment_src, GL_FRAGMENT_SHADER)
        return shaders.compileProgram(vertex_shader, fragment_shader)
    
    def _load_texture(self) -> int:
        if self.texture_path.exists():
            img = Image.open(self.texture_path).convert('RGB')
        else:
            img = Image.new('RGB', (2048, 1024), (30, 80, 150))
        
        texture_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img.width, img.height, 0, GL_RGB, GL_UNSIGNED_BYTE, img.tobytes())
        glGenerateMipmap(GL_TEXTURE_2D)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        
        return texture_id
    
    def _setup_sphere_geometry(self):
        vertices, tex_coords, normals, indices = SphereGeometry.generate(
            radius=SPHERE_RADIUS, stacks=SPHERE_STACKS, slices=SPHERE_SLICES
        )
        
        self.sphere_index_count = len(indices)
        self.sphere_vao = glGenVertexArrays(1)
        glBindVertexArray(self.sphere_vao)
        
        vbo = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        total_size = vertices.nbytes + tex_coords.nbytes + normals.nbytes
        glBufferData(GL_ARRAY_BUFFER, total_size, None, GL_STATIC_DRAW)
        
        offset = 0
        glBufferSubData(GL_ARRAY_BUFFER, offset, vertices.nbytes, vertices)
        offset += vertices.nbytes
        glBufferSubData(GL_ARRAY_BUFFER, offset, tex_coords.nbytes, tex_coords)
        offset += tex_coords.nbytes
        glBufferSubData(GL_ARRAY_BUFFER, offset, normals.nbytes, normals)
        
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(0))
        glEnableVertexAttribArray(0)
        
        offset = vertices.nbytes
        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(offset))
        glEnableVertexAttribArray(1)
        
        offset += tex_coords.nbytes
        glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(offset))
        glEnableVertexAttribArray(2)
        
        ibo = glGenBuffers(1)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.nbytes, indices, GL_STATIC_DRAW)
    
    def render_earth(self, mvp: np.ndarray, model: np.ndarray):
        glUseProgram(self.earth_shader)
        
        mvp_loc = glGetUniformLocation(self.earth_shader, "mvp")
        glUniformMatrix4fv(mvp_loc, 1, GL_TRUE, mvp)
        
        model_loc = glGetUniformLocation(self.earth_shader, "model")
        glUniformMatrix4fv(model_loc, 1, GL_TRUE, model)
        
        light_loc = glGetUniformLocation(self.earth_shader, "lightPos")
        glUniform3f(light_loc, 5.0, 3.0, 5.0)
        
        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_2D, self.texture_id)
        
        glBindVertexArray(self.sphere_vao)
        glDrawElements(GL_TRIANGLES, self.sphere_index_count, GL_UNSIGNED_INT, None)
    
    def render_markers(self, mvp: np.ndarray, search_markers: List[GeoLocation],
                      target_marker: Optional[GeoLocation] = None,
                      traceroute_markers: List[GeoLocation] = None):
        glDepthFunc(GL_LEQUAL)
        glUseProgram(self.marker_shader)
        
        mvp_loc = glGetUniformLocation(self.marker_shader, "mvp")
        glUniformMatrix4fv(mvp_loc, 1, GL_TRUE, mvp)
        
        if search_markers:
            self._draw_marker_batch(search_markers, MARKER_COLOR_SEARCH, MARKER_SIZE_SEARCH)
        
        if traceroute_markers:
            self._draw_marker_batch(traceroute_markers, MARKER_COLOR_TRACEROUTE, MARKER_SIZE_TRACEROUTE)
        
        if target_marker:
            self._draw_marker_batch([target_marker], MARKER_COLOR_TARGET, MARKER_SIZE_TARGET)
        
        glDepthFunc(GL_LESS)
    
    def _draw_marker_batch(self, locations: List[GeoLocation], color: Tuple[float, float, float], size: float):
        if not locations:
            return
        
        radius = SPHERE_RADIUS + MARKER_OFFSET
        positions = np.array([loc.to_cartesian(radius) for loc in locations], dtype=np.float32)
        
        vao = glGenVertexArrays(1)
        glBindVertexArray(vao)
        
        vbo = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, positions.nbytes, positions, GL_STREAM_DRAW)
        
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
        glEnableVertexAttribArray(0)
        
        color_loc = glGetUniformLocation(self.marker_shader, "markerColor")
        glUniform3f(color_loc, *color)
        
        size_loc = glGetUniformLocation(self.marker_shader, "pointSize")
        glUniform1f(size_loc, size)
        
        glDrawArrays(GL_POINTS, 0, len(positions))
        
        glBindVertexArray(0)
        glDeleteBuffers(1, [vbo])
        glDeleteVertexArrays(1, [vao])
    
    def render_line(self, mvp: np.ndarray, points: List[GeoLocation],
                   color: Tuple[float, float, float] = (1.0, 1.0, 1.0), alpha: float = 0.6):
        if len(points) < 2:
            return
        
        glUseProgram(self.line_shader)
        
        mvp_loc = glGetUniformLocation(self.line_shader, "mvp")
        glUniformMatrix4fv(mvp_loc, 1, GL_TRUE, mvp)
        
        radius = SPHERE_RADIUS + MARKER_OFFSET * 1.5
        positions = np.array([loc.to_cartesian(radius) for loc in points], dtype=np.float32)
        
        vao = glGenVertexArrays(1)
        glBindVertexArray(vao)
        
        vbo = glGenBuffers(1)
        glBindBuffer(GL_ARRAY_BUFFER, vbo)
        glBufferData(GL_ARRAY_BUFFER, positions.nbytes, positions, GL_STREAM_DRAW)
        
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
        glEnableVertexAttribArray(0)
        
        color_loc = glGetUniformLocation(self.line_shader, "lineColor")
        glUniform3f(color_loc, *color)
        
        alpha_loc = glGetUniformLocation(self.line_shader, "alpha")
        glUniform1f(alpha_loc, alpha)
        
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glLineWidth(3.0)
        
        glDrawArrays(GL_LINE_STRIP, 0, len(positions))
        
        glDisable(GL_BLEND)
        glBindVertexArray(0)
        glDeleteBuffers(1, [vbo])
        glDeleteVertexArrays(1, [vao])
'''

with open(BASE_DIR / "src" / "rendering" / "gl_renderer.py", "w", encoding="utf-8") as f:
    f.write(GL_RENDERER_PY)
print("   ✅ gl_renderer.py")

print("\n📝 Schreibe Network-Module...")

# --- src/network/traceroute.py ---
TRACEROUTE_PY = '''#!/usr/bin/env python3
"""
Traceroute-Funktionalität
"""
import subprocess
import re
import platform
from typing import List, Optional
from core.geo_location import GeoLocation
from data.geo_manager import GeoDataManager

class TracerouteHop:
    """Ein Hop im Traceroute"""
    def __init__(self, hop_num: int, ip: str, hostname: str, rtt: float):
        self.hop_num = hop_num
        self.ip = ip
        self.hostname = hostname
        self.rtt = rtt
        self.location: Optional[GeoLocation] = None

class Traceroute:
    """Führt Traceroute aus und lokalisiert Hops"""
    
    def __init__(self, geo_manager: GeoDataManager):
        self.geo_manager = geo_manager
        self.is_windows = platform.system() == "Windows"
    
    def trace(self, target: str, max_hops: int = 30) -> List[TracerouteHop]:
        """Führt Traceroute aus"""
        hops = []
        
        try:
            if self.is_windows:
                cmd = ["tracert", "-h", str(max_hops), "-w", "2000", target]
            else:
                cmd = ["traceroute", "-m", str(max_hops), "-w", "2", target]
            
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            for line in process.stdout:
                hop = self._parse_line(line)
                if hop:
                    hop.location = self.geo_manager.lookup_ip(hop.ip)
                    hops.append(hop)
                    yield hop
            
            process.wait()
            
        except Exception as e:
            print(f"❌ Traceroute-Fehler: {e}")
        
        return hops
    
    def _parse_line(self, line: str) -> Optional[TracerouteHop]:
        """Parsed eine Zeile der Traceroute-Ausgabe"""
        line = line.strip()
        
        if self.is_windows:
            match = re.match(r'\\s*(\\d+)\\s+([\\d\\s*]+ms)\\s+([\\d\\s*]+ms)\\s+([\\d\\s*]+ms)\\s+(\\S+)', line)
            if match:
                hop_num = int(match.group(1))
                rtt_str = match.group(4).replace('ms', '').strip()
                try:
                    rtt = float(rtt_str) if rtt_str != '*' else 0.0
                except:
                    rtt = 0.0
                
                target = match.group(5)
                
                ip_match = re.search(r'\\[(\\d+\\.\\d+\\.\\d+\\.\\d+)\\]', target)
                if ip_match:
                    ip = ip_match.group(1)
                    hostname = target.split('[')[0].strip()
                else:
                    ip = target
                    hostname = target
                
                return TracerouteHop(hop_num, ip, hostname, rtt)
        else:
            match = re.match(r'\\s*(\\d+)\\s+(\\S+)\\s+\\((\\d+\\.\\d+\\.\\d+\\.\\d+)\\)\\s+([\\d.]+)\\s*ms', line)
            if match:
                hop_num = int(match.group(1))
                hostname = match.group(2)
                ip = match.group(3)
                rtt = float(match.group(4))
                
                return TracerouteHop(hop_num, ip, hostname, rtt)
        
        return None
'''

with open(BASE_DIR / "src" / "network" / "traceroute.py", "w", encoding="utf-8") as f:
    f.write(TRACEROUTE_PY)
print("   ✅ traceroute.py")

# --- src/network/ping.py ---
PING_PY = '''#!/usr/bin/env python3
"""
Ping-Funktionalität
"""
import subprocess
import re
import platform
from typing import Optional

class PingResult:
    """Ergebnis eines Pings"""
    def __init__(self, success: bool, rtt: float, ttl: int):
        self.success = success
        self.rtt = rtt
        self.ttl = ttl

class Ping:
    """Führt Ping aus"""
    
    def __init__(self):
        self.is_windows = platform.system() == "Windows"
    
    def ping(self, target: str, count: int = 4) -> list:
        """Führt Ping aus"""
        results = []
        
        try:
            if self.is_windows:
                cmd = ["ping", "-n", str(count), target]
            else:
                cmd = ["ping", "-c", str(count), target]
            
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            for line in process.stdout:
                result = self._parse_line(line)
                if result:
                    results.append(result)
                    yield result
            
            process.wait()
            
        except Exception as e:
            print(f"❌ Ping-Fehler: {e}")
        
        return results
    
    def _parse_line(self, line: str) -> Optional[PingResult]:
        """Parsed Ping-Ausgabe"""
        if self.is_windows:
            match = re.search(r'time[=<](\\d+)ms.*TTL=(\\d+)', line, re.IGNORECASE)
            if match:
                rtt = float(match.group(1))
                ttl = int(match.group(2))
                return PingResult(True, rtt, ttl)
        else:
            match = re.search(r'time=([\\d.]+)\\s*ms.*ttl=(\\d+)', line, re.IGNORECASE)
            if match:
                rtt = float(match.group(1))
                ttl = int(match.group(2))
                return PingResult(True, rtt, ttl)
        
        return None
'''

with open(BASE_DIR / "src" / "network" / "ping.py", "w", encoding="utf-8") as f:
    f.write(PING_PY)
print("   ✅ ping.py")

# --- src/network/whois_lookup.py ---
WHOIS_PY = '''#!/usr/bin/env python3
"""
WHOIS-Lookup
"""
import socket

class WhoisLookup:
    """WHOIS-Abfragen"""
    
    def lookup(self, ip: str) -> str:
        """Führt WHOIS-Lookup aus"""
        try:
            whois_server = "whois.iana.org"
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect((whois_server, 43))
            sock.send(f"{ip}\\r\\n".encode())
            
            response = b""
            while True:
                data = sock.recv(4096)
                if not data:
                    break
                response += data
            
            sock.close()
            
            return response.decode('utf-8', errors='ignore')
            
        except Exception as e:
            return f"❌ WHOIS-Fehler: {e}"
'''

with open(BASE_DIR / "src" / "network" / "whois_lookup.py", "w", encoding="utf-8") as f:
    f.write(WHOIS_PY)
print("   ✅ whois_lookup.py")

print("\n✅ Network-Module geschrieben!\n")

# ENDE TEIL 3
# Fortsetzung in Teil 4...
# ============================================================================
# TEIL 4/4: UI WIDGETS & HAUPTPROGRAMM
# Füge diesen Teil direkt nach Teil 3 ein
# ============================================================================

print("📝 Schreibe UI-Module...")

# --- src/ui/widgets/globe_widget.py ---
GLOBE_WIDGET_PY = '''#!/usr/bin/env python3
"""
Globe Widget - 3D-OpenGL-Widget
"""
import numpy as np
from PyQt6 import QtCore
from PyQt6.QtOpenGLWidgets import QOpenGLWidget
from OpenGL.GL import *
from typing import List, Optional

from core.geo_location import GeoLocation
from core.config import (
    CAMERA_DISTANCE, CAMERA_FOV, CAMERA_NEAR, CAMERA_FAR,
    CAMERA_MIN_DISTANCE, CAMERA_MAX_DISTANCE, ROTATION_SENSITIVITY, ZOOM_FACTOR, EARTH_TEXTURE
)
from rendering.gl_renderer import GLRenderer
from utils.matrix_utils import create_rotation_matrix, create_projection_matrix, create_view_matrix

class GlobeWidget(QOpenGLWidget):
    """3D-Globus Widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        
        self.renderer = GLRenderer(EARTH_TEXTURE)
        self.rotation_matrix = create_rotation_matrix(90.0, np.array([1, 0, 0]))
        self.camera_distance = CAMERA_DISTANCE
        
        self.last_mouse_pos = None
        self.auto_rotate = False
        
        self.search_markers: List[GeoLocation] = []
        self.target_marker: Optional[GeoLocation] = None
        self.traceroute_markers: List[GeoLocation] = []
        self.show_markers = True
        
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._on_timer)
        self.timer.start(16)
    
    def _on_timer(self):
        if self.auto_rotate:
            self.rotate(-0.3, np.array([0, 1, 0]))
    
    def initializeGL(self):
        self.renderer.initialize()
    
    def resizeGL(self, w: int, h: int):
        glViewport(0, 0, w, h)
    
    def paintGL(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        projection, view, model = self._get_matrices()
        mvp = projection @ view @ model
        
        self.renderer.render_earth(mvp, model)
        
        if self.show_markers:
            self.renderer.render_markers(mvp, self.search_markers, 
                                        self.target_marker, self.traceroute_markers)
    
    def _get_matrices(self):
        aspect = self.width() / max(1.0, self.height())
        projection = create_projection_matrix(CAMERA_FOV, aspect, CAMERA_NEAR, CAMERA_FAR)
        view = create_view_matrix(self.camera_distance)
        model = self.rotation_matrix
        return projection, view, model
    
    def navigate_to(self, location: GeoLocation):
        self.target_marker = location
        self._align_to_location(location.lat, location.lon)
        self.update()
    
    def _align_to_location(self, lat: float, lon: float):
        base = create_rotation_matrix(90.0, np.array([1, 0, 0]))
        rot_y = create_rotation_matrix(-lon, np.array([0, 1, 0]))
        rot_x = create_rotation_matrix(lat - 90.0, np.array([1, 0, 0]))
        self.rotation_matrix = rot_x @ rot_y @ base
    
    def set_search_results(self, locations: List[GeoLocation]):
        self.search_markers = locations
        if locations:
            self.navigate_to(locations[0])
        else:
            self.update()
    
    def clear_markers(self):
        self.search_markers = []
        self.target_marker = None
        self.traceroute_markers = []
        self.update()
    
    def rotate(self, angle: float, axis: np.ndarray):
        rotation = create_rotation_matrix(angle, axis)
        self.rotation_matrix = rotation @ self.rotation_matrix
        self.update()
    
    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.last_mouse_pos = event.position()
    
    def mouseMoveEvent(self, event):
        if self.last_mouse_pos and (event.buttons() & QtCore.Qt.MouseButton.LeftButton):
            delta_x = event.position().x() - self.last_mouse_pos.x()
            delta_y = event.position().y() - self.last_mouse_pos.y()
            
            rot_y = create_rotation_matrix(delta_x * ROTATION_SENSITIVITY, np.array([0, 1, 0]))
            rot_x = create_rotation_matrix(delta_y * ROTATION_SENSITIVITY, np.array([1, 0, 0]))
            
            self.rotation_matrix = rot_x @ rot_y @ self.rotation_matrix
            self.update()
        
        self.last_mouse_pos = event.position()
    
    def mouseReleaseEvent(self, event):
        self.last_mouse_pos = None
    
    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        factor = ZOOM_FACTOR if delta > 0 else 1.0 / ZOOM_FACTOR
        
        self.camera_distance *= factor
        self.camera_distance = max(CAMERA_MIN_DISTANCE, min(CAMERA_MAX_DISTANCE, self.camera_distance))
        self.update()
'''

with open(BASE_DIR / "src" / "ui" / "widgets" / "globe_widget.py", "w", encoding="utf-8") as f:
    f.write(GLOBE_WIDGET_PY)
print("   ✅ globe_widget.py")

# --- src/ui/widgets/sidebar.py ---
SIDEBAR_PY = '''#!/usr/bin/env python3
"""
Sidebar Widget
"""
from PyQt6 import QtWidgets, QtCore
from core.config import COLOR_SURFACE, COLOR_BORDER, COLOR_TEXT

class Sidebar(QtWidgets.QWidget):
    """Rechte Sidebar"""
    
    search_requested = QtCore.pyqtSignal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumWidth(350)
        self.setMaximumWidth(500)
        self.setStyleSheet(f"background: {COLOR_SURFACE}; color: {COLOR_TEXT};")
        
        self._setup_ui()
    
    def _setup_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        
        header = QtWidgets.QLabel("🌍 EarthViewer")
        header.setStyleSheet("font-size: 24px; font-weight: bold; color: #0d7377;")
        layout.addWidget(header)
        
        self.search_input = QtWidgets.QLineEdit()
        self.search_input.setPlaceholderText("Stadt, IP, Koordinaten...")
        self.search_input.returnPressed.connect(self._on_search)
        layout.addWidget(self.search_input)
        
        search_btn = QtWidgets.QPushButton("🔍 Suchen")
        search_btn.clicked.connect(self._on_search)
        layout.addWidget(search_btn)
        
        self.result_list = QtWidgets.QListWidget()
        layout.addWidget(self.result_list)
        
        layout.addStretch()
    
    def _on_search(self):
        query = self.search_input.text().strip()
        if query:
            self.search_requested.emit(query)
    
    def update_results(self, locations):
        self.result_list.clear()
        for loc in locations:
            item = QtWidgets.QListWidgetItem(f"{loc.name} ({loc.lat:.2f}, {loc.lon:.2f})")
            item.setData(QtCore.Qt.ItemDataRole.UserRole, loc)
            self.result_list.addItem(item)
'''

with open(BASE_DIR / "src" / "ui" / "widgets" / "sidebar.py", "w", encoding="utf-8") as f:
    f.write(SIDEBAR_PY)
print("   ✅ sidebar.py")

# --- src/ui/widgets/main_window.py ---
MAIN_WINDOW_PY = '''#!/usr/bin/env python3
"""
Main Window
"""
from PyQt6 import QtWidgets, QtGui
from ui.widgets.globe_widget import GlobeWidget
from ui.widgets.sidebar import Sidebar
from data.geo_manager import GeoDataManager
from core.config import WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT

class MainWindow(QtWidgets.QMainWindow):
    """Hauptfenster"""
    
    def __init__(self):
        super().__init__()
        self.resize(WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setMinimumSize(WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT)
        
        self.geo_manager = GeoDataManager()
        
        self._setup_ui()
        self._apply_theme()
    
    def _setup_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        
        layout = QtWidgets.QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        
        self.globe = GlobeWidget(self)
        layout.addWidget(self.globe, 7)
        
        self.sidebar = Sidebar(self)
        self.sidebar.search_requested.connect(self._on_search)
        self.sidebar.result_list.itemDoubleClicked.connect(self._on_result_clicked)
        layout.addWidget(self.sidebar, 3)
    
    def _apply_theme(self):
        palette = QtGui.QPalette()
        palette.setColor(QtGui.QPalette.ColorRole.Window, QtGui.QColor(43, 43, 43))
        palette.setColor(QtGui.QPalette.ColorRole.WindowText, QtGui.QColor(255, 255, 255))
        self.setPalette(palette)
    
    def _on_search(self, query: str):
        results = self.geo_manager.search(query)
        self.sidebar.update_results(results)
        self.globe.set_search_results(results)
    
    def _on_result_clicked(self, item):
        location = item.data(QtCore.Qt.ItemDataRole.UserRole)
        if location:
            self.globe.navigate_to(location)
'''

with open(BASE_DIR / "src" / "ui" / "widgets" / "main_window.py", "w", encoding="utf-8") as f:
    f.write(MAIN_WINDOW_PY)
print("   ✅ main_window.py")

print("\n📝 Schreibe Hauptdateien...")

# --- main.py ---
MAIN_PY = '''#!/usr/bin/env python3
"""
EarthViewer 2.0 - Haupteinstiegspunkt
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from PyQt6 import QtWidgets, QtGui, QtCore
from ui.widgets.main_window import MainWindow
from core.config import WINDOW_TITLE

def main():
    """Hauptfunktion"""
    print("=" * 60)
    print("🌍 EarthViewer 2.0 - Modular Edition")
    print("=" * 60)
    
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    
    palette = QtGui.QPalette()
    palette.setColor(QtGui.QPalette.ColorRole.Window, QtGui.QColor(43, 43, 43))
    palette.setColor(QtGui.QPalette.ColorRole.WindowText, QtCore.Qt.GlobalColor.white)
    palette.setColor(QtGui.QPalette.ColorRole.Base, QtGui.QColor(30, 30, 30))
    palette.setColor(QtGui.QPalette.ColorRole.Text, QtCore.Qt.GlobalColor.white)
    palette.setColor(QtGui.QPalette.ColorRole.Button, QtGui.QColor(43, 43, 43))
    palette.setColor(QtGui.QPalette.ColorRole.ButtonText, QtCore.Qt.GlobalColor.white)
    palette.setColor(QtGui.QPalette.ColorRole.Highlight, QtGui.QColor(13, 115, 119))
    app.setPalette(palette)
    
    window = MainWindow()
    window.setWindowTitle(WINDOW_TITLE)
    window.show()
    
    print("✅ Anwendung gestartet")
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
'''

with open(BASE_DIR / "main.py", "w", encoding="utf-8") as f:
    f.write(MAIN_PY)
print("   ✅ main.py")

# --- requirements.txt ---
REQUIREMENTS_TXT = '''PyQt6>=6.5.0
PyQt6-Qt6>=6.5.0
PyOpenGL>=3.1.6
PyOpenGL-accelerate>=3.1.6
numpy>=1.24.0
Pillow>=10.0.0
geoip2>=4.7.0
'''

with open(BASE_DIR / "requirements.txt", "w", encoding="utf-8") as f:
    f.write(REQUIREMENTS_TXT)
print("   ✅ requirements.txt")

# --- README.md ---
README_MD = '''# EarthViewer 2.0.0

🌍 **Modulare, professionelle 3D-Erd-Visualisierung mit Netzwerk-Tools**

## Features

### 🗺️ Visualisierung
- Interaktive 3D-Erdkugel mit OpenGL
- Marker-System für Städte, IPs, Traceroute-Hops
- Echtzeit-Animation und Auto-Rotation

### 🌐 Netzwerk-Tools
- **Traceroute** mit Live-Visualisierung
- **WHOIS** IP-Informationen
- **Ping Monitor** mit Latenz-Graph
- **DNS Lookup** für Domains

### 📊 Daten
- GeoIP-Datenbank Support
- CSV-Stadt-Daten
- Export/Import von Sessions

## Installation

```bash
# Repository klonen
git clone <repo-url>
cd EarthViewer

# Virtual Environment erstellen
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# oder
venv\\Scripts\\activate  # Windows

# Dependencies installieren
pip install -r requirements.txt

# Programm starten
python main.py
```

## Ordnerstruktur

```
EarthViewer/
├── src/                  # Quellcode (modular)
│   ├── core/            # Kern-Klassen
│   ├── data/            # Daten-Management
│   ├── rendering/       # 3D-Rendering
│   ├── network/         # Netzwerk-Tools
│   ├── ui/              # User Interface
│   └── utils/           # Hilfsfunktionen
├── data/                # Daten (Geodaten, Texturen)
├── screenshots/         # Screenshots
├── logs/                # Log-Dateien
└── tests/               # Unit-Tests
```

## Verwendung

### Suche
- Städte: `berlin`, `new york`
- Mehrere Städte: `berlin leipzig koblenz`
- IP-Adressen: `8.8.8.8`
- Koordinaten: `52.52, 13.405`

### Steuerung
- **Maus ziehen**: Globus rotieren
- **Mausrad**: Zoom
- **Doppelklick**: Zu Ort navigieren

## Daten-Setup

### Geodaten
1. Erstelle `data/geodata/` Ordner
2. Lade Städte-CSV herunter (z.B. von simplemaps.com)
3. Optional: GeoLite2-City.mmdb für IP-Lokalisierung

### Textur
1. Erstelle `data/textures/` Ordner
2. Platziere `earth_map.jpg` (Equirectangular Projektion)
3. Download z.B. von NASA Visible Earth

## Lizenz

MIT License

## Credits

Erstellt mit ❤️ und Python
'''

with open(BASE_DIR / "README.md", "w", encoding="utf-8") as f:
    f.write(README_MD)
print("   ✅ README.md")

# --- __init__.py Dateien ---
for init_file in [
    "src/__init__.py",
    "src/core/__init__.py",
    "src/data/__init__.py",
    "src/rendering/__init__.py",
    "src/network/__init__.py",
    "src/ui/__init__.py",
    "src/ui/widgets/__init__.py",
    "src/utils/__init__.py",
    "tests/__init__.py"
]:
    init_path = BASE_DIR / init_file
    if not init_path.exists():
        init_path.touch()

print("\n✅ Alle __init__.py Dateien erstellt!")

# --- Test-Datei ---
TEST_GEO_LOCATION = '''#!/usr/bin/env python3
"""
Tests für GeoLocation
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from core.geo_location import GeoLocation
import numpy as np

def test_to_cartesian():
    """Test Koordinaten-Konvertierung"""
    berlin = GeoLocation("Berlin", 52.52, 13.405)
    pos = berlin.to_cartesian()
    
    assert isinstance(pos, np.ndarray)
    assert len(pos) == 3
    print(f"✅ Berlin Position: {pos}")

def test_distance():
    """Test Distanz-Berechnung"""
    berlin = GeoLocation("Berlin", 52.52, 13.405)
    paris = GeoLocation("Paris", 48.8566, 2.3522)
    
    dist = berlin.distance_to(paris)
    assert 870 < dist < 880
    print(f"✅ Berlin-Paris: {dist:.2f} km")

if __name__ == "__main__":
    test_to_cartesian()
    test_distance()
    print("\\n✅ Alle Tests bestanden!")
'''

with open(BASE_DIR / "tests" / "test_geo_location.py", "w", encoding="utf-8") as f:
    f.write(TEST_GEO_LOCATION)
print("   ✅ test_geo_location.py")

print("\n" + "=" * 70)
print("✅ INSTALLATION ABGESCHLOSSEN!")
print("=" * 70)
print("\n📋 Nächste Schritte:")
print("\n1. Installiere Dependencies:")
print("   pip install -r requirements.txt")
print("\n2. Füge Geodaten hinzu:")
print("   - Erstelle data/geodata/ Ordner")
print("   - Lade CSV-Städte-Daten herunter")
print("   - Optional: GeoLite2-City.mmdb")
print("\n3. Füge Erdtextur hinzu:")
print("   - Erstelle data/textures/ Ordner")
print("   - Platziere earth_map.jpg")
print("\n4. Starte die Anwendung:")
print("   python main.py")
print("\n5. Führe Tests aus:")
print("   python tests/test_geo_location.py")
print("\n" + "=" * 70)
print("🌍 Viel Erfolg mit EarthViewer 2.0!")
print("=" * 70)

# ENDE TEIL 4/4 - INSTALLATION KOMPLETT!

