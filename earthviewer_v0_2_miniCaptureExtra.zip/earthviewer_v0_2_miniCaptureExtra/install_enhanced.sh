#!/bin/bash
#
# EarthViewer 2.0 Enhanced Installation
# Mit Root-Helper für WiFi-Monitor
#

echo "╔════════════════════════════════════════╗"
echo "║   EarthViewer 2.0 Enhanced Installer   ║"
echo "╚════════════════════════════════════════╝"
echo ""

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
   echo "✅ Running as root - full features available"
else
   echo "⚠️  Not running as root - some features limited"
   echo "   For full functionality run: sudo $0"
fi

# Python Virtual Environment
echo "📦 Setting up Python environment..."
if [ ! -d "myenv" ]; then
    python3 -m venv myenv
fi
source myenv/bin/activate

# Install dependencies
echo "📦 Installing Python packages..."
pip install --upgrade pip
pip install -r requirements_fixed.txt

# System packages (needs root)
if [ "$EUID" -eq 0 ]; then
    echo "📦 Installing system packages..."
    apt-get update
    apt-get install -y \
        aircrack-ng \
        tshark \
        wireshark \
        wireless-tools \
        net-tools \
        nmap \
        arp-scan \
        iw \
        tcpdump
    
    # Configure tshark for non-root
    echo "🔧 Configuring tshark..."
    chmod +x /usr/bin/dumpcap
    setcap cap_net_raw,cap_net_admin=eip /usr/bin/dumpcap
    
    # Add user to wireshark group
    usermod -a -G wireshark $SUDO_USER 2>/dev/null
else
    echo "⚠️  Skipping system packages (needs root)"
fi

echo ""
echo "✅ Installation complete!"
echo ""
echo "To run EarthViewer:"
echo "  1. Normal mode:  source myenv/bin/activate && python main.py"
echo "  2. Root mode:    sudo -E myenv/bin/python main.py"
echo ""
echo "For WiFi monitoring features, run with sudo!"
echo ""
