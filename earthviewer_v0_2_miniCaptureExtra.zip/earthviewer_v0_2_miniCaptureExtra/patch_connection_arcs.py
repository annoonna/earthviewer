#!/usr/bin/env python3
# Patch-Skript: macht aus den geraden Live-Verbindungs-Linien gekrümmte Bögen.
# Ausführen im Projekt-Root:  python patch_connection_arcs.py
from pathlib import Path
import re
import textwrap

TARGET = Path("src/ui/widgets/globe_widget.py")

if not TARGET.exists():
    raise SystemExit("Datei src/ui/widgets/globe_widget.py wurde nicht gefunden (bitte im Projekt-Root ausführen).")

code = TARGET.read_text(encoding="utf-8")

# 1) Sicherstellen, dass numpy importiert wird
if "import numpy as np" not in code:
    m = re.search(r"^import .*", code, re.MULTILINE)
    if m:
        insert_pos = m.start()
        code = code[:insert_pos] + "import numpy as np\n" + code[insert_pos:]

# 2) Helper-Methode _create_arc_points einfügen (falls noch nicht vorhanden)
if "_create_arc_points" not in code:
    pattern = r"^(\s*)def _render_connection_lines\("
    m = re.search(pattern, code, re.MULTILINE)
    if not m:
        raise SystemExit("Fehler: def _render_connection_lines(...) nicht gefunden.")
    insert_indent = m.group(1)
    insert_pos = m.start()

    helper = textwrap.dedent("""\
        def _create_arc_points(self, start_geo, end_geo, num_segments: int = 64,
                               height_factor: float = 0.15) -> np.ndarray:
            \"\"\"Erzeugt eine gekrümmte Verbindung (Great-Circle-Arc) zwischen zwei GeoLocation-Punkten.\"\"\"
            from core import config

            base_radius = config.SPHERE_RADIUS + getattr(config, "MARKER_OFFSET", 0.02) * 1.5

            s = np.array(start_geo.to_cartesian(base_radius), dtype=np.float64)
            e = np.array(end_geo.to_cartesian(base_radius), dtype=np.float64)

            s_n = s / np.linalg.norm(s)
            e_n = e / np.linalg.norm(e)

            dot = float(np.clip(np.dot(s_n, e_n), -1.0, 1.0))
            if dot > 0.9999:
                return np.array([s, e], dtype=np.float32)

            omega = np.arccos(dot)
            sin_omega = np.sin(omega)

            points = []
            for i in range(num_segments + 1):
                t = i / num_segments
                factor_s = np.sin((1.0 - t) * omega) / sin_omega
                factor_e = np.sin(t * omega) / sin_omega
                p = factor_s * s_n + factor_e * e_n

                lift = np.sin(np.pi * t) * height_factor
                p = p * (1.0 + lift)

                points.append(p * base_radius)

            return np.array(points, dtype=np.float32)
    """)
    helper = "\n" + "\n".join(
        insert_indent + line if line.strip() else insert_indent
        for line in helper.splitlines()
    ) + "\n\n"
    code = code[:insert_pos] + helper + code[insert_pos:]

# 3) _render_connection_lines durch Bogen-Variante ersetzen
def repl(match):
    indent = match.group(1)
    body = textwrap.dedent("""\
        def _render_connection_lines(self, mvp):
            \"\"\"Rendert Live-Verbindungen als gekrümmte Bögen über der Erdoberfläche.\"\"\"
            if not self.connection_lines:
                return

            self.animation_offset = (time.time() * self.animation_speed * 0.5) % 1.0

            glEnable(GL_BLEND)
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

            for line in self.connection_lines:
                start_geo = line["start"]
                end_geo = line["end"]

                arc_points = self._create_arc_points(
                    start_geo,
                    end_geo,
                    num_segments=72,
                    height_factor=0.18
                )

                self.renderer.render_line(
                    mvp,
                    arc_points,
                    color=line.get("color", (0.3, 0.65, 1.0))
                )

            glDisable(GL_BLEND)
    """)
    return "\n".join(
        indent + line if line.strip() else indent
        for line in body.splitlines()
    )

code, n = re.subn(
    r"^(\s*)def _render_connection_lines\([\s\S]*?^\s*glDisable\(GL_BLEND\)\s*$",
    repl,
    code,
    flags=re.MULTILINE,
)

if n == 0:
    raise SystemExit("Fehler: _render_connection_lines konnte nicht ersetzt werden.")

# 4) Backup anlegen und Datei schreiben
backup = TARGET.with_suffix(".py.backup_connection_lines")
backup.write_text(TARGET.read_text(encoding="utf-8"), encoding="utf-8")
TARGET.write_text(code, encoding="utf-8")

print("Patch erfolgreich. Backup gespeichert als", backup)
