# CHANGELOG - EarthViewer 2.0

## Version 0.2 (13. November 2025)

### 🎉 Neue Features

#### Live Verbindungen System
- **Neues Tab**: "🔴 Live Verbindungen" in der Sidebar
- **Connection Tracker**: Echtzeit-Erfassung aller aktiven Netzwerkverbindungen
- **Animierte Visualisierung**: Pulsierende Linien auf dem 3D-Globus
- **Farbcodierung**:
  - Blau (#4da6ff): Incoming Connections
  - Grün (#4dff88): Outgoing Connections

#### Animation System
- Smooth spherical interpolation für natürliche Bögen
- Einstellbare Animations-Geschwindigkeit (1-10)
- Puls-Effekt entlang der Verbindungslinien
- Optimierte Performance für viele Verbindungen

#### Filter & Kontrollen
- Toggle Incoming/Outgoing Verbindungen
- Echtzeit-Statistiken:
  - Gesamt-Verbindungen
  - Incoming Counter
  - Outgoing Counter
- Interaktive Verbindungsliste mit Details
- Navigation zu Verbindungen per Klick

#### Port-Scanner Erweiterung
- Port-Bereich erweitert: 1-65535 (vorher 1-1024)
- Default Wert auf 65535 gesetzt

### 🛠️ Technische Änderungen

#### Neue Module
- `src/network/connection_tracker.py`: Connection Tracking System
  - ConnectionTracker-Klasse
  - Connection Dataclass
  - Thread-basiertes Monitoring
  - GeoIP-Integration

- `src/ui/widgets/live_connections_tab.py`: Live Connections UI
  - Tracking Start/Stop
  - Filter-Controls
  - Animations-Speed Slider
  - Connection List Widget
  - Statistics Display

#### Erweiterte Module
- `src/ui/widgets/globe_widget.py`:
  - `update_connections()`: Verarbeitet Connection-Daten
  - `_render_connection_lines()`: Rendert animierte Linien
  - `set_connection_filters()`: Filter-Steuerung
  - `set_animation_speed()`: Animation-Geschwindigkeit
  - `clear_connection_lines()`: Linien löschen
  - Neue Instanzvariablen für Connection-System

- `src/ui/widgets/sidebar.py`:
  - Integration des Live Connections Tab
  - ConnectionTracker Initialisierung

- `src/ui/widgets/network_scanner_tab.py`:
  - Port-Range auf 65535 erweitert

### 🐛 Bugfixes
- Import-Fehler in globe_widget.py behoben
- Syntax-Fehler in connection_tracker.py korrigiert
- Thread-Safety verbessert

### 📊 Performance
- Optimierte Render-Performance für viele Verbindungen
- Effizienteres Connection-Tracking
- Reduzierter Memory-Overhead

## Version 0.1 (November 2025)

### Initial Release

#### Core Features
- 3D OpenGL Globe mit Earth-Textur
- Interaktive Navigation (Maus, Zoom, Auto-Rotation)
- Intelligente Suche (Städte, IPs, Koordinaten)
- Favoriten-System

#### Netzwerk-Tools
- Traceroute-Visualisierung
- Port Scanner (1-1024)
- Network Monitoring
- Firewall/Protection Tab
- Traffic Graphen
- Protocol Analysis

#### UI Features
- Theme-System (Cyberpunk, Matrix, Neon, Classic)
- Intelligente Label-Positionierung
- Screenshot-Funktion
- Modulare Tab-Struktur

#### Technical
- Modulare Architektur
- PyQt6 + OpenGL
- GeoIP2-Integration
- Multi-Threading Support

---

**Maintained by**: Anno Onna
**Last Updated**: 13. November 2025
