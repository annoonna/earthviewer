#!/bin/bash
# EarthViewer 2.0 - Start-Script mit Backend-Optionen

echo "╔══════════════════════════════════════════════════════╗"
echo "║        🌍 EarthViewer 2.0 Launcher                  ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Aktiviere Virtual Environment falls vorhanden
if [ -d "venv" ]; then
    echo "📦 Aktiviere Virtual Environment..."
    source venv/bin/activate
fi

# Zeige Optionen
echo "Wähle Backend:"
echo "  1) X11 (empfohlen für Wayland-Systeme) [Standard]"
echo "  2) Wayland (experimental)"
echo "  3) Auto (System entscheidet)"
echo ""
read -p "Auswahl (1-3) [1]: " choice
choice=${choice:-1}

case $choice in
    1)
        echo "✅ Starte mit X11-Backend..."
        export QT_QPA_PLATFORM=xcb
        ;;
    2)
        echo "⚠️  Starte mit Wayland-Backend (experimental)..."
        export QT_QPA_PLATFORM=wayland
        ;;
    3)
        echo "🔄 Starte mit Auto-Erkennung..."
        unset QT_QPA_PLATFORM
        ;;
    *)
        echo "❌ Ungültige Auswahl, verwende Standard (X11)"
        export QT_QPA_PLATFORM=xcb
        ;;
esac

echo ""
echo "🚀 Starte EarthViewer..."
echo "════════════════════════════════════════════════════════"
echo ""

# Programm starten
python3 main.py

# Exit code ausgeben
exit_code=$?
echo ""
echo "════════════════════════════════════════════════════════"
if [ $exit_code -eq 0 ]; then
    echo "✅ EarthViewer wurde sauber beendet"
else
    echo "❌ EarthViewer mit Fehlercode beendet: $exit_code"
fi
