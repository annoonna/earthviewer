# Geodaten (Download-Ordner)

Hier hinein kommen die **heruntergeladenen Archive**, so wie im Original:

```
Geodaten/
├── GeoLite2-City_20251017/          <- enthaelt GeoLite2-City.mmdb
├── GeoLite2-City-CSV_20251017/
├── GeoLite2-Country_20251017/
├── GeoLite2-ASN_20251020/
├── simplemaps_worldcities_basicv1.77.zip
└── all datas/
```

**Das Programm liest diesen Ordner nicht.** Er ist reines Zwischenlager —
im Original war das genauso, dort enthielt er im ausgelieferten Archiv sogar
nur leere Verzeichnisse.

Gelesen wird ausschliesslich `data/geodata/`. Der Weg dorthin:

```bash
./geodaten_einrichten.sh              # sucht Geodaten/ selbst
./geodaten_einrichten.sh /pfad/Geodaten
./geodaten_einrichten.sh --pruefen    # erst zeigen, was gefunden wird
```

Das Skript holt die `GeoLite2-City.mmdb` nach `data/geodata/` und legt bei
Bedarf die Laenderordner an.
