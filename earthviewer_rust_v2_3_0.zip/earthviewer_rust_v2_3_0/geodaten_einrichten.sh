#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Legt GeoLite2-Datenbanken und Städtelisten dort ab, wo das Programm sucht.
#
# Hintergrund: das Python-Original liest ausschliesslich  data/geodata/.
# Der Ordner "Geodaten" (grosses G) im Original-Archiv war nur der private
# Download-Ordner und wurde vom Programm nie gelesen — er enthielt im
# ausgelieferten ZIP auch nur leere Verzeichnisse.
#
#   ./geodaten_einrichten.sh                 sucht selbst nach Geodaten/
#   ./geodaten_einrichten.sh /pfad/Geodaten  Quelle direkt angeben
#   ./geodaten_einrichten.sh --pruefen       nur zeigen, was gefunden wird
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ZIEL="$ROOT/data/geodata"

NURPRUEFEN=0
QUELLE=""
for a in "$@"; do
    case "$a" in
        --pruefen|-n) NURPRUEFEN=1 ;;
        --help|-h) sed -n '2,14p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) QUELLE="$a" ;;
    esac
done

echo "╔══════════════════════════════════════════════════════╗"
echo "║        Geodaten einrichten                           ║"
echo "╚══════════════════════════════════════════════════════╝"
echo "Ziel: $ZIEL"
echo ""

# ── Quelle finden ───────────────────────────────────────────────────────────
if [ -z "$QUELLE" ]; then
    for k in "$ROOT/Geodaten" "$ROOT/../Geodaten" "$HOME/Geodaten" \
             "$HOME/Videos"/*/Geodaten "$HOME/Downloads/Geodaten"; do
        [ -d "$k" ] && QUELLE="$k" && break
    done
fi
if [ -z "$QUELLE" ] || [ ! -d "$QUELLE" ]; then
    echo "❌ Kein Geodaten-Ordner gefunden."
    echo "   Pfad angeben:  ./geodaten_einrichten.sh /pfad/zu/Geodaten"
    exit 1
fi
echo "Quelle: $QUELLE"
echo ""

mkdir -p "$ZIEL"
kopiert=0

# ── MMDB: nur City wird ausgewertet ─────────────────────────────────────────
echo "── GeoIP-Datenbanken ──"
while IFS= read -r -d '' f; do
    name="$(basename "$f")"
    klein="$(echo "$name" | tr 'A-Z' 'a-z')"
    if [[ "$klein" == *city* ]]; then
        echo "  ✅ $name  → wird ausgewertet"
        [ "$NURPRUEFEN" -eq 0 ] && cp "$f" "$ZIEL/$name" && kopiert=$((kopiert+1))
    else
        echo "  ⏭  $name  → ignoriert (Original nimmt nur *city*)"
    fi
done < <(find "$QUELLE" -type f -name '*.mmdb' -print0 2>/dev/null)

if ! find "$QUELLE" -type f -name '*.mmdb' 2>/dev/null | grep -q .; then
    echo "  (keine .mmdb gefunden)"
fi

# ── Städte-CSV ──────────────────────────────────────────────────────────────
echo ""
echo "── Städtelisten ──"
while IFS= read -r -d '' f; do
    name="$(basename "$f")"
    land="$(basename "$(dirname "$f")")"
    echo "  ✅ $land/$name"
    if [ "$NURPRUEFEN" -eq 0 ]; then
        mkdir -p "$ZIEL/$land"
        cp "$f" "$ZIEL/$land/$name" && kopiert=$((kopiert+1))
    fi
done < <(find "$QUELLE" -type f -name '*.csv' ! -name '*Blocks*' ! -name '*Locations*' -print0 2>/dev/null)

echo ""
if [ "$NURPRUEFEN" -eq 1 ]; then
    echo "ℹ️  Nur geprüft, nichts kopiert (--pruefen)."
else
    echo "✅ $kopiert Datei(en) nach data/geodata/ gelegt."
    echo "   Danach: ./start.sh — das Startprotokoll nennt, was geladen wurde."
fi

# ── Laenderordner anlegen ───────────────────────────────────────────────────
# Das Original hatte 242 Ordner unter data/geodata/. Quelle ist die
# mitgelieferte worldcities.xlsx bzw. das simplemaps-Archiv aus Geodaten/.
if [ "$NURPRUEFEN" -eq 0 ]; then
    VORHANDEN=$(find "$ZIEL" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l)
    if [ "$VORHANDEN" -lt 100 ]; then
        echo ""
        echo "Nur $VORHANDEN Laenderordner vorhanden — lege die uebrigen an..."
        QUELLE_TAB=""
        for k in "$ZIEL/worldcities.xlsx" "$QUELLE"/simplemaps_worldcities*.zip; do
            [ -f "$k" ] && QUELLE_TAB="$k" && break
        done
        if [ -n "$QUELLE_TAB" ]; then
            "$ROOT/werkzeug/staedte_erzeugen.py" --quelle "$QUELLE_TAB"
        else
            echo "⚠️  Keine worldcities-Tabelle gefunden — uebersprungen."
        fi
    else
        echo ""
        echo "✅ $VORHANDEN Laenderordner bereits vorhanden"
    fi
fi
