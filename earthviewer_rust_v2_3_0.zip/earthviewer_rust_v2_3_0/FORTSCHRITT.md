# FORTSCHRITT — EarthViewer 2.x Erweiterungen (GlasWire + VisualTraceroute)

*Lebendes Arbeitsdokument. Für den nächsten Chat: hier steht, was fertig ist,
was gerade läuft und was als Nächstes drankommt. Ehrlich, gemessen, ohne
Schönfärberei.*

Letzte Aktualisierung: Beginn Runde C.

---

## Kontext in einem Absatz

Anno (Leipzig, Kali Linux) hat die 1:1-Rust-Portierung von EarthViewer 2.0
(v2.1.0, SatMonitor PRO inklusive) abgenommen und will das Programm jetzt
**erweitern**: Bugfixes, Google-Earth-Zoom, GlasWire-artiges Layout, gemischt
mit VisualTraceroute-Tiefe, plus sinnvolle Community-Features. Kein Bezahl-API,
keine Anmeldung, key-frei. Arbeitsweise: „alles in einem Rutsch", messen statt
raten, jeden Schritt per Xvfb-Screenshot gegenprüfen.

Testsystem, OOM-Fix (6 GB Swap!), shot.sh usw. stehen in `UEBERGABE.md` — die
gilt weiter. Dieses Dokument ergänzt sie um die Erweiterungs-Roadmap.

---

## Recherche-Ergebnisse (bereits erledigt, nicht neu machen)

**GlasWire — was Nutzer lieben:** sauberes Zeit-Graph-Dashboard mit
Zeitfenstern (5 Min / 3 Std / 24 Std / Woche / Monat), Klick in den Graph →
App-Details, dezente Alerts (keine nervigen Popups, „snooze"), „Time Machine"
(Verlauf zurückspulen), Mini-Viewer-Overlay, mehrere Firewall-Profile.

**VisualTraceroute (OVTR) — was es kann:** Hop-Tabelle mit IP / Hostname / Ort /
Land / Lat / Lon / Latenz / DNS-Zeit / Distanz zum Vorgänger; Whois pro Hop;
CSV-Export von Route und Sniff; latenz-/höhenkodierte Linienfarben; History mit
Autocomplete; „Screenshot"-Knopf; Option, die eigene öffentliche IP zu
verbergen.

**Sniffnet (Rust-GlasWire, Community-Wünsche):** Favoriten für Hosts/Apps/Dienste
+ Benachrichtigung bei Traffic; IP-Blacklist aus Datei; Schwellwert-Alerts
(Bytes/s, Pakete/s); PCAP-Export; Sound- + visuelle Alerts; Themes.

**Kartenmaterial (WICHTIG, geklärt):** VisualTraceroute nutzt NASA WorldWind,
das beim Zoomen **Kacheln von NASA/ESA-Servern nachlädt** (frei, kein Key, keine
Anmeldung — deshalb merkt man's nicht). Also derselbe Kachel-Ansatz wie Google
Earth, nur kostenloser Server. Für uns key-frei machbar über **NASA GIBS**
(Satellitenbilder, WMTS, kein Key) oder **OpenStreetMap-Raster** (Straßenkarte,
kein Key). Beide brauchen Netz beim Tiefzoom, beide abschaltbar. Echtes
Street-View (360°-Fotos) gibt es nur bei Google → nicht machbar ohne Bezahl-API.
Zwischenlösung ohne Netz: höher aufgelöste Offline-Textur (NASA Blue/Black
Marble 8K/16K, frei) in `data/textures/` — bleibt beim Zoom länger scharf.
**Einschränkung Container:** Große NASA-Texturen kann ich hier NICHT laden
(Netz nur für crates.io/apt/npm). Code bauen ja, Datei muss Anno beisteuern.

---

## Umsetzungsplan in Runden

| Runde | Inhalt | Status |
|-------|--------|--------|
| **A** | Bugfixes + Zoom (Annos 4 direkte Punkte) | ✅ **FERTIG** |
| **C** | VisualTraceroute-Tiefe (Hop-Tabelle, Whois, CSV, Latenzfarben) | ✅ **FERTIG** |
| —  | Höher aufgelöste Offline-Textur (Code + Anleitung) | ✅ **FERTIG** |
| **B** | GlasWire-Layout (Dashboard, Zeitfenster, Icon-Navleiste) | ✅ **FERTIG** |
| **D** | Echtes Kachelsystem (GIBS/OSM, abschaltbar) + Community-Extras | ⏳ **NÄCHSTES** (großes eigenes Vorhaben) |

Reihenfolge bewusst: erst echter Funktionsnutzen (C), dann Kosmetik (B), dann
das aufwändige Kachel-Rendering (D). Begründung in der Chat-Historie.

---

## ✅ Runde A — FERTIG (gemessen & verifiziert)

Alle vier direkten Punkte von Anno, gebaut, getestet, per Screenshot bzw.
Beispiel-Programm mit echten Daten belegt.

1. **Länder-Suche gefixt** — NEU `crates/ev-geo/src/countries.rs`:
   Länder-Register mit dt./engl. Aliassen → Ordnername + kuratierte Hauptstädte.
   `erkenne_land()` matcht EXAKT auf Alias (kein `contains`, sonst triggert
   „Deutschlandsberg" den Alias „deutschland"). In `search()` als Schritt 2.5
   eingehängt, `dedupe()`-Helfer extrahiert, Cap auf 216 erhöht.
   **Belegt:** „Deutschland" → 195 Treffer, 16 Bundesländer zuerst;
   „Deutschlandsberg" → 1 österr. Ort; „Leipzig" → 1. Enthält DE (16), AT (9),
   CH (8); USA & Co. fallen auf Städteliste zurück. ev-geo-Tests: 10 grün.

2. **Google-Earth-Zoom** — `globe_view.rs`: Camera hat jetzt `target_distance`;
   `zoom()` skaliert den Schritt exponentiell mit der Entfernung (0.88^schritte,
   schritte = scroll_y/50), nah fein, fern grob; `tick_zoom(dt)` führt weich
   nach (exp. Annäherung, 14/s); in der update-Schleife verdrahtet mit sofortigem
   `request_repaint()` während der Animation. `CAMERA_MIN_DISTANCE` 1.2 → 1.02
   (näher ran). **Belegt:** nach 5 Rad-Ticks 24.5x (vorher ~20.8x Max), weicher
   Anflug. Zoom-Tests aktualisiert (`zoom_steps_are_finer_when_closer`).

3. **Klickbare Bogen-Endpunkte mit Info** — `app.rs` globe_panel: neuer
   conn-hover-pick VOR dem generischen Marker-hover. Tooltip zeigt Prozess(PID) /
   IP:Port / Protokoll / Ort+Flagge / Richtung / lat,lon. Klick wählt die
   Verbindung (`selected_connection`, fürs Blockieren).

4. **Latenzfarbige Bögen** — Bögen sind schon richtungsfarbig (blau ein / grün
   aus). Echte Latenzfärbung folgt in Runde C, sobald Ping/RTT je Verbindung da
   ist (siehe unten).

Build sauber (0 Warnungen), 68 Tests grün in den geänderten Crates.

---

## ✅ Runde C — FERTIG (VisualTraceroute-Tiefe)

Traceroute vom simplen Linienzug zum Profi-Werkzeug ausgebaut. Build sauber,
134 Tests grün (net + app), Logik mit echten Werten belegt (Leipzig→Berlin
149 km, Latenzfarben grün/gelb/rot an den Schwellen 50/150 ms).

**Umgesetzt:**
- `TracerouteHop` erweitert: `dns_ms` (DNS-Rückwärtsauflösung via `getent hosts`,
  gemessen), `dist_prev_km` (Haversine zum vorherigen lokalisierten Hop),
  Helfer `ort()`/`land()`/`lat()`/`lon()`/`latenz_rgb()`. `haversine_km()` public.
- `trace_stream` füllt DNS-Zeit, Distanz und (falls IP==Hostname) den aufgelösten
  Namen. `tools::traceroute` schickt zusätzlich `ToolMsg::Hop(voller Hop)`.
- `ToolMsg::Hop` + `ToolJob::drain(..., hops)` (3. Arg). State:
  `traceroute_hops`, `tool_history`. Persistenz: `sessions/tool_history.json`,
  `AppState::push_history()` (jüngstes zuerst, max 20, dedupe).
- Netzwerk-Reiter: Verlaufs-Chips unter dem Zielfeld (Autocomplete-Ersatz),
  Hop-Tabelle `hop_tabelle()` mit Spalten # / IP / Hostname / Ort / Land / Lat /
  Lon / Latenz(farbig) / DNS / Distanz, „⬇ CSV kopieren"-Knopf
  (`hops_als_csv()`, Semikolon-CSV in die Zwischenablage).
- Globus: Traceroute-Linie latenzfarbig **pro Segment** (grün/gelb/rot), Fallback
  auf Themefarbe wenn keine Hop-Latenzen. Endpunkt-Tooltip aus Runde A bleibt.

**Bewusst weggelassen:** Whois-Knopf pro Hop-Zeile — WHOIS läuft schon über das
Netzwerk-Tool (IP ins Ziel, WHOIS wählen). Doppelung vermieden. Höhen-/
Elevations-Kodierung der Linien nach Latenz (OVTR-3D-Extra) ist optisch; die
Farbkodierung liefert dieselbe Information flacher.

**Im Container nicht sichtbar screenshotbar:** Hop-Tabelle + Chips brauchen echtes
`traceroute` (Netz). Auf Annos System erscheinen sie sofort. UI-Gerüst,
Persistenz und Berechnung sind test-/beispielgeprüft.

---

## ✅ Höher aufgelöste Offline-Textur — FERTIG

Kleiner Schritt, sofort sichtbarer Effekt. Build sauber, 230 Tests grün.

- `ev-core::config::earth_texture()` nutzt jetzt eine **Prioritätenliste** und
  nimmt die erste vorhandene Datei: `earth_hd.jpg` → `earth_hd.png` →
  `earth_8k.jpg` → `earth_16k.jpg` → `earth_map1.jpg` → `earth_map.jpg` →
  `earth_day.jpg`. Legt Anno eine HD-Textur als `earth_hd.jpg` ab, greift sie
  automatisch — ohne Code-Änderung.
- **Sofort-Effekt ohne Zutun:** wählt jetzt die mitgelieferte `earth_map1.jpg`
  (5400×2700) statt der kleineren `earth_map.jpg` → Kugel schon schärfer.
  Belegt per Startlog: „🗺 Erdtextur: earth_map1.jpg (5400×2700)".
- **Anisotrope Filterung** in `upload_rgba` (GL_TEXTURE_MAX_ANISOTROPY_EXT,
  0x84FE/0x84FF, bis 16×, nur wenn die GL-Erweiterung da ist) — schärft die
  Textur an flach angeschnittenen Stellen (Kugelrand, Tiefzoom). Mipmapping
  (LINEAR_MIPMAP_LINEAR) war schon aktiv.
- Startlog zeigt aktive Textur + Auflösung. `pruefe_daten.sh` meldet die aktive
  Textur (Größe + Auflösung via `identify`) und gibt bei der kleinen Standard-
  textur den HD-Tipp aus.
- `data/textures/README.md` neu: Prioritätenliste, freie key-freie NASA-Quellen
  (Blue/Black Marble, Natural Earth), Ablage-Anleitung, Format-Hinweise.

**Container-Grenze:** Große NASA-Texturen kann ich hier nicht laden (Netz nur
crates.io/apt/npm). Der Code ist fertig; Anno legt die Datei einmalig selbst ab.

---

## ✅ Runde B — FERTIG (GlasWire-Layout)

Zuschaltbares GlasWire-artiges Dashboard, Standard bleibt das klassische
1:1-Layout — Parität unangetastet. Build sauber, 78 Tests grün (app+core).

**Umgesetzt:**
- `LayoutModus` (Klassisch/Dashboard) + `Zeitfenster` (5m/3h/24h/Woche/Monat)
  in `state.rs`. Umschalten im Zahnrad-Dialog („Layout: Klassisch (1:1) ↔
  Dashboard (GlasWire-Stil)"). Env-Override `EARTHVIEWER_LAYOUT=dashboard` für
  Screenshot-Tests.
- NEU `crates/ev-app/src/dashboard.rs`: `nav_leiste()` (linke Icon-Navleiste,
  12 Bereiche), `kopf_und_graph()` (Titel + Zeitfenster-Umschalter + großer
  Zeit-Graph mit Up/Down/Total-Flächen und Hover-Wertanzeige an der Mausstelle
  = GlasWire-Detail).
- `app.rs`: `render_tab_body()` aus dem Reiter-Dispatch extrahiert (geteilt
  zwischen Seitenleiste und Dashboard). `dashboard_layout()` verdrahtet Nav +
  Kopf/Graph + Reiterinhalt. update-Schleife schaltet per `match self.state.layout`.
- Verifiziert: Dashboard zeigt Icon-Nav (aktiver Bereich türkis),
  Zeitfenster-Leiste (5 Min aktiv), Zeit-Graph, darunter Reiterinhalt
  (Monitoring-Spalten). Klassisch weiterhin Standard mit Globus.

**Bewusst so:** Kein Ersatz des Originals — der Globus tritt im Dashboard
zurück, zurück zum Globus über Zahnrad → Layout: Klassisch. `treue::Original`
bleibt unberührt. Echte Wochen-/Monats-Historie im Zeitfenster bräuchte
Persistenz (aktuell zeigen alle Fenster die vorhandenen ≤300 Punkte) — nachrüstbar
in Runde D.

---

## 🔨 Runde D — TEILWEISE FERTIG (Community-Extras + Kachelsystem)

Aufgeteilt: **Teil 1 (Community-Extras) FERTIG**, **Teil 2 (Kachelsystem) offen**.

### ✅ Teil 1 — Überwachungs-Extras (FERTIG)

Nach Sniffnet/GlasWire-Recherche. Build sauber, 61 app-Tests grün (3 neue in
`alerts`). NEU `crates/ev-app/src/alerts.rs`:
- `WatchConfig` (persistent in `sessions/watch.json`): Favoriten-Hosts/-Apps,
  KB/s-Schwelle, Melde-Schalter (Favoriten, geblockte). `toggle_host/app`.
- `AlarmProtokoll`: Ringpuffer (100), Entprellung (15 s Cooldown, erster Alarm
  feuert sofort), meldet je Host einmal pro Sitzung. `auswerten(t, kbs, cfg,
  conns, blocklist)` pro Sekunde in der update-Schleife aufgerufen. Stufen
  Info/Warnung/Kritisch mit Farbe+Symbol.
- UI: Favoriten-Stern (★/☆) je Zeile in Live-Verbindungen; Benachrichtigungs-
  Panel im Schützen-Reiter (jüngste zuerst, „vor Xs", Leeren-Knopf, dezent —
  kein Popup); Schwelle + Melde-Schalter im Zahnrad-Dialog.
- Verifiziert per Screenshot (Panel + Dialog-Optionen).

**Nachträge zu Teil 1 (erledigt in Folge-Sitzung):**
- ✅ **Rate-History-Persistenz** (`ratehist.rs`): Minuten-Eimer, persistent in
  `sessions/rate_history.json`, ~1 Monat Historie. Dashboard-Zeitfenster
  5m nutzt weiter den Sekunden-Livepuffer, 3h/24h/Woche/Monat den gemittelten
  Langzeitverlauf (mit Ausdünnung auf ≤400 Punkte). Echte Wochen-/Monatsansicht
  jetzt vorhanden. 3 Tests.
- ✅ **DNS/ASN-Provider-Anzeige**: separater ASN-MMDB-Reader in
  `GeoDataManager` (`asn`-Feld, `asn_lookup()`); Host-Detailfenster zeigt
  „Provider: AS… · Organisation". AppState hält jetzt `geo`-Arc für Lookups.

**Weiter offen (klein):** App-Favoriten-Stern in der Monitoring-Apps-Spalte
(`toggle_app` existiert, `#[allow(dead_code)]` — bewusst nicht erzwungen, um die
geteilte 4-Spalten-Closure nicht aufzublähen); Sound-Alarm (rodio-Abhängigkeit);
Themes-Erweiterung; Mini-Viewer-Overlay.

### ⏳ Teil 2 — Kachelsystem (FUNDAMENT GELEGT, GL-Schicht offen)

**Erledigt & getestet:**
- ✅ `ev-render::tiles` — Kachel-Mathematik (Slippy/Web-Mercator): `TileId`,
  `bounds()`, `lonlat_zu_tile()`, `zoomstufe()`, `sichtbare_tiles()` (X umläuft,
  Y geklemmt), `url()` (OSM {z}/{x}/{y} und GIBS {z}/{y}/{x}). 6 Tests.
- ✅ `ev-app::tileloader` — Hintergrund-Lader mit Disk-Cache
  (`sessions/tiles/<anbieter>/z/x/y.ext`), Dedup, `TileQuelle::osm()/gibs()` mit
  Pflicht-Attribution. Nur bei eingeschalteter Ebene aktiv. 3 Tests.
  Aktuell `#[allow(dead_code)]`, bis die GL-Schicht es nutzt.

**Noch offen (die schwere Schicht):**
- GL-Projektion: Mercator-Kacheln als eigene Geometrie auf die Kugeloberfläche
  legen (bounds → Kugelkoordinaten pro Kachel-Quad), Level-Wahl nach
  `zoomstufe(camera.distance)`, nur bei Tiefzoom + nur wenn eingeschaltet. Die
  vorhandene Basistextur bleibt Offline-Fallback.
- UI-Umschalter (An/Aus + OSM/GIBS) im Zahnrad-Dialog samt Attributionsanzeige.
- **Kann im Build-Container NICHT live getestet werden** (tile.openstreetmap.org
  und gibs.earthdata.nasa.gov sind gesperrt, `host_not_allowed`). Der Code ist
  vorbereitet; das echte Nachladen läuft erst auf Annos System mit offenem Netz.

### ✅ Vollständiges GlasWire-Theme (Chrome-weit)

Nicht nur Marker-, sondern das komplette Fenster-Chrome. Neu `UiPalette` in
`theme.rs`: `standard()` (= bisherige `ui::`-Werte, 1:1) und `glasswire()`
(dunkles Marineblau #0b111a, Teal-Akzent #2fa8b0, helle Schrift). `setup_style`
nimmt jetzt eine Palette; Theme-Wechsel färbt das ganze Chrome sofort um
(`UiPalette::fuer_theme`). **GlasWire ist Standard-Theme** (settings.json +
DEFAULT_THEME). Verifiziert: Panels, Knöpfe, Ränder, Akzente in GlasWire-Blau.
Kleine hartkodierte Grautöne (Trennlinien, Balkenhintergründe) bewusst belassen
— Gesamteindruck ist klar GlasWire.

### ✅ Feedback-Fixes Runde 2 (nach Annos Screenshots 20:20)

(Frühere Fixes 20:07 darunter.)

- **Satelliten-Scroll-Bug behoben:** Die Satellitenliste (bei 265 Sats sehr
  lang) fraß die ganze Höhe, der eingeklappte „Mehr"-Bereich darunter war
  unerreichbar (kein Scrollbalken). Fix: innere Liste hart auf 260 px begrenzt
  + ganzer Reiter in äußere ScrollArea gewickelt. „Mehr" jetzt erreichbar,
  Scrollbalken sichtbar — in klassischem UND Dashboard-Layout geprüft.
- **Dashboard ist jetzt Standard** (Anno-Wunsch „lass es automatisch an"):
  `LayoutModus::Dashboard` ist Default. Reiner GlasWire-Stil (Graph + Icon-Nav +
  Tabellen, kein Globus); „🌍 Globus"-Knopf oben holt den Globus jederzeit
  zurück. `EARTHVIEWER_LAYOUT=klassisch` erzwingt das alte Layout.
- **GlasWire-Theme** ist in der Theme-Liste (7 Themes). Annos ZIP war älter —
  die aktuelle enthält es.

- **Flaggen:** egui rendert keine Regional-Indicator-Emoji → Kästchen. Neu
  `country::flag_badge()` liefert Textkürzel „[DE]" (rendert immer);
  `flag_and_name` nutzt es. Alle UI-Aufrufe (tabs/tools) umgestellt.
- **Echte Tabellenspalten im Monitoring:** Spaltenköpfe „Name / Anz." mit
  Trennlinie, rechtsbündige Zähler, farbige Titel, Balken volle Breite.
- **Layout-Umschalter prominent:** „📊 Dashboard"/„🌍 Globus"-Knopf direkt in der
  oberen Leiste (nicht mehr im Zahnrad-Dialog vergraben). Ein Klick genügt.
- **GlasWire-Theme** ergänzt (theme.rs, dunkelblau + Grün/Rot-Akzente), jetzt 7
  Themes.
- Textur-Hinweis: Annos erste ZIP war noch ohne `earth_hd.jpg`; die aktuelle ZIP
  enthält sie (10800×5400) — Log zeigt dann „earth_hd.jpg (10800×5400)".

---

## Konventionen (gelten weiter)

- Build: `export PATH=/usr/lib/rust-1.89/bin:$PATH; cargo build --release -j1`,
  **6 GB Swap** gegen OOM (sonst wird rustc still gekillt).
- Screenshots: `werkzeug/shot.sh <tab…>`, Fenster via `xdotool`. Vor Neustart
  `pkill Xvfb; pkill earthviewer; rm -f /tmp/.X99-lock`.
- Kein U+FE0F in sichtbaren Strings (rendert als Kästchen).
- ZIP-Ausschluss: `target/`, `__pycache__`, `Cargo.lock`, `.git`.
- 1:1-Treue-Schalter (`ev-core::treue`) nicht brechen — Erweiterungen sind
  Zugaben, klar getrennt (im Original „Mehr (über das Original hinaus)").
- Version aktuell 2.1.0. Bei nächster Auslieferung bumpen (2.2.0 für die
  Erweiterungen).

---

## Offene Frage an Anno (nicht blockierend)

Reihenfolge B vs. D ist noch offen; aktuell B vor D geplant. Kacheln (D) sind
das größte Stück Arbeit und liefern optisch am meisten, funktional am wenigsten
— deshalb zuletzt.
