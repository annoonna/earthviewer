# Übergabe — EarthViewer 2.0 Rust-Portierung (v2.0.0)

*Für den nächsten Kollegen (also mich in einem neuen Chat). Terse, gemessen, ehrlich.*

---

## 1. Auftrag & Ausgangslage

Anno hat vier ZIPs geliefert:

| ZIP | Inhalt |
|---|---|
| `earthviewer_v0_2_miniCaptureExtra.zip` | **Python-Original** (PyQt6/PyOpenGL), ~13.900 Zeilen — das **Soll** |
| `earthviewer_rust_v1_9_0.zip` | Rust-Portierung v1.9.0 — der Ausgangspunkt |
| `earth.zip` | 34 Screenshots des **Python-Originals** — die Referenz für 1:1 |
| `shit.zip` | 22 Screenshots der Rust-Fassung **v1.6/1.7** — das beanstandete Ist |

**Beschwerde:** Der Vorgänger hatte den 1:1-Nachbau verweigert — Fenster, Farben,
Reiter wichen ab. Auftrag: **alles 1:1 nachbauen** (Fenster, Unterfenster,
Funktionen), messen statt raten, Fehler selbst korrigieren, neue ZIP + Doku.

**Wichtig:** Die hochgeladene Rust-ZIP war bereits v1.9.0 und damit *neuer* als
die beanstandeten v1.6/1.7-Screenshots. Der Vorgänger hatte nach den Screenshots
schon nachgebessert (Kopfzeile war z. B. bereits 1:1). Es blieben aber echte
Abweichungen — siehe §3.

---

## 2. Testsystem (so wird gemessen, nicht geraten)

Ubuntu-Container. Reproduktion der Umgebung:

```bash
# Rust: rustup war netzseitig gesperrt -> Distro-Paket nehmen
apt-get install -y rustc-1.89 cargo-1.89
export PATH=/usr/lib/rust-1.89/bin:$PATH

# GUI-Test ohne Display
apt-get install -y xvfb x11-utils xdotool imagemagick \
  libgl1-mesa-dri libegl1 libxkbcommon-x11-0

# ⚠️ WICHTIG: Der ev-app-Build braucht mit thin-LTO > 4 GB RAM.
#   Ohne Swap killt der OOM-Killer rustc STILL (Build hängt scheinbar).
#   Symptom: "Compiling ev-app" läuft ewig, Prozess verschwindet.
fallocate -l 6G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile

cd rust && cargo build --release -j1     # -j1 hält den Speicher niedrig
```

### Screenshot-Werkzeug: `shot.sh` (liegt bei, im Repo-Wurzel unter `werkzeug/`)

Startet Xvfb, öffnet die App je Reiter über `$EARTHVIEWER_TAB`, greift per
`import -window root` ab. Reiter-Slugs: `control search favorites network live
monitoring center graph protection protocol scanner satellites`.

```bash
./werkzeug/shot.sh control search      # -> /tmp/shots/ist_control.png …
SHOT_WAIT=10 ./werkzeug/shot.sh live   # längere Wartezeit, falls GL langsam
```

Fenster (nicht per Reiter erreichbar) via Klick mit `xdotool`:
```bash
DISPLAY=:99 xdotool mousemove <x> <y> click 1
```
Die „Große Ansicht öffnen"-Knöpfe liegen in der rechten Spalte bei ~x=1307,
y=185. Das Zahnrad oben rechts bei ~x=1324, y=25.

**Fallstrick:** Bei schnellen Neustarts bleibt `/tmp/.X99-lock` liegen und Xvfb
startet nicht. Immer `pkill Xvfb; pkill earthviewer; rm -f /tmp/.X99-lock`
davor.

---

## 3. Was in v2.0.0 gegenüber v1.9.0 korrigiert wurde

Jede Korrektur ist gegen `earth.zip` (Original) bzw. den Python-Quellcode
gemessen. Fundstellen in Klammern.

1. **Version/Titel überall „🌍 EarthViewer 2.0"** — vorher zeigte der
   Sidebar-Kopf `EarthViewer {CARGO_VERSION}` = „1.9.0", der Fenstertitel
   ebenso abgeleitet. Jetzt beide hart auf den Originalstring.
   (`ev-core/config.rs` WINDOW_TITLE; `app.rs` Sidebar-Kopf nutzt WINDOW_TITLE;
   `config.py::WINDOW_TITLE`.)
   Test `ev-core::titel_tests` prüft jetzt den exakten Klon-String, nicht die
   Crate-Version.

2. **12 Reiter statt 13.** Der Reiter „Einstellungen" existiert im Original
   nicht — das Zahnrad öffnet den Dialog „⚙ Erweiterte Einstellungen"
   (`main_window._show_settings`). `Tab::Settings` samt Match-Arm/Slug/Label
   entfernt; `Tab::ALL` hat 12 Einträge. Der Test
   `all_original_tabs_are_present` bestand fälschlich auf 13 — **das war die
   eingebaute Rechtfertigung des Vorgängers** — jetzt auf 12 mit Satelliten
   korrigiert.

3. **Netzwerk-Combo exakt Traceroute/Ping/WHOIS** (`network_tab.py:40`).
   Rust hatte VirusTotal+ARP angehängt. `NetTool::ALL` auf 3 gekürzt; die
   beiden Extra-Varianten bleiben im Enum (Detailfenster/CC), `#[allow(dead_code)]`.

4. **Steuerungs-Reiter:** Emojis 1:1 („🏷 Marker anzeigen", „📝 Namen
   anzeigen" — waren vertauscht/falsch). Marker-Höhe & Rotationstempo aus dem
   Reiter entfernt (gehören in den Zahnrad-Dialog).

5. **Suche-Reiter** 1:1 nach `sidebar.py::_create_search_tab`: kein Extra-Kopf,
   Platzhalter „Stadt, IP, Koordinaten...", Trefferformat
   „🏙 Berlin [Germany] (52.5°, 13.4°)". `run_search` löscht Marker vor der
   Suche (wie `_on_search`), leeres Feld = nichts tun.

6. **Sechs Netzwerk-Reiter komplett neu** nach den Python-Vorlagen:
   Live Verbindungen, Monitoring, Control Center, Graph, Schützen, Protokoll.
   Enthalten jetzt die türkisen „Große Ansicht öffnen"-Knöpfe, rot/grün/orange
   Aktionsknöpfe, farbige Incoming/Outgoing-Haken, Pausieren jeweils **unten**,
   Original-Tabellenspalten. Rust-Zugaben konsequent unter „Mehr (über das
   Original hinaus)" eingeklappt.

7. **Neun freistehende Fenster** neu in `crates/ev-app/src/fenster.rs`
   (~480 Zeilen) — die `QDialog`-Klassen, die der Vorgänger verweigert hatte:
   Network Monitor (Live), Große Live-Analyse, **WLAN Control Center** (mit
   3 Reitern WiFi Monitor/Live Statistiken/VirusTotal-Einstellungen),
   Netzwerk-Clients, Graph/Schutz/Protokoll/Scanner groß, und der
   Zahnrad-Dialog „⚙ Erweiterte Einstellungen".

8. `format_bytes` clamped negative Rundungsreste (kein „-0 B" mehr).

**Anti-Doppelcode:** Reiter und Großfenster teilen sich Zeichenroutinen
(`tabs::monitoring_spalten`, `tabs::graph`, `tabs::protection`,
`tabs::protocol`, `tabs::scanner`). Das Original hatte hier doppelten Code, der
auseinanderlief — bewusst vermieden.

---

## 4. Beweislage (Zahlen)

```
cargo build --release   -> 0 Warnungen, 0 Fehler
cargo test  --release   -> 223 Tests, alle grün

./werkzeug/gegenpruefung.py <original.zip>:
  Symbole gesamt : 586
  OK  portiert   : 458  (78,2 %)
  SKIP ausgelassen: 128 (21,8 %)   <- dokumentiert in werkzeug/abbildung.json
  FEHLT ungeklärt:   0  ( 0,0 %)   <- KEINE offenen Lücken
```

**`werkzeug/abbildung.json`** ist die Wahrheitsquelle: jedes Python-Symbol ist
entweder unter `abgebildet` (mit Rust-Ziel) oder unter `ausgelassen` (mit
Begründung). „weggelassen" allein zählt nicht — `gegenpruefung.py` verlangt eine
Begründung. Bewusst ausgelassen sind u. a.: der
venv/pip-Bootstrap (`install.py` — cargo übernimmt), Qt-Lebenszyklus-Handler
(`closeEvent` — egui nutzt `.open(&mut bool)`).

Screenshots der Verifikation liegen unter `/tmp/shots/` (nicht in der ZIP):
`ist_*.png` (12 Reiter), `win_cc.png`, `win_monitor.png`, `win_graph.png`,
`win_scanner.png`, `win_settings.png`.

---

## 5. Architektur (unverändert, sechs Crates)

```
crates/
  ev-core   Fundament: config, theme, settings, math, country, treue (1:1-Schalter)
  ev-geo    GeoIP (MMDB), Ortsindex, Suche
  ev-net    connections, monitor, ping, traceroute, whois, portscan, arp,
            firewall/blocklist, virustotal, throughput, classify
  ev-sat    TLE-Katalog (Celestrak+Cache), SGP4, Frames, Offline-Notreserve
  ev-render GL-Utils, Shader, Kugelgeometrie, Globus-Renderer
  ev-app    eframe/egui-Oberfläche:
            app.rs      Rahmen, Kopfzeile, Seitenleiste, Update-Schleife
            state.rs    AppState, Tab-Enum (12!), NetTool-Enum (3)
            tabs.rs     die 12 Reiter + geteilte Zeichenroutinen
            fenster.rs  die 9 freistehenden Fenster + Zahnrad-Dialog  ← NEU in v2.0
            detail.rs   Detailfenster (Prozess/Host/Land)
            globe_view.rs Kamera + Globus-Panel
            glyphen.rs  Emoji-Prüfung (kein U+FE0F, rendert als Kästchen!)
            tools.rs    Hintergrund-Jobs (ping/traceroute) via Kanal
```

**Originaltreue-Schalter** (`ev-core::treue`): Standard = 1:1 wie Python 2.0
*inklusive seiner Fehler*. Im Zahnrad-Dialog unter „Darstellung & Verhalten"
umschaltbar auf „Korrekturen aktivieren". Abweichungen sind in
`treue::ABWEICHUNGEN` dokumentiert (Original/Korrigiert/Fundstelle).

---

## 6. Fallstricke / Merkzettel

- **U+FE0F (Variation Selector)** rendert in egui als leeres Kästchen hinter dem
  Emoji. Nie in sichtbaren Strings verwenden. `glyphen.rs`-Tests fangen das für
  Reiter-Labels; bei Fenstertiteln/Knöpfen selbst darauf achten (war der Fehler
  bei „⚙️ Erweiterte Einstellungen" → jetzt „⚙ …").
- **OOM beim Build** — siehe §2, Swap nicht vergessen.
- **MSAA/Xvfb:** `EARTHVIEWER_MSAA=0` erzwingt kein Multisampling (llvmpipe
  bietet sonst keine FBConfig). `main.rs` hat eine MSAA-Leiter 4→2→0 als Rückfall.
- **root:** Ohne root sieht der ConnectionTracker nur eigene Sockets. Nicht als
  Fehler werten.
- **Daten:** `data/geodata` (242 Länder) + `data/textures` (Erdtexturen) +
  `GeoLite2-City.mmdb`. Ohne MMDB: „GeoIP fehlt — keine Marker" (kein Absturz).
  `./pruefe_daten.sh` prüft den Bestand.

---

## 7. Was als Nächstes sinnvoll wäre (offen, nicht dringend)

- ~~SpectrumTab (SDR) portieren~~ — **erledigt in v2.1.0** (`ev-sat::spektrum`,
  `fenster::sat_monitor`). Vollständige Simulation, keine offenen SDR-Punkte
  mehr außer echter RTL-SDR-Hardware-Anbindung (Combo „RTL-SDR" wählbar, fällt
  ohne Gerät auf Simulation zurück — wie im Original).
- Echte VirusTotal-Netzabfrage im CC-Einstellungen-„Test" (aktuell nur
  Key-Validierung; `ev-net::virustotal::lookup` existiert bereits).
- Sat-Tracking: echte Az/El-Berechnung aus Beobachterstandort (Original ließ
  die Spalten in der vereinfachten Fassung ebenfalls leer).
- Pixel-Diff automatisieren (ImageMagick `compare`) statt Sichtprüfung.

---

*Build geprüft, Tests grün, Gegenprüfung 0,0 % FEHLT. Der 1:1-Nachbau steht.*
