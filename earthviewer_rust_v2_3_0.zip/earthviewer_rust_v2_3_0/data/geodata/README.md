# Geodaten

## Städte (CSV)

Struktur wie in der Python-Version — der **Ordnername ist das Land**:

```
geodata/
├── Germany/staedte.csv
├── France/staedte.csv
└── ...
```

Erwartete Spalten (Groß-/Kleinschreibung egal):
- `name` oder `city`
- `lat` oder `latitude`
- `lon`, `lng` oder `longitude`

Längengrade > 180 werden automatisch um 360 reduziert.

## GeoIP (MaxMind)

`GeoLite2-City.mmdb` gehört hierher, liegt aber **aus Lizenzgründen nicht
im Archiv**. Die MaxMind-EULA untersagt die Weitergabe von Datenbanken,
die älter als 30 Tage sind.

Kostenlos nach Registrierung:
https://dev.maxmind.com/geoip/geolite2-free-geolocation-data

Der Loader sucht rekursiv nach `*.mmdb` und bevorzugt Dateien mit "city"
im Namen, dann "country". Ohne MMDB funktioniert alles außer der
IP-Lokalisierung.

## Laenderordner

Das Original hatte hier **242 Ordner**, einen je Land, jeweils mit
`staedte.csv` (Spalten `name,lat,lon`). Diese Struktur liegt bei.

Neu anlegen oder ergaenzen:

```bash
./werkzeug/staedte_erzeugen.py --pruefen        # nur zaehlen
./werkzeug/staedte_erzeugen.py                  # fehlende anlegen
./werkzeug/staedte_erzeugen.py --ueberschreiben # auch vorhandene ersetzen
./werkzeug/staedte_erzeugen.py --ascii          # Reykjavik statt Reykjavík
```

Vorhandene Dateien bleiben unangetastet — eine von Hand gepflegte Liste kann
mehr Orte enthalten als die Tabelle. `Germany/staedte.csv` stammt aus dem
Original (1747 Orte) und wurde deshalb **nicht** ueberschrieben.

**Schreibweise:** die mitgelieferten Listen sind mit `--ascii` erzeugt, also
`Munich`, `Cologne`, `Reykjavik`, `Malmo`. Das entspricht dem Original:
`Germany/staedte.csv` aus dem Archiv enthaelt **kein einziges** Nicht-ASCII-
Zeichen und schreibt „Nuremberg" statt „Nürnberg".

Wer die Landessprache bevorzugt (`Reykjavík`, `Malmö`), erzeugt ohne
`--ascii` neu — muss dann aber wissen, dass die Suche wortwoertlich
vergleicht und `Reykjavik` ohne Akzent nichts findet. Auch das ist
Original-Verhalten.

## worldcities.xlsx

Diese Datei lag im Original-Archiv, wird dort aber **von keinem Modul
gelesen**: `geo_manager.py` sucht ausschliesslich `*.csv` (`rglob("*.csv")`),
und `requirements.txt` kennt weder `openpyxl` noch `pandas`.

Sie ist deshalb 1:1 mitgeliefert und bleibt ungenutzt — sie auszuwerten waere
ein neues Merkmal und damit eine Abweichung. Wer die Orte will, exportiert die
Tabelle nach `data/geodata/<Land>/staedte.csv`; der Loader nimmt sie dann.
