# Was gehört wohin

Das Programm liest **ausschließlich** aus `data/`. Nach dem Kopieren prüft
`./pruefe_daten.sh`, ob alles am richtigen Platz liegt.

| Was du hast | Wohin damit |
|---|---|
| deine Erdtextur | `data/textures/earth_map.jpg` |
| deine Länderordner (Afghanistan, Albania, …) | `data/geodata/<Land>/staedte.csv` |
| `GeoLite2-City.mmdb` aus `GeoLite2-City_2025…/` | `data/geodata/` |
| deine Downloads (MaxMind-Archive, simplemaps) | `Geodaten/` — wird **nicht** gelesen |

Als Befehle, wenn dein altes Programm daneben liegt:

```bash
ALT=~/Videos/earthviewer_v0_2_miniCaptureExtra
NEU=~/Videos/earthviewer_rust_v1.5.0

cp -r "$ALT"/data/geodata/*  "$NEU"/data/geodata/
cp -r "$ALT"/data/textures/* "$NEU"/data/textures/
cp    "$ALT"/Geodaten/GeoLite2-City_*/GeoLite2-City.mmdb "$NEU"/data/geodata/

cd "$NEU" && ./pruefe_daten.sh
```

## Die drei Regeln, an denen es sonst scheitert

1. **Der Ordnername ist das Land.** `data/geodata/Germany/staedte.csv` →
   Land „Germany". Eine CSV direkt in `data/geodata/` bekommt kein Land.
2. **Die MMDB braucht `city` im Namen.** `GeoLite2-City.mmdb` passt,
   `GeoLite2-Country.mmdb` wird ignoriert — genau wie im Original.
3. **Spaltennamen:** `name` oder `city`, `lat` oder `latitude`,
   `lon`/`lng`/`longitude`. Groß-/Kleinschreibung egal, Reihenfolge egal.

## Ohne Daten

Es startet trotzdem. Die Kugel zeigt dann ein blaues Gradnetz statt
Kontinenten, die Suche findet nichts, und es gibt keine Marker und keine
Verbindungsbögen — mit einem gelben Hinweis in der Seitenleiste.

Ob die Bögen auf deiner Grafikkarte überhaupt ankommen, siehst du auch ohne
GeoIP: `EARTHVIEWER_DEMO_ORT=51.3,12.4 ./start.sh 1`
