# Texturen

Hier liegen die Erdtexturen (equirektangular, Seitenverhältnis 2:1).

## Welche Datei wird genommen?

**Seit v2.2.0 ist `earth_hd.jpg` (NASA Shaded Relief, 10800×5400) bereits
beigelegt** — die Kugel ist also ohne weiteren Download scharf. Herkunft und
Lizenz stehen in `HERKUNFT.txt` (gemeinfrei, NASA Public Domain). Zusätzlich
liegt `earth_bluemarble.jpg` (echte Satellitenoptik, 5400×2700) bei.

`ev-core::config::earth_texture()` sucht in dieser Reihenfolge und nimmt die
**erste vorhandene** — so wird die Kugel automatisch schärfer, sobald du eine
höher aufgelöste Datei ablegst, ganz ohne Code-Änderung:

1. `earth_hd.jpg`   <- **hier deine hochauflösende Textur ablegen (empfohlen)**
2. `earth_hd.png`
3. `earth_8k.jpg`
4. `earth_16k.jpg`
5. `earth_map1.jpg` (mitgeliefert, größer)
6. `earth_map.jpg`  (mitgeliefert, Standard)
7. `earth_day.jpg`

Fehlt alles, erzeugt `fallback_texture()` ein 512x256-Gradnetz mit Äquator —
der Globus ist dann sichtbar, aber ohne Kontinente. Absicht: so erkennt man den
fehlenden Download sofort statt einen Renderfehler zu vermuten.

## Schärfer zoomen (Google-Earth-Gefühl, ohne Netz, ohne Key, ohne Anmeldung)

Die mitgelieferte Textur wird beim Tiefzoom unscharf, weil sie nur begrenzt viele
Pixel hat. Für einen deutlich schärferen Zoom lege eine hochauflösende, **freie**
NASA-Textur als `earth_hd.jpg` ab. Kein API-Key, keine Anmeldung — nur ein
einmaliger Download auf deinem Rechner:

**NASA Blue Marble (Tag, farbig), bis 8K/16K, gemeinfrei:**
- https://visibleearth.nasa.gov/collection/1484/blue-marble

**NASA Black Marble (Nacht, Lichter — passt zum aktuellen dunklen Look):**
- https://earthobservatory.nasa.gov/features/NightLights

**Natural Earth (gemeinfrei, klassische Landkarte):**
- https://www.naturalearthdata.com/  -> Raster -> Natural Earth I/II,
  bis 16200x8100 verfügbar.

Nach dem Download:
```
cp deine_datei.jpg  data/textures/earth_hd.jpg
```
Beim nächsten Start wird sie automatisch geladen. Kontrolle: `./pruefe_daten.sh`
meldet, welche Erdtextur aktiv ist.

## Warum nicht automatisch herunterladen?

Bewusst nicht: Das Programm soll ohne dein Zutun nicht ins Netz gehen (dein
Sicherheitsanspruch). Der Download bleibt eine einmalige, freiwillige Handlung.
Für live nachgeladene Kacheln (echtes Google-Earth-Prinzip über die freien
NASA-GIBS- oder OpenStreetMap-Server) ist die abschaltbare Kachel-Ebene aus
Runde D vorgesehen — siehe FORTSCHRITT.md.

## Format-Hinweise

- Equirektangular / Plate Carrée, Seitenverhältnis exakt 2:1.
- JPG oder PNG. Sehr große PNGs kosten Startzeit; JPG ist meist besser.
- Zweierpotenz-Kantenlängen (4096x2048, 8192x4096) sind für Mipmaps ideal.
