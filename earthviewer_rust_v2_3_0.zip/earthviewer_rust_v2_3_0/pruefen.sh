#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Pflicht-Gate vor jeder Übergabe. Läuft ohne GPU und ohne Display.
# Konvention aus dem Py_DAW-Relay: "MESSEN STATT HÖREN".
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

fail=0
step() { echo ""; echo "── $1 ──"; }

step "1/5  cargo fmt --check"
if command -v rustfmt >/dev/null 2>&1 && cargo fmt --all -- --check >/dev/null 2>&1; then
    echo "✅ Formatierung sauber"
else
    echo "⚠️  Formatierung abweichend oder rustfmt fehlt (cargo fmt --all)"
fi

step "2/5  cargo clippy (Warnungen sind Fehler)"
if cargo clippy --workspace --all-targets -- -D warnings 2>&1 | tail -20; then
    echo "✅ clippy sauber"
else
    echo "❌ clippy meldet Probleme"; fail=1
fi

step "3/5  cargo test --workspace"
if cargo test --workspace 2>&1 | tail -25; then
    echo "✅ Tests grün"
else
    echo "❌ Tests rot"; fail=1
fi

step "4/5  Release-Build"
if cargo build --release -p ev-app >/dev/null 2>&1; then
    echo "✅ Release-Binary gebaut"
else
    echo "❌ Release-Build fehlgeschlagen"; fail=1
fi

step "5/5  Gegenpruefung gegen die Original-ZIP"
ORIG="${EARTHVIEWER_ORIG_ZIP:-}"
if [ -z "$ORIG" ]; then
    for k in ../earthviewer_v0_2_miniCaptureExtra.zip \
             /mnt/user-data/uploads/earthviewer_v0_2_miniCaptureExtra.zip; do
        [ -f "$k" ] && ORIG="$k" && break
    done
fi
if [ -n "$ORIG" ] && [ -f "$ORIG" ]; then
    ./werkzeug/gegenpruefung.py "$ORIG" | head -10
    echo "   (Details: ./werkzeug/gegenpruefung.py \"$ORIG\")"
else
    echo "ℹ️  Original-ZIP nicht gefunden - Gegenpruefung uebersprungen."
    echo "   Pfad setzen: EARTHVIEWER_ORIG_ZIP=/pfad/original.zip ./pruefen.sh"
fi

echo ""
echo "════════════════════════════════════════"
if [ "$fail" -eq 0 ]; then
    echo "✅ GATE BESTANDEN"
else
    echo "❌ GATE NICHT BESTANDEN — nicht übergeben!"
fi
exit $fail
