#!/usr/bin/env python3
"""
farben.py — misst Farben und Maße der Oberflaeche aus Bildschirmfotos.

Liest PNG **direkt aus einer ZIP** (oder aus einer Datei) und bestimmt:
  * Kante der Seitenleiste (Spaltensprung im Bild)
  * Flaechenfarben (Panel, Globusflaeche, Reiterleiste, Knoepfe)
  * Akzentfarbe (haeufigste gesaettigte Farbe in der Kopfzeile)
  * Scrollbalken: Lage und Breite
  * Schrifthoehen ueber Zeilenprofile

Aufruf:
  ./werkzeug/farben.py --zip bilder.zip --bild "Bildschirmfoto ... 14-20-11.png"
  ./werkzeug/farben.py --datei eigener_screenshot.png
"""
import argparse, io, struct, sys, zlib, zipfile
from collections import Counter
from pathlib import Path


# ── Minimaler PNG-Leser (kein Pillow noetig) ────────────────────────────────
def png_lesen(daten):
    if daten[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("kein PNG")
    pos, idat, breite, hoehe, tiefe, farbtyp = 8, b"", 0, 0, 0, 0
    while pos < len(daten):
        laenge = struct.unpack(">I", daten[pos:pos + 4])[0]
        typ = daten[pos + 4:pos + 8]
        rumpf = daten[pos + 8:pos + 8 + laenge]
        if typ == b"IHDR":
            breite, hoehe, tiefe, farbtyp = struct.unpack(">IIBB", rumpf[:10])
        elif typ == b"IDAT":
            idat += rumpf
        elif typ == b"IEND":
            break
        pos += 12 + laenge
    if tiefe != 8 or farbtyp not in (2, 6):
        raise ValueError(f"nur 8-bit RGB/RGBA, hier tiefe={tiefe} farbtyp={farbtyp}")
    kanaele = 3 if farbtyp == 2 else 4
    roh = zlib.decompress(idat)
    schritt = breite * kanaele
    zeilen, vorher, p = [], bytearray(schritt), 0
    for _ in range(hoehe):
        filt = roh[p]; p += 1
        zeile = bytearray(roh[p:p + schritt]); p += schritt
        if filt == 1:
            for i in range(kanaele, schritt):
                zeile[i] = (zeile[i] + zeile[i - kanaele]) & 0xFF
        elif filt == 2:
            for i in range(schritt):
                zeile[i] = (zeile[i] + vorher[i]) & 0xFF
        elif filt == 3:
            for i in range(schritt):
                links = zeile[i - kanaele] if i >= kanaele else 0
                zeile[i] = (zeile[i] + ((links + vorher[i]) >> 1)) & 0xFF
        elif filt == 4:
            for i in range(schritt):
                a = zeile[i - kanaele] if i >= kanaele else 0
                b = vorher[i]
                c = vorher[i - kanaele] if i >= kanaele else 0
                pp = a + b - c
                pa, pb, pc = abs(pp - a), abs(pp - b), abs(pp - c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                zeile[i] = (zeile[i] + pr) & 0xFF
        zeilen.append(bytes(zeile))
        vorher = zeile
    return breite, hoehe, kanaele, zeilen


class Bild:
    def __init__(self, daten):
        self.b, self.h, self.k, self.zeilen = png_lesen(daten)

    def px(self, x, y):
        i = x * self.k
        z = self.zeilen[y]
        return (z[i], z[i + 1], z[i + 2])

    def flaeche(self, x0, y0, x1, y1):
        """Haeufigste Farbe in einem Rechteck."""
        c = Counter()
        for y in range(max(0, y0), min(self.h, y1)):
            for x in range(max(0, x0), min(self.b, x1)):
                c[self.px(x, y)] += 1
        return c.most_common(1)[0] if c else ((0, 0, 0), 0)


def hexf(rgb):
    return "#%02X%02X%02X" % rgb


def fensterrand(bild):
    """Rechte/untere Kante des Programmfensters, falls es den Schirm nicht fuellt.

    Ohne das misst man den schwarzen Schreibtisch mit — mir genau so passiert.
    """
    y = bild.h // 4
    rechts = bild.b
    for x in range(bild.b - 1, bild.b // 2, -1):
        if bild.px(x, y) != (0, 0, 0):
            rechts = x + 1
            break
    x = rechts // 2
    unten = bild.h
    for y2 in range(bild.h - 1, bild.h // 2, -1):
        if bild.px(x, y2) != (0, 0, 0):
            unten = y2 + 1
            break
    return rechts, unten


def seitenleisten_kante(bild, rechts=None):
    """Sucht die senkrechte Kante zwischen Globusflaeche und Seitenleiste."""
    rechts = rechts or bild.b
    y = bild.h // 2
    beste, bester_sprung = None, 0
    for x in range(rechts // 2, rechts - 2):
        a, b = bild.px(x, y), bild.px(x + 1, y)
        d = sum(abs(p - q) for p, q in zip(a, b))
        if d > bester_sprung:
            bester_sprung, beste = d, x + 1
    return beste, bester_sprung


def senkrechte_kanten(bild, y):
    """Alle deutlichen Farbspruenge entlang einer Bildzeile."""
    out = []
    for x in range(1, bild.b - 1):
        a, b = bild.px(x, y), bild.px(x + 1, y)
        if sum(abs(p - q) for p, q in zip(a, b)) > 60:
            out.append(x + 1)
    return out


def textzeilen(bild, x0, x1, y0, y1, hintergrund, schwelle=40):
    """Findet Textzeilen als y-Baender, die vom Hintergrund abweichen."""
    baender, offen = [], None
    for y in range(y0, min(y1, bild.h)):
        treffer = 0
        for x in range(x0, min(x1, bild.b), 2):
            p = bild.px(x, y)
            if sum(abs(a - b) for a, b in zip(p, hintergrund)) > schwelle:
                treffer += 1
        if treffer >= 2:
            if offen is None:
                offen = y
        elif offen is not None:
            baender.append((offen, y - 1, y - offen))
            offen = None
    if offen is not None:
        baender.append((offen, y1 - 1, y1 - offen))
    return baender


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", type=Path)
    ap.add_argument("--bild", type=str)
    ap.add_argument("--datei", type=Path)
    ap.add_argument("--zeilen", action="store_true", help="Textzeilen-Hoehen ausgeben")
    a = ap.parse_args()

    if a.datei:
        daten = a.datei.read_bytes()
        name = a.datei.name
    else:
        with zipfile.ZipFile(a.zip) as zf:
            treffer = [n for n in zf.namelist() if a.bild in n] if a.bild else \
                      [n for n in zf.namelist() if n.endswith(".png")]
            if not treffer:
                sys.exit("Bild nicht in der ZIP gefunden")
            name = treffer[0]
            daten = zf.read(name)

    bild = Bild(daten)
    print("=" * 68)
    print(f"FARBMESSUNG  {name}")
    print(f"Groesse: {bild.b}x{bild.h}")
    print("=" * 68)

    rechts, unten = fensterrand(bild)
    if (rechts, unten) != (bild.b, bild.h):
        print(f"\nFenster fuellt den Schirm nicht: nutze {rechts}x{unten}")
    kante, sprung = seitenleisten_kante(bild, rechts)
    breite = rechts - kante if kante else 0
    print(f"\nSeitenleiste beginnt bei x={kante}  (Breite {breite} px, Sprung {sprung})")

    proben = {
        "Globusflaeche (links unten)": (30, unten - 120, 200, unten - 40),
        "Seitenleiste Flaeche":        (kante + 10, int(unten * 0.72), rechts - 30, int(unten * 0.80)),
        "Kopfzeile":                   (int(rechts * 0.2), 4, int(rechts * 0.5), 24),
        "Suchfeld":                    (60, 8, int(rechts * 0.15), 20),
    }
    print("\nFlaechenfarben (haeufigste):")
    for bez, (x0, y0, x1, y1) in proben.items():
        farbe, n = bild.flaeche(x0, y0, x1, y1)
        print(f"  {bez:<28} {hexf(farbe)}  rgb{farbe}  ({n} px)")

    # Scrollbalken: rechte Kante der Seitenleiste absuchen
    print("\nRechter Rand der Seitenleiste (Scrollbalken-Suche):")
    y = int(unten * 0.55)
    for x in range(rechts - 22, rechts - 1):
        print(f"  x={x:<5} {hexf(bild.px(x, y))}")

    # Akzentfarbe: saettigste Farbe in der Kopfzeile der Seitenleiste
    if kante:
        c = Counter()
        for y in range(int(unten * 0.02), int(unten * 0.12)):
            for x in range(kante + 5, rechts - 30):
                r, g, b = bild.px(x, y)
                mx, mn = max(r, g, b), min(r, g, b)
                if mx > 90 and (mx - mn) > 50:
                    c[(r, g, b)] += 1
        print("\nAkzentfarben in der Kopfzeile (saettigst, Top 5):")
        for farbe, n in c.most_common(5):
            print(f"  {hexf(farbe)}  rgb{farbe}  ({n} px)")
        # aktiver Reiter
        c2 = Counter()
        for y in range(int(unten * 0.12), int(unten * 0.17)):
            for x in range(kante + 5, rechts - 30):
                r, g, b = bild.px(x, y)
                mx, mn = max(r, g, b), min(r, g, b)
                if mx > 60 and (mx - mn) > 25:
                    c2[(r, g, b)] += 1
        print("\nReiterleiste, aktiver Reiter (Top 5):")
        for farbe, n in c2.most_common(5):
            print(f"  {hexf(farbe)}  rgb{farbe}  ({n} px)")

    if a.zeilen and kante:
        hg, _ = bild.flaeche(kante + 10, int(bild.h * 0.75), bild.b - 30, int(bild.h * 0.85))
        print(f"\nTextzeilen in der Seitenleiste (Hintergrund {hexf(hg)}):")
        for y0, y1, hoehe in textzeilen(bild, kante + 8, rechts - 25, int(unten * 0.1), int(unten * 0.75), hg)[:24]:
            print(f"  y {y0:>4}-{y1:<4}  Hoehe {hoehe:>3} px")

    print("\nSenkrechte Kanten auf halber Bildhoehe (Spaltengrenzen):")
    print(" ", senkrechte_kanten(bild, bild.h // 2)[:20])
    return 0


if __name__ == "__main__":
    sys.exit(main())
