#!/usr/bin/env python3
"""
staedte_erzeugen.py — legt data/geodata/<Land>/staedte.csv fuer alle Laender an.

Das Original hatte 246 Laenderordner; das ausgelieferte ZIP enthielt nur
Germany. Quelle ist die mitgelieferte `worldcities.xlsx` (bzw. eine
`worldcities.csv` aus dem simplemaps-Archiv).

Der xlsx-Leser kommt ohne openpyxl aus: eine xlsx ist ein ZIP aus XML.

  ./werkzeug/staedte_erzeugen.py                    nutzt data/geodata/worldcities.xlsx
  ./werkzeug/staedte_erzeugen.py --quelle DATEI     csv, xlsx oder simplemaps-zip
  ./werkzeug/staedte_erzeugen.py --min-einwohner N  nur groessere Orte
  ./werkzeug/staedte_erzeugen.py --pruefen          nur zaehlen, nichts schreiben
"""
import argparse, csv, io, re, sys, zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
WURZEL = Path(__file__).resolve().parent.parent
ZIEL = WURZEL / "data" / "geodata"

# Zeichen, die in Ordnernamen Aerger machen.
UNGUELTIG = re.compile(r'[/\\:*?"<>|]')


def xlsx_zeilen(daten: bytes):
    """Liest die erste Tabelle einer xlsx ohne Fremdbibliothek."""
    z = zipfile.ZipFile(io.BytesIO(daten))
    ss = []
    if "xl/sharedStrings.xml" in z.namelist():
        wurzel = ET.fromstring(z.read("xl/sharedStrings.xml"))
        for si in wurzel.findall(f"{NS}si"):
            ss.append("".join(t.text or "" for t in si.iter(f"{NS}t")))

    def wert(c):
        v = c.find(f"{NS}v")
        if v is None:
            return ""
        if c.get("t") == "s":
            i = int(v.text)
            return ss[i] if i < len(ss) else ""
        return v.text or ""

    blatt = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))
    for zeile in blatt.findall(f".//{NS}row"):
        yield [wert(c) for c in zeile]


def quelle_lesen(pfad: Path):
    """Liefert (kopf, zeilen) aus csv, xlsx oder simplemaps-zip."""
    roh = pfad.read_bytes()
    if pfad.suffix.lower() == ".zip":
        z = zipfile.ZipFile(io.BytesIO(roh))
        for n in z.namelist():
            if n.lower().endswith("worldcities.csv"):
                roh, pfad = z.read(n), Path(n)
                break
        else:
            for n in z.namelist():
                if n.lower().endswith(".xlsx"):
                    roh, pfad = z.read(n), Path(n)
                    break
            else:
                sys.exit("Im Archiv weder worldcities.csv noch .xlsx gefunden")

    if pfad.suffix.lower() == ".xlsx":
        it = xlsx_zeilen(roh)
        kopf = next(it)
        return kopf, it
    text = roh.decode("utf-8", "replace")
    leser = csv.reader(io.StringIO(text))
    kopf = next(leser)
    return kopf, leser


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quelle", type=Path)
    ap.add_argument("--min-einwohner", type=int, default=0)
    ap.add_argument("--pruefen", action="store_true")
    ap.add_argument("--ueberschreiben", action="store_true",
                    help="vorhandene staedte.csv ersetzen (Vorgabe: behalten)")
    ap.add_argument("--ascii", action="store_true",
                    help="Spalte city_ascii statt city — findet 'Reykjavik' "
                         "auch ohne Akzent, weicht aber von der Schreibweise "
                         "des Originals ab")
    a = ap.parse_args()

    quelle = a.quelle or (ZIEL / "worldcities.xlsx")
    if not quelle.is_file():
        sys.exit(f"Quelle nicht gefunden: {quelle}")

    kopf, zeilen = quelle_lesen(quelle)
    klein = [k.strip().lower() for k in kopf]

    def spalte(*namen):
        for n in namen:
            if n in klein:
                return klein.index(n)
        return None

    i_stadt = spalte("city_ascii", "city", "name") if a.ascii \
              else spalte("city", "city_ascii", "name")
    i_lat = spalte("lat", "latitude")
    i_lon = spalte("lng", "lon", "longitude")
    i_land = spalte("country")
    i_pop = spalte("population")
    if None in (i_stadt, i_lat, i_lon, i_land):
        sys.exit(f"Spalten fehlen. Kopfzeile war: {kopf}")

    nach_land = {}
    verworfen = 0
    for r in zeilen:
        try:
            stadt = (r[i_stadt] or "").strip()
            land = (r[i_land] or "").strip()
            lat = float(r[i_lat])
            lon = float(r[i_lon])
        except (IndexError, ValueError):
            verworfen += 1
            continue
        if not stadt or not land:
            verworfen += 1
            continue
        if a.min_einwohner and i_pop is not None:
            try:
                if float(r[i_pop] or 0) < a.min_einwohner:
                    continue
            except ValueError:
                pass
        nach_land.setdefault(UNGUELTIG.sub("-", land), []).append((stadt, lat, lon))

    gesamt = sum(len(v) for v in nach_land.values())
    print(f"Quelle       : {quelle}")
    print(f"Laender      : {len(nach_land)}")
    print(f"Orte         : {gesamt}")
    if verworfen:
        print(f"uebersprungen: {verworfen} (unvollstaendige Zeilen)")

    if a.pruefen:
        print("\n--pruefen: nichts geschrieben.")
        for land in sorted(nach_land)[:8]:
            print(f"   {land:<28} {len(nach_land[land]):>5} Orte")
        print("   ...")
        return 0

    neu = behalten = 0
    for land, orte in sorted(nach_land.items()):
        ordner = ZIEL / land
        datei = ordner / "staedte.csv"
        # NICHTS KAPUTT MACHEN: eine vorhandene Liste kann von Hand gepflegt
        # oder aus dem Original sein und mehr Orte enthalten als die Tabelle.
        if datei.exists() and not a.ueberschreiben:
            behalten += 1
            continue
        ordner.mkdir(parents=True, exist_ok=True)
        with datei.open("w", encoding="utf-8", newline="") as f:
            s = csv.writer(f)
            s.writerow(["name", "lat", "lon"])
            for stadt, lat, lon in sorted(orte):
                s.writerow([stadt, f"{lat:.4f}", f"{lon:.4f}"])
        neu += 1

    print(f"\n✅ {neu} Laenderordner angelegt unter {ZIEL}")
    if behalten:
        print(f"   {behalten} vorhandene Datei(en) unangetastet gelassen")
        print("   (mit --ueberschreiben ersetzen)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
