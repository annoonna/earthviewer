#!/usr/bin/env python3
"""
messen.py — Kennzahlen der Portierung. Misst statt zu behaupten.

Aufruf: ./werkzeug/messen.py [--zip ORIGINAL.zip] [--schnell]

Gemessen wird:
  * Quelltextumfang Python (aus der ZIP) vs. Rust
  * Testanzahl und Testlaufzeit
  * Bauzeit (kalt/inkrementell) und Binaergroesse
  * Startzeit bis zum ersten Frame (nur mit Display)
  * unsafe-Bloecke und ihre Verteilung
"""
import argparse, json, re, subprocess, sys, time, zipfile
from pathlib import Path

WURZEL = Path(__file__).resolve().parent.parent
TOT = re.compile(r"(\.bak(_\d+)?$|\.backup(_\d+)?$|\.BROKEN$|\(Kopie\)|__pycache__)")


def lauf(cmd, timeout=1800, cwd=WURZEL):
    t0 = time.perf_counter()
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True,
                       text=True, timeout=timeout)
    return r, time.perf_counter() - t0


def zeilen_python(zpfad):
    lebend = tot = dateien = 0
    with zipfile.ZipFile(zpfad) as zf:
        for n in zf.namelist():
            if not n.endswith(".py"):
                continue
            z = zf.read(n).decode("utf-8", "ignore").count("\n")
            if TOT.search(n):
                tot += z
            else:
                lebend += z
                dateien += 1
    return lebend, tot, dateien


def zeilen_rust():
    code = test = dateien = 0
    for p in WURZEL.glob("crates/**/*.rs"):
        txt = p.read_text(encoding="utf-8", errors="ignore")
        dateien += 1
        in_test = False
        tiefe = 0
        for zeile in txt.splitlines():
            if "#[cfg(test)]" in zeile:
                in_test = True
                tiefe = 0
            if in_test:
                test += 1
                tiefe += zeile.count("{") - zeile.count("}")
                if tiefe <= 0 and "}" in zeile and test > 1:
                    in_test = False
            else:
                code += 1
    return code, test, dateien


def unsafe_bloecke():
    treffer = {}
    for p in WURZEL.glob("crates/**/*.rs"):
        n = len(re.findall(r"\bunsafe\s*\{", p.read_text(encoding="utf-8", errors="ignore")))
        if n:
            treffer[str(p.relative_to(WURZEL))] = n
    return treffer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", type=Path,
                    default=Path("/mnt/user-data/uploads/earthviewer_v0_2_miniCaptureExtra.zip"))
    ap.add_argument("--schnell", action="store_true", help="ohne kalten Build")
    ap.add_argument("--json", type=Path)
    a = ap.parse_args()
    m = {}

    print("=" * 66)
    print("MESSUNG  EarthViewer Rust")
    print("=" * 66)

    # ── Umfang ────────────────────────────────────────────────────────────
    if a.zip.is_file():
        leb, tot, pyd = zeilen_python(a.zip)
        m["python_lebend"], m["python_tot"], m["python_dateien"] = leb, tot, pyd
        print(f"\nPython (Original, aus ZIP gelesen)")
        print(f"  lebender Code      : {leb:>7} Zeilen in {pyd} Dateien")
        print(f"  Backup-Leichen     : {tot:>7} Zeilen  ({tot/max(leb+tot,1)*100:.0f} % des Archivs)")

    rc, rt, rd = zeilen_rust()
    m["rust_code"], m["rust_test"], m["rust_dateien"] = rc, rt, rd
    print(f"\nRust (Portierung)")
    print(f"  Code               : {rc:>7} Zeilen in {rd} Dateien")
    print(f"  davon Tests        : {rt:>7} Zeilen  ({rt/max(rc+rt,1)*100:.0f} %)")

    # ── unsafe ────────────────────────────────────────────────────────────
    us = unsafe_bloecke()
    m["unsafe"] = us
    gesamt = sum(us.values())
    print(f"\nunsafe-Bloecke       : {gesamt}")
    for f, n in sorted(us.items()):
        print(f"  {n:>3}x  {f}")
    if set(us) and all("gl_util" in f for f in us):
        print("  -> vollstaendig in gl_util.rs gekapselt")

    # ── Tests ─────────────────────────────────────────────────────────────
    print("\nTests")
    r, dauer = lauf("cargo test --workspace --offline 2>&1")
    n = sum(int(x) for x in re.findall(r"(\d+) passed", r.stdout))
    fehl = sum(int(x) for x in re.findall(r"(\d+) failed", r.stdout))
    m["tests"], m["tests_failed"], m["test_sekunden"] = n, fehl, round(dauer, 1)
    print(f"  bestanden          : {n}")
    print(f"  fehlgeschlagen     : {fehl}")
    print(f"  Laufzeit           : {dauer:.1f} s")

    # ── Bauzeit ───────────────────────────────────────────────────────────
    print("\nBauzeit")
    r, dauer = lauf("touch crates/ev-app/src/main.rs && cargo build --release -p ev-app --offline 2>&1")
    m["build_inkrementell_s"] = round(dauer, 1)
    print(f"  inkrementell       : {dauer:.1f} s")
    if not a.schnell:
        r, dauer = lauf("cargo clean -p ev-app && cargo build --release -p ev-app --offline 2>&1")
        m["build_kalt_s"] = round(dauer, 1)
        print(f"  ev-app von vorn    : {dauer:.1f} s")

    binaer = WURZEL / "target/release/earthviewer"
    if binaer.exists():
        mb = binaer.stat().st_size / 1e6
        m["binaer_mb"] = round(mb, 1)
        print(f"  Binaergroesse      : {mb:.1f} MB")

    # ── Startzeit ─────────────────────────────────────────────────────────
    import os
    if os.environ.get("DISPLAY"):
        print("\nStart")
        t0 = time.perf_counter()
        pr = subprocess.Popen([str(binaer)], stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True,
                              env={**os.environ, "EARTHVIEWER_ROOT": str(WURZEL)})
        erster = None
        while time.perf_counter() - t0 < 60:
            line = pr.stdout.readline()
            if not line:
                break
            if "Renderer initialisiert" in line:
                erster = time.perf_counter() - t0
                break
        pr.terminate()
        if erster:
            m["start_bis_renderer_s"] = round(erster, 2)
            print(f"  bis Renderer bereit: {erster:.2f} s")
        else:
            print("  (Renderer-Meldung nicht gesehen)")
    else:
        print("\nStart: uebersprungen (kein DISPLAY)")

    print("\n" + "=" * 66)
    if a.json:
        a.json.write_text(json.dumps(m, indent=2), encoding="utf-8")
        print(f"Kennzahlen: {a.json}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
