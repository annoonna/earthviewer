#!/usr/bin/env python3
"""
staedte_aufteilen.py — macht aus simplemaps `worldcities.csv` eine
Ordnerstruktur, die der Loader versteht.

Warum noetig: `geo_manager.py` nimmt den **Ordnernamen** als Land
(`country = csv_file.parent.name`) und ignoriert eine Spalte `country`.
Eine einzelne grosse CSV wuerde also alle Staedte demselben Land zuordnen.

    ./werkzeug/staedte_aufteilen.py worldcities.csv data/geodata
    ./werkzeug/staedte_aufteilen.py worldcities.csv data/geodata --min-einwohner 50000
"""
import argparse, csv, sys
from collections import defaultdict
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv_datei", type=Path)
    ap.add_argument("ziel", type=Path)
    ap.add_argument("--min-einwohner", type=int, default=0,
                    help="kleinere Orte ueberspringen (Spalte population)")
    a = ap.parse_args()

    if not a.csv_datei.is_file():
        sys.exit(f"nicht gefunden: {a.csv_datei}")

    nach_land = defaultdict(list)
    uebersprungen = 0
    with a.csv_datei.open(encoding="utf-8-sig", newline="") as f:
        for zeile in csv.DictReader(f):
            name = (zeile.get("city") or zeile.get("city_ascii") or
                    zeile.get("name") or "").strip()
            land = (zeile.get("country") or "Unknown").strip() or "Unknown"
            lat = zeile.get("lat") or zeile.get("latitude")
            lon = zeile.get("lng") or zeile.get("lon") or zeile.get("longitude")
            if not name or not lat or not lon:
                uebersprungen += 1
                continue
            if a.min_einwohner:
                try:
                    if float(zeile.get("population") or 0) < a.min_einwohner:
                        uebersprungen += 1
                        continue
                except ValueError:
                    pass
            # Ordnernamen entschaerfen
            sicher = "".join(c if c.isalnum() or c in " -_" else "_" for c in land).strip()
            nach_land[sicher or "Unknown"].append((name, lat, lon))

    a.ziel.mkdir(parents=True, exist_ok=True)
    gesamt = 0
    for land, orte in sorted(nach_land.items()):
        ordner = a.ziel / land
        ordner.mkdir(exist_ok=True)
        with (ordner / "staedte.csv").open("w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["name", "lat", "lon"])
            w.writerows(orte)
        gesamt += len(orte)

    print(f"✅ {gesamt} Orte in {len(nach_land)} Länderordner geschrieben")
    if uebersprungen:
        print(f"   {uebersprungen} Zeilen übersprungen (unvollständig oder zu klein)")
    print(f"   Ziel: {a.ziel}")
    print("   Danach: ./start.sh — das Startprotokoll nennt die Anzahl.")


if __name__ == "__main__":
    main()
