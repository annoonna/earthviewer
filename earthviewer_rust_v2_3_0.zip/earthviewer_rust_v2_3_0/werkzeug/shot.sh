#!/bin/bash
# shot.sh TAB [TAB…] — startet Xvfb+App je Reiter, legt /tmp/shots/ist_TAB.png ab.
set -u
mkdir -p /tmp/shots
Xvfb :99 -screen 0 1456x819x24 -ac >/dev/null 2>&1 &
XV=$!
sleep 1.5
cd /home/claude/work/rust
for TAB in "$@"; do
  DISPLAY=:99 WINIT_UNIX_BACKEND=x11 EARTHVIEWER_MSAA=0 EARTHVIEWER_TAB="$TAB" \
    ./target/release/earthviewer >/tmp/run_$TAB.log 2>&1 &
  APP=$!
  sleep "${SHOT_WAIT:-9}"
  DISPLAY=:99 import -window root "/tmp/shots/ist_${TAB}.png" 2>/dev/null
  kill $APP 2>/dev/null; wait $APP 2>/dev/null
done
kill $XV 2>/dev/null
ls -la /tmp/shots/
