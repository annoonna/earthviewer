#!/usr/bin/env python3
"""
gegenpruefung.py — Deckungsgrad-Messung Python-Original -> Rust-Portierung.

WICHTIG: Liest die Original-ZIP **direkt** (zipfile), entpackt nichts.
Damit gibt es keinen falschen Pfad und keine veraltete Kopie.

Aufruf:
    ./werkzeug/gegenpruefung.py /pfad/zur/original.zip [--json bericht.json]

Ausgabe: je Python-Symbol (Klasse/Funktion/Konstante) eine Einstufung
  OK       im Rust-Baum gefunden (direkt oder ueber abbildung.json)
  SKIP     bewusst ausgelassen, mit Begruendung
  FEHLT    weder gefunden noch begruendet  <- das sind die echten Funde
"""
import argparse, ast, json, re, sys, zipfile
from collections import defaultdict
from pathlib import Path

HIER = Path(__file__).resolve().parent
WURZEL = HIER.parent

# Dateien, die im Original tote Zweige sind.
TOTE_ZWEIGE = re.compile(
    r"(\.bak(_\d+)?$|\.backup(_\d+)?$|\.BROKEN$|\(Kopie\)|__pycache__|\.orig$|~$)"
)


def zip_oeffnen(pfad):
    """Oeffnet die ZIP; faellt bei sperrigen Archiven auf `unzip` zurueck.

    Gruende fuer den Rueckfall: teilweise geschriebene Uploads, Archive ohne
    Kompression, Zip64-Eigenheiten. `unzip` ist toleranter als zipfile.
    """
    try:
        return zipfile.ZipFile(pfad), None
    except (zipfile.BadZipFile, OSError) as e:
        import shutil, subprocess
        if not shutil.which("unzip"):
            sys.exit(f"ZIP unlesbar ({e}) und `unzip` nicht vorhanden.")
        namen = subprocess.run(["unzip", "-Z1", str(pfad)],
                               capture_output=True, text=True).stdout.split("\n")
        namen = [n for n in namen if n and not n.endswith("/")]

        class UnzipHuelle:
            def namelist(self):
                return namen

            def read(self, name):
                return subprocess.run(["unzip", "-p", str(pfad), name],
                                      capture_output=True).stdout

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

        print(f"ℹ️  zipfile scheiterte ({e}) — nutze `unzip`.")
        return UnzipHuelle(), "unzip"


def python_dateien(zf):
    """Alle lebenden .py-Eintraege der ZIP, ohne Backups."""
    for n in zf.namelist():
        if not n.endswith(".py"):
            continue
        if TOTE_ZWEIGE.search(n):
            continue
        yield n


def symbole_aus(quelle, pfad):
    """Klassen, Funktionen und Modul-Konstanten einer Datei."""
    try:
        baum = ast.parse(quelle, filename=pfad)
    except SyntaxError as e:
        return [], f"SyntaxError: {e}"
    gefunden = []
    for knoten in baum.body:
        if isinstance(knoten, ast.ClassDef):
            gefunden.append(("class", knoten.name, knoten.lineno))
            for k in knoten.body:
                if isinstance(k, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if not k.name.startswith("__"):
                        gefunden.append(("method", f"{knoten.name}.{k.name}", k.lineno))
        elif isinstance(knoten, (ast.FunctionDef, ast.AsyncFunctionDef)):
            gefunden.append(("func", knoten.name, knoten.lineno))
        elif isinstance(knoten, ast.Assign):
            for ziel in knoten.targets:
                if isinstance(ziel, ast.Name) and ziel.id.isupper():
                    gefunden.append(("const", ziel.id, knoten.lineno))
    return gefunden, None


def rust_korpus():
    """Gesamter Rust-Quelltext + Doku als ein Suchraum."""
    teile = []
    for muster in ("crates/**/*.rs", "docs/*.md", "*.md", "*.sh"):
        for p in WURZEL.glob(muster):
            try:
                teile.append(p.read_text(encoding="utf-8", errors="ignore"))
            except OSError:
                pass
    return "\n".join(teile)


def schlangen_zu_camel(name):
    return "".join(t.capitalize() for t in name.split("_") if t)


def kandidaten(art, name):
    """Wie koennte das Symbol in Rust heissen?"""
    kurz = name.split(".")[-1]
    roh = kurz.lstrip("_")
    k = {kurz, roh, name}
    if art in ("class",):
        k |= {roh, schlangen_zu_camel(roh)}
    else:
        k |= {roh, schlangen_zu_camel(roh)}
        # PyQt-Camel -> Rust-Snake
        k.add(re.sub(r"(?<!^)(?=[A-Z])", "_", roh).lower())
    return {x for x in k if len(x) >= 4}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("zip", type=Path)
    ap.add_argument("--json", type=Path)
    ap.add_argument("--nur-fehlend", action="store_true")
    args = ap.parse_args()

    if not args.zip.is_file():
        sys.exit(f"ZIP nicht gefunden: {args.zip}")

    abb_datei = HIER / "abbildung.json"
    abb = json.loads(abb_datei.read_text(encoding="utf-8")) if abb_datei.exists() else {}
    direkt = abb.get("abgebildet", {})
    ausgelassen = abb.get("ausgelassen", {})

    korpus = rust_korpus()
    korpus_klein = korpus.lower()

    ergebnis = defaultdict(list)
    dateien = 0
    zeilen_gesamt = 0

    zf, _ = zip_oeffnen(args.zip)
    with zf:
        for name in sorted(python_dateien(zf)):
            quelle = zf.read(name).decode("utf-8", errors="ignore")
            zeilen_gesamt += quelle.count("\n")
            dateien += 1
            syms, fehler = symbole_aus(quelle, name)
            if fehler:
                ergebnis["PARSE"].append((name, fehler, 0))
                continue
            modul = name.split("/")[-1]
            for art, sym, zeile in syms:
                schluessel = f"{modul}::{sym}"
                if schluessel in ausgelassen or modul in ausgelassen:
                    grund = ausgelassen.get(schluessel) or ausgelassen.get(modul)
                    ergebnis["SKIP"].append((schluessel, grund, zeile))
                    continue
                if schluessel in direkt:
                    ergebnis["OK"].append((schluessel, direkt[schluessel], zeile))
                    continue
                treffer = next(
                    (k for k in kandidaten(art, sym) if k.lower() in korpus_klein), None
                )
                if treffer:
                    ergebnis["OK"].append((schluessel, f"~{treffer}", zeile))
                else:
                    ergebnis["FEHLT"].append((schluessel, art, zeile))

    ok, skip, fehlt = len(ergebnis["OK"]), len(ergebnis["SKIP"]), len(ergebnis["FEHLT"])
    gesamt = ok + skip + fehlt

    print("=" * 72)
    print(f"GEGENPRUEFUNG  {args.zip.name}")
    print("=" * 72)
    print(f"Python-Dateien (ohne Backups) : {dateien}")
    print(f"Python-Zeilen                 : {zeilen_gesamt}")
    print(f"Symbole gesamt                : {gesamt}")
    print(f"  OK    portiert              : {ok:4d}  ({ok/max(gesamt,1)*100:5.1f} %)")
    print(f"  SKIP  bewusst ausgelassen   : {skip:4d}  ({skip/max(gesamt,1)*100:5.1f} %)")
    print(f"  FEHLT ungeklaert            : {fehlt:4d}  ({fehlt/max(gesamt,1)*100:5.1f} %)")
    print("=" * 72)

    if fehlt:
        print("\nUNGEKLAERTE SYMBOLE (das sind die echten Funde):")
        nach_modul = defaultdict(list)
        for sym, art, zeile in ergebnis["FEHLT"]:
            nach_modul[sym.split("::")[0]].append((sym.split("::")[1], art, zeile))
        for modul in sorted(nach_modul):
            print(f"\n  {modul}")
            for sym, art, zeile in sorted(nach_modul[modul]):
                print(f"    Z.{zeile:<5} {art:<7} {sym}")

    if args.json:
        args.json.write_text(json.dumps(
            {k: [list(x) for x in v] for k, v in ergebnis.items()},
            indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"\nBericht: {args.json}")

    return 1 if fehlt else 0


if __name__ == "__main__":
    sys.exit(main())
