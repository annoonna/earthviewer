# Portierungs-Notizen: Python → Rust

Diese Datei ist das Gedächtnis der Portierung. Sie beantwortet für jede
Python-Datei die Frage: *Wo ist das jetzt, und was hat sich geändert?*

---

## A. Datei-für-Datei-Zuordnung

### A1. Übernommen

| Python | Rust | Anmerkung |
|---|---|---|
| `main.py` | `crates/ev-app/src/main.rs` | Banner + Fenster-Setup identisch |
| `src/core/config.py` | `ev-core/src/config.rs` | Konstanten 1:1; Pfade als Funktionen |
| `src/core/config.py` (THEMES) | `ev-core/src/theme.rs` | alle 6 Themes, gleiche RGB-Werte |
| `src/core/settings.py` | `ev-core/src/settings.rs` | + API-Key-Filter beim Speichern |
| `src/core/geo_location.py` | `ev-core/src/geo.rs` | `to_cartesian`, `to_uv`, Haversine |
| `src/utils/matrix_utils.py` | `ev-core/src/math.rs` | numpy → glam, siehe **B1** |
| `src/data/geo_manager.py` | `ev-geo/src/lib.rs` | rglob → iterativer Walk |
| `geoip2` (PyPI) | `ev-geo/src/mmdb.rs` | `maxminddb`-Crate |
| `src/network/connection_tracker.py` | `ev-net/src/connections.rs` | psutil → `/proc`, siehe **B2** |
| `src/network/ping.py` | `ev-net/src/ping.rs` | Generator → mpsc-Channel |
| `src/network/traceroute.py` | `ev-net/src/traceroute.rs` | Parser toleranter, siehe **C1** |
| `src/network/whois_lookup.py` | `ev-net/src/whois.rs` | + Referral-Verfolgung, siehe **C2** |
| `src/network/arp_scanner.py` | `ev-net/src/arp.rs` | scapy → passiv, siehe **B4** |
| `src/network/virustotal_analyzer.py` | `ev-net/src/virustotal.rs` | requests → ureq |
| `src/utils/orbit_calculator.py` | `ev-sat/src/propagate.rs` | skyfield → `sgp4`, siehe **B3** |
| `src/data/satellite_manager.py` | `ev-sat/src/catalog.rs` | + TLE-Cache, siehe **C3** |
| `src/rendering/sphere_geometry.py` | `ev-render/src/geometry.rs` | identische Formeln |
| `src/rendering/shaders.py` | `ev-render/src/shaders.rs` | GLSL **wörtlich** übernommen |
| `src/rendering/gl_renderer.py` | `ev-render/src/globe.rs` | PyOpenGL → glow |
| `src/ui/widgets/globe_widget.py` | `ev-app/src/globe_view.rs` | QOpenGLWidget → egui-Callback |
| `src/ui/widgets/main_window.py` | `ev-app/src/app.rs` | + alle Tab-Klassen |
| `src/ui/widgets/sidebar.py` | `ev-app/src/app.rs` (`side_panel`) | |
| `src/ui/theme_dialog.py` | `ev-app/src/app.rs` (`settings_tab`) | Dialog → Tab |

### A2. Bewusst NICHT übernommen

| Python | Warum nicht |
|---|---|
| `*.bak_*`, `*.backup_*`, `* (Kopie).py` | 14 Sicherungskopien von `globe_widget.py`, 6 von `satellite_integration.py`. Alles tote Zweige. |
| `src/core/satellite_tracker_engine.py.BROKEN` | Dateiendung sagt alles. |
| `install.py` (1593 Zeilen) | Baute ein venv + pip-Umgebung. `cargo` erledigt das. |
| `patch_connection_arcs.py` | Einmal-Patchskript, dessen Ergebnis bereits in `globe_widget.py` steht. |
| `tools/setup_satellite_*.py` | Generatoren, deren Ausgabe schon eingecheckt war. |
| `wifi_capture.py`, `wifi_monitor_panel*.py` | **Bewusst offen gelassen — siehe Abschnitt E.** |
| `src/data/spectator_api.py` | Fremd-API ohne dokumentierten Endpunkt; durch Celestrak ersetzt. |
| `src/ui/widgets/*_large_window.py` (4×) | Waren nur „gleicher Inhalt, größeres Fenster". In egui macht das der Fensterrahmen. |

### A3. Ersetzte Abhängigkeiten

| Python-Paket | Rust | Grund |
|---|---|---|
| PyQt6 | `eframe` / `egui` 0.31 | Immediate-Mode, kein C++-Unterbau |
| PyOpenGL | `glow` 0.16 | von eframe mitgeliefert, ein Kontext für alles |
| numpy | `glam` 0.27 | siehe **B1** |
| Pillow | `image` 0.25 | nur JPEG+PNG aktiviert |
| psutil | *keine* | `/proc` direkt, siehe **B2** |
| scapy | *keine* | passiver ARP-Cache, siehe **B4** |
| skyfield + sgp4 | `sgp4` 1.2 | siehe **B3** |
| geoip2 | `maxminddb` 0.24 | |
| requests | `ureq` 2 | blockierend, kein Tokio nötig |
| pyqtgraph | *keine* | Diagramme zeichnet egui selbst |

---

## B. Die vier Stellen, an denen es ernst wurde

### B1. numpy row-major vs. glam column-major

**Das Problem.** NumPy speichert zeilenweise und wendet Matrizen als `M @ v` an.
glam speichert **spaltenweise** und wendet sie als `M * v` an. Wer die Zahlen
aus `matrix_utils.py` in Lesereihenfolge in `Mat4::from_cols_array` kippt,
bekommt eine transponierte Matrix und einen Globus, der sich falsch dreht.

**Die Lösung.** In `ev-core/src/math.rs` werden ausschließlich glam-Konstruktoren
benutzt (`from_axis_angle`, `perspective_rh_gl`, `from_translation`). Die
*mathematischen* Matrizen sind dann identisch mit den Python-Versionen.

**Was gleich bleibt.** Die Multiplikationsreihenfolge:
Python `rot_x @ rot_y @ base` == Rust `rot_x * rot_y * base`.

**Beim Hochladen an die GPU** ist `transpose = false` korrekt, weil glam und
GLSL beide column-major sind. Steht so in `gl_util.rs::set_mat4`.

Abgesichert durch `math::tests::rotation_matches_python_rodrigues`.

### B2. psutil → `/proc/net/*`

`psutil.net_connections(kind='inet')` liest intern genau das, was wir jetzt
selbst lesen: `/proc/net/tcp`, `tcp6`, `udp`, `udp6`.

Zwei Fallstricke, beide in `proc_net.rs` behandelt und getestet:

1. **IPv4-Adressen stehen little-endian im Hex.** `0100007F` ist `127.0.0.1`,
   nicht `1.0.0.127`.
2. **IPv6 sind vier separate little-endian 32-Bit-Wörter**, nicht ein einzelner
   128-Bit-Wert.

Das Prozess-Mapping (`inode → PID → Name`) läuft über `/proc/*/fd/*`-Symlinks
der Form `socket:[12345]`. Ohne root sieht man nur eigene Prozesse — **genau
wie bei psutil**, das ist kein Rückschritt.

### B3. 🐞 Satelliten-Bezugssystem (echter Fehler im Original)

`orbit_calculator.py` gab Positionen im **inertialen** System (TEME) zurück.
`globe_widget.py` zeichnete sie direkt auf die **erdfeste** Textur-Kugel.

Folge: Alle Satelliten wanderten mit rund 15°/h gegenüber ihrer echten
Bodenspur. Nach sechs Stunden Laufzeit stand die ISS 90° neben der Wahrheit.

**Korrektur** in `ev-sat/src/frames.rs`: TEME → ECEF über eine Drehung um
−GMST (Greenwich Mean Sidereal Time, IAU-1982-Reihe).

`Frame::Inertial` reproduziert das alte Verhalten — falls du vergleichen willst.
`Frame::EarthFixed` ist Standard.

Abgesichert durch `frames::tests::gmst_is_in_range_and_advances`
(prüft die 15,041°/Sternstunde) und `propagate::tests::earthfixed_and_inertial_differ`.

**Zusätzlicher Fund:** `calculate_ground_track()` benutzte
`x=cos·cos, y=cos·sin, z=sin` — `GeoLocation.to_cartesian` aber
`x=cos·sin, y=sin, z=cos·cos`. Die Achsen waren also **zusätzlich** vertauscht.
Bodenspuren lagen komplett woanders als die Städte. Korrigiert in
`propagate::ground_track`, abgesichert durch
`frames::tests::globe_axes_match_geolocation_convention`.

### B4. scapy → passiver ARP-Cache

Das Original verschickte mit scapy rohe ARP-Requests. Das braucht `CAP_NET_RAW`
(praktisch: root) und legt Pakete auf den Draht.

Die Rust-Fassung liest stattdessen `/proc/net/arp` — den Nachbar-Cache, den der
Kernel ohnehin führt. Kein root, keine eigenen Pakete.

`arp::sweep_hint()` kann den Cache aktiv füllen, aber **nur mit gewöhnlichen
leeren UDP-Datagrammen an Port 9 (Discard)**. Kein Raw-Socket, keine gefälschten
Header. Das ist eine bewusste Entscheidung: Ein Werkzeug, das im fremden WLAN
ungefragt ARP-Stürme auslöst, will man nicht versehentlich starten.

Als Zugabe gibt es eine kleine OUI-Tabelle (Raspberry Pi, AVM, VMware, QEMU …),
die das Original gar nicht hatte.

### B5. 🐞 Blickwinkel-Presets zeigten das Falsche (echter Fehler im Original)

`globe_widget.align_view()` benutzte fest verdrahtete Matrizen, die nicht zu
`_align_to_location()` passten. **Drei von fünf Presets** zeigten etwas anderes
als ihr Name versprach:

| Preset | Original | zeigte tatsächlich |
|---|---|---|
| Nordpol | `rotation(180, X)` | Äquator bei 180° |
| Südpol | `IDENTITY` | Äquator bei 0° |
| Äquator | `rotation(90, X)` | **Nordpol** |
| Deutschland | `_align_to_location(...)` | korrekt |
| Ziel | `_align_to_location(...)` | korrekt |

Die beiden korrekten Presets riefen `_align_to_location()` auf, die drei
falschen nicht — es gab zwei Quellen der Wahrheit, die auseinandergelaufen sind.

**Herleitung.** Aus `align_to(lat, lon) = rot_x(lat−90) · rot_y(−lon) · rot_x(90)`:
- lat = +90 → `rotation(90, X)` — Nordpol
- lat = 0 → `IDENTITY` — Äquator
- lat = −90 → `rotation(−90, X)` — Südpol

Die Original-Werte für Nordpol und Äquator waren also genau vertauscht bzw.
um 90° daneben.

**Korrektur.** `align_preset()` ruft jetzt ausschließlich `align_to()` auf.
Eine Quelle der Wahrheit, kein Auseinanderlaufen mehr möglich.

Abgesichert durch vier Tests (`north_pole_preset_shows_the_north_pole` usw.),
die jeweils prüfen, dass der benannte Punkt tatsächlich im View-Raum nach
+Z zeigt. `original_hardcoded_matrices_were_wrong` dokumentiert den Fehler.

**Nebenwirkung: Startansicht.** Das Original startete mit `rotation(90, X)` —
also mit Blick auf den Nordpol. Das sieht aus, als sei die Textur kaputt (siehe
`docs/screenshot_bug.png`). Die Rust-Fassung startet auf Mitteleuropa; der
Polblick ist über das Preset weiterhin erreichbar.

### B6. Multisampling ist nicht überall verfügbar

`main.py` setzte `fmt.setSamples(4)` fest. Qt fiel still auf 0 zurück, wenn der
Treiber das nicht anbot. `eframe`/`glutin` tut das **nicht** — es bricht mit
`NoGlutinConfigs` ab, und zwar auf:

- llvmpipe / Xvfb (Software-Rendering, CI, Server ohne GPU)
- virtuellen GPUs (VMware SVGA, QXL, virtio-gpu ohne Venus)
- älteren Intel-iGPUs mit begrenzten FBConfigs

`main.rs` probiert deshalb die Kette 4× → 2× → 0× durch und meldet den Rückfall
auf stderr. Über `EARTHVIEWER_MSAA=0` erzwingbar.

⚠️ Beim Prüfen der Variante **nicht** auf `e.to_string()` matchen — die
`Display`-Ausgabe von `eframe::Error::NoGlutinConfigs` lautet „Found no glutin
configs matching the template…" und enthält den Variantennamen gerade nicht.
`matches!(e, eframe::Error::NoGlutinConfigs(..))` benutzen.

---

## C. Kleinere Verbesserungen

### C1. Traceroute-Parser
Das Original-Regex verlangte `hostname (ip) rtt ms` in exakt dieser Form.
Hops ohne Reverse-DNS (nur nackte IP) fielen durch. Der Rust-Parser
akzeptiert beide Formen. Test: `parses_bare_ip_hop`.

### C2. WHOIS-Referrals
Das Original fragte `whois.iana.org` und gab dessen Antwort aus — also
meistens nur „frag mal RIPE". Jetzt werden bis zu zwei `refer:`/`whois:`/
`ReferralServer:`-Verweise verfolgt, man bekommt die echten Daten.

### C3. TLE-Cache
Ohne Internet zeigte das Original gar keine Satelliten. Jetzt werden geladene
TLE unter `sessions/tle_<gruppe>.txt` abgelegt und beim Start zuerst von dort
gelesen. Reihenfolge: Cache → Netz → leer.

### C4. Textur-Fallback
Fehlte `data/textures/earth_map.jpg`, war die Kugel schwarz. Jetzt erzeugt
`gl_util::fallback_texture()` ein 512×256-Gradnetz mit markiertem Äquator —
man sieht sofort, dass die Textur fehlt, statt einen Renderfehler zu vermuten.

### C5. Richtungslogik wählbar
Das Original bestimmte „eingehend/ausgehend" per `md5(key) % 2` — eine rein
optische 50/50-Heuristik, im Quelltext auch so kommentiert. Beibehalten als
`DirectionMode::Balanced5050` (Standard, FNV-1a statt MD5). Neu daneben:
`DirectionMode::Real`, das lauschende lokale Ports auswertet. Umschaltbar im
Netzwerk-Tab.

---

## D. Was sich im Verhalten sichtbar ändert

| Vorher | Nachher |
|---|---|
| Satelliten driften gegen die Bodenspur | stehen erdfest korrekt |
| Bodenspuren an völlig falscher Position | korrekt |
| WHOIS liefert nur den IANA-Verweis | liefert die echten RIR-Daten |
| Kein Internet → keine Satelliten | Cache aus `sessions/` |
| Fehlende Textur → schwarze Kugel | sichtbares Gradnetz |
| ARP-Scan braucht root | läuft ohne root (passiv) |
| Traceroute überspringt Hops ohne DNS | zeigt sie |
| „Äquator" zeigt den Nordpol | zeigt den Äquator |
| „Nordpol"/„Südpol" zeigen den Äquator | zeigen die Pole |
| Start mit Blick auf den Nordpol | Start auf Mitteleuropa |
| Ohne MSAA-Unterstützung: Absturz | Rückfall 4×→2×→0× |
| API-Key liegt in `settings.json` | nur aus `$EARTHVIEWER_VT_API_KEY` |

---

## E. Bewusst offen gelassen: WiFi-Capture

`src/network/wifi_capture.py` (268 Zeilen) und die zugehörigen Panels setzen
das WLAN-Interface in den Monitor-Modus und schneiden fremden Funkverkehr mit.

Das ist **nicht portiert**, und zwar aus zwei Gründen:

1. **Technisch** braucht es `CAP_NET_RAW` + `CAP_NET_ADMIN`, einen
   nl80211-Netlink-Stack und einen Treiber, der Monitor-Modus kann. In Rust
   wäre das ein eigenes Teilprojekt (`neli` oder `nl80211`-Bindings), kein
   Nebenprodukt dieser Portierung.

2. **Rechtlich** ist das Mitschneiden fremden WLAN-Verkehrs in Deutschland
   nach § 202b StGB (Abfangen von Daten) strafbar, wenn es nicht das eigene
   Netz ist oder eine Einwilligung vorliegt. Für Pentests im Auftrag gilt das
   nicht — aber dann willst du ohnehin `airmon-ng`/`hcxdumptool`, die das
   deutlich besser können als ein selbstgebauter Sniffer.

Falls du es doch brauchst: Der saubere Weg wäre ein separates Crate
`ev-wifi` mit `nl80211`-Bindings, das nur startet, wenn ein explizites
`--i-have-authorization`-Flag gesetzt ist. Das ist bewusst *deine*
Entscheidung, nicht meine.

Die übrigen Security-Funktionen (Connection-Tracking, ARP-Nachbarschaft,
GeoIP, VirusTotal, WHOIS, Traceroute) sind vollständig portiert — die
betreffen alle den eigenen Rechner bzw. öffentlich abfragbare Daten.
