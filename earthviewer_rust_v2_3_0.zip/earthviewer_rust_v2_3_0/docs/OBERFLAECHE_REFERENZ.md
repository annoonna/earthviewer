# Oberflächen-Referenz aus den Original-Bildschirmfotos

Quelle: `Bildschirmfoto_vom_2026-08-21_14-2.zip` — 34 Aufnahmen, 1920×1080,
vom laufenden **EarthViewer 2.0** (Python/PyQt6).

Diese Datei ist die **Sollvorgabe**. Bis v0.4.0 habe ich die Oberfläche aus dem
Quelltext erschlossen; das war ungenau. Was hier steht, ist gesehen, nicht
vermutet. Abweichungen sind mit ❌ markiert und in `RELAY.md` §4 als Aufgabe
hinterlegt. Verkleinerte Originale liegen in `docs/referenz/`.

**Stand v0.5.0** — angeglichen: Kopfzeile mit Titel, Statuszeile,
Zoom-Fussleiste, einzeilig scrollende Reiterleiste, Steuerungs-Reiter
(grosses Steuerkreuz, Auto-Rotation als Umschaltknopf, Ansicht als
Auswahlfeld, nur zwei Optionen), Graph als gestapeltes Flaechendiagramm in
KB/s mit 300 Punkten, Durchsatzmessung aus `/proc/net/dev`.
**Stand v0.9.0** — zusätzlich: Satelliten-Reiter auf das Original-Modell
(Gruppen als Ankreuzfelder, Einzelauswahl je Objekt, „Alle auswählen/abwählen",
Fußzeile `N/M aktiv`), Beschriftungen werden ausgedünnt.
Noch offen: ⚙/🎨-Knöpfe in der Kopfzeile, Byte-Zahlen je App im Monitoring.

**Stand v0.8.0** — zusätzlich: Farben und Schriftgrößen aus `config.py`
übernommen, Scrollbalken belegen eigene Spalte (kein Text mehr dahinter),
Monitoring vierspaltig, Zeichenvorrat geprüft (`ev-app::glyphen`).

**Stand v0.6.0** — zusaetzlich: texturierte Satelliten-Sprites
(`satellite_icon.png`, Original-Shader woertlich), Satelliten laden beim Start
selbsttaetig aus Cache bzw. Notreserve, Traceroute-Ausgabe im
Original-Format.
Noch offen: Satelliten-Reiter-Modell (Celestrak-Gruppen als Ankreuzfelder mit
Einzelauswahl), Monitoring als vier Tabellen nebeneinander, ⚙/🎨-Knoepfe,
Ausduennen ueberlappender Beschriftungen.

---

## 0. Das Gestaltungsmuster

Nachgemessen an den Original-Aufnahmen (waagerechte Rahmenlinien in der
Seitenleiste zaehlen, `werkzeug/farben.py`):

| Reiter | Rahmenlinien bei y |
|---|---|
| Suche | 459, 1011 → **ein Kasten** um die Trefferliste |
| Netzwerk | 305, 1021 → **ein Kasten** um das Ergebnis |
| Steuerung | 460, 558, 617, 658, 669, 710 → **kein Kasten**, nur umrahmte Knoepfe |
| Satelliten | zwei Kaesten („Globus Anzeige", „Aktive Satelliten") |

Daraus die Regel, die seit v1.9.0 durchgaengig gilt:

1. **Inhaltsbereiche bekommen einen Rahmen** (`#555555`) — Listen, Tabellen,
   Ergebnisfelder. Werkzeug: `tabs::rahmen()` bzw. `tabs::gruppe(titel, …)`.
2. **Knoepfe gehen ueber die volle Breite**, Hauptaktionen tuerkis `#0d7377`.
   Werkzeug: `tabs::breiter_knopf()`.
3. **Ueberschriften** 18 px fett, Zwischenueberschriften 16 px.
4. Reine Bedienabschnitte (Steuerkreuz, Optionen) bleiben **ohne** Kasten.

## 1. Rahmen

| Element | Original | Rust v0.4.0 |
|---|---|---|
| Fenstertitel | `EarthViewer 2.0` | `EarthViewer 3.0 — Rust Edition` |
| Suchleiste | volle Breite, Lupe links, Knopf **Suchen** rechts, dahinter ⚙ und 🎨 | ✅ ähnlich, ⚙/🎨 fehlen ❌ |
| Platzhalter | `Stadt, Land, IP oder mehrere Städte (z.B. 'berlin leipzig koblenz' oder '52.52, 13.405')` | abweichend ❌ |
| Seitenleiste | rechts, ~370 px | ✅ |
| Kopf der Leiste | `🌍 EarthViewer 2.0` groß in Türkis | fehlt ❌ |
| Statuszeile | `Status: Bereit` / `Status: 50 Ergebnisse gefunden` | fehlt ❌ |
| Fuß der Leiste | `Zoom: 5.9x` (ändert sich beim Zoomen) | fehlt ❌ |

## 2. Reiterleiste

**Einzeilig und scrollend**, mit Pfeilen am rechten Rand. Nicht umbrechend.
✅ seit v1.7.0. Nachgemessen (`werkzeug/farben.py`, Zeile y=286 im Original):

| | Farbe |
|---|---|
| aktiver Reiter | `#0D7377` |
| inaktiver Reiter | `#3A3A3A` |
| Luecke dazwischen | `#2B2B2B`, 2 px |

⚠️ In v1.5.0 hatte ich den Rollbalken versteckt und die Pfeile **vergessen** —
damit waren 8 von 13 Reitern unerreichbar.

Gesehene Reiter in dieser Reihenfolge:

`⚙ Steuerung` · `🔍 Suche` · `⭐ Favoriten` · `🌐 Netzwerk` ·
`🔴 Live Verbindungen` · `📊 Monitoring` · `🖥 Control Center` · `📈 Graph` ·
`🔒 Schützen` · `📊 Protokoll Analyse` · `🔍 Netzwerk Scanner` · `🛰 Satelliten`

= **12 Reiter**. Einstellungen und Theme laufen über ⚙/🎨 in der Kopfzeile,
nicht über Reiter. (v0.4.0 hat 13, weil Einstellungen ein Reiter ist — das ist
vertretbar, aber die ⚙/🎨-Knöpfe fehlen trotzdem.)

## 3. Reiter im Einzelnen

### ⚙ Steuerung
- `🎮 Navigation` — Steuerkreuz aus **großen** Knöpfen (~115×60 px):
  obere Zeile mittig `⬆`, untere Zeile `⬅` `⬇` `➡`
- `🔧 Funktionen` — drei **Knöpfe** über volle Breite:
  `Auto-Rotation` (Umschalter), `↺ Zurücksetzen`, `📸 Screenshot`
  ❌ v0.4.0 hat Auto-Rotation als Ankreuzfeld
- `👁 Ansicht` — **ein Auswahlfeld** (ComboBox), Wert z. B. `Deutschland`
  ❌ v0.4.0 zeigt fünf einzelne Knöpfe
- `⚡ Optionen` — genau zwei Ankreuzfelder:
  `📍 Marker anzeigen`, `🏷 Namen anzeigen`
  ❌ v0.4.0 hat zusätzlich Satelliten-Schalter und zwei Schieberegler

### 🔍 Suche
- eigenes Eingabefeld, Platzhalter `Stadt, IP, Koordinaten...`
- **großer türkiser Knopf** `🔍 Suchen` über volle Breite
- `📍 Suchergebnisse` + umrahmte Liste

### 🌐 Netzwerk
- `🌐 Netzwerk-Tool` + Auswahlfeld mit **genau drei** Einträgen,
  Reihenfolge: **Traceroute, Ping, WHOIS**
  ❌ v0.4.0 bietet fünf (zusätzlich VirusTotal, ARP) und beginnt mit Ping
- `🎯 Ziel` + Feld, Platzhalter `z.B. golem.de oder 8.8.8.8`
- `☐ 🔁 Loop   Intervall: [30 s]`
- `▶ Starten` über volle Breite
- `📊 Ergebnis` — **grüner Monospace-Text**, Format je Hop ✅ seit v0.6.0:
  ```
  Hop 10: 176.52.252.32 (176.52.252.32) - 66.8ms
  Hop 8:
  lag2.0002.cord.02.fra.de.net.telefonica.de
  (62.53.28.151) - 64.9ms
  ```
  Abschluss: `✅ 15 Hops lokalisiert` ✅

### 📊 Monitoring
- `📊 Live Network Monitoring` + grüner Knopf `🔍 Große Ansicht öffnen`
- Unterzeile `Live-Traffic von Apps, Hosts, Protokollen und Ländern`
- **vier Tabellen nebeneinander**: `Apps` `Hosts` `Verkehr` `Länder`
  je zwei Spalten (Name, **Traffic**), Werte in KB: `235.1 KB`, `1.7 KB`
  ✅ seit v0.8.0 vierspaltig.
  ⚠️ **Byte-Zahlen je App/Host bleiben offen.** `/proc` liefert Verkehr nur
  pro Interface, nicht pro Socket — dafür bräuchte es eBPF (der Weg, den
  `nethogs` geht). Die Spalten zeigen deshalb Verbindungszahlen, und der
  **gemessene** Gesamtdurchsatz steht als Zeile darüber. Lieber eine ehrliche
  Zahl weniger als eine erfundene mehr.
- `⏸ Pausieren`

### 📈 Graph
- `📈 Network Traffic Graph` + grüner Knopf `🔍 Große Ansicht öffnen`
- Kopfzeile: `▪105.2 KB/s | ▪245.5 KB/s | ▪350.8 KB/s | Datenpunkte: 202/300`
- **gestapeltes Flächendiagramm**, y = `Traffic (KB/s)`, x = `Zeit (s)`
  Legende: 🟡 `Upload` · 🟠 `Download` · 🩷 `Total`
  ❌ v0.4.0 zeichnet **Linien** und misst **Verbindungszahlen**, nicht KB/s
- Verlauf hält **300** Punkte
- `⏸ Pausieren` · `🗑 Löschen`

### 🛰 Satelliten
- `🛰 Satelliten-Zentrale` + türkiser Knopf `🖥 PRO Monitor öffnen`
- Gruppe `Globus Anzeige`:
  - `☑ Auf Globus anzeigen`
  - `Kategorien:` — Ankreuzfelder **je Celestrak-Gruppe**:
    `Space Stations`, `Weather`, `Starlink`, `GPS` ✅ seit v0.9.0
- `Aktive Satelliten:` — `Alle auswählen` | `Alle abwählen`
- Liste mit **Ankreuzfeld je Satellit**: `☑ ISS (ZARYA) (Space Stations)` ✅ seit v0.9.0
- Fuß: `☑ 21/21 Satelliten aktiv`

## 4. Darstellung auf dem Globus

| Element | Original | Rust v0.4.0 |
|---|---|---|
| Erdtextur | Nachtlichter, dunkelblau | ✅ identisch (gleiche Datei) |
| Suchtreffer | violette Punkte + Namen in **Gelb** | ✅ ähnlich |
| Zielmarke | **pink/magenta**, größer, Name in Pink | ✅ |
| Traceroute-Hops | magenta Punkte, **durch Linien verbunden**, Beschriftung `Hop 7: IP: 176.52.252.32, ES` bzw. `Hop 2: Berlin, DE` in **Cyan** | Linien ✅, Beschriftungsformat ❌ |
| Live-Verbindung | hellblauer Bogen, weit über die Kugel gewölbt | ✅ |
| Satelliten | **Satelliten-Symbole** mit Solarpaneelen (Textur-Sprites, 32 px) | ✅ seit v0.6.0, Größe regelbar |
| Beschriftungen | überlappen bei vielen Treffern sichtbar | ✅ seit v0.9.0 ausgedünnt (26 px Mindestabstand) — bewusst **besser** als das Original |

## 5. Was die Bilder zusätzlich verraten

1. **Mehrfachsuche**: Der Platzhalter nennt `'berlin leipzig koblenz'` —
   mehrere Orte in einer Abfrage. `GeoDataManager::search` kann das
   (Mehrwortzweig), aber die Oberfläche wirbt nicht dafür.
2. **50 Treffer gleichzeitig** werden mit Namen gezeichnet. Die
   Überlappung ist im Original deutlich sichtbar — Kandidat für eine echte
   Verbesserung (Beschriftungen ausdünnen statt alle zeichnen).
3. **Zoomfaktor** wird angezeigt (`5.9x`, `8.9x`) — es gibt also eine
   Umrechnung von Kameraabstand in einen Faktor.
4. **Traffic wird in Bytes gemessen**, nicht in Verbindungen. Dafür braucht es
   `/proc/net/dev`-Deltas; die Zahlen in Monitoring und Graph hängen daran.
