# Architektur

## Warum sechs Crates statt eines

Das Python-Original hatte eine flache `src/`-Struktur, in der alles auf alles
zugreifen konnte. `globe_widget.py` importierte Netzwerk-, Geo-, Satelliten-
und Rendering-Code gleichzeitig und war deshalb 1090 Zeilen lang.

Die Rust-Fassung erzwingt die Schichtung über Crate-Grenzen. Wenn `ev-render`
plötzlich `ev-net` bräuchte, muss man das in `Cargo.toml` eintragen — und
merkt dabei, dass man gerade etwas falsch macht.

```
                    ┌───────────┐
                    │  ev-app   │  eframe/egui · Fenster, Tabs, Interaktion
                    └─────┬─────┘
        ┌───────────┬─────┼──────┬───────────┐
        ▼           ▼     ▼      ▼           ▼
   ┌─────────┐ ┌────────┐ │ ┌────────┐ ┌───────────┐
   │ ev-geo  │ │ ev-net │ │ │ ev-sat │ │ ev-render │
   └────┬────┘ └───┬────┘ │ └───┬────┘ └─────┬─────┘
        │          │      │     │            │
        └──────────┴──────┴─────┴────────────┘
                          ▼
                    ┌───────────┐
                    │  ev-core  │  Konfiguration · Geometrie · Mathematik
                    └───────────┘
```

`ev-net` hängt zusätzlich an `ev-geo` (Verbindungen brauchen GeoIP-Lookups).
Sonst zeigen alle Pfeile nur nach unten. Keine Zyklen.

## Was in welchem Crate liegt

### `ev-core` — das Fundament
Keine I/O außer Settings-Datei, keine Threads, keine GPU.

- `config.rs` — alle Konstanten des Originals, Pfadauflösung über
  `$EARTHVIEWER_ROOT` → Aufwärtssuche → CWD
- `geo.rs` — `GeoLocation` mit `to_cartesian` / `to_uv` / Haversine
- `math.rs` — Rotation, Projektion, View, Great-Circle-Bögen,
  Bildschirmprojektion mit Rückseiten-Test
- `theme.rs` — die sechs Themes als `const`
- `settings.rs` — JSON-Persistenz mit API-Key-Filter

### `ev-geo` — Ortsdaten
- CSV-Städte aus `data/geodata/<Land>/staedte.csv` (Ordnername = Land)
- MaxMind-MMDB für IP→Ort
- `search()` mit der dreistufigen Logik des Originals:
  Koordinaten → IP → Volltext, danach Positions-Deduplikation

### `ev-net` — Netzwerk und Security
- `proc_net.rs` — der `/proc/net`-Parser (ersetzt psutil)
- `connections.rs` — Tracker-Thread mit mpsc statt Qt-Signal
- `ping.rs`, `traceroute.rs`, `whois.rs`, `arp.rs`, `virustotal.rs`

### `ev-sat` — Satelliten
- `catalog.rs` — TLE-Parsing, Kategorisierung, Celestrak-Anbindung, Cache
- `frames.rs` — Julianisches Datum, GMST, TEME↔ECEF, Achskonvention
- `propagate.rs` — SGP4-Propagation, Bahnkurven, Bodenspuren

### `ev-render` — OpenGL
- `geometry.rs` — UV-Sphere
- `shaders.rs` — die GLSL-Quellen des Originals, unverändert
- `gl_util.rs` — **alle** `unsafe`-Blöcke des Projekts
- `scene.rs` — beschreibt *was* gezeichnet wird, ohne GL. Dadurch testbar.
- `globe.rs` — führt Szene + GL zusammen

### `ev-app` — Oberfläche
- `main.rs` — Banner, `eframe::run_native`
- `state.rs` — der gesamte Anwendungszustand an einer Stelle
- `globe_view.rs` — Kamera + PaintCallback + Label-Overlay
- `tools.rs` — Hintergrund-Jobs (Ping, Traceroute, …) als mpsc-Kanäle
- `app.rs` — die `eframe::App`-Implementierung

## Die drei Nebenläufigkeits-Muster

Python nutzte `QThread` + `pyqtSignal`. Rust hat kein Signal/Slot, deshalb:

**1. Dauerläufer (Connection-Tracker)**
Ein Thread, der alle 2 s einen Snapshot über `mpsc::Sender` schickt.
`try_recv()` in der UI holt den *neuesten* und verwirft veraltete —
sonst staut sich der Kanal, wenn die UI langsamer ist als der Tracker.

**2. Einmal-Jobs (Ping, Traceroute, WHOIS, VirusTotal, ARP)**
Thread + Kanal, der `ToolMsg::Line` / `ToolMsg::Marker` / `ToolMsg::Done`
schickt. Die UI hält genau einen `Option<ToolJob>` — solange der belegt ist,
sind die Buttons deaktiviert. Kein Job-Stapel, keine Race-Conditions.

**3. Der GL-Callback**
`egui_glow::CallbackFn` verlangt `Fn + Send + Sync + 'static`. Der Renderer
liegt deshalb in `Arc<Mutex<Option<GlobeRenderer>>>`. Das `Option` ist wichtig:
vor der ersten GL-Initialisierung und nach `on_exit` ist es `None`.

## Warum `Scene` von `GlobeRenderer` getrennt ist

`Scene` ist reine Daten — Punkte, Farben, Linienzüge. Kein GL-Handle, kein
`unsafe`, keine GPU.

Das ist der Grund, warum 18 Renderer-Tests ohne Grafikkarte laufen: Man kann
prüfen, ob ein Great-Circle-Bogen 73 Punkte hat und sich in der Mitte abhebt,
ohne je einen Kontext zu erzeugen. In PyQt6 ging das nicht — dort steckte die
Geometrie in `paintGL()` und war nur visuell prüfbar.

`app.rs::build_scene()` ist das direkte Gegenstück zu `globe_widget.paintGL()`,
nur eben ohne Seiteneffekte.

## `unsafe` — gemessen, nicht behauptet

`./werkzeug/messen.py` zählt die Blöcke. Stand v0.4.0:

| Datei | Blöcke |
|---|---:|
| `ev-render/src/gl_util.rs` | 23 |
| **alle übrigen Dateien** | **0** |

Geschichte dieser Zahl: In v0.3.0 stand hier „das einzige `unsafe` im Projekt"
über `gl_util.rs` — **das war falsch**, und `werkzeug/messen.py` hat es
aufgedeckt: 19 Blöcke in drei Dateien. Seit v1.2.0 stimmt die Aussage, weil
`globe.rs` und `globe_view.rs` nur noch die Hüllen aus `gl_util.rs` rufen
(`dreiecke_zeichnen`, `punkte_zeichnen`, `tiefe_schreiben`, `puffer_leeren` …).

**Regel:** Wer außerhalb von `gl_util.rs` einen GL-Aufruf braucht, ergänzt dort
eine Hülle. `grep -rc "unsafe {" crates/*/src/*.rs` muss außer `gl_util.rs`
überall null liefern. Alle 23 sind reine FFI-Aufrufe an glow; keiner
dereferenziert rohe Zeiger oder umgeht das Typsystem.

## Wo die Konventionen des Originals erhalten blieben

- Alle Konstanten aus `config.py` haben denselben Namen und Wert
- Die sechs Themes haben identische RGB-Werte
- Die GLSL-Shader sind Zeichen für Zeichen dieselben
- Die Achskonvention von `to_cartesian` (Y = Nord) ist unverändert —
  daran hängt die Textur-Zuordnung
- Der Kamera-Startzustand (90° um X) ist derselbe
- `settings.json` bleibt lesbar/schreibbar (bis auf den API-Key)
