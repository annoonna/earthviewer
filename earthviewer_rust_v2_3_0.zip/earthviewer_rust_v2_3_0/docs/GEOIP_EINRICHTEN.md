# GeoLite2-Daten einrichten

## Kurz

**Die MMDB gehört nach `data/geodata/`.** Unterordner sind erlaubt.

```bash
./geodaten_einrichten.sh /pfad/zu/Geodaten
./start.sh
```

## Warum nicht nach `Geodaten/`?

Weil das Original diesen Ordner **nie gelesen hat.**

`src/core/config.py`:
```python
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DATA_DIR     = PROJECT_ROOT / "data"
GEODATA_DIR  = DATA_DIR / "geodata"     # <- hier wird gesucht
```

`src/data/geo_manager.py`:
```python
def __init__(self, data_root: Path = GEODATA_DIR):
    ...
for mmdb_file in self.data_root.rglob("*.mmdb"):
```

`Geodaten/` (großes G, im Projektstamm) war der private Download-Ordner, der
beim Packen mit ins Archiv gerutscht ist. Im ausgelieferten ZIP enthält er
sogar nur **leere Verzeichnisse** — die Datenbanken waren nie dabei. Die
Rust-Portierung übernimmt diese Pfadlogik 1:1.

## Was ausgewertet wird

`rglob("*.mmdb")` ist **rekursiv**, aber es gilt eine harte Bedingung:

```python
if "city" in mmdb_file.name.lower():
```

| Datei | wird genutzt |
|---|---|
| `GeoLite2-City.mmdb` | ✅ ja |
| `GeoLite2-Country.mmdb` | ❌ nein |
| `GeoLite2-ASN.mmdb` | ❌ nein |

Country und ASN ignoriert das Original. Mit eingeschalteten Korrekturen
(Einstellungen → „Korrekturen aktivieren") nimmt die Rust-Fassung eine
Country-Datenbank als Rückfall — im 1:1-Betrieb nicht.

Beide Ablagen funktionieren, weil die Suche rekursiv ist:

```
data/geodata/GeoLite2-City.mmdb                              flach
data/geodata/GeoLite2-City_20251017/GeoLite2-City.mmdb       mit Ordner
```

## Städtelisten

`rglob("*.csv")`, und der **Ordnername ist das Land**:

```python
country = csv_file.parent.name
```

Spalten: `name` oder `city` · `lat` · `lon` oder `lng`.
Längengrade über 180 werden um 360 reduziert.

```
data/geodata/Germany/staedte.csv     -> Land „Germany"
data/geodata/Austria/staedte.csv     -> Land „Austria"
```

### simplemaps `worldcities.csv`

Eine einzige große CSV würde **allen** Städten dasselbe Land geben — den
Ordnernamen. Deshalb liegt ein Aufteiler bei:

```bash
./werkzeug/staedte_aufteilen.py worldcities.csv data/geodata
./werkzeug/staedte_aufteilen.py worldcities.csv data/geodata --min-einwohner 50000
```

Er liest die Spalte `country` und schreibt je Land einen Ordner mit
`staedte.csv`. Die Volldatei hat rund 44.000 Orte; mit `--min-einwohner`
lässt sich das eindampfen.

Die mitgelieferte `data/geodata/worldcities.xlsx` bleibt **ungenutzt** —
das Original las kein Excel (`requirements.txt` kennt weder `openpyxl` noch
`pandas`). Sie einzulesen wäre ein neues Merkmal.

## Kontrolle

Das Startprotokoll sagt, was gefunden wurde:

```
📁 Geodaten: /pfad/data/geodata
   gefunden: /pfad/data/geodata/GeoLite2-City.mmdb
✅ GeoIP: /pfad/data/geodata/GeoLite2-City.mmdb
✅ 1746 Orte geladen
```

Fehlt etwas, wird es benannt:

```
ℹ️  Keine *.mmdb unter /pfad/data/geodata
    GeoLite2-City.mmdb dort ablegen (Unterordner sind erlaubt).
```

Im Reiter **Control Center** steht dasselbe als Zeile `GeoIP: aktiv` bzw.
`keine MMDB`.

## Lizenz

GeoLite2 gehört MaxMind. Die EULA untersagt die Weitergabe von Datenbanken,
die älter als 30 Tage sind — deshalb liegen sie **nicht** im Paket.
Kostenloser Bezug nach Registrierung:
<https://dev.maxmind.com/geoip/geolite2-free-geolocation-data>
