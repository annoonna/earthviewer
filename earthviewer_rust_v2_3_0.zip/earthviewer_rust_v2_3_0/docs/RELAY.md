# RELAY — Übergabe an die nächste Session

> Für: die nächste Claude-Instanz, die an EarthViewer Rust weiterarbeitet.
> Von: der Instanz, die die Portierung Python → Rust gemacht hat.
> Datum: 2026-08-22 · Version: **v1.4.0**

---

## 0. Pflichtlektüre vor der ersten Änderung

Lies in dieser Reihenfolge, bevor du irgendetwas anfasst:

0. **`docs/OBERFLAECHE_REFERENZ.md`** — die Sollvorgabe der Oberflaeche,
   abgelesen aus 34 Bildschirmfotos des laufenden Originals. Was dort mit ❌
   markiert ist, weicht noch ab. **Diese Datei schlaegt den Quelltext**, wenn
   beide sich widersprechen: sie zeigt, was das Programm wirklich tat.
1. **`docs/PORT_NOTES.md`** — was aus welcher Python-Datei wurde, und die vier
   Stellen, an denen es nicht trivial war
2. **`docs/SECURITY_NOTES.md`** — der kompromittierte API-Key und warum
   WiFi-Capture nicht portiert ist
3. **`docs/ARCHITECTURE.md`** — die Crate-Schichtung und warum es sechs sind
4. **diese Datei** — Stand, offene Punkte, Fallstricke

Danach: `./pruefen.sh` laufen lassen. Wenn das rot ist, war jemand vor dir
unsauber — **das zuerst reparieren**, nicht darauf aufbauen.

---

## 1. Stand v1.4.0

| Sache | Status |
|---|---|
| Kompiliert (debug + release) | ✅ 0 Warnungen |
| `cargo clippy -D warnings` | ✅ sauber |
| Tests | ✅ **216 grün, 0 rot** |
| `./start.sh` — Erstlauf richtet ein | ✅ getestet |
| `./start.sh` — Folgelauf Schnellpfad | ✅ **48 ms** gemessen |
| **GUI startet, Fenster + Globus** | ✅ **verifiziert** (Xvfb + llvmpipe, `docs/screenshot.png`) |
| GUI auf echter GPU | ⚠️ noch offen — siehe §2 |

Testverteilung: `ev-core` 3 · `ev-geo` 3 · `ev-net` 26 · `ev-sat` 23 ·
`ev-render` 18 · `ev-app` 29 · `ev-net` jetzt 51.

### Belastungstests (v1.4.0 gemessen, Einkern-Container)

| Fall | Ergebnis |
|---|---|
| Portscan 1–65535, antwortender Host | 0,5 s · ~140 000 Ports/s |
| Portscan, kontrollierte Gegenprobe | 10 von 10 Horchern gefunden, Zaehler stimmt |
| 7000 Satelliten: TLE lesen | < 0,01 s |
| 7000 Satelliten: SGP4-Aufbau | 0,01 s |
| 7000 Satelliten: Propagation je Bild | **3,9 ms** (~1,8 Mio Positionen/s) |
| Bahnkurve, 180 Punkte | 0,08 ms |

Die Propagation laeuft nur einmal je Sekunde, nicht je Bild — bei 7000
Objekten also rund 4 ms Last pro Sekunde. Unkritisch.

⚠️ **Nicht messbar im Container:** der *stille* Host, bei dem jeder Port in
die 500-ms-Grenze laeuft. Das Sandbox-Netz antwortet sofort mit einem Fehler
statt zu verwerfen. Rechnerisch: 65535 Ports / 100 Threads x 0,5 s
= **rund 5,5 Minuten**. Wer das kuerzen will, dreht die Threadzahl hoch —
der Scanner haelt 512 Threads aus.

### Reiter: 13 (11 aus `sidebar.py` + Satelliten + Einstellungen)
Control · Search · Favorites · Network · LiveConnections · Monitoring ·
ControlCenter · Graph · Protection · Protocol · Scanner · Satellites · Settings

Ein Reiter laesst sich direkt oeffnen: `EARTHVIEWER_TAB=graph ./start.sh 1`.
Der Test `all_original_tabs_are_present` prueft gegen die Liste aus
`sidebar.py` — wer einen Reiter entfernt, faellt auf.

### Was funktional drin ist
- 3D-Globus, Erdtextur, Maus-Rotation, Zoom, Auto-Rotation, 5 Blickwinkel-Presets
- Suche: Städte-CSV, GeoIP-MMDB, `"lat, lon"`-Koordinaten
- Marker + Labels mit Rückseiten-Test, 6 Themes
- Connection-Tracker (`/proc`, ohne root), Verbindungsbögen mit Puls
- Ping, Traceroute (mit Marker auf dem Globus), WHOIS mit Referral, VirusTotal,
  ARP-Nachbarschaft
- Satelliten: TLE von Celestrak + Cache, SGP4, Kategorien mit Farben,
  erdfest/inertial umschaltbar
- Einstellungen persistent in `settings.json`

---

## 2. Was noch offen ist

**Die GUI läuft** — Fenster, Globus mit Textur und Beleuchtung, Sidebar mit
allen vier Tabs, Renderer-Init, Connection-Tracker. Belegt durch
`docs/screenshot.png`, aufgenommen unter Xvfb mit llvmpipe.

Damit ist **Software-Rendering** verifiziert. Was noch nicht geprüft ist:

1. **Echte GPU.** Auf deiner Kiste greift der MSAA-Rückfall vermutlich gar
   nicht (4× ist da verfügbar), und der Treiber ist ein anderer. Erwartung:
   läuft besser, nicht schlechter — aber ungeprüft.

2. **`gl.line_width()` > 1.0.** Unter llvmpipe waren keine Verbindungsbögen
   sichtbar (keine Verbindungen im Container). Im Core-Profil ist
   `glLineWidth` nicht garantiert; das Original umging das mit einem
   *Compatibility*-Profil. Falls die Bögen auf echter Hardware hauchdünn oder
   unsichtbar sind: in `ev-render/src/globe.rs::render_lines` auf schmale
   Dreiecksstreifen umstellen. **Das ist der wahrscheinlichste Rest-Stolperstein.**

3. **`PROGRAM_POINT_SIZE`.** Ist in `globe.rs::render` gesetzt, aber auf
   manchen Mesa-Versionen zickig. Symptom wäre: alle Marker 1 px groß.

4. **Interaktion.** Drehen, Zoomen, Klicks konnten headless nicht ausgelöst
   werden. Die Logik ist durch Tests gedeckt, die Verdrahtung an egui nicht.

**So testest du:**
```bash
./start.sh 1                            # X11 erzwingen
./start.sh 2                            # Wayland nativ
EARTHVIEWER_BUILD=debug ./start.sh 1    # mit Debug-Symbolen
LIBGL_ALWAYS_SOFTWARE=1 EARTHVIEWER_MSAA=0 ./start.sh 1   # Notfall-Fallback
xvfb-run -s '-screen 0 1400x900x24' ./start.sh 1          # headless
```
Bei GL-Problemen zuerst `./start.sh 1` — XWayland ist erfahrungsgemäß robuster
als natives Wayland mit glutin.

---

## 3. Fallstricke, die dich Zeit kosten würden

### 3.1 Matrix-Reihenfolge
glam ist column-major, numpy war row-major. **Niemals** Python-Zahlen in
Lesereihenfolge in `Mat4::from_cols_array` kippen. Details in
`ev-core/src/math.rs` im Modulkommentar. Der Test
`rotation_matches_python_rodrigues` fängt Regressionen.

### 3.2 Achskonvention des Globus
`GeoLocation::to_cartesian` liefert **Y = Nord**, nicht Z. Das hängt an der
Textur-Zuordnung und ist nicht verhandelbar. Wenn du irgendwo ECEF-Daten
(Z = Nord) einspeist, musst du durch `frames::ecef_to_globe`.
Test: `globe_axes_match_geolocation_convention`.

### 3.3 TLE-Prüfsummen
Beim Schreiben von Test-TLEs: Zeichen 69 ist eine Modulo-10-Prüfsumme über die
ersten 68 Zeichen (Ziffern zählen als Wert, `-` als 1, alles andere als 0).
Das `sgp4`-Crate prüft sie. Ich bin da reingelaufen — hier das Skript:
```python
def cks(line68):
    return sum(int(c) if c.isdigit() else (1 if c == '-' else 0) for c in line68) % 10
```

### 3.4 `sgp4::Constants::propagate` nimmt ein nacktes `f64`
Nicht `MinutesSinceEpoch(...)`. Das war in älteren Versionen anders und steht
so noch in vielen Beispielen im Netz.

### 3.5 Der GL-Callback braucht `Send + Sync`
Deshalb liegt der Renderer in `Arc<Mutex<Option<GlobeRenderer>>>`. Wenn du dort
etwas hineinreichst, das nicht `Send` ist, bricht der Build an einer sehr
unübersichtlichen Stelle. Das `Option` ist nötig: vor GL-Init und nach
`on_exit` ist es `None`.

### 3.6 `eframe::Error` — nicht auf `to_string()` matchen
Die `Display`-Ausgabe von `NoGlutinConfigs` lautet „Found no glutin configs
matching the template…" und enthält den Variantennamen **nicht**. Wer darauf
matcht, bekommt einen Fallback, der nie greift (mir genau so passiert).
`matches!(e, eframe::Error::NoGlutinConfigs(..))` benutzen.

### 3.7 Zwei Quellen der Wahrheit für Kameramatrizen
Das war Bug B5 im Original: `align_view()` hatte eigene Matrizen,
`_align_to_location()` andere — drei von fünf Presets zeigten den falschen
Punkt. Wenn du neue Blickwinkel ergänzt: **immer** über `align_to()`, nie
mit eigenen Matrizen. Die Tests `*_preset_shows_the_*` fangen Rückfälle.

### 3.8 Build-Zeit
eframe zieht ~380 Crates. Erster Build auf einem Kern: ~25 min. Danach ist
inkrementell alles unter 15 s. Nicht erschrecken.

---

## 3a. Gemessener Deckungsgrad — **hier zuerst hinschauen**

Nicht schaetzen, messen:

```bash
./werkzeug/gegenpruefung.py /pfad/earthviewer_v0_2_miniCaptureExtra.zip
./werkzeug/messen.py --schnell
cargo run --release -p ev-net --example scanbench    # Portscanner
cargo run --release -p ev-sat --example satbench     # 7000 Satelliten
./werkzeug/farben.py --zip bilder.zip --bild "14-20-11" --zeilen   # Original
./werkzeug/farben.py --datei eigener_screenshot.png                # eigener Stand
```

**Regel fuer die Oberflaeche:** neue Symbole erst in
`ev-app::glyphen::SYMBOLE` eintragen, *nachdem* sie in einem Bildschirmfoto
sauber erschienen sind. egui's Schriften decken laengst nicht alles ab, und
Fehlendes erscheint als leeres Kaestchen. Die Tests in `glyphen.rs` halten das
fest. **Keine verschachtelten `ScrollArea`** — sonst liegen zwei Balken
uebereinander und verdecken Text.

Stand v0.9.0: 586 Symbole · 339 OK (58 %) · 130 begruendet ausgelassen (22 %) ·
117 ungeklaert (20 %). Davon rund 60 reine Qt-Dekoration.

**Die namentlich offenen Posten** (mit Fundstelle im Original):

| Original | offen | Symbole |
|---|---:|---|
| `satellite_integration.py` | 18 | SatelliteControlWidget._clear_all_visualizations, SatelliteControlWidget._deselect_all, SatelliteControlWidget._open_monitor_window … |
| `virustotal_analyzer.py` | 16 | VirusTotalAnalyzer._make_cache_key, VirusTotalAnalyzer._test_api_key, VirusTotalAnalyzer._worker_loop … |
| `globe_widget.py` | 16 | GlobeWidget._update_old_orbits, GlobeWidget.clear_connection_lines, GlobeWidget.navigate_to … |
| `sat_monitor_window.py` | 11 | SatMonitorWindow._show_about, SimulationWorker._gaussian, SimulationWorker.run … |
| `control_center_window.py` | 10 | ControlCenterWindow._open_clients_window, NetworkClientsWindow._find_row_by_ip, NetworkClientsWindow._on_device_clicked … |
| `process_detail_window.py` | 9 | ProcessDetailWindow._create_alarms_tab, ProcessDetailWindow._create_hosts_tab, ProcessDetailWindow._create_info_tab … |
| `network_stats_widget.py` | 8 | NetworkStatsWidget._show_country_details, NetworkStatsWidget._show_host_details, NetworkStatsWidget._show_process_details … |
| `sidebar.py` | 5 | Sidebar._on_favorite_clicked, Sidebar._on_result_clicked, Sidebar.update_results … |
| `api_key_manager.py` | 4 | APIKeyManagerWidget._on_test_result, APIKeyManagerWidget._open_virustotal, APIKeyManagerWidget._test_key … |
| `theme_dialog.py` | 3 | ThemeDialog._create_custom_editor, ThemeDialog._pick_color, ThemeDialog._update_preview |
| `host_detail_window.py` | 3 | HostDetailWindow._load_data, HostDetailWindow._start_updates, HostDetailWindow._update_traffic |
| `hosts_view_widget.py` | 3 | HostsViewWidget._get_app_icon, HostsViewWidget.get_hostname, HostsViewWidget.update_data |

Regeln fuer die Arbeit damit:
- Ein Symbol nach `abbildung.json` -> `abgebildet` zu schieben ist nur erlaubt,
  wenn es im Rust-Baum **wirklich** ein Gegenstueck hat. Der Eintrag nennt es.
- Ein Symbol nach `ausgelassen` zu schieben braucht eine **Begruendung**.
  "brauchen wir nicht" ist keine. Rechtliche, technische oder
  Redundanz-Gruende sind welche.
- Der Deckungsgrad darf zwischen zwei Versionen **nie sinken**.

## 4. Naechste sinnvolle Schritte

Priorisiert, mit Aufwandsschätzung:

| # | Aufgabe | Aufwand | Warum |
|---|---|---|---|
| 1 | **Auf echter GPU starten**, §2 abarbeiten | S | letzte Unbekannte |
| 2 | Bogen-Rendering als Dreiecksstreifen statt `LINE_STRIP` | M | macht `line_width` egal |
| 2c | Texturierte Satelliten-Sprites (`satellite_sprites.py`) | M | derzeit einfarbige Punkte |
| 3 | Satelliten-Klick → Detailfenster | M | war im Original (`_render_selected_satellite_info`), fehlt noch |
| 4 | Orbit-/Ground-Track-Anzeige pro Satellit | M | `ev-sat` kann es schon, UI fehlt |
| 5 | Hover-Tooltip über Markern | S | Original hatte `_render_hover_tooltip` |
| 6 | Screenshot-Funktion | S | Original: `take_screenshot`, egui kann `ViewportCommand::Screenshot` |
| 7 | Eigene IP per GeoIP → Heimatpunkt automatisch | S | derzeit fest auf Leipzig |
| 8 | `ev-wifi` als separates Crate | XL | **nur mit expliziter Freigabe**, siehe SECURITY_NOTES §E |

Punkt 3–5 sind die einzigen echten Funktionslücken gegenüber dem Original.

---

## 5. Konventionen dieses Projekts

Übernommen aus dem Py_DAW-Relay, weil sie sich bewährt haben:

- **NICHTS KAPUTT MACHEN.** Vor jeder Änderung `./pruefen.sh`. Danach auch.
- **MESSEN STATT RATEN.** Jede Verhaltensänderung braucht einen Test, der
  vorher rot war. „Sieht richtig aus" zählt nicht.
- **Rendering ist glow, nicht egui.** Der Globus geht durch den PaintCallback.
  Wer anfängt, Kugeln mit `egui::Painter` zu malen, hat die Schichtung verlassen.
- **`unsafe` nur in `ev-render/src/gl_util.rs`.** Wenn du woanders `unsafe`
  brauchst, ist das ein Designproblem, kein Sprachproblem.
- **Keine Zyklen zwischen Crates.** Wenn `ev-render` plötzlich `ev-net` will,
  gehört die gemeinsame Sache nach `ev-core`.
- **Deutsche Kommentare, englische Bezeichner.** So wie es jetzt ist.
- **Keine Backup-Dateien im Baum.** Das Original hatte 20 Stück. Dafür gibt es
  Git.

---

## 6. Wenn du Version v0.3.1+ abschließt

1. `./pruefen.sh` muss grün sein
2. Version in `Cargo.toml` (`workspace.package.version`) hochziehen
3. `CHANGELOG.md` ergänzen
4. **Diese Datei aktualisieren** — §1 Stand, §2 offene Punkte, §4 Nächste Schritte
5. ZIP bauen:
   ```bash
   ./paket_bauen.sh
   ```
   Das Skript filtert `target/`, `.env`, `*.mmdb` und Backup-Dateien.
6. Vor der Übergabe die Checkliste am Ende von `SECURITY_NOTES.md` durchgehen.
