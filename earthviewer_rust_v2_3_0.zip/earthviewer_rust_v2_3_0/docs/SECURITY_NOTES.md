# Sicherheitshinweise

Diese Datei sammelt, was bei der Portierung sicherheitsrelevant aufgefallen ist.
Als Sicherheitsforscher liest du das vermutlich zuerst — deshalb kurz und ohne
Umschweife.

---

## 🔴 SOFORT: VirusTotal-API-Key kompromittiert

**Fund.** `settings.json` in `earthviewer_v0_2_miniCaptureExtra.zip` enthielt:

```json
"virustotal": { "api_key": "000a2c…bae4", … }
```

Ein scharfer 64-Zeichen-VT-Key im Klartext, mit im ausgelieferten Archiv.

**Bewertung.** Das Archiv hat mindestens einmal die Maschine gewechselt (es lag
als Upload vor). Damit ist der Key als offengelegt zu behandeln — unabhängig
davon, wer ihn tatsächlich gesehen hat.

Ein VT-Key ist kein Zahlungsmittel, aber:
- er ist an dein Konto gebunden und zählt gegen dein Kontingent,
- Missbrauch (Massenabfragen) kann zur Sperrung des Kontos führen,
- die Abfragehistorie eines Keys ist selbst ein Informationsleck: wer weiß,
  welche IPs du prüfst, weiß, woran du arbeitest.

**Maßnahme.**
1. Key unter https://www.virustotal.com/gui/my-apikey zurücksetzen.
2. Alte Kopien von `settings.json` in Backups und Git-Historie suchen:
   ```bash
   grep -rl "000a2ce2fd" ~/ 2>/dev/null
   git log -p --all -S "000a2ce2fd" -- '*.json'   # falls versioniert
   ```
3. Neuen Key **nicht** wieder in eine Datei im Projektbaum schreiben.

**Was die Rust-Fassung dagegen tut.**
- Der Key wird ausschließlich aus `$EARTHVIEWER_VT_API_KEY` gelesen
  (`ev-core/src/settings.rs::virustotal_api_key`).
- `Settings::save()` entfernt jeden Schlüssel namens `virustotal_api_key`,
  bevor geschrieben wird — auch wenn ihn jemand von Hand einträgt.
- `start.sh` lädt optional eine `.env`; die steht in `.gitignore`.
- `.env.example` zeigt das Format, enthält aber keinen Wert.

---

## 🟡 Datenschutz: GeoLite2-Datenbanken

`data/geodata/*.mmdb` sind MaxMind-GeoLite2-Dateien. Deren Lizenz (CC BY-SA 4.0
bzw. die MaxMind-EULA seit 2019) verlangt:

- Namensnennung von MaxMind,
- **keine Weitergabe von Datenbanken, die älter als 30 Tage sind**,
- Registrierung für den Download.

Die im Original mitgelieferten Dateien tragen Datumsstempel von Oktober 2025.
Wenn du das Projekt weitergibst, gehören die `.mmdb`-Dateien **nicht** ins
Archiv — nur ein Hinweis, wie man sie selbst bezieht. In `.gitignore` und in
der ZIP-Erstellung ist das entsprechend gehandhabt.

---

## 🟡 Angriffsfläche der portierten Werkzeuge

Was das Programm nach außen tut, vollständig aufgelistet:

| Funktion | Verbindung nach außen | Rechte |
|---|---|---|
| Connection-Tracker | **keine** — liest nur `/proc` | keine |
| ARP-Nachbarschaft | leere UDP-Datagramme ins eigene /24 | keine |
| Ping | ruft `/usr/bin/ping` auf | keine (setuid-Binary) |
| Traceroute | ruft `/usr/bin/traceroute` auf | keine |
| WHOIS | TCP/43 zu IANA + einem RIR | keine |
| VirusTotal | HTTPS zu `virustotal.com` | keine |
| TLE-Download | HTTPS zu `celestrak.org` | keine |

**Das Programm braucht zu keinem Zeitpunkt root.** Wenn du es doch als root
startest, siehst du im Connection-Tracker zusätzlich fremde Prozesse — das ist
der einzige Unterschied.

**Kein `unsafe` außerhalb von `ev-render/src/gl_util.rs`.** Alle GL-Aufrufe sind
dort gekapselt; der Rest des Projekts ist vollständig sicherer Rust.

---

## 🟡 Externe Prozesse

`ping`, `traceroute` und `arp` werden als Unterprozesse gestartet. Die
Zieladresse kommt aus einem Textfeld.

**Kein Shell-Injection-Risiko:** `std::process::Command` übergibt Argumente als
Vektor an `execvp`, es gibt keine Shell dazwischen. Ein Ziel wie
`1.1.1.1; rm -rf ~` wird als *ein* Argument an `ping` gereicht und dort als
ungültiger Hostname abgelehnt.

Das war in Python mit `subprocess.Popen(cmd_list, …)` ebenfalls schon korrekt —
kein Rückschritt, aber erwähnenswert, weil es leicht kaputtgeht, wenn jemand
später `shell=true` bzw. `sh -c` einbaut. **Bitte nicht.**

---

## 🟢 Was besser geworden ist

- **Kein Raw-Socket-Code mehr.** scapy ist weg; ARP läuft passiv.
- **Keine WLAN-Monitor-Funktion.** Siehe `PORT_NOTES.md` Abschnitt E — bewusst
  nicht portiert, § 202b StGB.
- **Kein `OpenGL.ERROR_CHECKING = False`.** Das Original schaltete die
  PyOpenGL-Fehlerprüfung global ab, um Performance zu gewinnen — damit fielen
  auch echte Fehler unter den Tisch. glow meldet Compile-/Link-Fehler direkt.
- **Rate-Limiting für VirusTotal** ist jetzt erzwungen (`throttle_delay`),
  nicht nur eine Einstellung, die man ignorieren kann.

---

## Checkliste vor der Weitergabe

- [ ] `settings.json` enthält keinen `api_key`
- [ ] `.env` ist **nicht** im Archiv
- [ ] `*.mmdb` sind **nicht** im Archiv (Lizenz)
- [ ] `grep -ri "apikey\|api_key\|token\|password" --include="*.rs" --include="*.json" .` ist leer
- [ ] `./pruefen.sh` läuft durch
