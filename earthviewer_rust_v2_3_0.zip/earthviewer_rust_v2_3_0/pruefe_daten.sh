#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Prueft, ob die selbst kopierten Daten dort liegen, wo das Programm sucht.
# Aendert nichts — meldet nur.
#
#   ./pruefe_daten.sh
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GEO="$ROOT/data/geodata"
TEX="$ROOT/data/textures"
fehler=0
warnung=0

ok()   { echo "  ✅ $*"; }
warn() { echo "  ⚠️  $*"; warnung=$((warnung+1)); }
bad()  { echo "  ❌ $*"; fehler=$((fehler+1)); }

echo "╔══════════════════════════════════════════════════════╗"
echo "║        Datenpruefung                                 ║"
echo "╚══════════════════════════════════════════════════════╝"
echo "Programmordner: $ROOT"

# ── 1. Erdtextur ────────────────────────────────────────────────────────────
echo ""
echo "── Erdtextur ── $TEX/"
# Dieselbe Prioritätenliste wie ev-core::config::earth_texture().
aktiv=""
for name in earth_hd.jpg earth_hd.png earth_8k.jpg earth_16k.jpg \
            earth_map1.jpg earth_map.jpg earth_day.jpg; do
    if [ -f "$TEX/$name" ]; then aktiv="$name"; break; fi
done
if [ -n "$aktiv" ]; then
    groesse=$(stat -c%s "$TEX/$aktiv" 2>/dev/null || echo 0)
    typ=$(file -b --mime-type "$TEX/$aktiv" 2>/dev/null)
    # Auflösung, falls ImageMagick/identify vorhanden.
    aufl=$(identify -format "%wx%h" "$TEX/$aktiv" 2>/dev/null || echo "?")
    if [ "$groesse" -lt 10000 ]; then
        warn "$aktiv nur $groesse Bytes — ist das wirklich die Textur?"
    elif [ "$typ" != "image/jpeg" ] && [ "$typ" != "image/png" ]; then
        warn "$aktiv Dateityp $typ — erwartet wird ein Bild"
    else
        ok "aktiv: $aktiv ($(numfmt --to=iec "$groesse" 2>/dev/null || echo "$groesse B"), $aufl)"
        case "$aktiv" in
            earth_map.jpg|earth_day.jpg)
                echo "   Tipp: für schärferen Zoom eine HD-Textur als earth_hd.jpg ablegen"
                echo "         (siehe data/textures/README.md — frei, kein Key, keine Anmeldung)";;
        esac
    fi
else
    warn "keine Erdtextur — der Globus zeigt ein blaues Gradnetz statt Kontinenten"
fi

# ── 2. GeoIP ────────────────────────────────────────────────────────────────
echo ""
echo "── GeoIP ── $GEO/**/*.mmdb"
mapfile -t mmdb < <(find "$GEO" -type f -iname '*.mmdb' 2>/dev/null)
if [ "${#mmdb[@]}" -eq 0 ]; then
    bad "keine .mmdb gefunden — ohne sie: keine Marker, keine Verbindungsboegen"
    echo "     Aus  Geodaten/GeoLite2-City_*/GeoLite2-City.mmdb  hierher kopieren."
else
    city=0
    for f in "${mmdb[@]}"; do
        name=$(basename "$f")
        if echo "$name" | grep -qi city; then
            ok "$name  ($(numfmt --to=iec "$(stat -c%s "$f")" 2>/dev/null))"
            city=1
        else
            echo "  ·  $name (wird ignoriert — nur Dateien mit \"city\" im Namen zaehlen)"
        fi
    done
    [ "$city" -eq 0 ] && bad "keine Datei mit \"city\" im Namen — Country/ASN reichen nicht"
fi

# ── 3. Staedtelisten ────────────────────────────────────────────────────────
echo ""
echo "── Staedtelisten ── $GEO/<Land>/staedte.csv"
mapfile -t csv < <(find "$GEO" -type f -iname '*.csv' 2>/dev/null)
if [ "${#csv[@]}" -eq 0 ]; then
    bad "keine CSV gefunden — die Ortssuche findet dann nichts"
    echo "     Deine Laenderordner nach  data/geodata/  kopieren."
else
    laender=$(find "$GEO" -mindepth 1 -maxdepth 1 -type d | wc -l)
    zeilen=$(cat "${csv[@]}" 2>/dev/null | wc -l)
    ok "${#csv[@]} Datei(en) in $laender Ordner(n), rund $((zeilen - ${#csv[@]})) Orte"

    # Kopfzeile der ersten Datei pruefen
    kopf=$(head -1 "${csv[0]}" | tr -d '\r')
    if echo "$kopf" | grep -qiE '(^|,)(name|city)(,|$)' \
    && echo "$kopf" | grep -qiE '(^|,)(lat|latitude)(,|$)' \
    && echo "$kopf" | grep -qiE '(^|,)(lon|lng|longitude)(,|$)'; then
        ok "Kopfzeile passt: $kopf"
    else
        bad "Kopfzeile passt nicht: \"$kopf\""
        echo "     Erwartet: name|city , lat|latitude , lon|lng|longitude"
    fi

    # Liegen CSVs direkt in geodata/ statt in einem Landesordner?
    lose=$(find "$GEO" -maxdepth 1 -type f -iname '*.csv' | wc -l)
    [ "$lose" -gt 0 ] && warn "$lose CSV liegt direkt in geodata/ — das Land kommt aus dem Ordnernamen, dort waere es leer"
fi

# ── 4. Schreibrechte ────────────────────────────────────────────────────────
echo ""
echo "── Schreibrechte ── sessions/ screenshots/ logs/"
for d in sessions screenshots logs; do
    mkdir -p "$ROOT/$d" 2>/dev/null
    if [ -w "$ROOT/$d" ]; then
        ok "$d/ beschreibbar"
    else
        bad "$d/ nicht beschreibbar — Favoriten und TLE-Cache gehen verloren"
        echo "     sudo chown -R \"\$USER\" \"$ROOT\""
    fi
done

echo ""
echo "════════════════════════════════════════"
if [ "$fehler" -eq 0 ] && [ "$warnung" -eq 0 ]; then
    echo "✅ Alles am richtigen Platz. ./start.sh"
elif [ "$fehler" -eq 0 ]; then
    echo "✅ Lauffaehig, $warnung Hinweis(e) oben."
else
    echo "❌ $fehler Punkt(e) offen, $warnung Hinweis(e)."
fi
exit "$fehler"
