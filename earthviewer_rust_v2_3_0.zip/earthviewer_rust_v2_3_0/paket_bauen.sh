#!/usr/bin/env bash
# Baut das Uebergabe-ZIP. Filtert alles, was nicht hineingehoert.
#
#   ./paket_bauen.sh              volles Paket (mit Staedtelisten und Textur)
#   ./paket_bauen.sh --schlank    ohne Daten — zum Selberbefuellen
set -euo pipefail
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

VERSION=$(grep -m1 '^version' Cargo.toml | cut -d'"' -f2)
SCHLANK=0
[ "${1:-}" = "--schlank" ] && SCHLANK=1

if [ "$SCHLANK" -eq 1 ]; then
    NAME="earthviewer_rust_v${VERSION}_schlank"
else
    NAME="earthviewer_rust_v${VERSION}"
fi
OUT="../${NAME}.zip"

echo "📦 Baue $OUT"

# Sicherheitscheck vor dem Paketieren
if grep -rqi "api_key" settings.json 2>/dev/null; then
    echo "❌ settings.json enthaelt api_key — abgebrochen."
    exit 1
fi
[ -f .env ] && echo "ℹ️  .env vorhanden, wird ausgeschlossen."

AUSSCHLUSS=(
    -x 'target/*' -x '.git/*' -x '.env' -x '*.mmdb'
    -x 'logs/*' -x 'sessions/*' -x 'screenshots/*'
    -x '*.bak' -x '*.bak_*' -x '*.backup' -x '*.backup_*' -x '*.orig' -x '*~'
)
if [ "$SCHLANK" -eq 1 ]; then
    # Nur das Geruest samt Anleitungen — Nutzdaten kopiert der Nutzer selbst.
    AUSSCHLUSS+=(
        -x 'data/geodata/*/*'
        -x 'data/geodata/worldcities.xlsx'
        -x 'data/textures/*.jpg' -x 'data/textures/*.png'
        -x 'data/textures/satellites/*'
        -x 'docs/referenz/*' -x 'docs/screenshot*.png'
    )
fi

rm -f "$OUT"
zip -r -q "$OUT" . "${AUSSCHLUSS[@]}"

echo "✅ $(du -h "$OUT" | cut -f1)  $OUT"
unzip -l "$OUT" | tail -1
if [ "$SCHLANK" -eq 1 ]; then
    echo ""
    echo "Schlanke Fassung: data/ ist leer. Nach dem Entpacken:"
    echo "  ./pruefe_daten.sh     zeigt, was noch fehlt"
fi
