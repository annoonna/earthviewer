//! Theme-System — Port von `THEMES` / `get_theme_color` aus config.py.
use std::collections::BTreeMap;

pub type Rgb = [u8; 3];

#[derive(Clone, Debug)]
pub struct Theme {
    pub name: &'static str,
    pub description: &'static str,
    pub search_marker: Rgb,
    pub traceroute_marker: Rgb,
    pub traceroute_line: Rgb,
    pub target_marker: Rgb,
    pub label_search: Rgb,
    pub label_traceroute: Rgb,
    pub label_target: Rgb,
    pub background: Rgb,
}

impl Theme {
    pub fn color(&self, element: &str) -> Rgb {
        match element {
            "search_marker" => self.search_marker,
            "traceroute_marker" => self.traceroute_marker,
            "traceroute_line" => self.traceroute_line,
            "target_marker" => self.target_marker,
            "label_search" => self.label_search,
            "label_traceroute" => self.label_traceroute,
            "label_target" => self.label_target,
            "background" => self.background,
            _ => [255, 255, 255],
        }
    }
    pub fn color_f32(&self, element: &str) -> [f32; 3] {
        let c = self.color(element);
        [c[0] as f32 / 255.0, c[1] as f32 / 255.0, c[2] as f32 / 255.0]
    }
}

pub const CLASSIC_CYBER: Theme = Theme {
    name: "Classic Cyber",
    description: "Original Theme mit Cyan-Akzenten",
    search_marker: [255, 220, 80],
    traceroute_marker: [0, 255, 255],
    traceroute_line: [0, 255, 255],
    target_marker: [255, 100, 100],
    label_search: [255, 220, 80],
    label_traceroute: [0, 255, 255],
    label_target: [255, 100, 100],
    background: [0, 0, 5],
};

pub const MATRIX: Theme = Theme {
    name: "Matrix",
    description: "Neon-Grün Matrix-Style",
    search_marker: [100, 255, 100],
    traceroute_marker: [57, 255, 20],
    traceroute_line: [57, 255, 20],
    target_marker: [255, 80, 80],
    label_search: [100, 255, 100],
    label_traceroute: [57, 255, 20],
    label_target: [255, 80, 80],
    background: [0, 0, 0],
};

pub const CYBERPUNK: Theme = Theme {
    name: "Cyberpunk",
    description: "Pink/Purple Cyberpunk-Vibes",
    search_marker: [138, 43, 226],
    traceroute_marker: [255, 0, 255],
    traceroute_line: [255, 0, 255],
    target_marker: [255, 20, 147],
    label_search: [138, 43, 226],
    label_traceroute: [255, 0, 255],
    label_target: [255, 20, 147],
    background: [10, 0, 20],
};

pub const HACKER: Theme = Theme {
    name: "Hacker",
    description: "Grün/Orange Hacker-Style",
    search_marker: [0, 255, 0],
    traceroute_marker: [255, 128, 0],
    traceroute_line: [255, 165, 0],
    target_marker: [255, 50, 50],
    label_search: [0, 255, 0],
    label_traceroute: [255, 128, 0],
    label_target: [255, 50, 50],
    background: [0, 10, 0],
};

pub const NIGHT_VISION: Theme = Theme {
    name: "Night Vision",
    description: "Militär-Style Grüntöne",
    search_marker: [150, 255, 150],
    traceroute_marker: [100, 200, 100],
    traceroute_line: [80, 180, 80],
    target_marker: [200, 255, 100],
    label_search: [150, 255, 150],
    label_traceroute: [100, 200, 100],
    label_target: [200, 255, 100],
    background: [0, 20, 0],
};

pub const SYNTHWAVE: Theme = Theme {
    name: "Synthwave",
    description: "80s Retro Pink/Cyan",
    search_marker: [255, 0, 128],
    traceroute_marker: [0, 255, 255],
    traceroute_line: [255, 0, 255],
    target_marker: [255, 128, 0],
    label_search: [255, 0, 128],
    label_traceroute: [0, 255, 255],
    label_target: [255, 128, 0],
    background: [20, 0, 40],
};

pub const GLASSWIRE: Theme = Theme {
    name: "GlassWire",
    description: "Dunkelblau mit Grün/Rot-Graph — GlasWire-Look",
    search_marker: [80, 200, 120],
    traceroute_marker: [70, 180, 240],
    traceroute_line: [70, 180, 240],
    target_marker: [235, 90, 80],
    label_search: [120, 220, 150],
    label_traceroute: [90, 190, 245],
    label_target: [235, 110, 100],
    background: [8, 12, 20],
};

pub const ALL_THEMES: &[Theme] = &[
    CLASSIC_CYBER, GLASSWIRE, MATRIX, CYBERPUNK, HACKER, NIGHT_VISION, SYNTHWAVE,
];

pub const DEFAULT_THEME: &str = "GlassWire";

pub fn theme_by_name(name: &str) -> Theme {
    ALL_THEMES
        .iter()
        .find(|t| t.name == name)
        .cloned()
        .unwrap_or(CLASSIC_CYBER)
}

pub fn theme_names() -> Vec<&'static str> {
    ALL_THEMES.iter().map(|t| t.name).collect()
}

/// Custom-Theme-Overrides (Python: `settings["custom_theme_colors"]`).
pub fn apply_custom(mut base: Theme, custom: &BTreeMap<String, Rgb>) -> Theme {
    for (k, v) in custom {
        match k.as_str() {
            "search_marker" => base.search_marker = *v,
            "traceroute_marker" => base.traceroute_marker = *v,
            "traceroute_line" => base.traceroute_line = *v,
            "target_marker" => base.target_marker = *v,
            "label_search" => base.label_search = *v,
            "label_traceroute" => base.label_traceroute = *v,
            "label_target" => base.label_target = *v,
            "background" => base.background = *v,
            _ => {}
        }
    }
    base
}


// ── Oberflaechen-Palette ────────────────────────────────────────────────────
/// Die Farben aus `config.py` des Originals — **wortwoertlich uebernommen**,
/// nachgemessen an den Bildschirmfotos mit `werkzeug/farben.py`.
pub mod ui {
    use super::Rgb;

    /// `COLOR_BACKGROUND = "#1e1e1e"` — Fenster, Eingabefelder
    pub const BACKGROUND: Rgb = [0x1e, 0x1e, 0x1e];
    /// `COLOR_SURFACE = "#2b2b2b"` — Seitenleiste, Panels
    pub const SURFACE: Rgb = [0x2b, 0x2b, 0x2b];
    /// `COLOR_SURFACE_VARIANT = "#3a3a3a"` — Knoepfe im Ruhezustand
    pub const SURFACE_VARIANT: Rgb = [0x3a, 0x3a, 0x3a];
    /// `COLOR_PRIMARY = "#0d7377"` — Akzent, aktiver Reiter, Auswahl
    pub const PRIMARY: Rgb = [0x0d, 0x73, 0x77];
    /// `COLOR_PRIMARY_HOVER = "#0e8388"`
    pub const PRIMARY_HOVER: Rgb = [0x0e, 0x83, 0x88];
    /// `COLOR_BORDER = "#555555"`
    pub const BORDER: Rgb = [0x55, 0x55, 0x55];
    /// `COLOR_TEXT = "#ffffff"`
    pub const TEXT: Rgb = [0xff, 0xff, 0xff];
    /// `COLOR_TEXT_SECONDARY = "#aaaaaa"`
    pub const TEXT_SECONDARY: Rgb = [0xaa, 0xaa, 0xaa];

    /// Schriftgroessen in px, wie im Original-Stylesheet gezaehlt.
    /// (11 px und 14 px dominieren mit 28 bzw. 26 Fundstellen.)
    pub const FONT_TITEL: f32 = 24.0;
    pub const FONT_GROSS: f32 = 18.0;
    pub const FONT_UEBERSCHRIFT: f32 = 16.0;
    pub const FONT_NORMAL: f32 = 14.0;
    pub const FONT_KLEIN: f32 = 11.0;
    pub const FONT_MONO: f32 = 12.0;

    /// `sidebar.py`: setMinimumWidth(350) / setMaximumWidth(500).
    /// Nachgemessen im Bildschirmfoto: 485 px bei 1920 px Fensterbreite.
    pub const SEITENLEISTE_MIN: f32 = 350.0;
    pub const SEITENLEISTE_STANDARD: f32 = 470.0;
    pub const SEITENLEISTE_MAX: f32 = 500.0;

    /// Nachgemessene Bandhoehen aus dem Bildschirmfoto (1920x1080, 1:1).
    pub const HOEHE_REITER: f32 = 34.0;
    pub const HOEHE_KNOPF: f32 = 38.0;
    /// Steuerkreuz: gemessen 137x90 px, Verhaeltnis 0.65.
    pub const KREUZ_VERHAELTNIS: f32 = 0.65;
}

/// Laufzeit-Farbpalette für das komplette Fenster-Chrome (Panels, Knöpfe,
/// Ränder, Text). Das Original nutzte feste Konstanten in `ui::…`; für das
/// vollständige GlasWire-Aussehen brauchen wir sie umschaltbar. `standard()`
/// liefert exakt die bisherigen `ui::`-Werte (1:1-Verhalten bleibt),
/// `glasswire()` den dunkelblauen GlasWire-Look mit Teal-Akzent.
#[derive(Clone, Copy, Debug)]
pub struct UiPalette {
    pub background: Rgb,
    pub surface: Rgb,
    pub surface_variant: Rgb,
    pub primary: Rgb,
    pub primary_hover: Rgb,
    pub border: Rgb,
    pub text: Rgb,
    pub text_secondary: Rgb,
}

impl UiPalette {
    /// Die bisherigen Werte aus `ui::…` — Standard, ändert nichts am Original.
    pub const fn standard() -> Self {
        Self {
            background: ui::BACKGROUND,
            surface: ui::SURFACE,
            surface_variant: ui::SURFACE_VARIANT,
            primary: ui::PRIMARY,
            primary_hover: ui::PRIMARY_HOVER,
            border: ui::BORDER,
            text: ui::TEXT,
            text_secondary: ui::TEXT_SECONDARY,
        }
    }

    /// GlasWire-Look: dunkles Blaugrau, Teal-Akzent, hellgraue Schrift.
    pub const fn glasswire() -> Self {
        Self {
            background: [0x0b, 0x11, 0x1a],
            surface: [0x12, 0x1b, 0x27],
            surface_variant: [0x1c, 0x28, 0x38],
            primary: [0x2f, 0xa8, 0xb0],
            primary_hover: [0x40, 0xc4, 0xcc],
            border: [0x2a, 0x3a, 0x4d],
            text: [0xe8, 0xef, 0xf5],
            text_secondary: [0x8f, 0xa3, 0xb5],
        }
    }

    /// Palette nach Themenname. Nur „GlassWire" weicht ab; andere Themes
    /// behalten das Standard-Chrome (sie ändern nur Globus-/Markerfarben).
    pub fn fuer_theme(name: &str) -> Self {
        if name.eq_ignore_ascii_case("GlassWire") {
            Self::glasswire()
        } else {
            Self::standard()
        }
    }
}

#[cfg(test)]
mod ui_tests {
    use super::ui::*;

    #[test]
    fn palette_matches_original_config_py() {
        assert_eq!(BACKGROUND, [0x1e, 0x1e, 0x1e]);
        assert_eq!(SURFACE, [0x2b, 0x2b, 0x2b]);
        assert_eq!(PRIMARY, [0x0d, 0x73, 0x77]);
        assert_eq!(BORDER, [0x55, 0x55, 0x55]);
        assert_eq!(TEXT_SECONDARY, [0xaa, 0xaa, 0xaa]);
    }

    #[test]
    fn hover_is_brighter_than_primary() {
        let hell = |c: [u8; 3]| c.iter().map(|v| *v as u32).sum::<u32>();
        let (a, b) = (hell(PRIMARY_HOVER), hell(PRIMARY));
        assert!(a > b, "Hover {a} muss heller sein als Primary {b}");
    }

    #[test]
    fn font_sizes_are_ordered() {
        // Zur Laufzeit vergleichen, sonst rechnet der Compiler die Konstanten
        // weg und clippy meldet zu Recht `assert!(true)`.
        let stufen = [FONT_TITEL, FONT_GROSS, FONT_UEBERSCHRIFT, FONT_NORMAL, FONT_KLEIN];
        assert!(stufen.windows(2).all(|w| w[0] > w[1]), "Stufen: {stufen:?}");
        // Die im Original gezaehlten Groessen muessen dabei sein.
        for erwartet in [24.0_f32, 18.0, 16.0, 14.0, 11.0] {
            assert!(stufen.contains(&erwartet), "{erwartet} px fehlt");
        }
    }

    #[test]
    fn sidebar_width_within_original_bounds() {
        // sidebar.py erlaubt 350..500; gemessen wurden 485 px.
        let (min, std, max) = (SEITENLEISTE_MIN, SEITENLEISTE_STANDARD, SEITENLEISTE_MAX);
        assert!(std >= min && std <= max, "{std} liegt nicht in {min}..{max}");
        assert!((std - 485.0).abs() < 40.0, "zu weit von der Messung entfernt: {std}");
    }
}
