//! Zentrale Konfiguration — 1:1 Port von `src/core/config.py`.
use std::path::{Path, PathBuf};
use std::sync::OnceLock;

// ── Fenster ────────────────────────────────────────────────────────────────
/// Fenstertitel. **Aus der Paketversion abgeleitet** — vorher stand hier
/// fest "3.0", waehrend die Seitenleiste "1.4.0" zeigte. Zwei Quellen fuer
/// dieselbe Zahl laufen zwangslaeufig auseinander.
pub const WINDOW_TITLE: &str =
    "🌍 EarthViewer 2.0"; // config.py: WINDOW_TITLE — exakt, ohne Zusatz.
pub const WINDOW_WIDTH: f32 = 1400.0;
pub const WINDOW_HEIGHT: f32 = 900.0;
pub const WINDOW_MIN_WIDTH: f32 = 1000.0;
pub const WINDOW_MIN_HEIGHT: f32 = 600.0;

// ── Rendering ──────────────────────────────────────────────────────────────
pub const SPHERE_RADIUS: f32 = 1.0;
pub const MARKER_OFFSET: f32 = 0.02;
pub const SPHERE_STACKS: u32 = 64;
pub const SPHERE_SLICES: u32 = 128;

// ── Kamera ─────────────────────────────────────────────────────────────────
pub const CAMERA_FOV: f32 = 45.0;
pub const CAMERA_NEAR: f32 = 0.1;
pub const CAMERA_FAR: f32 = 100.0;
pub const CAMERA_DISTANCE: f32 = 2.8;
pub const CAMERA_MIN_DISTANCE: f32 = 1.02; // dicht über der Oberfläche (Google-Earth-Nähe)
pub const CAMERA_MAX_DISTANCE: f32 = 25.0;

// ── Animation ──────────────────────────────────────────────────────────────
pub const AUTO_ROTATE_SPEED: f32 = 0.3;
pub const ROTATION_SENSITIVITY: f32 = 0.3;
pub const ZOOM_FACTOR: f32 = 0.9;

// ── Marker ─────────────────────────────────────────────────────────────────
/// Hintergrund der Globusfläche. Im Original **fest verdrahtet** in
/// `globe_widget.paintGL`: `glClearColor(0.02, 0.02, 0.05, 1.0)`.
/// Das Theme aendert daran nichts — nachgemessen als #05050D.
pub const GLOBE_CLEAR_COLOR: [f32; 3] = [0.02, 0.02, 0.05];

pub const MARKER_COLOR_SEARCH: [f32; 3] = [1.0, 0.9, 0.2];
pub const MARKER_COLOR_TARGET: [f32; 3] = [1.0, 0.1, 0.1];
pub const MARKER_COLOR_TRACEROUTE: [f32; 3] = [0.2, 0.8, 1.0];
pub const MARKER_COLOR_PING: [f32; 3] = [0.2, 1.0, 0.2];

pub const MARKER_SIZE_SEARCH: f32 = 12.0;
pub const MARKER_SIZE_TARGET: f32 = 18.0;
pub const MARKER_SIZE_TRACEROUTE: f32 = 10.0;

// ── Netzwerk ───────────────────────────────────────────────────────────────
pub const TRACEROUTE_MAX_HOPS: u32 = 30;
pub const TRACEROUTE_TIMEOUT_S: f64 = 2.0;
pub const PING_COUNT: u32 = 4;
pub const PING_INTERVAL_S: f64 = 1.0;
pub const WHOIS_TIMEOUT_S: u64 = 10;

// ── Pfade ──────────────────────────────────────────────────────────────────
static PROJECT_ROOT: OnceLock<PathBuf> = OnceLock::new();

/// Projekt-Wurzel. Suchreihenfolge:
/// 1. `$EARTHVIEWER_ROOT`
/// 2. Aufwärtssuche ab dem Binary nach einem Verzeichnis mit `data/`
/// 3. Aktuelles Arbeitsverzeichnis
pub fn project_root() -> &'static Path {
    PROJECT_ROOT.get_or_init(|| {
        if let Ok(p) = std::env::var("EARTHVIEWER_ROOT") {
            let p = PathBuf::from(p);
            if p.is_dir() {
                return p;
            }
        }
        if let Ok(exe) = std::env::current_exe() {
            let mut cur = exe.parent().map(Path::to_path_buf);
            while let Some(dir) = cur {
                if dir.join("data").is_dir() {
                    return dir;
                }
                cur = dir.parent().map(Path::to_path_buf);
            }
        }
        std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."))
    })
}

pub fn data_dir() -> PathBuf { project_root().join("data") }
pub fn geodata_dir() -> PathBuf { data_dir().join("geodata") }
pub fn texture_dir() -> PathBuf { data_dir().join("textures") }
pub fn screenshot_dir() -> PathBuf { project_root().join("screenshots") }
pub fn log_dir() -> PathBuf { project_root().join("logs") }
pub fn session_dir() -> PathBuf { project_root().join("sessions") }
/// Wählt die Erdtextur. **Bevorzugt eine höher aufgelöste Datei**, wenn der
/// Nutzer sie in data/textures/ ablegt — so wird die Kugel beim Tiefzoom
/// schärfer, ohne Code-Änderung und ohne Netz. Reihenfolge (erste vorhandene
/// gewinnt): eigene HD-Textur → mitgelieferte Standardtexturen.
///
/// Empfehlung für scharfen Zoom: eine der freien, key-freien NASA-Texturen
/// (Blue/Black Marble) als `earth_hd.jpg` hier ablegen. Siehe
/// data/textures/README.md für die genauen Bezugsquellen.
pub fn earth_texture() -> PathBuf {
    let dir = texture_dir();
    for name in [
        "earth_hd.jpg",        // vom Nutzer beigesteuert (empfohlen, hochauflösend)
        "earth_hd.png",
        "earth_8k.jpg",
        "earth_16k.jpg",
        "earth_map1.jpg",      // mitgeliefert, größer als earth_map.jpg
        "earth_map.jpg",       // mitgeliefert (Standard-Fallback)
        "earth_day.jpg",
    ] {
        let p = dir.join(name);
        if p.is_file() {
            return p;
        }
    }
    // Nichts gefunden: den bisherigen Standardnamen zurückgeben (load_texture
    // fällt dann selbst auf das eingebaute Gradnetz zurück).
    dir.join("earth_map.jpg")
}

/// Legt die Laufzeit-Verzeichnisse an (Python-Äquivalent: Schleife am Modulkopf).
pub fn ensure_runtime_dirs() {
    for d in [screenshot_dir(), log_dir(), session_dir()] {
        let _ = std::fs::create_dir_all(d);
    }
}
