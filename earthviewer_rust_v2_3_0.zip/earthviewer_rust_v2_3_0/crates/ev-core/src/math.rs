//! Matrix-Utilities — Port von `src/utils/matrix_utils.py`.
//!
//! ⚠️ WICHTIG FÜR SPÄTERE SESSIONS:
//! NumPy speichert row-major und wendet Matrizen als `M @ v` an.
//! glam speichert **column-major** und wendet sie als `M * v` an.
//! Die *mathematischen* Matrizen sind identisch, nur das Speicherlayout
//! unterscheidet sich. Deshalb: niemals `from_cols_array` mit den
//! Python-Zahlen in Lesereihenfolge füttern — immer die glam-Konstruktoren
//! benutzen (wie hier) oder explizit transponieren.
//! Die Multiplikations-*Reihenfolge* bleibt identisch:
//! Python `rot_x @ rot_y @ base`  ==  Rust `rot_x * rot_y * base`.
use glam::{Mat4, Vec3};

/// 4x4-Rotationsmatrix um beliebige Achse (Rodrigues, rechtshändig).
pub fn rotation(angle_deg: f32, axis: Vec3) -> Mat4 {
    let axis = if axis.length_squared() > 0.0 { axis.normalize() } else { Vec3::Y };
    Mat4::from_axis_angle(axis, angle_deg.to_radians())
}

/// Perspektiv-Projektion (OpenGL-Konvention, z ∈ [-1, 1]).
pub fn projection(fov_deg: f32, aspect: f32, near: f32, far: f32) -> Mat4 {
    Mat4::perspective_rh_gl(fov_deg.to_radians(), aspect.max(1e-6), near, far)
}

/// View-Matrix: Kamera auf +Z, Blick auf den Ursprung.
pub fn view(distance: f32) -> Mat4 {
    Mat4::from_translation(Vec3::new(0.0, 0.0, -distance))
}

pub fn translation(x: f32, y: f32, z: f32) -> Mat4 {
    Mat4::from_translation(Vec3::new(x, y, z))
}

/// Great-Circle-Bogen zwischen zwei Punkten auf der Kugel, mit Anhebung.
/// Port von `GlobeWidget._create_arc_points`.
pub fn great_circle_arc(start: Vec3, end: Vec3, segments: usize, height_factor: f32) -> Vec<Vec3> {
    let base_radius = start.length();
    if base_radius <= f32::EPSILON || end.length() <= f32::EPSILON {
        return vec![start, end];
    }
    let s_n = start.normalize();
    let e_n = end.normalize();
    let dot = s_n.dot(e_n).clamp(-1.0, 1.0);
    if dot > 0.9999 {
        return vec![start, end];
    }
    let omega = dot.acos();
    let sin_omega = omega.sin();
    let mut pts = Vec::with_capacity(segments + 1);
    for i in 0..=segments {
        let t = i as f32 / segments as f32;
        let fs = ((1.0 - t) * omega).sin() / sin_omega;
        let fe = (t * omega).sin() / sin_omega;
        let p = s_n * fs + e_n * fe;
        let lift = (std::f32::consts::PI * t).sin() * height_factor;
        pts.push(p * (1.0 + lift) * base_radius);
    }
    pts
}

/// Projiziert einen Weltpunkt auf Bildschirmkoordinaten.
/// Gibt `None` zurück, wenn der Punkt hinter der Kugel oder außerhalb liegt.
/// Port von `GlobeWidget._project_to_screen`.
pub fn project_to_screen(
    pos_3d: Vec3,
    mvp: Mat4,
    view_model: Mat4,
    viewport_w: f32,
    viewport_h: f32,
) -> Option<(f32, f32)> {
    let clip = mvp * pos_3d.extend(1.0);
    if clip.w.abs() < 1e-6 || clip.w < 0.0 {
        return None;
    }
    let ndc = clip.truncate() / clip.w;
    if !(-1.2..=1.2).contains(&ndc.x) || !(-1.2..=1.2).contains(&ndc.y) {
        return None;
    }
    // Rückseiten-Test: Normale in den View-Raum drehen, z muss nach vorn zeigen.
    let n = pos_3d.normalize_or_zero();
    let nv = view_model * n.extend(0.0);
    if nv.z < 0.0 {
        return None;
    }
    Some((
        (ndc.x + 1.0) * 0.5 * viewport_w,
        (1.0 - ndc.y) * 0.5 * viewport_h,
    ))
}

/// Abstand eines Punktes zu einer Strecke — Port von `_dist_to_segment`.
pub fn dist_to_segment(p: (f32, f32), a: (f32, f32), b: (f32, f32)) -> f32 {
    let (abx, aby) = (b.0 - a.0, b.1 - a.1);
    let len2 = abx * abx + aby * aby;
    if len2 < 1e-9 {
        return ((p.0 - a.0).powi(2) + (p.1 - a.1).powi(2)).sqrt();
    }
    let t = (((p.0 - a.0) * abx + (p.1 - a.1) * aby) / len2).clamp(0.0, 1.0);
    let (cx, cy) = (a.0 + t * abx, a.1 + t * aby);
    ((p.0 - cx).powi(2) + (p.1 - cy).powi(2)).sqrt()
}

/// Nächstgelegener Bildschirmpunkt zum Zeiger innerhalb von `radius` Pixeln.
/// Port von `_check_hover` / `_check_satellite_click`.
pub fn pick_nearest(cursor: (f32, f32), points: &[(f32, f32)], radius: f32) -> Option<usize> {
    let mut best: Option<(usize, f32)> = None;
    for (i, p) in points.iter().enumerate() {
        let d = ((cursor.0 - p.0).powi(2) + (cursor.1 - p.1).powi(2)).sqrt();
        if d <= radius && best.map(|(_, bd)| d < bd).unwrap_or(true) {
            best = Some((i, d));
        }
    }
    best.map(|(i, _)| i)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rotation_matches_python_rodrigues() {
        // Python: create_rotation_matrix(90, [1,0,0]) dreht +Y nach +Z
        let m = rotation(90.0, Vec3::X);
        let v = m * Vec3::Y.extend(0.0);
        assert!((v.z - 1.0).abs() < 1e-5, "got {v:?}");
        assert!(v.y.abs() < 1e-5);
    }

    #[test]
    fn view_translates_backwards() {
        let m = view(2.8);
        let p = m * Vec3::ZERO.extend(1.0);
        assert!((p.z + 2.8).abs() < 1e-6);
    }

    #[test]
    fn distance_to_segment_handles_all_cases() {
        // senkrecht auf die Mitte
        assert!((dist_to_segment((5.0, 3.0), (0.0, 0.0), (10.0, 0.0)) - 3.0).abs() < 1e-5);
        // hinter dem Endpunkt -> Abstand zum Endpunkt
        assert!((dist_to_segment((13.0, 4.0), (0.0, 0.0), (10.0, 0.0)) - 5.0).abs() < 1e-5);
        // entartete Strecke (Punkt)
        assert!((dist_to_segment((3.0, 4.0), (0.0, 0.0), (0.0, 0.0)) - 5.0).abs() < 1e-5);
    }

    #[test]
    fn pick_nearest_finds_closest_within_radius() {
        let pts = [(10.0, 10.0), (50.0, 50.0), (12.0, 11.0)];
        assert_eq!(pick_nearest((11.0, 10.5), &pts, 20.0), Some(0));
        assert_eq!(pick_nearest((49.0, 51.0), &pts, 20.0), Some(1));
    }

    #[test]
    fn pick_nearest_respects_radius() {
        let pts = [(100.0, 100.0)];
        assert_eq!(pick_nearest((0.0, 0.0), &pts, 20.0), None);
        assert_eq!(pick_nearest((0.0, 0.0), &[], 20.0), None);
    }

    #[test]
    fn arc_endpoints_are_on_sphere() {
        let a = Vec3::new(1.0, 0.0, 0.0);
        let b = Vec3::new(0.0, 0.0, 1.0);
        let pts = great_circle_arc(a, b, 32, 0.18);
        assert_eq!(pts.len(), 33);
        assert!((pts[0].length() - 1.0).abs() < 1e-5);
        assert!((pts[32].length() - 1.0).abs() < 1e-5);
        // Mitte muss angehoben sein
        assert!(pts[16].length() > 1.15, "mid len {}", pts[16].length());
    }
}
