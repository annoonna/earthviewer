//! Originaltreue — ein Schalter für alle Stellen, an denen die Portierung
//! bewusst vom Python-Original abweicht.
//!
//! Vorgabe von Anno: *„Keine Abweichungen. Füge keine neuen Features hinzu
//! und lass keine alten weg."* Deshalb ist [`Treue::Original`] die
//! **Voreinstellung**: das Programm verhält sich dann exakt wie
//! EarthViewer 2.0, einschließlich seiner Fehler.
//!
//! Die Korrekturen bleiben erhalten und sind einen Haken entfernt
//! ([`Treue::Korrigiert`], Reiter Einstellungen oder
//! `EARTHVIEWER_TREUE=korrigiert`). Jede einzelne ist in
//! `docs/PORT_NOTES.md` mit Fundstelle belegt.

use std::sync::atomic::{AtomicBool, Ordering};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Treue {
    /// 1:1 wie das Python-Original — Voreinstellung.
    Original,
    /// Mit den nachgewiesenen Korrekturen.
    Korrigiert,
}

/// Eine gekapselte Abweichung, für die Anzeige im Einstellungen-Reiter.
pub struct Abweichung {
    pub titel: &'static str,
    pub original: &'static str,
    pub korrigiert: &'static str,
    pub fundstelle: &'static str,
}

pub const ABWEICHUNGEN: &[Abweichung] = &[
    Abweichung {
        titel: "Satelliten-Bezugssystem",
        original: "TEME (inertial) direkt auf die erdfeste Kugel — Drift ~15°/h",
        korrigiert: "TEME → ECEF über GMST",
        fundstelle: "orbit_calculator.py + globe_widget.py",
    },
    Abweichung {
        titel: "Bodenspur-Achsen",
        original: "x=cos·cos, y=cos·sin, z=sin — passt nicht zu GeoLocation",
        korrigiert: "dieselbe Konvention wie to_cartesian",
        fundstelle: "orbit_calculator.py::calculate_ground_track",
    },
    Abweichung {
        titel: "Blickwinkel-Presets",
        original: "„Äquator\" zeigt den Nordpol, „Nordpol\"/„Südpol\" den Äquator",
        korrigiert: "jedes Preset zentriert seinen Punkt",
        fundstelle: "globe_widget.py::align_view",
    },
    Abweichung {
        titel: "Startansicht",
        original: "Blick auf den Nordpol",
        korrigiert: "Blick auf Mitteleuropa",
        fundstelle: "globe_widget.py::__init__",
    },
    Abweichung {
        titel: "Beschriftungen",
        original: "alle zeichnen, auch übereinander",
        korrigiert: "26 px Mindestabstand, Marker bleiben vollzählig",
        fundstelle: "globe_widget.py::_render_labels",
    },
];

static KORRIGIERT: AtomicBool = AtomicBool::new(false);

/// Liest `$EARTHVIEWER_TREUE`. Alles außer `korrigiert`/`fixed` bleibt original.
pub fn init_from_env() {
    if let Ok(v) = std::env::var("EARTHVIEWER_TREUE") {
        let v = v.trim().to_ascii_lowercase();
        set(if v == "korrigiert" || v == "fixed" || v == "0" {
            Treue::Korrigiert
        } else {
            Treue::Original
        });
    }
}

pub fn set(t: Treue) {
    KORRIGIERT.store(t == Treue::Korrigiert, Ordering::Relaxed);
}

pub fn get() -> Treue {
    if KORRIGIERT.load(Ordering::Relaxed) { Treue::Korrigiert } else { Treue::Original }
}

/// Kurzform: `true`, wenn die Korrekturen aktiv sind.
pub fn korrigiert() -> bool {
    KORRIGIERT.load(Ordering::Relaxed)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Die Tests teilen sich den globalen Schalter — deshalb nacheinander
    /// in einem einzigen Test, sonst stören sie sich gegenseitig.
    #[test]
    fn schalter_und_abweichungen() {
        // Voreinstellung ist 1:1 zum Original.
        set(Treue::Original);
        assert_eq!(get(), Treue::Original);
        assert!(!korrigiert());

        set(Treue::Korrigiert);
        assert_eq!(get(), Treue::Korrigiert);
        assert!(korrigiert());

        set(Treue::Original);
        assert!(!korrigiert());
    }

    #[test]
    fn jede_abweichung_ist_beschrieben() {
        // Ueber eine Laufzeit-Bindung, sonst rechnet clippy die Konstante weg.
        let liste: &[Abweichung] = ABWEICHUNGEN;
        assert!(liste.len() >= 5, "zu wenige Eintraege: {}", liste.len());
        for a in liste {
            assert!(!a.titel.is_empty(), "Titel fehlt");
            assert!(!a.original.is_empty(), "Originalverhalten fehlt: {}", a.titel);
            assert!(!a.korrigiert.is_empty(), "Korrektur fehlt: {}", a.titel);
            assert!(
                a.fundstelle.contains(".py"),
                "Fundstelle muss auf eine Python-Datei zeigen: {}",
                a.titel
            );
        }
    }

    #[test]
    fn titel_sind_eindeutig() {
        let mut t: Vec<&str> = ABWEICHUNGEN.iter().map(|a| a.titel).collect();
        let n = t.len();
        t.sort_unstable();
        t.dedup();
        assert_eq!(t.len(), n, "doppelter Titel in ABWEICHUNGEN");
    }
}
