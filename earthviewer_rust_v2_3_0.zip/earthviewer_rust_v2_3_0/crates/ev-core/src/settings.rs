//! Persistente Einstellungen — Port von `src/core/settings.py`.
//!
//! 🔐 SICHERHEITSHINWEIS (siehe docs/SECURITY_NOTES.md):
//! Das Python-Original hat den VirusTotal-API-Key im Klartext in
//! `settings.json` abgelegt und diese Datei mit ins Repo/ZIP gepackt.
//! Diese Portierung liest den Key bevorzugt aus `$EARTHVIEWER_VT_API_KEY`
//! und schreibt ihn niemals in eine ausgelieferte Datei.
use serde_json::{Map, Value};
use std::path::PathBuf;
use std::sync::{Mutex, OnceLock};

pub struct Settings {
    path: PathBuf,
    map: Map<String, Value>,
}

impl Settings {
    pub fn load() -> Self {
        let path = crate::config::project_root().join("settings.json");
        let map = std::fs::read_to_string(&path)
            .ok()
            .and_then(|s| serde_json::from_str::<Value>(&s).ok())
            .and_then(|v| v.as_object().cloned())
            .unwrap_or_else(Self::defaults);
        Self { path, map }
    }

    fn defaults() -> Map<String, Value> {
        let mut m = Map::new();
        m.insert("marker_offset".into(), Value::from(0.02));
        m.insert("auto_rotate_speed".into(), Value::from(0.3));
        m.insert("show_markers".into(), Value::Bool(true));
        m.insert("show_labels".into(), Value::Bool(true));
        m.insert("theme".into(), Value::from(crate::theme::DEFAULT_THEME));
        m
    }

    pub fn save(&self) -> bool {
        // API-Keys nie mit rausschreiben.
        let mut sanitized = self.map.clone();
        sanitized.remove("virustotal_api_key");
        serde_json::to_string_pretty(&Value::Object(sanitized))
            .ok()
            .and_then(|s| std::fs::write(&self.path, s).ok())
            .is_some()
    }

    pub fn get_f32(&self, key: &str, default: f32) -> f32 {
        self.map.get(key).and_then(Value::as_f64).map(|v| v as f32).unwrap_or(default)
    }
    pub fn get_bool(&self, key: &str, default: bool) -> bool {
        self.map.get(key).and_then(Value::as_bool).unwrap_or(default)
    }
    pub fn get_string(&self, key: &str, default: &str) -> String {
        self.map.get(key).and_then(Value::as_str).unwrap_or(default).to_string()
    }
    pub fn set<V: Into<Value>>(&mut self, key: &str, value: V) {
        self.map.insert(key.to_string(), value.into());
        self.save();
    }

    /// VirusTotal-Key: **nur** aus der Umgebung.
    pub fn virustotal_api_key() -> Option<String> {
        std::env::var("EARTHVIEWER_VT_API_KEY").ok().filter(|s| !s.trim().is_empty())
    }
}

static GLOBAL: OnceLock<Mutex<Settings>> = OnceLock::new();

pub fn global() -> &'static Mutex<Settings> {
    GLOBAL.get_or_init(|| Mutex::new(Settings::load()))
}
