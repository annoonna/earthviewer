//! GeoLocation — Port von `src/core/geo_location.py`.
use glam::Vec3;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
pub struct GeoLocation {
    pub name: String,
    pub lat: f32,
    pub lon: f32,
    #[serde(default)]
    pub country: String,
    #[serde(default = "default_kind")]
    pub location_type: String,
    #[serde(default)]
    pub metadata: BTreeMap<String, String>,
}

fn default_kind() -> String { "city".into() }

impl GeoLocation {
    pub fn new(name: impl Into<String>, lat: f32, lon: f32) -> Self {
        Self { name: name.into(), lat, lon, country: String::new(),
               location_type: "city".into(), metadata: BTreeMap::new() }
    }

    pub fn with_country(mut self, c: impl Into<String>) -> Self { self.country = c.into(); self }
    pub fn with_kind(mut self, k: impl Into<String>) -> Self { self.location_type = k.into(); self }
    pub fn with_meta(mut self, k: &str, v: impl Into<String>) -> Self {
        self.metadata.insert(k.into(), v.into()); self
    }

    /// Lat/Lon → kartesisch. Achtung: identische Achsen-Konvention wie Python
    /// (Y = Nord, Z zeigt bei lon=0 zum Betrachter).
    pub fn to_cartesian(&self, radius: f32) -> Vec3 {
        let lat = self.lat.to_radians();
        let lon = self.lon.to_radians();
        Vec3::new(
            radius * lat.cos() * lon.sin(),
            radius * lat.sin(),
            radius * lat.cos() * lon.cos(),
        )
    }

    /// Textur-UV (equirectangular).
    pub fn to_uv(&self) -> (f32, f32) {
        ((self.lon + 180.0) / 360.0, (90.0 - self.lat) / 180.0)
    }

    /// Haversine-Distanz in km.
    pub fn distance_to(&self, other: &GeoLocation) -> f64 {
        const R: f64 = 6371.0;
        let lat1 = (self.lat as f64).to_radians();
        let lon1 = (self.lon as f64).to_radians();
        let lat2 = (other.lat as f64).to_radians();
        let lon2 = (other.lon as f64).to_radians();
        let dlat = lat2 - lat1;
        let dlon = lon2 - lon1;
        let a = (dlat / 2.0).sin().powi(2)
            + lat1.cos() * lat2.cos() * (dlon / 2.0).sin().powi(2);
        R * 2.0 * a.sqrt().clamp(-1.0, 1.0).asin()
    }
}
