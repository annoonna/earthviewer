//! Länderfahnen und -namen — Port von `src/utils/country_flags.py`.
//!
//! Das Original pflegte eine Tabelle mit ~250 Emoji von Hand. Unnötig:
//! ISO-3166-1-alpha-2 lässt sich **rechnerisch** in Regional-Indicator-Symbole
//! überführen ('A' → U+1F1E6). Das deckt alle Codes ab, auch künftige.

/// ISO-Code → Fahnen-Emoji. `"DE"` → 🇩🇪
/// Emoji-Flagge aus ISO-Code (Regional-Indicator-Paar). ACHTUNG: egui's
/// eingebauter NotoEmoji-Font enthält KEINE Flaggen — dort erscheinen Kästchen.
/// Für die egui-Oberfläche stattdessen `flag_badge()` verwenden.
pub fn flag(iso: &str) -> String {
    let c = iso.trim().to_ascii_uppercase();
    let b = c.as_bytes();
    if b.len() != 2 || !b.iter().all(|x| x.is_ascii_uppercase()) {
        return "?".into();
    }
    b.iter()
        .filter_map(|x| char::from_u32(0x1F1E6 + (*x - b'A') as u32))
        .collect()
}

/// Text-Länderkürzel für die Oberfläche — rendert immer (kein Emoji-Font nötig).
/// „DE" → „[DE]". Unbekanntes → leer.
pub fn flag_badge(iso: &str) -> String {
    let c = iso.trim().to_ascii_uppercase();
    if c.is_empty() || c == "UNKNOWN" || c == "XX" {
        return String::new();
    }
    if c.len() == 2 && c.bytes().all(|x| x.is_ascii_uppercase()) {
        format!("[{c}]")
    } else {
        String::new()
    }
}

/// ISO-Code → Klarname (deutsch). Deckt die im Netzverkehr häufigsten ab;
/// unbekannte Codes werden unverändert zurückgegeben.
pub fn name(iso: &str) -> String {
    let c = iso.trim().to_ascii_uppercase();
    let n = match c.as_str() {
        "DE" => "Deutschland",   "AT" => "Österreich",  "CH" => "Schweiz",
        "US" => "USA",           "GB" => "Vereinigtes Königreich", "UK" => "Vereinigtes Königreich",
        "FR" => "Frankreich",    "IT" => "Italien",     "ES" => "Spanien",
        "NL" => "Niederlande",   "BE" => "Belgien",     "LU" => "Luxemburg",
        "PL" => "Polen",         "CZ" => "Tschechien",  "SK" => "Slowakei",
        "DK" => "Dänemark",      "SE" => "Schweden",    "NO" => "Norwegen",
        "FI" => "Finnland",      "IS" => "Island",      "IE" => "Irland",
        "PT" => "Portugal",      "GR" => "Griechenland","HU" => "Ungarn",
        "RO" => "Rumänien",      "BG" => "Bulgarien",   "HR" => "Kroatien",
        "SI" => "Slowenien",     "RS" => "Serbien",     "UA" => "Ukraine",
        "RU" => "Russland",      "BY" => "Belarus",     "LT" => "Litauen",
        "LV" => "Lettland",      "EE" => "Estland",     "TR" => "Türkei",
        "CN" => "China",         "JP" => "Japan",       "KR" => "Südkorea",
        "IN" => "Indien",        "SG" => "Singapur",    "HK" => "Hongkong",
        "TW" => "Taiwan",        "TH" => "Thailand",    "VN" => "Vietnam",
        "ID" => "Indonesien",    "MY" => "Malaysia",    "PH" => "Philippinen",
        "AU" => "Australien",    "NZ" => "Neuseeland",  "CA" => "Kanada",
        "MX" => "Mexiko",        "BR" => "Brasilien",   "AR" => "Argentinien",
        "CL" => "Chile",         "CO" => "Kolumbien",   "PE" => "Peru",
        "ZA" => "Südafrika",     "EG" => "Ägypten",     "NG" => "Nigeria",
        "KE" => "Kenia",         "MA" => "Marokko",     "IL" => "Israel",
        "AE" => "VAE",           "SA" => "Saudi-Arabien","IR" => "Iran",
        "PK" => "Pakistan",      "BD" => "Bangladesch", "KZ" => "Kasachstan",
        "" | "UNKNOWN" => "unbekannt",
        other => return other.to_string(),
    };
    n.to_string()
}

/// `"DE"` → `"🇩🇪 Deutschland"` — das, was `get_flag_and_name` lieferte.
pub fn flag_and_name(iso: &str) -> String {
    let c = iso.trim();
    if c.is_empty() || c.eq_ignore_ascii_case("unknown") {
        return "unbekannt".into();
    }
    let badge = flag_badge(c);
    if badge.is_empty() { name(c) } else { format!("{badge} {}", name(c)) }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn computes_flags_from_iso() {
        assert_eq!(flag("DE"), "🇩🇪");
        assert_eq!(flag("US"), "🇺🇸");
        assert_eq!(flag("jp"), "🇯🇵"); // Kleinschreibung erlaubt
    }

    #[test]
    fn flag_is_two_regional_indicators() {
        let f = flag("FR");
        let chars: Vec<char> = f.chars().collect();
        assert_eq!(chars.len(), 2);
        assert!(chars.iter().all(|c| (0x1F1E6..=0x1F1FF).contains(&(*c as u32))));
    }

    #[test]
    fn invalid_codes_get_question_mark() {
        // 🏳 (U+1F3F3) fehlt in NotoEmoji — im Bildschirmfoto erschien ein
        // leeres Kaestchen. Deshalb schlichtes Fragezeichen.
        assert_eq!(flag(""), "?");
        assert_eq!(flag("D"), "?");
        assert_eq!(flag("DEU"), "?");
        assert_eq!(flag("D1"), "?");
    }

    #[test]
    fn known_names_are_german() {
        assert_eq!(name("DE"), "Deutschland");
        assert_eq!(name("CH"), "Schweiz");
        assert_eq!(name(""), "unbekannt");
    }

    #[test]
    fn unknown_code_passes_through() {
        assert_eq!(name("ZZ"), "ZZ");
    }

    #[test]
    fn flag_and_name_combines() {
        assert_eq!(flag_and_name("DE"), "[DE] Deutschland");
        assert_eq!(flag_and_name(""), "unbekannt");
        assert_eq!(flag_and_name("Unknown"), "unbekannt");
    }

    #[test]
    fn flag_badge_rendert_immer() {
        // Textkürzel statt Emoji — rendert in egui ohne Emoji-Font.
        assert_eq!(flag_badge("DE"), "[DE]");
        assert_eq!(flag_badge("us"), "[US]");
        assert_eq!(flag_badge(""), "");
        assert_eq!(flag_badge("Unknown"), "");
        assert_eq!(flag_badge("XX"), "");
        assert_eq!(flag_badge("Germany"), ""); // Klarname ist kein ISO-Code
    }
}
