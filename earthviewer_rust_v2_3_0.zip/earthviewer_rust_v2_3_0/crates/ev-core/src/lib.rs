//! `ev-core` — gemeinsames Fundament des EarthViewer (Rust-Portierung).
//!
//! Entspricht dem Python-Paket `src/core/` + `src/utils/matrix_utils.py`.
pub mod config;
pub mod country;
pub mod geo;
pub mod math;
pub mod settings;
pub mod theme;
pub mod treue;

pub use geo::GeoLocation;
pub use theme::Theme;
pub use treue::Treue;

/// Versions-String, wird im Fenstertitel und im Startbanner benutzt.
pub const VERSION: &str = env!("CARGO_PKG_VERSION");


#[cfg(test)]
mod titel_tests {
    #[test]
    fn fenstertitel_ist_der_originaltitel() {
        // config.py: WINDOW_TITLE = "🌍 EarthViewer 2.0" — Zeichen fuer Zeichen.
        // Die interne Crate-Version darf hier NICHT hineinlaufen; das war die
        // Quelle der "1.6.0/1.7.0/1.9.0"-Anzeigen, die der Auftraggeber zu
        // Recht beanstandet hat.
        assert_eq!(crate::config::WINDOW_TITLE, "🌍 EarthViewer 2.0");
    }
}
