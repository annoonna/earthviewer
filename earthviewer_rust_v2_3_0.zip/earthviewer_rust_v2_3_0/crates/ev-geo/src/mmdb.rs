//! MaxMind-GeoLite2-Zugriff. Ersetzt das Python-Paket `geoip2`.
use ev_core::GeoLocation;
use maxminddb::geoip2;
use std::net::IpAddr;
use std::path::Path;

pub struct GeoIpReader {
    reader: maxminddb::Reader<Vec<u8>>,
}

impl GeoIpReader {
    pub fn open(path: &Path) -> anyhow::Result<Self> {
        let reader = maxminddb::Reader::open_readfile(path)?;
        Ok(Self { reader })
    }

    /// City-Lookup → GeoLocation (Name = Stadt, country = ISO-Code).
    pub fn city(&self, ip: IpAddr) -> Option<GeoLocation> {
        let rec: geoip2::City = self.reader.lookup(ip).ok()?;
        let loc = rec.location?;
        let (lat, lon) = (loc.latitude?, loc.longitude?);
        let city_name = rec
            .city
            .as_ref()
            .and_then(|c| c.names.as_ref())
            .and_then(|n| n.get("en").or_else(|| n.get("de")))
            .map(|s| s.to_string())
            .unwrap_or_else(|| format!("IP: {ip}"));
        let iso = rec
            .country
            .as_ref()
            .and_then(|c| c.iso_code)
            .unwrap_or("")
            .to_string();
        Some(
            GeoLocation::new(city_name, lat as f32, lon as f32)
                .with_country(iso)
                .with_kind("ip")
                .with_meta("ip", ip.to_string()),
        )
    }

    /// ASN-Lookup, falls eine ASN-MMDB geladen wurde.
    pub fn asn(&self, ip: IpAddr) -> Option<(u32, String)> {
        let rec: geoip2::Asn = self.reader.lookup(ip).ok()?;
        Some((
            rec.autonomous_system_number?,
            rec.autonomous_system_organization.unwrap_or("").to_string(),
        ))
    }
}
