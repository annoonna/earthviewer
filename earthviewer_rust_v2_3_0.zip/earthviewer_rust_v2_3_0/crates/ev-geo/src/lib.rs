//! `ev-geo` — Geodaten-Verwaltung.
//! Port von `src/data/geo_manager.py` (CSV-Städte + MaxMind GeoLite2).

use ev_core::config;
use ev_core::GeoLocation;
use std::net::IpAddr;
use std::path::{Path, PathBuf};

pub mod countries;
pub mod mmdb;
use mmdb::GeoIpReader;

pub struct GeoDataManager {
    pub data_root: PathBuf,
    pub locations: Vec<GeoLocation>,
    pub geoip: Option<GeoIpReader>,
    /// Separate ASN-Datenbank (GeoLite2-ASN.mmdb), falls vorhanden — für die
    /// Provider-/Netzbetreiber-Anzeige pro Verbindung (Runde D).
    pub asn: Option<GeoIpReader>,
}

impl GeoDataManager {
    pub fn new() -> Self {
        Self::with_root(config::geodata_dir())
    }

    pub fn with_root(root: impl Into<PathBuf>) -> Self {
        let data_root = root.into();
        let mut me = Self { data_root, locations: Vec::new(), geoip: None, asn: None };
        me.load_csv_data();
        me.load_geoip_database();
        eprintln!("✅ {} Orte geladen", me.locations.len());
        if me.geoip.is_some() {
            eprintln!("✅ GeoIP-Datenbank aktiv");
        }
        me
    }

    /// Rekursiver Walk über `data/geodata/**/*.csv`.
    /// Der Ordnername ist — wie im Original — das Land.
    fn load_csv_data(&mut self) {
        if !self.data_root.exists() {
            eprintln!("⚠️  Geodaten-Ordner nicht gefunden: {}", self.data_root.display());
            eprintln!("    Dort erwartet: <Land>/staedte.csv mit Spalten name|city, lat, lon|lng");
            return;
        }
        eprintln!("📁 Geodaten: {}", self.data_root.display());
        let mut files = Vec::new();
        collect_files(&self.data_root, "csv", &mut files);
        for f in files {
            let country = f
                .parent()
                .and_then(|p| p.file_name())
                .map(|s| s.to_string_lossy().to_string())
                .unwrap_or_default();
            if let Err(e) = self.read_city_csv(&f, &country) {
                eprintln!("⚠️  Fehler: {}: {e}", f.display());
            }
        }
    }

    fn read_city_csv(&mut self, path: &Path, country: &str) -> anyhow::Result<()> {
        let mut rdr = csv::ReaderBuilder::new()
            .flexible(true)
            .from_path(path)?;
        let headers = rdr.headers()?.clone();
        let idx = |names: &[&str]| -> Option<usize> {
            headers.iter().position(|h| {
                let h = h.trim().to_ascii_lowercase();
                names.iter().any(|n| h == *n)
            })
        };
        let i_name = idx(&["name", "city"]);
        let i_lat = idx(&["lat", "latitude"]);
        let i_lon = idx(&["lon", "lng", "longitude"]);
        let (Some(i_name), Some(i_lat), Some(i_lon)) = (i_name, i_lat, i_lon) else {
            return Ok(());
        };
        for rec in rdr.records() {
            let Ok(rec) = rec else { continue };
            let name = rec.get(i_name).unwrap_or("").trim();
            if name.is_empty() {
                continue;
            }
            let (Ok(lat), Ok(mut lon)) = (
                rec.get(i_lat).unwrap_or("0").trim().parse::<f32>(),
                rec.get(i_lon).unwrap_or("0").trim().parse::<f32>(),
            ) else {
                continue;
            };
            if lon > 180.0 {
                lon -= 360.0;
            }
            self.locations.push(
                GeoLocation::new(name, lat, lon).with_country(country).with_kind("city"),
            );
        }
        Ok(())
    }

    /// Sucht die MMDB. 1:1 wie `_load_geoip_database`:
    /// `data_root.rglob("*.mmdb")`, und **nur** Dateien mit `city` im Namen.
    /// Country- und ASN-Datenbanken ignoriert das Original bewusst.
    ///
    /// Mit aktiven Korrekturen (`ev_core::treue`) wird zusätzlich eine
    /// Country-MMDB als Rückfall akzeptiert.
    fn load_geoip_database(&mut self) {
        let mut files = Vec::new();
        collect_files(&self.data_root, "mmdb", &mut files);

        if files.is_empty() {
            eprintln!("ℹ️  Keine *.mmdb unter {}", self.data_root.display());
            eprintln!("    GeoLite2-City.mmdb dort ablegen (Unterordner sind erlaubt).");
            eprintln!("    Hilfe: docs/GEOIP_EINRICHTEN.md oder ./geodaten_einrichten.sh");
            return;
        }

        // Gefundene Dateien nennen — sonst raet man, warum nichts passiert.
        for f in &files {
            eprintln!("   gefunden: {}", f.display());
        }

        let passt = |p: &std::path::Path, wort: &str| {
            p.file_name()
                .map(|n| n.to_string_lossy().to_lowercase().contains(wort))
                .unwrap_or(false)
        };

        let mut kandidaten: Vec<&PathBuf> = files.iter().filter(|f| passt(f, "city")).collect();
        if kandidaten.is_empty() && ev_core::treue::korrigiert() {
            kandidaten = files.iter().filter(|f| passt(f, "country")).collect();
            if !kandidaten.is_empty() {
                eprintln!("ℹ️  Keine City-Datenbank — nutze Country als Rückfall.");
            }
        }
        if kandidaten.is_empty() {
            eprintln!("⚠️  Keine Datei mit \"city\" im Namen — das Original nimmt nur solche.");
            eprintln!("    Country- und ASN-Datenbanken werden nicht ausgewertet.");
            return;
        }

        for f in kandidaten {
            match GeoIpReader::open(f) {
                Ok(r) => {
                    eprintln!("✅ GeoIP: {}", f.display());
                    self.geoip = Some(r);
                    break;
                }
                Err(e) => eprintln!("⚠️  GeoIP-Fehler ({}): {e}", f.display()),
            }
        }
        // Separate ASN-Datenbank laden (Provider-Anzeige) — optional.
        if let Some(f) = files.iter().find(|f| passt(f, "asn")) {
            match GeoIpReader::open(f) {
                Ok(r) => { eprintln!("✅ ASN: {}", f.display()); self.asn = Some(r); }
                Err(e) => eprintln!("⚠️  ASN-Fehler ({}): {e}", f.display()),
            }
        }
    }

    /// Provider/Netzbetreiber zu einer IP: (AS-Nummer, Organisation).
    pub fn asn_lookup(&self, ip: &str) -> Option<(u32, String)> {
        let addr: IpAddr = ip.parse().ok()?;
        self.asn.as_ref()?.asn(addr)
    }

    /// Universelle Suche: Koordinaten → IP → Text. Port von `GeoDataManager.search`.
    pub fn search(&self, query: &str) -> Vec<GeoLocation> {
        let query = query.trim();
        if query.is_empty() {
            return Vec::new();
        }

        // 1) "lat, lon"
        let parts: Vec<&str> = query.split(',').collect();
        if parts.len() == 2 {
            if let (Ok(lat), Ok(lon)) =
                (parts[0].trim().parse::<f32>(), parts[1].trim().parse::<f32>())
            {
                if (-90.0..=90.0).contains(&lat) && (-180.0..=180.0).contains(&lon) {
                    return vec![GeoLocation::new(
                        format!("Koordinaten: {lat:.4}, {lon:.4}"),
                        lat,
                        lon,
                    )
                    .with_kind("custom")];
                }
            }
        }

        // 2) IP-Adresse
        if query.parse::<IpAddr>().is_ok() {
            if let Some(loc) = self.lookup_ip(query) {
                return vec![loc];
            }
        }

        // 2.5) Länderabfrage: „Deutschland" → alle 16 Bundesländer statt eines
        //      Ortsnamens-Zufallstreffers wie „Deutschlandsberg [Austria]".
        if let Some(land) = countries::erkenne_land(query) {
            // Erst die hinterlegten Verwaltungssitze (präzise, kuratiert).
            if !land.capitals.is_empty() {
                let mut v: Vec<GeoLocation> = land
                    .capitals
                    .iter()
                    .map(|(name, lat, lon)| {
                        GeoLocation::new(*name, *lat, *lon)
                            .with_country(land.display)
                            .with_kind("region")
                    })
                    .collect();
                // Zusätzlich die Städte des Landes anhängen (falls vorhanden),
                // damit man nach dem Überblick weiter hineinsuchen kann.
                let extra: Vec<GeoLocation> = self
                    .locations
                    .iter()
                    .filter(|l| l.country.eq_ignore_ascii_case(land.folder))
                    .take(200)
                    .cloned()
                    .collect();
                v.extend(extra);
                return Self::dedupe(v);
            }
            // Kein kuratierter Satz: alle Städte des Landes zeigen.
            let v: Vec<GeoLocation> = self
                .locations
                .iter()
                .filter(|l| l.country.eq_ignore_ascii_case(land.folder))
                .cloned()
                .collect();
            if !v.is_empty() {
                return Self::dedupe(v);
            }
        }

        // 3) Textsuche
        let terms: Vec<String> = query
            .to_lowercase()
            .split_whitespace()
            .map(str::to_string)
            .collect();
        let mut results: Vec<GeoLocation> = Vec::new();

        if terms.len() > 1 {
            for term in &terms {
                if term.len() < 3 {
                    continue;
                }
                let mut hits: Vec<&GeoLocation> = self
                    .locations
                    .iter()
                    .filter(|l| {
                        l.name.to_lowercase().contains(term)
                            || l.country.to_lowercase().contains(term)
                    })
                    .collect();
                hits.sort_by_key(|l| l.name.len());
                results.extend(hits.into_iter().take(10).cloned());
            }
        } else {
            let q = terms.first().cloned().unwrap_or_default();
            let mut hits: Vec<&GeoLocation> = self
                .locations
                .iter()
                .filter(|l| {
                    l.name.to_lowercase().contains(&q) || l.country.to_lowercase().contains(&q)
                })
                .collect();
            hits.sort_by_key(|l| l.name.len());
            results = hits.into_iter().cloned().collect();
        }

        // Duplikate über gerundete Position entfernen (wie im Original).
        Self::dedupe(results)
    }

    /// Entfernt Duplikate über die gerundete Position und deckelt bei 50 (bzw.
    /// 216 für Länderansichten mit vielen Städten). Port der Schlussschleife.
    fn dedupe(results: Vec<GeoLocation>) -> Vec<GeoLocation> {
        let mut seen: Vec<(i32, i32)> = Vec::new();
        let mut unique = Vec::new();
        for loc in results {
            let key = ((loc.lat * 10.0).round() as i32, (loc.lon * 10.0).round() as i32);
            if !seen.contains(&key) {
                seen.push(key);
                unique.push(loc);
            }
            if unique.len() >= 216 {
                break;
            }
        }
        unique
    }

    pub fn lookup_ip(&self, ip: &str) -> Option<GeoLocation> {
        let reader = self.geoip.as_ref()?;
        let addr: IpAddr = ip.parse().ok()?;
        reader.city(addr)
    }
}

impl Default for GeoDataManager {
    fn default() -> Self { Self::new() }
}

/// Ersetzt `Path.rglob("*.ext")` — iterativ, damit tiefe Bäume den Stack nicht sprengen.
fn collect_files(root: &Path, ext: &str, out: &mut Vec<PathBuf>) {
    let mut stack = vec![root.to_path_buf()];
    while let Some(dir) = stack.pop() {
        let Ok(entries) = std::fs::read_dir(&dir) else { continue };
        for e in entries.flatten() {
            let p = e.path();
            if p.is_dir() {
                stack.push(p);
            } else if p.extension().map(|x| x.eq_ignore_ascii_case(ext)).unwrap_or(false) {
                out.push(p);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn coordinate_query_parses() {
        let gm = GeoDataManager { data_root: PathBuf::from("/nonexistent"), locations: vec![], geoip: None, asn: None };
        let r = gm.search("51.34, 12.38");
        assert_eq!(r.len(), 1);
        assert!((r[0].lat - 51.34).abs() < 1e-4);
        assert_eq!(r[0].location_type, "custom");
    }

    #[test]
    fn text_search_dedups_by_position() {
        let gm = GeoDataManager {
            data_root: PathBuf::from("/nonexistent"),
            locations: vec![
                GeoLocation::new("Leipzig", 51.34, 12.38).with_country("Germany"),
                GeoLocation::new("Leipzig-Mitte", 51.34, 12.38).with_country("Germany"),
                GeoLocation::new("Leipzig", 40.0, -85.0).with_country("United States"),
            ],
            geoip: None,
            asn: None,
        };
        let r = gm.search("leipzig");
        assert_eq!(r.len(), 2, "gleiche Position muss dedupliziert werden");
    }

    /// Die Auswahlregel des Originals: nur „city" im Dateinamen.
    fn waehlt_city(dateien: &[&str], korrigiert: bool) -> Option<String> {
        let passt = |n: &str, w: &str| n.to_lowercase().contains(w);
        let mut k: Vec<&&str> = dateien.iter().filter(|n| passt(n, "city")).collect();
        if k.is_empty() && korrigiert {
            k = dateien.iter().filter(|n| passt(n, "country")).collect();
        }
        k.first().map(|s| s.to_string())
    }

    #[test]
    fn only_city_databases_are_accepted() {
        let d = ["GeoLite2-ASN.mmdb", "GeoLite2-Country.mmdb", "GeoLite2-City.mmdb"];
        assert_eq!(waehlt_city(&d, false).as_deref(), Some("GeoLite2-City.mmdb"));
    }

    #[test]
    fn country_only_is_ignored_in_fidelity_mode() {
        // 1:1 wie das Original: ohne City-Datenbank bleibt GeoIP aus.
        let d = ["GeoLite2-ASN.mmdb", "GeoLite2-Country.mmdb"];
        assert_eq!(waehlt_city(&d, false), None);
        // Mit Korrekturen greift der Rueckfall.
        assert_eq!(waehlt_city(&d, true).as_deref(), Some("GeoLite2-Country.mmdb"));
    }

    #[test]
    fn recursive_search_finds_nested_files() {
        // rglob ist rekursiv — Unterordner wie GeoLite2-City_20251017/ gehen.
        let dir = std::env::temp_dir().join("ev_geo_test/GeoLite2-City_20251017");
        std::fs::create_dir_all(&dir).unwrap();
        let f = dir.join("GeoLite2-City.mmdb");
        std::fs::write(&f, b"kein echtes MMDB").unwrap();
        let mut out = Vec::new();
        collect_files(&std::env::temp_dir().join("ev_geo_test"), "mmdb", &mut out);
        assert_eq!(out.len(), 1, "verschachtelte Datei muss gefunden werden");
        let _ = std::fs::remove_dir_all(std::env::temp_dir().join("ev_geo_test"));
    }

    #[test]
    fn empty_query_yields_nothing() {
        let gm = GeoDataManager { data_root: PathBuf::from("/nonexistent"), locations: vec![], geoip: None, asn: None };
        assert!(gm.search("   ").is_empty());
    }
}
