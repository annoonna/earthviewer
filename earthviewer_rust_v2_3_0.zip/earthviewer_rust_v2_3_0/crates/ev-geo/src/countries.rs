//! Länder-Erkennung für die Ortssuche.
//!
//! Problem, das dieses Modul löst: Tippt der Nutzer „Deutschland", fand die
//! reine Textsuche „Deutschlandsberg [Austria]" (ein Ort, dessen *Name* die
//! Zeichenkette enthält) und stellte ihn wegen kürzerer Namenslänge nach oben.
//! Das Land selbst wurde nie erkannt.
//!
//! Lösung: eine kleine Tabelle bekannter Länder mit deutschen und englischen
//! Namen, die auf den Ordnernamen in `data/geodata/<Land>` abbildet. Für
//! Bundesstaaten-Länder liefern wir zusätzlich die Verwaltungshauptstädte, damit
//! „Deutschland" alle 16 Bundesländer als Marker zeigt statt eines Zufallstreffers.

/// Ein Land: Anzeigename, der Ordnername in data/geodata, deutsche/englische
/// Aliasse (klein geschrieben) und optional die Verwaltungssitze.
pub struct Country {
    /// Anzeigename in der Trefferliste, z. B. „Deutschland".
    pub display: &'static str,
    /// Ordnername unter data/geodata, z. B. „Germany".
    pub folder: &'static str,
    /// Kleingeschriebene Namen, die diesen Eintrag treffen.
    pub aliases: &'static [&'static str],
    /// Verwaltungssitze (Name, lat, lon). Leer = keine hinterlegt.
    pub capitals: &'static [(&'static str, f32, f32)],
}

/// Die 16 deutschen Landeshauptstädte (bzw. Stadtstaaten selbst).
/// Quelle: Landeshauptstädte, WGS84.
const DE_LAENDER: &[(&str, f32, f32)] = &[
    ("Stuttgart (Baden-Württemberg)", 48.7758, 9.1829),
    ("München (Bayern)", 48.1372, 11.5755),
    ("Berlin", 52.5200, 13.4050),
    ("Potsdam (Brandenburg)", 52.4009, 13.0591),
    ("Bremen", 53.0793, 8.8017),
    ("Hamburg", 53.5511, 9.9937),
    ("Wiesbaden (Hessen)", 50.0826, 8.2400),
    ("Schwerin (Mecklenburg-Vorpommern)", 53.6355, 11.4012),
    ("Hannover (Niedersachsen)", 52.3759, 9.7320),
    ("Düsseldorf (Nordrhein-Westfalen)", 51.2277, 6.7735),
    ("Mainz (Rheinland-Pfalz)", 49.9929, 8.2473),
    ("Saarbrücken (Saarland)", 49.2402, 6.9969),
    ("Dresden (Sachsen)", 51.0504, 13.7373),
    ("Magdeburg (Sachsen-Anhalt)", 52.1205, 11.6276),
    ("Kiel (Schleswig-Holstein)", 54.3233, 10.1228),
    ("Erfurt (Thüringen)", 50.9848, 11.0299),
];

/// Österreichische Landeshauptstädte.
const AT_LAENDER: &[(&str, f32, f32)] = &[
    ("Wien", 48.2082, 16.3738),
    ("Sankt Pölten (Niederösterreich)", 48.2047, 15.6256),
    ("Linz (Oberösterreich)", 48.3069, 14.2858),
    ("Salzburg", 47.8095, 13.0550),
    ("Graz (Steiermark)", 47.0707, 15.4395),
    ("Innsbruck (Tirol)", 47.2692, 11.4041),
    ("Bregenz (Vorarlberg)", 47.5031, 9.7471),
    ("Klagenfurt (Kärnten)", 46.6247, 14.3050),
    ("Eisenstadt (Burgenland)", 47.8457, 16.5250),
];

/// Schweizer Kantonshauptorte (Auswahl der größten).
const CH_LAENDER: &[(&str, f32, f32)] = &[
    ("Bern", 46.9480, 7.4474),
    ("Zürich", 47.3769, 8.5417),
    ("Genf", 46.2044, 6.1432),
    ("Basel", 47.5596, 7.5886),
    ("Lausanne", 46.5197, 6.6323),
    ("Luzern", 47.0502, 8.3093),
    ("St. Gallen", 47.4245, 9.3767),
    ("Lugano", 46.0037, 8.9511),
];

/// US-Bundesstaaten würden den Rahmen sprengen (50 Stück); für die USA lassen
/// wir `capitals` leer und fallen auf die Städteliste des Landes zurück.
pub const COUNTRIES: &[Country] = &[
    Country { display: "Deutschland", folder: "Germany",
        aliases: &["deutschland", "germany", "brd", "allemagne"], capitals: DE_LAENDER },
    Country { display: "Österreich", folder: "Austria",
        aliases: &["österreich", "oesterreich", "austria"], capitals: AT_LAENDER },
    Country { display: "Schweiz", folder: "Switzerland",
        aliases: &["schweiz", "switzerland", "suisse", "svizzera"], capitals: CH_LAENDER },
    Country { display: "Frankreich", folder: "France",
        aliases: &["frankreich", "france"], capitals: &[] },
    Country { display: "Italien", folder: "Italy",
        aliases: &["italien", "italy", "italia"], capitals: &[] },
    Country { display: "Spanien", folder: "Spain",
        aliases: &["spanien", "spain", "españa", "espana"], capitals: &[] },
    Country { display: "Polen", folder: "Poland",
        aliases: &["polen", "poland", "polska"], capitals: &[] },
    Country { display: "Vereinigtes Königreich", folder: "United Kingdom",
        aliases: &["vereinigtes königreich", "united kingdom", "uk", "england",
                   "grossbritannien", "großbritannien", "britain"], capitals: &[] },
    Country { display: "Vereinigte Staaten", folder: "United States",
        aliases: &["vereinigte staaten", "united states", "usa", "amerika", "america"],
        capitals: &[] },
];

/// Erkennt eine Länderabfrage. Rückgabe: der Country, wenn `query` (getrimmt,
/// klein) exakt einem Alias entspricht. Bewusst KEIN `contains` — sonst träfe
/// „deutschlandsberg" wieder den Alias „deutschland".
pub fn erkenne_land(query: &str) -> Option<&'static Country> {
    let q = query.trim().to_lowercase();
    COUNTRIES.iter().find(|c| c.aliases.iter().any(|a| *a == q))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn deutschland_wird_erkannt() {
        let c = erkenne_land("Deutschland").expect("Deutschland fehlt");
        assert_eq!(c.folder, "Germany");
        assert_eq!(c.capitals.len(), 16, "16 Bundesländer erwartet");
    }

    #[test]
    fn deutschlandsberg_ist_kein_land() {
        // Der Kernbug: Ortsname darf den Länder-Alias nicht triggern.
        assert!(erkenne_land("Deutschlandsberg").is_none());
    }

    #[test]
    fn englische_und_kurznamen_treffen() {
        assert_eq!(erkenne_land("germany").unwrap().folder, "Germany");
        assert_eq!(erkenne_land("USA").unwrap().folder, "United States");
        assert_eq!(erkenne_land("uk").unwrap().folder, "United Kingdom");
    }

    #[test]
    fn alle_capitals_sind_plausibel() {
        for c in COUNTRIES {
            for (name, lat, lon) in c.capitals {
                assert!(!name.is_empty());
                assert!((-90.0..=90.0).contains(lat), "{name} lat {lat}");
                assert!((-180.0..=180.0).contains(lon), "{name} lon {lon}");
            }
        }
    }
}
