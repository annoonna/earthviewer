fn main() {
    let t = std::time::Instant::now();
    let gm = ev_geo::GeoDataManager::new();
    println!("Ladezeit : {:.2} s", t.elapsed().as_secs_f64());
    println!("Orte     : {}", gm.locations.len());
    let mut laender: Vec<&str> = gm.locations.iter().map(|l| l.country.as_str()).collect();
    laender.sort_unstable(); laender.dedup();
    println!("Laender  : {}", laender.len());
    for q in ["Leipzig", "Tokyo", "Sydney", "Reykjavik", "51.34, 12.38"] {
        let t = std::time::Instant::now();
        let r = gm.search(q);
        println!("  {:<14} {:>3} Treffer in {:>5.1} ms   {}", q, r.len(),
                 t.elapsed().as_secs_f64()*1000.0,
                 r.first().map(|x| format!("{} / {}", x.name, x.country)).unwrap_or_default());
    }
}
