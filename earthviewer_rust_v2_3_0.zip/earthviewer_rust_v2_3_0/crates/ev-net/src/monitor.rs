//! Traffic-Statistik — Port von `src/network/network_monitor.py`.
//! Speist die Tabs Monitoring, Graph und Protokoll-Analyse.
use crate::connections::Connection;
use std::collections::HashMap;

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Bucket {
    pub total: f64,
    pub count: usize,
}

/// Ein Messpunkt für den Graph-Tab.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Sample {
    pub t: f64,
    pub connections: usize,
    pub incoming: usize,
    pub outgoing: usize,
    pub countries: usize,
}

/// Aggregierte Sicht auf den aktuellen Verbindungs-Snapshot.
/// Das Python-Original nutzte `defaultdict` — hier `HashMap` mit denselben
/// vier Dimensionen: Apps, Hosts, Protokolle, Länder.
#[derive(Default)]
pub struct NetworkMonitor {
    pub apps: HashMap<String, Bucket>,
    pub hosts: HashMap<String, Bucket>,
    pub protocols: HashMap<String, Bucket>,
    pub countries: HashMap<String, Bucket>,
    /// Welche Apps sprechen mit welchem Host (Port von `host_apps`).
    pub host_apps: HashMap<String, Vec<String>>,
    pub history: Vec<Sample>,
    pub paused: bool,
    pub max_history: usize,
}

impl NetworkMonitor {
    pub fn new() -> Self {
        Self { max_history: 300, ..Default::default() }
    }

    /// Ein Snapshot einarbeiten. `elapsed` ist die Zeit seit dem Start in s.
    pub fn ingest(&mut self, conns: &[Connection], elapsed: f64) {
        if self.paused {
            return;
        }
        self.apps.clear();
        self.hosts.clear();
        self.protocols.clear();
        self.countries.clear();
        self.host_apps.clear();

        for c in conns {
            bump(&mut self.apps, &c.app_name);
            bump(&mut self.hosts, &c.remote_ip);
            bump(&mut self.protocols, &c.protocol);
            let country = if c.country.is_empty() { "Unknown" } else { &c.country };
            bump(&mut self.countries, country);

            let entry = self.host_apps.entry(c.remote_ip.clone()).or_default();
            if !entry.contains(&c.app_name) {
                entry.push(c.app_name.clone());
            }
        }

        let incoming = conns.iter().filter(|c| c.is_incoming()).count();
        self.history.push(Sample {
            t: elapsed,
            connections: conns.len(),
            incoming,
            outgoing: conns.len() - incoming,
            countries: self.countries.len(),
        });
        if self.history.len() > self.max_history {
            let cut = self.history.len() - self.max_history;
            self.history.drain(..cut);
        }
    }

    pub fn clear_history(&mut self) {
        self.history.clear();
    }

    /// Top-N absteigend nach `total`. Port von `get_top_*`.
    pub fn top(map: &HashMap<String, Bucket>, limit: usize) -> Vec<(String, Bucket)> {
        let mut v: Vec<(String, Bucket)> =
            map.iter().map(|(k, b)| (k.clone(), b.clone())).collect();
        v.sort_by(|a, b| {
            b.1.total
                .partial_cmp(&a.1.total)
                .unwrap_or(std::cmp::Ordering::Equal)
                .then_with(|| a.0.cmp(&b.0))
        });
        v.truncate(limit);
        v
    }

    pub fn top_apps(&self, n: usize) -> Vec<(String, Bucket)> { Self::top(&self.apps, n) }
    pub fn top_hosts(&self, n: usize) -> Vec<(String, Bucket)> { Self::top(&self.hosts, n) }
    pub fn top_countries(&self, n: usize) -> Vec<(String, Bucket)> { Self::top(&self.countries, n) }
    pub fn top_protocols(&self, n: usize) -> Vec<(String, Bucket)> { Self::top(&self.protocols, n) }

    pub fn apps_for_host(&self, host: &str) -> Vec<String> {
        self.host_apps.get(host).cloned().unwrap_or_default()
    }

    /// Anteil eines Protokolls in Prozent — für den Protokoll-Tab.
    pub fn protocol_share(&self, name: &str) -> f64 {
        let total: f64 = self.protocols.values().map(|b| b.total).sum();
        if total <= 0.0 { return 0.0; }
        self.protocols.get(name).map(|b| b.total / total * 100.0).unwrap_or(0.0)
    }
}

fn bump(map: &mut HashMap<String, Bucket>, key: &str) {
    let e = map.entry(key.to_string()).or_default();
    e.total += 1.0;
    e.count += 1;
}

/// Menschenlesbare Byte-Angabe — Port von `_format_bytes`.
pub fn format_bytes(b: f64) -> String {
    const UNITS: [&str; 5] = ["B", "KB", "MB", "GB", "TB"];
    // Winzige negative Rundungsreste (-0.0000…) sollen nicht als "-0 B" erscheinen.
    let mut v = if b < 0.0 { 0.0 } else { b };
    let mut i = 0;
    while v >= 1024.0 && i < UNITS.len() - 1 {
        v /= 1024.0;
        i += 1;
    }
    if i == 0 { format!("{v:.0} {}", UNITS[i]) } else { format!("{v:.1} {}", UNITS[i]) }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::connections::Direction;

    fn conn(app: &str, ip: &str, proto: &str, country: &str, d: Direction) -> Connection {
        Connection {
            local_ip: "10.0.0.2".into(), local_port: 1234,
            remote_ip: ip.into(), remote_port: 443, protocol: proto.into(),
            direction: d, app_name: app.into(), pid: 1,
            bytes_sent: 0, bytes_recv: 0, timestamp: 0.0,
            country: country.into(), city: "X".into(), lat: 1.0, lon: 1.0,
        }
    }

    fn sample_set() -> Vec<Connection> {
        vec![
            conn("firefox", "1.1.1.1", "TCP", "AU", Direction::Outgoing),
            conn("firefox", "8.8.8.8", "TCP", "US", Direction::Outgoing),
            conn("firefox", "1.1.1.1", "UDP", "AU", Direction::Incoming),
            conn("ssh", "9.9.9.9", "TCP", "CH", Direction::Outgoing),
        ]
    }

    #[test]
    fn aggregates_four_dimensions() {
        let mut m = NetworkMonitor::new();
        m.ingest(&sample_set(), 1.0);
        assert_eq!(m.apps.len(), 2);
        assert_eq!(m.hosts.len(), 3);
        assert_eq!(m.protocols.len(), 2);
        assert_eq!(m.countries.len(), 3);
    }

    #[test]
    fn top_apps_is_sorted_descending() {
        let mut m = NetworkMonitor::new();
        m.ingest(&sample_set(), 1.0);
        let top = m.top_apps(10);
        assert_eq!(top[0].0, "firefox");
        assert_eq!(top[0].1.count, 3);
        assert_eq!(top[1].0, "ssh");
    }

    #[test]
    fn top_respects_limit() {
        let mut m = NetworkMonitor::new();
        m.ingest(&sample_set(), 1.0);
        assert_eq!(m.top_hosts(2).len(), 2);
    }

    #[test]
    fn host_apps_mapping_has_no_duplicates() {
        let mut m = NetworkMonitor::new();
        m.ingest(&sample_set(), 1.0);
        assert_eq!(m.apps_for_host("1.1.1.1"), vec!["firefox"]);
        assert!(m.apps_for_host("nirgends").is_empty());
    }

    #[test]
    fn protocol_share_sums_to_100() {
        let mut m = NetworkMonitor::new();
        m.ingest(&sample_set(), 1.0);
        let s = m.protocol_share("TCP") + m.protocol_share("UDP");
        assert!((s - 100.0).abs() < 1e-6, "s = {s}");
        assert!((m.protocol_share("TCP") - 75.0).abs() < 1e-6);
    }

    #[test]
    fn protocol_share_of_unknown_is_zero() {
        let m = NetworkMonitor::new();
        assert_eq!(m.protocol_share("SCTP"), 0.0);
    }

    #[test]
    fn history_records_direction_split() {
        let mut m = NetworkMonitor::new();
        m.ingest(&sample_set(), 5.0);
        let s = *m.history.last().unwrap();
        assert_eq!(s.connections, 4);
        assert_eq!(s.incoming, 1);
        assert_eq!(s.outgoing, 3);
        assert_eq!(s.countries, 3);
    }

    #[test]
    fn history_is_capped() {
        let mut m = NetworkMonitor::new();
        m.max_history = 10;
        for i in 0..50 { m.ingest(&sample_set(), i as f64); }
        assert_eq!(m.history.len(), 10);
        assert_eq!(m.history.last().unwrap().t, 49.0);
    }

    #[test]
    fn pause_stops_ingestion() {
        let mut m = NetworkMonitor::new();
        m.ingest(&sample_set(), 1.0);
        m.paused = true;
        m.ingest(&sample_set(), 2.0);
        assert_eq!(m.history.len(), 1);
    }

    #[test]
    fn clear_history_keeps_aggregates() {
        let mut m = NetworkMonitor::new();
        m.ingest(&sample_set(), 1.0);
        m.clear_history();
        assert!(m.history.is_empty());
        assert_eq!(m.apps.len(), 2);
    }

    #[test]
    fn format_bytes_scales() {
        assert_eq!(format_bytes(512.0), "512 B");
        assert_eq!(format_bytes(2048.0), "2.0 KB");
        assert_eq!(format_bytes(5.0 * 1024.0 * 1024.0), "5.0 MB");
    }
}
