//! Connection-Tracker — Port von `src/network/connection_tracker.py`.
//! Qt-Signals (`pyqtSignal`) sind durch `std::sync::mpsc` ersetzt.

use crate::proc_net::{self, TcpState};
use ev_geo::GeoDataManager;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{mpsc, Arc, Mutex};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Direction { Incoming, Outgoing }

/// Wie die Richtung bestimmt wird.
///
/// Das Python-Original nutzte bewusst eine **rein optische** 50/50-Heuristik
/// (`md5(key) % 2`), damit ungefähr gleich viele blaue und grüne Bögen
/// entstehen. Das ist technisch falsch, aber hübsch. Wir bieten beides an.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DirectionMode {
    /// 1:1 wie Python: deterministischer Hash, 50/50-Verteilung.
    Balanced5050,
    /// Technisch korrekt: lauscht der lokale Port, ist es eingehend.
    Real,
}

#[derive(Clone, Debug)]
pub struct Connection {
    pub local_ip: String,
    pub local_port: u16,
    pub remote_ip: String,
    pub remote_port: u16,
    pub protocol: String,
    pub direction: Direction,
    pub app_name: String,
    pub pid: i32,
    pub bytes_sent: u64,
    pub bytes_recv: u64,
    pub timestamp: f64,
    pub country: String,
    pub city: String,
    pub lat: f32,
    pub lon: f32,
}

impl Connection {
    pub fn key(&self) -> String {
        format!("{}:{}-{}:{}-{}", self.local_ip, self.local_port,
                self.remote_ip, self.remote_port, self.protocol)
    }
    pub fn is_outgoing(&self) -> bool { self.direction == Direction::Outgoing }
    pub fn is_incoming(&self) -> bool { self.direction == Direction::Incoming }
    pub fn has_location(&self) -> bool { self.lat != 0.0 || self.lon != 0.0 }
}

/// Nur fuer Sichttests: Ersatzort aus `$EARTHVIEWER_DEMO_ORT`.
fn demo_ort() -> Option<(f32, f32)> {
    let v = std::env::var("EARTHVIEWER_DEMO_ORT").ok()?;
    let (a, b) = v.split_once(',')?;
    Some((a.trim().parse().ok()?, b.trim().parse().ok()?))
}

/// FNV-1a — ersetzt `int(md5(key).hexdigest(), 16) % 2`.
/// Andere Bits, gleiche Eigenschaft: deterministisch und gleichverteilt.
fn fnv1a(s: &str) -> u64 {
    let mut h: u64 = 0xcbf2_9ce4_8422_2325;
    for b in s.as_bytes() {
        h ^= *b as u64;
        h = h.wrapping_mul(0x0000_0100_0000_01b3);
    }
    h
}

pub struct TrackerConfig {
    pub show_incoming: bool,
    pub show_outgoing: bool,
    pub max_connections: usize,
    pub update_interval: Duration,
    pub direction_mode: DirectionMode,
}

impl Default for TrackerConfig {
    fn default() -> Self {
        Self {
            show_incoming: true,
            show_outgoing: true,
            max_connections: 100,
            update_interval: Duration::from_secs(2),
            direction_mode: DirectionMode::Balanced5050,
        }
    }
}

/// Ein Snapshot der aktiven Verbindungen — das, was über den Channel geht.
pub type Snapshot = Vec<Connection>;

pub struct ConnectionTracker {
    geo: Arc<GeoDataManager>,
    cfg: Arc<Mutex<TrackerConfig>>,
    running: Arc<AtomicBool>,
    rx: Option<mpsc::Receiver<Snapshot>>,
}

impl ConnectionTracker {
    pub fn new(geo: Arc<GeoDataManager>) -> Self {
        Self {
            geo,
            cfg: Arc::new(Mutex::new(TrackerConfig::default())),
            running: Arc::new(AtomicBool::new(false)),
            rx: None,
        }
    }

    pub fn set_filters(&self, show_incoming: bool, show_outgoing: bool) {
        if let Ok(mut c) = self.cfg.lock() {
            c.show_incoming = show_incoming;
            c.show_outgoing = show_outgoing;
        }
    }

    pub fn set_direction_mode(&self, mode: DirectionMode) {
        if let Ok(mut c) = self.cfg.lock() { c.direction_mode = mode; }
    }

    pub fn is_running(&self) -> bool { self.running.load(Ordering::Relaxed) }

    /// Startet den Hintergrund-Thread. Nachrichten via [`Self::try_recv`].
    pub fn start(&mut self) {
        if self.is_running() { return; }
        self.running.store(true, Ordering::Relaxed);
        let (tx, rx) = mpsc::channel();
        self.rx = Some(rx);

        let geo = Arc::clone(&self.geo);
        let cfg = Arc::clone(&self.cfg);
        let running = Arc::clone(&self.running);

        std::thread::Builder::new()
            .name("ev-conn-tracker".into())
            .spawn(move || {
                eprintln!("🔄 Connection Tracker gestartet");
                while running.load(Ordering::Relaxed) {
                    let (interval, snap) = {
                        let c = cfg.lock().expect("tracker cfg poisoned");
                        (c.update_interval, collect(&geo, &c))
                    };
                    if tx.send(snap).is_err() {
                        break; // UI ist weg
                    }
                    std::thread::sleep(interval);
                }
                eprintln!("⏹️  Connection Tracker gestoppt");
            })
            .expect("tracker thread");
    }

    pub fn stop(&self) { self.running.store(false, Ordering::Relaxed); }

    /// Holt den neuesten Snapshot (überspringt veraltete).
    pub fn try_recv(&self) -> Option<Snapshot> {
        let rx = self.rx.as_ref()?;
        let mut last = None;
        while let Ok(s) = rx.try_recv() { last = Some(s); }
        last
    }
}

impl Drop for ConnectionTracker {
    fn drop(&mut self) { self.stop(); }
}

/// Ein Durchlauf: /proc lesen, filtern, geolokalisieren.
pub fn collect(geo: &GeoDataManager, cfg: &TrackerConfig) -> Snapshot {
    let sockets = proc_net::read_all();
    let procs = proc_net::inode_to_process();

    // Lauschende lokale Ports für den Real-Modus.
    let listening: Vec<u16> = sockets
        .iter()
        .filter(|s| s.state == TcpState::Listen)
        .map(|s| s.local_port)
        .collect();

    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs_f64())
        .unwrap_or(0.0);

    let mut out = Vec::new();
    for s in &sockets {
        // Nur etablierte Verbindungen mit Gegenstelle (wie im Original).
        if s.state != TcpState::Established { continue; }
        if s.remote_ip.is_unspecified() || s.remote_port == 0 { continue; }

        let key = format!("{}:{}->{}:{}", s.local_ip, s.local_port, s.remote_ip, s.remote_port);
        let direction = match cfg.direction_mode {
            DirectionMode::Balanced5050 => {
                if fnv1a(&key) % 2 == 0 { Direction::Incoming } else { Direction::Outgoing }
            }
            DirectionMode::Real => {
                if listening.contains(&s.local_port) { Direction::Incoming }
                else { Direction::Outgoing }
            }
        };

        if direction == Direction::Incoming && !cfg.show_incoming { continue; }
        if direction == Direction::Outgoing && !cfg.show_outgoing { continue; }

        let (pid, app_name) = procs
            .get(&s.inode)
            .cloned()
            .unwrap_or((0, "System".to_string()));

        let remote = s.remote_ip.to_string();
        // Pruefhilfe: EARTHVIEWER_DEMO_ORT=lat,lon verteilt Verbindungen ohne
        // GeoIP faecherfoermig um diesen Punkt. Nur fuer Sichttests der
        // Bogendarstellung — im Normalbetrieb nicht gesetzt.
        if let Some(demo) = demo_ort() {
            let n = out.len() as f32;
            out.push(Connection {
                local_ip: s.local_ip.to_string(), local_port: s.local_port,
                remote_ip: remote.clone(), remote_port: s.remote_port,
                protocol: s.protocol.to_string(),
                direction: if fnv1a(&key) % 2 == 0 { Direction::Incoming }
                           else { Direction::Outgoing },
                app_name: procs.get(&s.inode).map(|p| p.1.clone())
                    .unwrap_or_else(|| "System".into()),
                pid: procs.get(&s.inode).map(|p| p.0).unwrap_or(0),
                bytes_sent: 0, bytes_recv: 0, timestamp: now,
                country: "XX".into(), city: format!("Demo {n}"),
                lat: demo.0 + (n * 37.0).sin() * 40.0,
                lon: demo.1 + (n * 53.0).cos() * 90.0,
            });
            if out.len() >= cfg.max_connections { break; }
            continue;
        }
        let (country, city, lat, lon) = match geo.lookup_ip(&remote) {
            Some(l) => {
                let c = if l.country.is_empty() { "Unknown".into() } else { l.country.clone() };
                let n = if l.name.is_empty() { "Unknown".into() } else { l.name.clone() };
                (c, n, l.lat, l.lon)
            }
            None => ("Unknown".into(), "Unknown".into(), 0.0, 0.0),
        };

        out.push(Connection {
            local_ip: s.local_ip.to_string(),
            local_port: s.local_port,
            remote_ip: remote,
            remote_port: s.remote_port,
            protocol: s.protocol.to_string(),
            direction,
            app_name,
            pid,
            bytes_sent: 0,
            bytes_recv: 0,
            timestamp: now,
            country, city, lat, lon,
        });

        if out.len() >= cfg.max_connections { break; }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fnv_is_deterministic() {
        assert_eq!(fnv1a("a:1->b:2"), fnv1a("a:1->b:2"));
        assert_ne!(fnv1a("a:1->b:2"), fnv1a("a:1->b:3"));
    }

    #[test]
    fn fnv_splits_roughly_evenly() {
        let mut even = 0;
        for i in 0..2000 {
            if fnv1a(&format!("10.0.0.1:{i}->93.184.216.34:443")) % 2 == 0 { even += 1; }
        }
        assert!((800..1200).contains(&even), "unbalanciert: {even}/2000");
    }

    #[test]
    fn demo_ort_parses_and_defaults_off() {
        std::env::remove_var("EARTHVIEWER_DEMO_ORT");
        assert!(demo_ort().is_none(), "im Normalbetrieb aus");
        std::env::set_var("EARTHVIEWER_DEMO_ORT", "51.34, 12.38");
        let (a, b) = demo_ort().expect("muss parsen");
        assert!((a - 51.34).abs() < 1e-4 && (b - 12.38).abs() < 1e-4);
        std::env::set_var("EARTHVIEWER_DEMO_ORT", "unsinn");
        assert!(demo_ort().is_none(), "Muell muss abgelehnt werden");
        std::env::remove_var("EARTHVIEWER_DEMO_ORT");
    }

    #[test]
    fn connection_key_is_stable() {
        let c = Connection {
            local_ip: "10.0.0.2".into(), local_port: 1234,
            remote_ip: "1.1.1.1".into(), remote_port: 443,
            protocol: "TCP".into(), direction: Direction::Outgoing,
            app_name: "firefox".into(), pid: 1, bytes_sent: 0, bytes_recv: 0,
            timestamp: 0.0, country: "AU".into(), city: "Sydney".into(),
            lat: -33.8, lon: 151.2,
        };
        assert_eq!(c.key(), "10.0.0.2:1234-1.1.1.1:443-TCP");
        assert!(c.is_outgoing() && c.has_location());
    }
}
