//! Nativer `/proc/net/*`-Parser — ersetzt `psutil.net_connections()`.
//!
//! Warum kein Crate? Weil das Original nur `kind='inet'` + `ESTABLISHED`
//! brauchte und wir so ohne unsafe, ohne libc-Bindings und ohne Root
//! auskommen. Das ist gleichzeitig die schnellste Variante.

use std::collections::HashMap;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
use std::path::Path;

/// TCP-Zustände aus `include/net/tcp_states.h`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TcpState {
    Established, SynSent, SynRecv, FinWait1, FinWait2, TimeWait,
    Close, CloseWait, LastAck, Listen, Closing, Other(u8),
}

impl TcpState {
    fn from_hex(v: u8) -> Self {
        match v {
            0x01 => Self::Established, 0x02 => Self::SynSent,  0x03 => Self::SynRecv,
            0x04 => Self::FinWait1,    0x05 => Self::FinWait2, 0x06 => Self::TimeWait,
            0x07 => Self::Close,       0x08 => Self::CloseWait,0x09 => Self::LastAck,
            0x0A => Self::Listen,      0x0B => Self::Closing,  other => Self::Other(other),
        }
    }
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Established => "ESTABLISHED", Self::SynSent => "SYN_SENT",
            Self::SynRecv => "SYN_RECV",  Self::FinWait1 => "FIN_WAIT1",
            Self::FinWait2 => "FIN_WAIT2",Self::TimeWait => "TIME_WAIT",
            Self::Close => "CLOSE",       Self::CloseWait => "CLOSE_WAIT",
            Self::LastAck => "LAST_ACK",  Self::Listen => "LISTEN",
            Self::Closing => "CLOSING",   Self::Other(_) => "UNKNOWN",
        }
    }
}

#[derive(Clone, Debug)]
pub struct RawSocket {
    pub protocol: &'static str, // "TCP" | "UDP"
    pub local_ip: IpAddr,
    pub local_port: u16,
    pub remote_ip: IpAddr,
    pub remote_port: u16,
    pub state: TcpState,
    pub uid: u32,
    pub inode: u64,
}

/// Liest alle vier `/proc/net`-Tabellen ein.
pub fn read_all() -> Vec<RawSocket> {
    let mut out = Vec::new();
    for (file, proto, v6) in [
        ("/proc/net/tcp", "TCP", false),
        ("/proc/net/tcp6", "TCP", true),
        ("/proc/net/udp", "UDP", false),
        ("/proc/net/udp6", "UDP", true),
    ] {
        if let Ok(text) = std::fs::read_to_string(file) {
            parse_table(&text, proto, v6, &mut out);
        }
    }
    out
}

fn parse_table(text: &str, proto: &'static str, v6: bool, out: &mut Vec<RawSocket>) {
    for line in text.lines().skip(1) {
        let f: Vec<&str> = line.split_whitespace().collect();
        if f.len() < 10 {
            continue;
        }
        let (Some((lip, lport)), Some((rip, rport))) =
            (parse_addr(f[1], v6), parse_addr(f[2], v6))
        else { continue };
        let state = u8::from_str_radix(f[3], 16).map(TcpState::from_hex)
            .unwrap_or(TcpState::Other(0));
        let uid = f[7].parse::<u32>().unwrap_or(0);
        let inode = f[9].parse::<u64>().unwrap_or(0);
        out.push(RawSocket {
            protocol: proto,
            local_ip: lip, local_port: lport,
            remote_ip: rip, remote_port: rport,
            state, uid, inode,
        });
    }
}

/// `0100007F:0035` → 127.0.0.1:53.
/// IPv4: ein little-endian u32. IPv6: vier little-endian u32.
fn parse_addr(s: &str, v6: bool) -> Option<(IpAddr, u16)> {
    let (a, p) = s.split_once(':')?;
    let port = u16::from_str_radix(p, 16).ok()?;
    if v6 {
        if a.len() != 32 { return None; }
        let mut bytes = [0u8; 16];
        for w in 0..4 {
            let word = u32::from_str_radix(&a[w * 8..w * 8 + 8], 16).ok()?;
            bytes[w * 4..w * 4 + 4].copy_from_slice(&word.to_le_bytes());
        }
        Some((IpAddr::V6(Ipv6Addr::from(bytes)), port))
    } else {
        if a.len() != 8 { return None; }
        let word = u32::from_str_radix(a, 16).ok()?;
        Some((IpAddr::V4(Ipv4Addr::from(word.to_le_bytes())), port))
    }
}

/// Socket-Inode → (PID, Prozessname). Ersetzt `psutil.Process(conn.pid).name()`.
/// Ohne Root sieht man nur eigene Prozesse — genau wie bei psutil.
pub fn inode_to_process() -> HashMap<u64, (i32, String)> {
    let mut map = HashMap::new();
    let Ok(procs) = std::fs::read_dir("/proc") else { return map };
    for entry in procs.flatten() {
        let name = entry.file_name();
        let Some(pid) = name.to_str().and_then(|s| s.parse::<i32>().ok()) else { continue };
        let fd_dir = entry.path().join("fd");
        let Ok(fds) = std::fs::read_dir(&fd_dir) else { continue };
        let mut comm: Option<String> = None;
        for fd in fds.flatten() {
            let Ok(target) = std::fs::read_link(fd.path()) else { continue };
            let t = target.to_string_lossy();
            let Some(rest) = t.strip_prefix("socket:[") else { continue };
            let Some(inode) = rest.strip_suffix(']').and_then(|s| s.parse::<u64>().ok())
            else { continue };
            if comm.is_none() {
                comm = Some(read_comm(&entry.path()));
            }
            map.insert(inode, (pid, comm.clone().unwrap_or_default()));
        }
    }
    map
}

fn read_comm(proc_dir: &Path) -> String {
    std::fs::read_to_string(proc_dir.join("comm"))
        .map(|s| s.trim().to_string())
        .unwrap_or_else(|_| "Unknown".into())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_ipv4_little_endian() {
        let (ip, port) = parse_addr("0100007F:0035", false).unwrap();
        assert_eq!(ip.to_string(), "127.0.0.1");
        assert_eq!(port, 53);
    }

    #[test]
    fn parses_ipv6() {
        // ::1 → 32 Nullen bis auf das letzte Wort
        let (ip, port) = parse_addr("00000000000000000000000001000000:1F90", true).unwrap();
        assert_eq!(ip.to_string(), "::1");
        assert_eq!(port, 8080);
    }

    #[test]
    fn rejects_malformed() {
        assert!(parse_addr("nope", false).is_none());
        assert!(parse_addr("0100007F", false).is_none());
    }

    #[test]
    fn parses_a_real_table_line() {
        let text = "  sl  local_address rem_address   st tx rx tr tm retr uid timeout inode\n\
                    0: 0100007F:0035 0200000A:C350 01 00000000:00000000 00:00000000 00000000 1000 0 54321 1";
        let mut out = Vec::new();
        parse_table(text, "TCP", false, &mut out);
        assert_eq!(out.len(), 1);
        assert_eq!(out[0].state, TcpState::Established);
        assert_eq!(out[0].remote_port, 50000);
        assert_eq!(out[0].inode, 54321);
        assert_eq!(out[0].uid, 1000);
    }

    #[test]
    fn state_mapping_is_stable() {
        assert_eq!(TcpState::from_hex(0x0A).as_str(), "LISTEN");
        assert_eq!(TcpState::from_hex(0x01).as_str(), "ESTABLISHED");
    }
}
