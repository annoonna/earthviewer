//! Traceroute — Port von `src/network/traceroute.py`.
use ev_core::GeoLocation;
use ev_geo::GeoDataManager;
use std::io::{BufRead, BufReader};
use std::process::{Command, Stdio};
use std::sync::mpsc::{self, Receiver};
use std::sync::Arc;

#[derive(Clone, Debug)]
pub struct TracerouteHop {
    pub hop_num: u32,
    pub ip: String,
    pub hostname: String,
    /// Round-Trip-Zeit in ms (erste gemessene Sonde).
    pub rtt: f64,
    /// Zeit für die DNS-Rückwärtsauflösung dieses Hops in ms (0 = nicht gemessen).
    pub dns_ms: f64,
    /// Luftlinie zum vorherigen lokalisierten Hop in km (0 = unbekannt).
    pub dist_prev_km: f64,
    pub location: Option<GeoLocation>,
}

impl TracerouteHop {
    /// Ort „Stadt, Land" aus der GeoLocation, sonst leer.
    pub fn ort(&self) -> String {
        match &self.location {
            Some(l) if !l.name.is_empty() && !l.country.is_empty() =>
                format!("{}, {}", l.name, l.country),
            Some(l) if !l.country.is_empty() => l.country.clone(),
            Some(l) if !l.name.is_empty() => l.name.clone(),
            _ => String::new(),
        }
    }
    pub fn land(&self) -> String {
        self.location.as_ref().map(|l| l.country.clone()).unwrap_or_default()
    }
    pub fn lat(&self) -> Option<f32> { self.location.as_ref().map(|l| l.lat) }
    pub fn lon(&self) -> Option<f32> { self.location.as_ref().map(|l| l.lon) }
    /// Latenzklasse für die Farbgebung (OVTR-Idee): grün/gelb/rot.
    pub fn latenz_rgb(&self) -> [f32; 3] {
        match self.rtt {
            r if r <= 0.0 => [0.55, 0.55, 0.60],   // unbekannt: grau
            r if r < 50.0 => [0.30, 0.90, 0.45],   // schnell: grün
            r if r < 150.0 => [0.95, 0.80, 0.25],  // mittel: gelb
            _ => [0.95, 0.35, 0.30],               // langsam: rot
        }
    }
}

pub fn trace_stream(
    geo: Arc<GeoDataManager>,
    target: &str,
    max_hops: u32,
) -> Receiver<TracerouteHop> {
    let (tx, rx) = mpsc::channel();
    let target = target.to_string();
    std::thread::spawn(move || {
        let child = Command::new("traceroute")
            .arg("-m").arg(max_hops.to_string())
            .arg("-w").arg("2")
            .arg(&target)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn();
        let Ok(mut child) = child else {
            eprintln!("❌ Traceroute-Fehler: `traceroute` nicht installiert");
            return;
        };
        if let Some(out) = child.stdout.take() {
            let mut letzte: Option<(f32, f32)> = None; // vorherige lokalisierte Position
            for line in BufReader::new(out).lines().map_while(Result::ok) {
                if let Some(mut hop) = parse_line(&line) {
                    // DNS-Rückwärtsauflösung messen (Zeit für lookup_addr).
                    let t0 = std::time::Instant::now();
                    let dns_name = rueckwaerts_dns(&hop.ip);
                    hop.dns_ms = t0.elapsed().as_secs_f64() * 1000.0;
                    if hop.hostname == hop.ip {
                        if let Some(n) = dns_name { hop.hostname = n; }
                    }
                    hop.location = geo.lookup_ip(&hop.ip);
                    // Distanz zum vorherigen lokalisierten Hop (Haversine).
                    if let (Some(l), Some((plat, plon))) = (&hop.location, letzte) {
                        hop.dist_prev_km = haversine_km(plat, plon, l.lat, l.lon);
                    }
                    if let Some(l) = &hop.location { letzte = Some((l.lat, l.lon)); }
                    if tx.send(hop).is_err() { break; }
                }
            }
        }
        let _ = child.wait();
    });
    rx
}

/// Parst `  3  ae-1.router.net (62.115.1.2)  8.123 ms`.
/// Deutlich toleranter als das Original-Regex: Hostname darf fehlen.
pub fn parse_line(line: &str) -> Option<TracerouteHop> {
    let l = line.trim();
    let mut it = l.split_whitespace();
    let hop_num = it.next()?.parse::<u32>().ok()?;

    let rest: Vec<&str> = it.collect();
    if rest.is_empty() || rest[0] == "*" { return None; }

    // IP entweder in Klammern hinter dem Hostnamen oder direkt als erstes Token.
    let (hostname, ip) = match rest.iter().position(|t| t.starts_with('(')) {
        Some(i) => {
            let ip = rest[i].trim_matches(['(', ')']).to_string();
            (rest[..i].join(" "), ip)
        }
        None => (rest[0].to_string(), rest[0].to_string()),
    };
    if ip.is_empty() || !ip.chars().any(|c| c.is_ascii_digit()) { return None; }

    // Erste Zahl vor einem "ms".
    let rtt = rest
        .windows(2)
        .find(|w| w[1] == "ms")
        .and_then(|w| w[0].parse::<f64>().ok())
        .unwrap_or(0.0);

    Some(TracerouteHop {
        hop_num, ip, hostname, rtt, dns_ms: 0.0, dist_prev_km: 0.0, location: None,
    })
}

/// Rückwärts-DNS ohne Fremdcrate: ruft das System-Tool `getent hosts` bzw.
/// fällt auf `host`/`nslookup` zurück. Gibt den ersten Namen zurück.
fn rueckwaerts_dns(ip: &str) -> Option<String> {
    // `getent hosts <ip>` liefert "IP  name" wenn auflösbar.
    if let Ok(o) = Command::new("getent").arg("hosts").arg(ip).output() {
        if o.status.success() {
            let s = String::from_utf8_lossy(&o.stdout);
            if let Some(name) = s.split_whitespace().nth(1) {
                if name != ip { return Some(name.to_string()); }
            }
        }
    }
    None
}

/// Haversine-Distanz zweier Punkte in km.
pub fn haversine_km(lat1: f32, lon1: f32, lat2: f32, lon2: f32) -> f64 {
    let r = 6371.0_f64;
    let (la1, lo1, la2, lo2) =
        (lat1 as f64, lon1 as f64, lat2 as f64, lon2 as f64);
    let dlat = (la2 - la1).to_radians();
    let dlon = (lo2 - lo1).to_radians();
    let a = (dlat / 2.0).sin().powi(2)
        + la1.to_radians().cos() * la2.to_radians().cos() * (dlon / 2.0).sin().powi(2);
    2.0 * r * a.sqrt().asin()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_hostname_and_ip() {
        let h = parse_line(" 3  ae-1.router.net (62.115.1.2)  8.123 ms  8.4 ms").unwrap();
        assert_eq!(h.hop_num, 3);
        assert_eq!(h.ip, "62.115.1.2");
        assert_eq!(h.hostname, "ae-1.router.net");
        assert!((h.rtt - 8.123).abs() < 1e-9);
    }

    #[test]
    fn parses_bare_ip_hop() {
        let h = parse_line(" 1  192.168.1.1  1.02 ms").unwrap();
        assert_eq!(h.ip, "192.168.1.1");
        assert_eq!(h.hop_num, 1);
    }

    #[test]
    fn skips_timeouts_and_headers() {
        assert!(parse_line(" 5  * * *").is_none());
        assert!(parse_line("traceroute to 1.1.1.1, 30 hops max").is_none());
    }

    #[test]
    fn haversine_leipzig_berlin() {
        // Leipzig 51.34,12.38 → Berlin 52.52,13.40 ≈ 150 km.
        let d = haversine_km(51.34, 12.38, 52.52, 13.40);
        assert!((d - 150.0).abs() < 20.0, "Distanz {d} km");
    }

    #[test]
    fn latenz_farben_stufen() {
        let mut h = parse_line(" 1  1.2.3.4  10.0 ms").unwrap();
        assert_eq!(h.latenz_rgb(), [0.30, 0.90, 0.45]); // grün
        h.rtt = 100.0;
        assert_eq!(h.latenz_rgb(), [0.95, 0.80, 0.25]); // gelb
        h.rtt = 300.0;
        assert_eq!(h.latenz_rgb(), [0.95, 0.35, 0.30]); // rot
    }
}
