//! Durchsatzmessung aus `/proc/net/dev` — ersetzt `psutil.net_io_counters()`.
//!
//! 📸 Aus den Original-Bildschirmfotos: Monitoring und Graph zeigen **KB/s**
//! und **KB**, nicht Verbindungszahlen. Bis v0.4.0 hatte ich das falsch
//! verstanden und Verbindungen gezählt. Diese Datei schließt die Lücke.

use std::collections::HashMap;
use std::time::Instant;

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Counters {
    pub rx_bytes: u64,
    pub tx_bytes: u64,
    pub rx_packets: u64,
    pub tx_packets: u64,
}

/// Momentaner Durchsatz in Byte pro Sekunde.
#[derive(Clone, Copy, Debug, Default, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct Rate {
    pub down_bps: f64,
    pub up_bps: f64,
}

impl Rate {
    pub fn total_bps(&self) -> f64 { self.down_bps + self.up_bps }
    pub fn down_kbs(&self) -> f64 { self.down_bps / 1024.0 }
    pub fn up_kbs(&self) -> f64 { self.up_bps / 1024.0 }
    pub fn total_kbs(&self) -> f64 { self.total_bps() / 1024.0 }
}

/// Parst `/proc/net/dev`. Loopback wird übersprungen — sonst zählt lokaler
/// Verkehr doppelt und die Kurve lügt.
pub fn parse_dev(text: &str) -> HashMap<String, Counters> {
    let mut out = HashMap::new();
    for line in text.lines().skip(2) {
        let Some((name, rest)) = line.split_once(':') else { continue };
        let name = name.trim();
        if name.is_empty() || name == "lo" { continue; }
        let f: Vec<&str> = rest.split_whitespace().collect();
        if f.len() < 10 { continue; }
        let g = |i: usize| f.get(i).and_then(|x| x.parse::<u64>().ok()).unwrap_or(0);
        out.insert(name.to_string(), Counters {
            rx_bytes: g(0), rx_packets: g(1),
            tx_bytes: g(8), tx_packets: g(9),
        });
    }
    out
}

pub fn read() -> HashMap<String, Counters> {
    std::fs::read_to_string("/proc/net/dev").map(|t| parse_dev(&t)).unwrap_or_default()
}

pub fn sum(m: &HashMap<String, Counters>) -> Counters {
    let mut s = Counters::default();
    for c in m.values() {
        s.rx_bytes += c.rx_bytes; s.tx_bytes += c.tx_bytes;
        s.rx_packets += c.rx_packets; s.tx_packets += c.tx_packets;
    }
    s
}

/// Bildet aus aufeinanderfolgenden Ständen eine Rate.
pub struct ThroughputMeter {
    last: Option<(Counters, Instant)>,
    pub rate: Rate,
    /// Gesamtvolumen seit Programmstart (für die KB-Spalten im Monitoring).
    pub session_rx: u64,
    pub session_tx: u64,
}

impl Default for ThroughputMeter {
    fn default() -> Self { Self::new() }
}

impl ThroughputMeter {
    pub fn new() -> Self {
        Self { last: None, rate: Rate::default(), session_rx: 0, session_tx: 0 }
    }

    pub fn tick(&mut self) -> Rate {
        self.tick_with(sum(&read()), Instant::now())
    }

    /// Testbare Variante: Zähler und Zeitpunkt werden übergeben.
    pub fn tick_with(&mut self, now_counters: Counters, now: Instant) -> Rate {
        if let Some((prev, t0)) = self.last {
            let dt = now.duration_since(t0).as_secs_f64();
            if dt > 1e-3 {
                // saturating_sub fängt Zählerüberlauf und Interface-Neustart ab
                let drx = now_counters.rx_bytes.saturating_sub(prev.rx_bytes);
                let dtx = now_counters.tx_bytes.saturating_sub(prev.tx_bytes);
                self.session_rx += drx;
                self.session_tx += dtx;
                self.rate = Rate { down_bps: drx as f64 / dt, up_bps: dtx as f64 / dt };
            }
        }
        self.last = Some((now_counters, now));
        self.rate
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;

    const DEV: &str = "Inter-|   Receive                                                |  Transmit\n\
 face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed\n\
    lo: 123456     789    0    0    0     0          0         0   123456     789    0    0    0     0       0          0\n\
  eth0: 1048576    1000    0    0    0     0          0         0   524288     500    0    0    0     0       0          0\n\
 wlan0:  262144     250    0    0    0     0          0         0   131072     120    0    0    0     0       0          0";

    #[test]
    fn parses_and_skips_loopback() {
        let m = parse_dev(DEV);
        assert_eq!(m.len(), 2, "lo muss übersprungen werden");
        assert!(!m.contains_key("lo"));
        assert_eq!(m["eth0"].rx_bytes, 1_048_576);
        assert_eq!(m["eth0"].tx_bytes, 524_288);
        assert_eq!(m["wlan0"].rx_packets, 250);
    }

    #[test]
    fn sums_all_interfaces() {
        let s = sum(&parse_dev(DEV));
        assert_eq!(s.rx_bytes, 1_048_576 + 262_144);
        assert_eq!(s.tx_bytes, 524_288 + 131_072);
    }

    #[test]
    fn first_tick_has_no_rate() {
        let mut m = ThroughputMeter::new();
        let r = m.tick_with(Counters { rx_bytes: 1000, tx_bytes: 500, ..Default::default() },
                            Instant::now());
        assert_eq!(r, Rate::default(), "ohne Vorwert gibt es keine Rate");
    }

    #[test]
    fn computes_bytes_per_second() {
        let mut m = ThroughputMeter::new();
        let t0 = Instant::now();
        m.tick_with(Counters { rx_bytes: 0, tx_bytes: 0, ..Default::default() }, t0);
        // +2048 B empfangen, +1024 B gesendet in 2 s
        let r = m.tick_with(
            Counters { rx_bytes: 2048, tx_bytes: 1024, ..Default::default() },
            t0 + Duration::from_secs(2));
        assert!((r.down_bps - 1024.0).abs() < 1e-6, "down = {}", r.down_bps);
        assert!((r.up_bps - 512.0).abs() < 1e-6);
        assert!((r.down_kbs() - 1.0).abs() < 1e-6);
        assert!((r.total_kbs() - 1.5).abs() < 1e-6);
    }

    #[test]
    fn session_volume_accumulates() {
        let mut m = ThroughputMeter::new();
        let t0 = Instant::now();
        m.tick_with(Counters::default(), t0);
        m.tick_with(Counters { rx_bytes: 1000, tx_bytes: 200, ..Default::default() },
                    t0 + Duration::from_secs(1));
        m.tick_with(Counters { rx_bytes: 3000, tx_bytes: 700, ..Default::default() },
                    t0 + Duration::from_secs(2));
        assert_eq!(m.session_rx, 3000);
        assert_eq!(m.session_tx, 700);
    }

    #[test]
    fn counter_reset_does_not_produce_garbage() {
        // Interface neu gestartet -> Zähler springt zurück. Darf nicht negativ
        // oder absurd groß werden.
        let mut m = ThroughputMeter::new();
        let t0 = Instant::now();
        m.tick_with(Counters { rx_bytes: 10_000_000, tx_bytes: 5_000_000, ..Default::default() }, t0);
        let r = m.tick_with(Counters { rx_bytes: 100, tx_bytes: 50, ..Default::default() },
                            t0 + Duration::from_secs(1));
        assert_eq!(r.down_bps, 0.0);
        assert_eq!(r.up_bps, 0.0);
    }

    #[test]
    fn zero_elapsed_keeps_previous_rate() {
        let mut m = ThroughputMeter::new();
        let t0 = Instant::now();
        m.tick_with(Counters::default(), t0);
        m.tick_with(Counters { rx_bytes: 1024, ..Default::default() },
                    t0 + Duration::from_secs(1));
        let before = m.rate;
        let r = m.tick_with(Counters { rx_bytes: 9999, ..Default::default() }, t0 + Duration::from_secs(1));
        assert_eq!(r, before, "Division durch ~0 muss vermieden werden");
    }

    #[test]
    fn malformed_lines_are_ignored() {
        assert!(parse_dev("").is_empty());
        assert!(parse_dev("kaputt\nnoch kaputter\n eth0: 1 2 3").is_empty());
    }
}
