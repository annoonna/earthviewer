//! ARP-/LAN-Scanner — Port von `src/network/arp_scanner.py`.
//!
//! ⚠️ Unterschied zum Original: dort wurde **scapy** benutzt, das rohe
//! ARP-Pakete sendet und dafür `CAP_NET_RAW` (praktisch: root) braucht.
//! Diese Portierung ist bewusst **passiv**: sie liest den Kernel-Nachbar-Cache
//! (`/proc/net/arp`). Kein Root, keine Pakete auf dem Draht, keine
//! rechtlichen Fragen in fremden Netzen. Ein aktiver Sweep lässt sich
//! optional über [`sweep_hint`] anstoßen (normale UDP-Pings, kein Raw-Socket).
use std::collections::BTreeMap;
use std::net::{Ipv4Addr, UdpSocket};
use std::time::Duration;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ArpEntry {
    pub ip: String,
    pub mac: String,
    pub iface: String,
    pub flags: String,
    pub vendor: String,
}

impl ArpEntry {
    pub fn is_complete(&self) -> bool {
        self.mac != "00:00:00:00:00:00" && !self.mac.is_empty()
    }
}

/// Liest `/proc/net/arp`.
pub fn read_arp_cache() -> Vec<ArpEntry> {
    std::fs::read_to_string("/proc/net/arp")
        .map(|t| parse_arp_table(&t))
        .unwrap_or_default()
}

pub fn parse_arp_table(text: &str) -> Vec<ArpEntry> {
    let mut out = Vec::new();
    for line in text.lines().skip(1) {
        let f: Vec<&str> = line.split_whitespace().collect();
        if f.len() < 6 { continue; }
        let mac = f[3].to_ascii_lowercase();
        out.push(ArpEntry {
            ip: f[0].to_string(),
            vendor: vendor_from_mac(&mac),
            mac,
            flags: f[2].to_string(),
            iface: f[5].to_string(),
        });
    }
    out
}

/// Sehr kleine OUI-Tabelle für die häufigsten Heim-/Lab-Geräte.
/// (Das Original hatte gar keine — reines Plus.)
pub fn vendor_from_mac(mac: &str) -> String {
    static OUI: &[(&str, &str)] = &[
        ("b8:27:eb", "Raspberry Pi Foundation"),
        ("dc:a6:32", "Raspberry Pi Trading"),
        ("e4:5f:01", "Raspberry Pi Trading"),
        ("00:1a:11", "Google"),
        ("f4:f5:d8", "Google"),
        ("00:50:56", "VMware"),
        ("00:0c:29", "VMware"),
        ("08:00:27", "Oracle VirtualBox"),
        ("52:54:00", "QEMU/KVM"),
        ("00:15:5d", "Microsoft Hyper-V"),
        ("3c:5a:b4", "Google"),
        ("ac:de:48", "Private"),
        ("00:1b:63", "Apple"),
        ("a4:83:e7", "Apple"),
        ("d0:37:45", "AVM (FRITZ!Box)"),
        ("38:10:d5", "AVM (FRITZ!Box)"),
        ("c8:0e:14", "AVM (FRITZ!Box)"),
    ];
    let prefix: String = mac.chars().take(8).collect();
    OUI.iter()
        .find(|(p, _)| *p == prefix)
        .map(|(_, v)| v.to_string())
        .unwrap_or_else(|| "Unknown".into())
}

/// Ermittelt lokale IPv4 + /24-Netz, ohne externe Crates:
/// UDP-Socket "verbinden" (sendet nichts) und lokale Adresse auslesen.
pub fn local_ipv4() -> Option<Ipv4Addr> {
    let sock = UdpSocket::bind("0.0.0.0:0").ok()?;
    sock.set_write_timeout(Some(Duration::from_millis(200))).ok()?;
    sock.connect("192.0.2.1:9").ok()?; // TEST-NET-1, es fließt kein Traffic
    match sock.local_addr().ok()? {
        std::net::SocketAddr::V4(a) => Some(*a.ip()),
        _ => None,
    }
}

/// Erzeugt alle Host-Adressen eines /24 rund um `base`.
pub fn subnet_24(base: Ipv4Addr) -> Vec<Ipv4Addr> {
    let o = base.octets();
    (1u16..255).map(|h| Ipv4Addr::new(o[0], o[1], o[2], h as u8)).collect()
}

/// Stupst Hosts an, damit der Kernel den ARP-Cache füllt.
/// Bewusst harmlos: ein einzelnes leeres UDP-Datagramm an einen Discard-Port.
pub fn sweep_hint(targets: &[Ipv4Addr]) {
    let Ok(sock) = UdpSocket::bind("0.0.0.0:0") else { return };
    let _ = sock.set_write_timeout(Some(Duration::from_millis(50)));
    for ip in targets {
        let _ = sock.send_to(&[], (*ip, 9));
    }
}

/// Gruppiert nach Interface — praktisch für die UI-Tabelle.
pub fn group_by_iface(entries: &[ArpEntry]) -> BTreeMap<String, Vec<ArpEntry>> {
    let mut m: BTreeMap<String, Vec<ArpEntry>> = BTreeMap::new();
    for e in entries {
        m.entry(e.iface.clone()).or_default().push(e.clone());
    }
    m
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "IP address       HW type     Flags       HW address            Mask     Device\n\
192.168.1.1      0x1         0x2         d0:37:45:aa:bb:cc     *        wlan0\n\
192.168.1.42     0x1         0x2         b8:27:eb:11:22:33     *        eth0\n\
192.168.1.99     0x1         0x0         00:00:00:00:00:00     *        eth0";

    #[test]
    fn parses_arp_table() {
        let e = parse_arp_table(SAMPLE);
        assert_eq!(e.len(), 3);
        assert_eq!(e[0].ip, "192.168.1.1");
        assert_eq!(e[0].iface, "wlan0");
        assert_eq!(e[0].vendor, "AVM (FRITZ!Box)");
        assert_eq!(e[1].vendor, "Raspberry Pi Foundation");
    }

    #[test]
    fn detects_incomplete_entries() {
        let e = parse_arp_table(SAMPLE);
        assert!(e[0].is_complete());
        assert!(!e[2].is_complete());
    }

    #[test]
    fn subnet_has_254_hosts() {
        let s = subnet_24(Ipv4Addr::new(192, 168, 1, 77));
        assert_eq!(s.len(), 254);
        assert_eq!(s[0], Ipv4Addr::new(192, 168, 1, 1));
        assert_eq!(s[253], Ipv4Addr::new(192, 168, 1, 254));
    }

    #[test]
    fn groups_by_interface() {
        let g = group_by_iface(&parse_arp_table(SAMPLE));
        assert_eq!(g.get("eth0").map(Vec::len), Some(2));
        assert_eq!(g.get("wlan0").map(Vec::len), Some(1));
    }
}
