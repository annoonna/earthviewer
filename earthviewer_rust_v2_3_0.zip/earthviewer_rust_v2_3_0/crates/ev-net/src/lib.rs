//! `ev-net` — Netzwerk- und Security-Werkzeuge.
//! Port von `src/network/` (psutil/scapy/requests → native Rust bzw. ureq).
pub mod arp;
pub mod classify;
pub mod connections;
pub mod firewall;
pub mod monitor;
pub mod ping;
pub mod portscan;
pub mod proc_net;
pub mod throughput;
pub mod traceroute;
pub mod virustotal;
pub mod whois;

pub use connections::{Connection, ConnectionTracker, Direction, DirectionMode};
pub use classify::{classify, IpClass};
pub use firewall::BlockList;
pub use monitor::NetworkMonitor;
pub use throughput::{Rate, ThroughputMeter};
