//! IP-Blockliste — Port von `ProtectionTab` / `src/network/ip_blocker.py`.
//!
//! ⚠️ Unterschied zum Original: dort wurden `iptables`-Regeln gesetzt, was root
//! verlangt und dauerhaft am System schraubt. Diese Portierung führt die Liste
//! **anwendungsintern** und markiert betroffene Verbindungen rot. Wer echte
//! Kernel-Regeln will, exportiert sie mit `iptables_rules()` und setzt sie
//! bewusst selbst — dann steht die Entscheidung im Shell-Verlauf.
use std::collections::BTreeSet;
use std::net::IpAddr;
use std::path::Path;

#[derive(Default)]
pub struct BlockList {
    entries: BTreeSet<String>,
}

impl BlockList {
    pub fn new() -> Self { Self::default() }

    /// Nimmt nur gültige IP-Adressen an. Gibt `false` bei Müll oder Duplikat.
    pub fn block(&mut self, ip: &str) -> bool {
        let ip = ip.trim();
        if ip.parse::<IpAddr>().is_err() { return false; }
        self.entries.insert(ip.to_string())
    }

    pub fn unblock(&mut self, ip: &str) -> bool { self.entries.remove(ip.trim()) }
    pub fn is_blocked(&self, ip: &str) -> bool { self.entries.contains(ip.trim()) }
    pub fn len(&self) -> usize { self.entries.len() }
    pub fn is_empty(&self) -> bool { self.entries.is_empty() }
    pub fn iter(&self) -> impl Iterator<Item = &String> { self.entries.iter() }
    pub fn clear(&mut self) { self.entries.clear(); }

    pub fn status_line(&self) -> String {
        format!("🛡 Blockliste aktiv · {} IP(s)", self.entries.len())
    }

    /// Erzeugt die iptables-Zeilen, ohne sie auszuführen.
    pub fn iptables_rules(&self) -> Vec<String> {
        self.entries
            .iter()
            .map(|ip| format!("iptables -A INPUT -s {ip} -j DROP"))
            .collect()
    }

    pub fn save(&self, path: &Path) -> std::io::Result<()> {
        std::fs::write(path, self.entries.iter().cloned().collect::<Vec<_>>().join("\n"))
    }

    pub fn load(path: &Path) -> Self {
        let mut me = Self::new();
        if let Ok(text) = std::fs::read_to_string(path) {
            for line in text.lines() { me.block(line); }
        }
        me
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn blocks_and_unblocks() {
        let mut b = BlockList::new();
        assert!(b.block("1.2.3.4"));
        assert!(b.is_blocked("1.2.3.4"));
        assert_eq!(b.len(), 1);
        assert!(b.unblock("1.2.3.4"));
        assert!(b.is_empty());
    }

    #[test]
    fn rejects_invalid_input() {
        let mut b = BlockList::new();
        assert!(!b.block("nicht-ip"));
        assert!(!b.block(""));
        assert!(!b.block("999.1.1.1"));
        assert!(b.is_empty());
    }

    #[test]
    fn accepts_ipv6() {
        let mut b = BlockList::new();
        assert!(b.block("2001:db8::1"));
        assert!(b.is_blocked("2001:db8::1"));
    }

    #[test]
    fn duplicates_are_not_counted_twice() {
        let mut b = BlockList::new();
        assert!(b.block("1.2.3.4"));
        assert!(!b.block("1.2.3.4"));
        assert_eq!(b.len(), 1);
    }

    #[test]
    fn trims_whitespace() {
        let mut b = BlockList::new();
        b.block("  1.2.3.4  ");
        assert!(b.is_blocked("1.2.3.4"));
    }

    #[test]
    fn generates_iptables_rules_without_running_them() {
        let mut b = BlockList::new();
        b.block("1.2.3.4");
        let r = b.iptables_rules();
        assert_eq!(r, vec!["iptables -A INPUT -s 1.2.3.4 -j DROP"]);
    }

    #[test]
    fn roundtrips_through_disk() {
        let mut b = BlockList::new();
        b.block("1.2.3.4");
        b.block("5.6.7.8");
        let p = std::env::temp_dir().join("ev_blocklist_test.txt");
        b.save(&p).unwrap();
        let l = BlockList::load(&p);
        assert_eq!(l.len(), 2);
        assert!(l.is_blocked("5.6.7.8"));
        let _ = std::fs::remove_file(&p);
    }
}
