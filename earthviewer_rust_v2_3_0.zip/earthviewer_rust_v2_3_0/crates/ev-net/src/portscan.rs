//! TCP-Port-Scanner — Port von `PortScannerThread` aus `network_scanner_tab.py`.
//! 100 Python-Threads → ein Pool aus N Rust-Threads mit gemeinsamem Zähler.
use std::net::{SocketAddr, TcpStream, ToSocketAddrs};
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::mpsc::{self, Receiver};
use std::sync::Arc;
use std::time::Duration;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct OpenPort {
    pub port: u16,
    pub service: String,
}

pub enum ScanMsg {
    Found(OpenPort),
    Progress { scanned: u32, total: u32 },
    Done { open: usize },
    Error(String),
}

pub struct ScanHandle {
    pub rx: Receiver<ScanMsg>,
    stop: Arc<AtomicBool>,
}

impl ScanHandle {
    pub fn stop(&self) { self.stop.store(true, Ordering::Relaxed); }
}

/// Startet den Scan. `threads` entspricht dem `num_threads = 100` des Originals.
pub fn scan(
    target: &str,
    start_port: u16,
    end_port: u16,
    threads: usize,
    timeout_ms: u64,
) -> ScanHandle {
    let (tx, rx) = mpsc::channel();
    let stop = Arc::new(AtomicBool::new(false));
    let stop_c = Arc::clone(&stop);
    let target = target.to_string();

    std::thread::spawn(move || {
        let addr = match resolve(&target) {
            Some(a) => a,
            None => {
                let _ = tx.send(ScanMsg::Error(format!("'{target}' nicht auflösbar")));
                let _ = tx.send(ScanMsg::Done { open: 0 });
                return;
            }
        };
        let (lo, hi) = (start_port.min(end_port), start_port.max(end_port));
        let total = (hi as u32 - lo as u32) + 1;
        let next = Arc::new(AtomicU32::new(lo as u32));
        let scanned = Arc::new(AtomicU32::new(0));
        let found = Arc::new(AtomicU32::new(0));

        let mut handles = Vec::new();
        for _ in 0..threads.max(1) {
            let (tx, next, scanned, found, stop) = (
                tx.clone(), Arc::clone(&next), Arc::clone(&scanned),
                Arc::clone(&found), Arc::clone(&stop_c),
            );
            handles.push(std::thread::spawn(move || {
                loop {
                    if stop.load(Ordering::Relaxed) { break; }
                    let p = next.fetch_add(1, Ordering::Relaxed);
                    if p > hi as u32 { break; }
                    let port = p as u16;
                    if probe(addr, port, timeout_ms) {
                        found.fetch_add(1, Ordering::Relaxed);
                        let _ = tx.send(ScanMsg::Found(OpenPort {
                            port, service: service_name(port).to_string(),
                        }));
                    }
                    let n = scanned.fetch_add(1, Ordering::Relaxed) + 1;
                    if n % 100 == 0 || n == total {
                        let _ = tx.send(ScanMsg::Progress { scanned: n, total });
                    }
                }
            }));
        }
        for h in handles { let _ = h.join(); }
        let _ = tx.send(ScanMsg::Done { open: found.load(Ordering::Relaxed) as usize });
    });

    ScanHandle { rx, stop }
}

fn resolve(target: &str) -> Option<SocketAddr> {
    format!("{target}:80").to_socket_addrs().ok()?.next()
}

fn probe(mut addr: SocketAddr, port: u16, timeout_ms: u64) -> bool {
    addr.set_port(port);
    TcpStream::connect_timeout(&addr, Duration::from_millis(timeout_ms)).is_ok()
}

/// Port → Dienstname. Port von `_get_service_name`, deutlich erweitert.
pub fn service_name(port: u16) -> &'static str {
    match port {
        20 | 21 => "FTP",       22 => "SSH",        23 => "Telnet",
        25 => "SMTP",           53 => "DNS",        67 | 68 => "DHCP",
        69 => "TFTP",           80 => "HTTP",       110 => "POP3",
        119 => "NNTP",          123 => "NTP",       135 => "MSRPC",
        137..=139 => "NetBIOS", 143 => "IMAP",      161 | 162 => "SNMP",
        389 => "LDAP",          443 => "HTTPS",     445 => "SMB",
        465 => "SMTPS",         514 => "Syslog",    587 => "SMTP (Submission)",
        631 => "IPP/CUPS",      636 => "LDAPS",     993 => "IMAPS",
        995 => "POP3S",         1080 => "SOCKS",    1433 => "MSSQL",
        1521 => "Oracle",       1723 => "PPTP",     1883 => "MQTT",
        2049 => "NFS",          2375 | 2376 => "Docker", 3128 => "Squid",
        3306 => "MySQL",        3389 => "RDP",      4444 => "Metasploit",
        5060 | 5061 => "SIP",   5353 => "mDNS",
        5432 | 5433 => "PostgreSQL", 5900..=5905 => "VNC",
        6379 => "Redis",        6667 => "IRC",      8080 => "HTTP-Alt",
        8443 => "HTTPS-Alt",    8888 => "HTTP-Alt", 9090 => "Cockpit",
        9200 => "Elasticsearch", 11211 => "Memcached", 27017 => "MongoDB",
        _ => "unbekannt",
    }
}

/// Häufig geprüfte Ports — Schnellwahl im Scanner-Tab.
pub const COMMON_PORTS: &[u16] = &[
    21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 587, 993, 995,
    1433, 3306, 3389, 5432, 5900, 6379, 8080, 8443, 27017,
];

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn known_services_are_named() {
        assert_eq!(service_name(22), "SSH");
        assert_eq!(service_name(443), "HTTPS");
        assert_eq!(service_name(3306), "MySQL");
        assert_eq!(service_name(138), "NetBIOS");
        assert_eq!(service_name(5901), "VNC");
    }

    #[test]
    fn unknown_port_falls_back() {
        assert_eq!(service_name(54321), "unbekannt");
    }

    #[test]
    fn closed_port_on_localhost_is_detected() {
        let addr: SocketAddr = "127.0.0.1:1".parse().unwrap();
        assert!(!probe(addr, 1, 200), "Port 1 sollte zu sein");
    }

    #[test]
    fn open_port_is_detected() {
        // Eigenen Listener aufmachen und wiederfinden.
        let l = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let port = l.local_addr().unwrap().port();
        let addr: SocketAddr = "127.0.0.1:1".parse().unwrap();
        assert!(probe(addr, port, 500), "eigener Listener muss gefunden werden");
    }

    #[test]
    fn scan_reports_done_and_finds_listener() {
        let l = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let port = l.local_addr().unwrap().port();
        let h = scan("127.0.0.1", port, port, 4, 500);
        let mut found = false;
        let mut done = false;
        for msg in h.rx.iter() {
            match msg {
                ScanMsg::Found(p) => { assert_eq!(p.port, port); found = true; }
                ScanMsg::Done { open } => { assert_eq!(open, 1); done = true; break; }
                _ => {}
            }
        }
        assert!(found && done);
    }

    #[test]
    fn unresolvable_target_reports_error() {
        let h = scan("kein.host.invalid.", 80, 80, 2, 200);
        let mut got_error = false;
        for msg in h.rx.iter() {
            match msg {
                ScanMsg::Error(_) => got_error = true,
                ScanMsg::Done { .. } => break,
                _ => {}
            }
        }
        assert!(got_error);
    }

    #[test]
    fn common_ports_list_is_sane() {
        assert!(COMMON_PORTS.contains(&22) && COMMON_PORTS.contains(&443));
        assert!(COMMON_PORTS.windows(2).all(|w| w[0] < w[1]), "muss sortiert sein");
    }
}
