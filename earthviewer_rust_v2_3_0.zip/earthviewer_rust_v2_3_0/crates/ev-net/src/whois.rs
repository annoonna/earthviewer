//! WHOIS über TCP/43 — Port von `src/network/whois_lookup.py`,
//! aber mit Referral-Verfolgung (das Original blieb bei IANA stehen).
use std::io::{Read, Write};
use std::net::{TcpStream, ToSocketAddrs};
use std::time::Duration;

const IANA: &str = "whois.iana.org";

pub fn lookup(query: &str) -> String {
    match lookup_chain(query, 2) {
        Ok(s) => s,
        Err(e) => format!("❌ WHOIS-Fehler: {e}"),
    }
}

/// Fragt IANA, folgt dann bis zu `depth` `refer:`/`whois:`-Verweisen.
pub fn lookup_chain(query: &str, depth: u8) -> std::io::Result<String> {
    let mut server = IANA.to_string();
    let mut last = query_server(&server, query)?;
    for _ in 0..depth {
        let Some(next) = extract_referral(&last) else { break };
        if next == server { break; }
        match query_server(&next, query) {
            Ok(body) if !body.trim().is_empty() => { server = next; last = body; }
            _ => break,
        }
    }
    Ok(last)
}

pub fn query_server(server: &str, query: &str) -> std::io::Result<String> {
    let timeout = Duration::from_secs(ev_core::config::WHOIS_TIMEOUT_S);
    let addr = format!("{server}:43")
        .to_socket_addrs()?
        .next()
        .ok_or_else(|| std::io::Error::new(std::io::ErrorKind::NotFound, "kein A-Record"))?;
    let mut sock = TcpStream::connect_timeout(&addr, timeout)?;
    sock.set_read_timeout(Some(timeout))?;
    sock.set_write_timeout(Some(timeout))?;
    sock.write_all(format!("{query}\r\n").as_bytes())?;
    let mut buf = Vec::new();
    sock.read_to_end(&mut buf)?;
    Ok(String::from_utf8_lossy(&buf).into_owned())
}

pub fn extract_referral(body: &str) -> Option<String> {
    for line in body.lines() {
        let l = line.trim();
        for key in ["refer:", "whois:", "ReferralServer:"] {
            if let Some(v) = l.strip_prefix(key) {
                let v = v.trim().trim_start_matches("whois://");
                if !v.is_empty() { return Some(v.to_string()); }
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn finds_refer_line() {
        let body = "% IANA WHOIS\nrefer:        whois.ripe.net\n\ninetnum: 1.0.0.0";
        assert_eq!(extract_referral(body).as_deref(), Some("whois.ripe.net"));
    }

    #[test]
    fn strips_whois_scheme() {
        let body = "ReferralServer: whois://whois.arin.net";
        assert_eq!(extract_referral(body).as_deref(), Some("whois.arin.net"));
    }

    #[test]
    fn no_referral_returns_none() {
        assert!(extract_referral("inetnum: 1.0.0.0 - 1.0.0.255").is_none());
    }
}
