//! IP-Einstufung — Port von `ConnectionTracker.classify_ip`.
//! Ausschlaggebend für die Frage: gehört diese Gegenstelle überhaupt ins Netz?
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum IpClass {
    Loopback, Private, LinkLocal, Cgnat, Multicast, Documentation, Public,
}

impl IpClass {
    pub fn label(&self) -> &'static str {
        match self {
            Self::Loopback => "loopback",
            Self::Private => "privat (RFC1918)",
            Self::LinkLocal => "link-local",
            Self::Cgnat => "CGNAT (RFC6598)",
            Self::Multicast => "multicast",
            Self::Documentation => "Dokumentation",
            Self::Public => "öffentlich",
        }
    }
    /// Nur öffentliche Adressen lassen sich sinnvoll geolokalisieren.
    pub fn is_geolocatable(&self) -> bool { matches!(self, Self::Public) }
    pub fn rgb(&self) -> [u8; 3] {
        match self {
            Self::Public => [120, 200, 255],
            Self::Private | Self::Cgnat => [150, 220, 150],
            Self::Loopback => [160, 160, 160],
            _ => [200, 190, 120],
        }
    }
}

pub fn classify(ip: &str) -> Option<IpClass> {
    classify_addr(&ip.trim().parse::<IpAddr>().ok()?)
}

pub fn classify_addr(ip: &IpAddr) -> Option<IpClass> {
    Some(match ip {
        IpAddr::V4(v4) => classify_v4(v4),
        IpAddr::V6(v6) => classify_v6(v6),
    })
}

fn classify_v4(a: &Ipv4Addr) -> IpClass {
    let o = a.octets();
    if a.is_loopback() { return IpClass::Loopback; }
    if a.is_link_local() { return IpClass::LinkLocal; }
    if a.is_multicast() { return IpClass::Multicast; }
    if a.is_private() { return IpClass::Private; }
    // RFC 6598: 100.64.0.0/10 — Carrier-Grade NAT, sieht öffentlich aus, ist es nicht.
    if o[0] == 100 && (64..=127).contains(&o[1]) { return IpClass::Cgnat; }
    // RFC 5737 Dokumentationsnetze
    if (o[0], o[1], o[2]) == (192, 0, 2)
        || (o[0], o[1], o[2]) == (198, 51, 100)
        || (o[0], o[1], o[2]) == (203, 0, 113) { return IpClass::Documentation; }
    IpClass::Public
}

fn classify_v6(a: &Ipv6Addr) -> IpClass {
    if a.is_loopback() { return IpClass::Loopback; }
    if a.is_multicast() { return IpClass::Multicast; }
    let s = a.segments();
    if s[0] & 0xffc0 == 0xfe80 { return IpClass::LinkLocal; }
    if s[0] & 0xfe00 == 0xfc00 { return IpClass::Private; } // ULA fc00::/7
    if s[0] == 0x2001 && s[1] == 0x0db8 { return IpClass::Documentation; }
    IpClass::Public
}

/// Reverse-DNS — Port von `ARPScanner._resolve_hostname`.
/// std hat keine Rückwärtsauflösung; `getent hosts` erledigt es ohne libc-Bindung.
pub fn reverse_dns(ip: &str) -> Option<String> {
    if ip.trim().parse::<IpAddr>().is_err() { return None; }
    let out = std::process::Command::new("getent")
        .arg("hosts").arg(ip.trim())
        .output().ok()?;
    if !out.status.success() { return None; }
    let text = String::from_utf8_lossy(&out.stdout);
    let name = text.split_whitespace().nth(1)?.to_string();
    if name.is_empty() || name == ip.trim() { None } else { Some(name) }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classifies_ipv4() {
        assert_eq!(classify("127.0.0.1"), Some(IpClass::Loopback));
        assert_eq!(classify("192.168.1.1"), Some(IpClass::Private));
        assert_eq!(classify("10.0.0.5"), Some(IpClass::Private));
        assert_eq!(classify("172.16.0.1"), Some(IpClass::Private));
        assert_eq!(classify("169.254.1.1"), Some(IpClass::LinkLocal));
        assert_eq!(classify("8.8.8.8"), Some(IpClass::Public));
    }

    #[test]
    fn detects_cgnat() {
        // Sieht öffentlich aus, ist aber Providernetz — im Original nicht erkannt.
        assert_eq!(classify("100.64.0.1"), Some(IpClass::Cgnat));
        assert_eq!(classify("100.127.255.254"), Some(IpClass::Cgnat));
        assert_eq!(classify("100.128.0.1"), Some(IpClass::Public));
    }

    #[test]
    fn detects_documentation_nets() {
        assert_eq!(classify("192.0.2.1"), Some(IpClass::Documentation));
        assert_eq!(classify("203.0.113.7"), Some(IpClass::Documentation));
    }

    #[test]
    fn classifies_ipv6() {
        assert_eq!(classify("::1"), Some(IpClass::Loopback));
        assert_eq!(classify("fe80::1"), Some(IpClass::LinkLocal));
        assert_eq!(classify("fd00::1"), Some(IpClass::Private));
        assert_eq!(classify("2001:db8::1"), Some(IpClass::Documentation));
        assert_eq!(classify("2606:4700::1111"), Some(IpClass::Public));
    }

    #[test]
    fn only_public_is_geolocatable() {
        assert!(classify("8.8.8.8").unwrap().is_geolocatable());
        assert!(!classify("192.168.1.1").unwrap().is_geolocatable());
        assert!(!classify("100.64.0.1").unwrap().is_geolocatable());
    }

    #[test]
    fn rejects_garbage() {
        assert!(classify("keine-ip").is_none());
        assert!(classify("").is_none());
        assert!(reverse_dns("keine-ip").is_none());
    }

    #[test]
    fn every_class_has_label_and_colour() {
        for c in [IpClass::Loopback, IpClass::Private, IpClass::LinkLocal,
                  IpClass::Cgnat, IpClass::Multicast, IpClass::Documentation,
                  IpClass::Public] {
            assert!(!c.label().is_empty());
            assert_eq!(c.rgb().len(), 3);
        }
    }
}
