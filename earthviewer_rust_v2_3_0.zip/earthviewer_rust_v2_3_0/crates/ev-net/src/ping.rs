//! Ping — Port von `src/network/ping.py`.
//! Wie im Original wird das System-`ping` benutzt (kein Root nötig).
use std::io::{BufRead, BufReader};
use std::process::{Command, Stdio};
use std::sync::mpsc::{self, Receiver};

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PingResult {
    pub success: bool,
    pub rtt: f64,
    pub ttl: u32,
}

/// Startet einen Ping und liefert die Ergebnisse zeilenweise über einen Channel
/// (Rust-Äquivalent zum Python-Generator mit `yield`).
pub fn ping_stream(target: &str, count: u32) -> Receiver<PingResult> {
    let (tx, rx) = mpsc::channel();
    let target = target.to_string();
    std::thread::spawn(move || {
        let child = Command::new("ping")
            .arg("-c").arg(count.to_string())
            .arg(&target)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn();
        let Ok(mut child) = child else {
            eprintln!("❌ Ping-Fehler: `ping` nicht gefunden");
            return;
        };
        if let Some(out) = child.stdout.take() {
            for line in BufReader::new(out).lines().map_while(Result::ok) {
                if let Some(r) = parse_line(&line) {
                    if tx.send(r).is_err() { break; }
                }
            }
        }
        let _ = child.wait();
    });
    rx
}

/// Blockierende Variante für Tests/CLI.
pub fn ping_blocking(target: &str, count: u32) -> Vec<PingResult> {
    ping_stream(target, count).iter().collect()
}

/// Robuster Parser: sucht unabhängig von der Reihenfolge nach `time=` und `ttl=`.
pub fn parse_line(line: &str) -> Option<PingResult> {
    let l = line.trim();
    if l.is_empty() { return None; }
    let lower = l.to_ascii_lowercase();
    let rtt = extract_after(&lower, "time=").or_else(|| extract_after(&lower, "time<"))?;
    let ttl = extract_after(&lower, "ttl=")?;
    Some(PingResult { success: true, rtt, ttl: ttl as u32 })
}

/// Zieht die erste Zahl direkt hinter `needle`.
fn extract_after(haystack: &str, needle: &str) -> Option<f64> {
    let pos = haystack.find(needle)? + needle.len();
    let rest = &haystack[pos..];
    let end = rest
        .find(|c: char| !(c.is_ascii_digit() || c == '.'))
        .unwrap_or(rest.len());
    if end == 0 { return None; }
    rest[..end].parse::<f64>().ok()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_linux_output() {
        let r = parse_line("64 bytes from 1.1.1.1: icmp_seq=1 ttl=57 time=12.4 ms").unwrap();
        assert_eq!(r.ttl, 57);
        assert!((r.rtt - 12.4).abs() < 1e-9);
    }

    #[test]
    fn parses_windows_style_order() {
        let r = parse_line("Reply from 1.1.1.1: bytes=32 time=10ms TTL=57").unwrap();
        assert_eq!(r.ttl, 57);
        assert!((r.rtt - 10.0).abs() < 1e-9);
    }

    #[test]
    fn parses_sub_millisecond() {
        let r = parse_line("64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time<1 ms").unwrap();
        assert_eq!(r.ttl, 64);
    }

    #[test]
    fn ignores_summary_lines() {
        assert!(parse_line("--- 1.1.1.1 ping statistics ---").is_none());
        assert!(parse_line("").is_none());
        assert!(parse_line("Request timeout for icmp_seq 3").is_none());
    }
}
