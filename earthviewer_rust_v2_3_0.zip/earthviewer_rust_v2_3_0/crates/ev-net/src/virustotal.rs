//! VirusTotal v3 — Port von `src/network/virustotal_analyzer.py`.
//!
//! 🔐 Der API-Key kommt **ausschließlich** aus `$EARTHVIEWER_VT_API_KEY`.
//! Siehe docs/SECURITY_NOTES.md — das Original hatte ihn im Klartext in
//! `settings.json` und damit im ausgelieferten Archiv.
use serde::Deserialize;
use std::collections::HashMap;
use std::time::{Duration, Instant};

const BASE: &str = "https://www.virustotal.com/api/v3";

#[derive(Clone, Debug, Default, PartialEq)]
pub struct VtVerdict {
    pub ip: String,
    pub harmless: u32,
    pub malicious: u32,
    pub suspicious: u32,
    pub undetected: u32,
    pub country: String,
    pub as_owner: String,
    pub reputation: i64,
}

impl VtVerdict {
    /// Grobe Risikoeinstufung für die Farbe in der UI.
    pub fn risk(&self) -> Risk {
        if self.malicious >= 3 { Risk::High }
        else if self.malicious >= 1 { Risk::Medium }
        else if self.suspicious >= 2 { Risk::Low }
        else { Risk::Clean }
    }
    pub fn total_engines(&self) -> u32 {
        self.harmless + self.malicious + self.suspicious + self.undetected
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Risk { Clean, Low, Medium, High }

impl Risk {
    pub fn label(&self) -> &'static str {
        match self { Self::Clean => "sauber", Self::Low => "niedrig",
                     Self::Medium => "mittel", Self::High => "hoch" }
    }
    pub fn rgb(&self) -> [u8; 3] {
        match self {
            Self::Clean => [80, 220, 120], Self::Low => [220, 220, 80],
            Self::Medium => [255, 165, 0], Self::High => [255, 60, 60],
        }
    }
}

#[derive(Deserialize)]
struct VtResponse { data: VtData }
#[derive(Deserialize)]
struct VtData { attributes: VtAttrs }
#[derive(Deserialize)]
struct VtAttrs {
    #[serde(default)] last_analysis_stats: Stats,
    #[serde(default)] country: String,
    #[serde(default)] as_owner: String,
    #[serde(default)] reputation: i64,
}
#[derive(Deserialize, Default)]
struct Stats {
    #[serde(default)] harmless: u32,
    #[serde(default)] malicious: u32,
    #[serde(default)] suspicious: u32,
    #[serde(default)] undetected: u32,
}

/// Zwischenspeicher-Eintrag — Port von `self._cache[key] = {timestamp, data}`.
#[derive(Clone, Debug)]
struct Eintrag {
    zeit: Instant,
    daten: VtVerdict,
}

/// Lebensdauer eines Eintrags. 1:1 aus `virustotal_analyzer.py`:
/// `if (time.time() - entry.get("timestamp", 0)) < 3600`.
pub const CACHE_TTL: Duration = Duration::from_secs(3600);

/// Rate-Limiter: die kostenlose VT-API erlaubt 4 Anfragen/Minute.
pub struct VirusTotal {
    api_key: Option<String>,
    min_interval: Duration,
    last_call: Option<Instant>,
    cache: HashMap<String, Eintrag>,
}

impl VirusTotal {
    pub fn from_env() -> Self {
        Self {
            api_key: ev_core::settings::Settings::virustotal_api_key(),
            min_interval: Duration::from_secs_f64(16.0),
            last_call: None,
            cache: HashMap::new(),
        }
    }

    /// Port von `_make_cache_key`: `"{kind}:{value}"`.
    pub fn cache_key(kind: &str, value: &str) -> String {
        format!("{kind}:{value}")
    }

    /// Gültiger Eintrag im Zwischenspeicher? `None`, wenn fehlend oder zu alt.
    pub fn cached(&self, kind: &str, value: &str) -> Option<VtVerdict> {
        let e = self.cache.get(&Self::cache_key(kind, value))?;
        (e.zeit.elapsed() < CACHE_TTL).then(|| e.daten.clone())
    }

    /// Nur für Tests und Wiederherstellung: Eintrag mit gesetztem Alter ablegen.
    pub fn cache_put(&mut self, kind: &str, value: &str, daten: VtVerdict, alter: Duration) {
        let zeit = Instant::now().checked_sub(alter).unwrap_or_else(Instant::now);
        self.cache.insert(Self::cache_key(kind, value), Eintrag { zeit, daten });
    }

    pub fn cache_len(&self) -> usize {
        self.cache.len()
    }

    pub fn cache_clear(&mut self) {
        self.cache.clear();
    }

    pub fn is_configured(&self) -> bool { self.api_key.is_some() }

    pub fn set_min_interval(&mut self, secs: f64) {
        self.min_interval = Duration::from_secs_f64(secs.max(0.0));
    }

    /// Wartet, falls das Rate-Limit es verlangt. Gibt die Wartezeit zurück.
    pub fn throttle_delay(&self) -> Duration {
        match self.last_call {
            Some(t) => self.min_interval.saturating_sub(t.elapsed()),
            None => Duration::ZERO,
        }
    }

    /// Nachschlagen mit Zwischenspeicher. `force` umgeht ihn, genau wie der
    /// gleichnamige Parameter in `scan_ip(ip, force=False)`.
    pub fn lookup_ip(&mut self, ip: &str) -> anyhow::Result<VtVerdict> {
        self.lookup_ip_force(ip, false)
    }

    pub fn lookup_ip_force(&mut self, ip: &str, force: bool) -> anyhow::Result<VtVerdict> {
        let ip = ip.trim();
        if ip.is_empty() {
            anyhow::bail!("leere Adresse");
        }
        if !force {
            if let Some(v) = self.cached("ip", ip) {
                return Ok(v);
            }
        }
        let key = self
            .api_key
            .clone()
            .ok_or_else(|| anyhow::anyhow!("kein VT-API-Key ($EARTHVIEWER_VT_API_KEY)"))?;
        let wait = self.throttle_delay();
        if !wait.is_zero() { std::thread::sleep(wait); }
        self.last_call = Some(Instant::now());

        let body: VtResponse = ureq::get(&format!("{BASE}/ip_addresses/{ip}"))
            .set("x-apikey", &key)
            .timeout(Duration::from_secs(20))
            .call()?
            .into_json()?;

        let a = body.data.attributes;
        let ergebnis = VtVerdict {
            ip: ip.to_string(),
            harmless: a.last_analysis_stats.harmless,
            malicious: a.last_analysis_stats.malicious,
            suspicious: a.last_analysis_stats.suspicious,
            undetected: a.last_analysis_stats.undetected,
            country: a.country,
            as_owner: a.as_owner,
            reputation: a.reputation,
        };
        self.cache_put("ip", ip, ergebnis.clone(), Duration::ZERO);
        Ok(ergebnis)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn v(m: u32, s: u32) -> VtVerdict {
        VtVerdict { malicious: m, suspicious: s, harmless: 60, undetected: 10, ..Default::default() }
    }

    #[test]
    fn risk_thresholds() {
        assert_eq!(v(0, 0).risk(), Risk::Clean);
        assert_eq!(v(0, 2).risk(), Risk::Low);
        assert_eq!(v(1, 0).risk(), Risk::Medium);
        assert_eq!(v(5, 0).risk(), Risk::High);
    }

    #[test]
    fn engine_count_sums_up() {
        assert_eq!(v(2, 1).total_engines(), 73);
    }

    #[test]
    fn parses_api_shape() {
        let json = r#"{"data":{"attributes":{"last_analysis_stats":
            {"harmless":70,"malicious":2,"suspicious":1,"undetected":5},
            "country":"US","as_owner":"CLOUDFLARENET","reputation":-3}}}"#;
        let r: VtResponse = serde_json::from_str(json).unwrap();
        assert_eq!(r.data.attributes.last_analysis_stats.malicious, 2);
        assert_eq!(r.data.attributes.country, "US");
        assert_eq!(r.data.attributes.reputation, -3);
    }

    #[test]
    fn cache_key_matches_original_format() {
        assert_eq!(VirusTotal::cache_key("ip", "1.1.1.1"), "ip:1.1.1.1");
        assert_eq!(VirusTotal::cache_key("domain", "golem.de"), "domain:golem.de");
    }

    #[test]
    fn fresh_entry_is_returned() {
        let mut vt = VirusTotal::from_env();
        vt.cache_put("ip", "1.1.1.1", v(0, 0), Duration::from_secs(10));
        assert!(vt.cached("ip", "1.1.1.1").is_some());
        assert_eq!(vt.cache_len(), 1);
    }

    #[test]
    fn entry_older_than_an_hour_expires() {
        // 1:1 wie im Original: Grenze ist 3600 s.
        let mut vt = VirusTotal::from_env();
        vt.cache_put("ip", "8.8.8.8", v(1, 0), Duration::from_secs(3599));
        assert!(vt.cached("ip", "8.8.8.8").is_some(), "59:59 muss noch gelten");
        vt.cache_put("ip", "9.9.9.9", v(1, 0), Duration::from_secs(3601));
        assert!(vt.cached("ip", "9.9.9.9").is_none(), "über 3600 s muss verfallen");
    }

    #[test]
    fn unknown_key_is_a_miss() {
        let vt = VirusTotal::from_env();
        assert!(vt.cached("ip", "nie.gesehen").is_none());
        assert!(vt.cached("domain", "1.1.1.1").is_none(), "Art gehört zum Schlüssel");
    }

    #[test]
    fn clear_empties_the_cache() {
        let mut vt = VirusTotal::from_env();
        vt.cache_put("ip", "1.1.1.1", v(0, 0), Duration::ZERO);
        vt.cache_clear();
        assert_eq!(vt.cache_len(), 0);
    }

    #[test]
    fn cached_lookup_needs_no_key() {
        // Ohne API-Key schlägt lookup_ip fehl — aus dem Zwischenspeicher
        // muss es trotzdem gehen, sonst wäre der Speicher nutzlos.
        std::env::remove_var("EARTHVIEWER_VT_API_KEY");
        let mut vt = VirusTotal::from_env();
        vt.cache_put("ip", "1.1.1.1", v(2, 1), Duration::from_secs(5));
        let r = vt.lookup_ip("1.1.1.1").expect("Treffer aus dem Speicher");
        assert_eq!(r.malicious, 2);
    }

    #[test]
    fn empty_address_is_rejected() {
        let mut vt = VirusTotal::from_env();
        assert!(vt.lookup_ip("   ").is_err());
    }

    #[test]
    fn missing_key_is_not_configured() {
        std::env::remove_var("EARTHVIEWER_VT_API_KEY");
        assert!(!VirusTotal::from_env().is_configured());
    }
}
