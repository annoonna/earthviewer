//! Kontrollierter Nachweis: findet der Scanner genau die Ports, die horchen?
use std::net::TcpListener;

fn main() {
    // Zehn bekannte Horcher aufmachen
    let horcher: Vec<TcpListener> = (0..10)
        .map(|_| TcpListener::bind("127.0.0.1:0").unwrap())
        .collect();
    let mut erwartet: Vec<u16> = horcher.iter()
        .map(|l| l.local_addr().unwrap().port()).collect();
    erwartet.sort_unstable();
    println!("Erwartet: {erwartet:?}");

    let von = *erwartet.first().unwrap();
    let bis = *erwartet.last().unwrap();
    let t0 = std::time::Instant::now();
    let h = ev_net::portscan::scan("127.0.0.1", von, bis, 100, 500);
    let mut gefunden: Vec<u16> = Vec::new();
    let mut gemeldet = 0usize;
    for m in h.rx.iter() {
        match m {
            ev_net::portscan::ScanMsg::Found(p) => gefunden.push(p.port),
            ev_net::portscan::ScanMsg::Done { open } => { gemeldet = open; break; }
            _ => {}
        }
    }
    gefunden.sort_unstable();
    let s = t0.elapsed().as_secs_f64();
    println!("Gefunden: {gefunden:?}");
    println!("Bereich {von}-{bis} ({} Ports) in {s:.2} s", bis as u32 - von as u32 + 1);
    println!("Done meldet {gemeldet}, Found-Meldungen: {}", gefunden.len());

    let fehlend: Vec<u16> = erwartet.iter().filter(|p| !gefunden.contains(p)).copied().collect();
    println!("{}", if fehlend.is_empty() {
        "OK: alle Horcher gefunden".to_string()
    } else {
        format!("FEHLER: nicht gefunden {fehlend:?}")
    });
    println!("{}", if gemeldet == gefunden.len() {
        "OK: Zaehler stimmt mit den Meldungen ueberein".to_string()
    } else {
        format!("FEHLER: Zaehler {gemeldet} != Meldungen {}", gefunden.len())
    });
    drop(horcher);
}
