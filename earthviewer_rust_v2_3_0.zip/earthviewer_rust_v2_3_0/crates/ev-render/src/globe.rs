//! Der eigentliche Globus-Renderer — Port von `src/rendering/gl_renderer.py`.
use crate::geometry::SphereMesh;
use crate::gl_util::{self, load_sprite_texture, load_texture, DynamicBuffer, Program};
use crate::scene::Scene;
use crate::shaders;
use ev_core::config;
use glam::Mat4;

pub struct GlobeRenderer {
    earth: Program,
    marker: Program,
    line: Program,
    sphere_vao: glow::VertexArray,
    sphere_vbo: glow::Buffer,
    sphere_ebo: glow::Buffer,
    index_count: i32,
    texture: glow::Texture,
    dynamic: DynamicBuffer,
    /// Sprite-Programm + Icon. `None`, wenn kein Icon gefunden wurde —
    /// dann fällt die App auf einfarbige Punkte zurück.
    sprite: Option<(Program, glow::Texture)>,
    /// Lichtposition — im Original fix in gl_renderer.py.
    pub light_pos: [f32; 3],
    /// Zuschaltbare Karten-Kachel-Ebene (Runde D).
    pub tiles: crate::tile_layer::TileLayer,
}

impl GlobeRenderer {
    pub fn new(gl: &glow::Context, texture_path: &std::path::Path) -> anyhow::Result<Self> {
        let earth = Program::new(gl, shaders::EARTH_VERT, shaders::EARTH_FRAG)?;
        let marker = Program::new(gl, shaders::MARKER_VERT, shaders::MARKER_FRAG)?;
        let line = Program::new(gl, shaders::LINE_VERT, shaders::LINE_FRAG)?;

        let mesh = SphereMesh::generate(
            config::SPHERE_RADIUS, config::SPHERE_STACKS, config::SPHERE_SLICES,
        );
        let interleaved = mesh.interleaved();

        let (sphere_vao, sphere_vbo, sphere_ebo) =
            gl_util::kugel_puffer_anlegen(gl, &interleaved, &mesh.indices)?;

        let texture = load_texture(gl, texture_path)?;
        let dynamic = DynamicBuffer::new(gl)?;

        // Satelliten-Icon: erst satellite_icon.png, sonst satellite_icon1.png.
        let sprite_dir = ev_core::config::texture_dir().join("satellites");
        let sprite = ["satellite_icon.png", "satellite_icon1.png"]
            .iter()
            .map(|n| sprite_dir.join(n))
            .find(|p| p.is_file())
            .and_then(|p| {
                match (
                    Program::new(gl, shaders::SPRITE_VERT, shaders::SPRITE_FRAG),
                    load_sprite_texture(gl, &p, 128),
                ) {
                    (Ok(prog), Ok(tex)) => {
                        eprintln!("✅ Satelliten-Sprites: {}", p.display());
                        Some((prog, tex))
                    }
                    (Err(e), _) | (_, Err(e)) => {
                        eprintln!("⚠️  Satelliten-Sprites deaktiviert: {e}");
                        None
                    }
                }
            });

        Ok(Self {
            earth, marker, line,
            sphere_vao, sphere_vbo, sphere_ebo,
            index_count: mesh.index_count(),
            texture, dynamic, sprite,
            light_pos: [5.0, 3.0, 5.0],
            tiles: crate::tile_layer::TileLayer::new(),
        })
    }

    /// Zeichnet die App Satelliten als Symbole oder als Punkte?
    pub fn has_sprites(&self) -> bool { self.sprite.is_some() }

    pub fn render(&mut self, gl: &glow::Context, mvp: Mat4, model: Mat4, scene: &Scene) {
        gl_util::zeichenzustand_setzen(gl);
        self.render_earth(gl, mvp, model);
        // Karten-Kacheln über der Basistextur (Runde D) — nur wenn eingeschaltet.
        self.tiles.render(gl, &self.earth, mvp, model, self.light_pos);
        self.render_lines(gl, mvp, scene);
        self.render_markers(gl, mvp, scene);
        self.render_sprites(gl, mvp, scene);
        gl_util::zeichenzustand_aufheben(gl);
    }

    fn render_earth(&self, gl: &glow::Context, mvp: Mat4, model: Mat4) {
        self.earth.use_it(gl);
        self.earth.set_mat4(gl, "mvp", &mvp);
        self.earth.set_mat4(gl, "model", &model);
        self.earth.set_vec3(gl, "lightPos", self.light_pos);
        self.earth.set_i32(gl, "earthTexture", 0);
        gl_util::textur_binden(gl, 0, Some(self.texture));
        gl_util::dreiecke_zeichnen(gl, self.sphere_vao, self.index_count);
    }

    fn render_markers(&mut self, gl: &glow::Context, mvp: Mat4, scene: &Scene) {
        if scene.markers.is_empty() { return; }
        self.marker.use_it(gl);
        self.marker.set_mat4(gl, "mvp", &mvp);
        for batch in &scene.markers {
            let flat: Vec<f32> = batch.points.iter().flat_map(|p| [p.x, p.y, p.z]).collect();
            self.dynamic.upload(gl, &flat);
            self.marker.set_vec3(gl, "markerColor", batch.color);
            self.marker.set_f32(gl, "pointSize", batch.size);
            gl_util::punkte_zeichnen(gl, self.dynamic.vao, glow::POINTS,
                                     batch.points.len() as i32);
        }
    }

    /// Texturierte Punkt-Sprites — Port von `SatelliteSpriteRenderer.render_satellites`.
    fn render_sprites(&mut self, gl: &glow::Context, mvp: Mat4, scene: &Scene) {
        if scene.sprites.is_empty() { return; }
        let Some((prog, tex)) = &self.sprite else { return };
        prog.use_it(gl);
        prog.set_mat4(gl, "mvp", &mvp);
        prog.set_i32(gl, "tex", 0);
        gl_util::textur_binden(gl, 0, Some(*tex));
        // Sprites hinter der Kugel sollen verdeckt bleiben, aber die Tiefe
        // nicht schreiben — sonst schneiden sich überlappende Symbole weg.
        gl_util::tiefe_schreiben(gl, false);
        for batch in &scene.sprites {
            let flat: Vec<f32> = batch.points.iter().flat_map(|p| [p.x, p.y, p.z]).collect();
            self.dynamic.upload(gl, &flat);
            prog.set_f32(gl, "baseSize", batch.size);
            gl_util::vec4_setzen(gl, prog.raw, "tint", batch.tint);
            gl_util::punkte_zeichnen(gl, self.dynamic.vao, glow::POINTS,
                                     batch.points.len() as i32);
        }
        gl_util::tiefe_schreiben(gl, true);
        gl_util::textur_binden(gl, 0, None);
    }

    fn render_lines(&mut self, gl: &glow::Context, mvp: Mat4, scene: &Scene) {
        if scene.lines.is_empty() { return; }
        self.line.use_it(gl);
        self.line.set_mat4(gl, "mvp", &mvp);
        for batch in &scene.lines {
            let flat: Vec<f32> = batch.points.iter().flat_map(|p| [p.x, p.y, p.z]).collect();
            self.dynamic.upload(gl, &flat);
            self.line.set_vec3(gl, "lineColor", batch.color);
            self.line.set_f32(gl, "alpha", batch.alpha);
            // glLineWidth > 1 ist im Core-Profil nicht garantiert —
            // das Original brauchte deshalb ein Compatibility-Profil.
            gl_util::linienbreite_setzen(gl, batch.width);
            gl_util::punkte_zeichnen(gl, self.dynamic.vao, glow::LINE_STRIP,
                                     batch.points.len() as i32);
        }
    }

    pub fn destroy(&self, gl: &glow::Context) {
        self.earth.destroy(gl);
        self.marker.destroy(gl);
        self.line.destroy(gl);
        self.dynamic.destroy(gl);
        if let Some((prog, tex)) = &self.sprite {
            prog.destroy(gl);
            gl_util::textur_loeschen(gl, *tex);
        }
        gl_util::kugel_puffer_loeschen(
            gl, self.sphere_vao, self.sphere_vbo, self.sphere_ebo, self.texture);
    }
}
