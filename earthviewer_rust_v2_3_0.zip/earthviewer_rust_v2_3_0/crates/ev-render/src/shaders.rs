//! GLSL-Quelltexte — **wörtlich** aus `src/rendering/shaders.py` übernommen.
//! (Nicht anfassen ohne Not: die Erde sieht genau so aus wie vorher.)

pub const EARTH_VERT: &str = r#"#version 330 core
layout(location = 0) in vec3 position;
layout(location = 1) in vec2 texCoord;
layout(location = 2) in vec3 normal;

uniform mat4 mvp;
uniform mat4 model;
uniform vec3 lightPos;

out vec2 fragTexCoord;
out float lightIntensity;

void main() {
    gl_Position = mvp * vec4(position, 1.0);
    fragTexCoord = texCoord;

    vec3 worldPos = (model * vec4(position, 1.0)).xyz;
    vec3 worldNormal = normalize(mat3(model) * normal);
    vec3 lightDir = normalize(lightPos - worldPos);

    float diffuse = max(dot(worldNormal, lightDir), 0.0);
    lightIntensity = 0.3 + 0.7 * diffuse;
}
"#;

pub const EARTH_FRAG: &str = r#"#version 330 core
in vec2 fragTexCoord;
in float lightIntensity;

out vec4 outColor;

uniform sampler2D earthTexture;

void main() {
    vec4 texColor = texture(earthTexture, fragTexCoord);
    outColor = vec4(texColor.rgb * lightIntensity, texColor.a);
}
"#;

pub const MARKER_VERT: &str = r#"#version 330 core
layout(location = 0) in vec3 position;

uniform mat4 mvp;
uniform float pointSize;

void main() {
    gl_Position = mvp * vec4(position, 1.0);
    gl_PointSize = pointSize;
}
"#;

pub const MARKER_FRAG: &str = r#"#version 330 core
out vec4 outColor;

uniform vec3 markerColor;

void main() {
    vec2 coord = gl_PointCoord - vec2(0.5);
    if (length(coord) > 0.5) {
        discard;
    }
    outColor = vec4(markerColor, 1.0);
}
"#;

pub const LINE_VERT: &str = r#"#version 330 core
layout(location = 0) in vec3 position;

uniform mat4 mvp;

void main() {
    gl_Position = mvp * vec4(position, 1.0);
}
"#;

pub const LINE_FRAG: &str = r#"#version 330 core
out vec4 outColor;

uniform vec3 lineColor;
uniform float alpha;

void main() {
    outColor = vec4(lineColor, alpha);
}
"#;

/// Texturierte Punkt-Sprites für Satelliten.
/// **Wörtlich** aus `src/rendering/satellite_sprites.py` übernommen
/// (`VERTEX_SHADER_SRC` / `FRAGMENT_SHADER_SRC`).
pub const SPRITE_VERT: &str = r#"#version 330 core
layout(location = 0) in vec3 aPos;

uniform mat4 mvp;
uniform float baseSize;

void main()
{
    gl_Position = mvp * vec4(aPos, 1.0);
    gl_PointSize = baseSize;
}
"#;

pub const SPRITE_FRAG: &str = r#"#version 330 core
out vec4 FragColor;

uniform sampler2D tex;
uniform vec4 tint;

void main()
{
    // gl_PointCoord gibt die Texturkoordinaten innerhalb des Punktes (0..1)
    vec2 uv = gl_PointCoord;
    vec4 texColor = texture(tex, uv);

    // Premultiplied Alpha / Tint
    vec4 color = texColor * tint;

    // Sehr transparente Pixel verwerfen (saubere Kanten)
    if (color.a < 0.1)
        discard;

    FragColor = color;
}
"#;

/// Für GL-ES / WebGL wird `#version 330 core` durch `#version 300 es` ersetzt.
pub fn for_gles(src: &str) -> String {
    src.replace("#version 330 core", "#version 300 es\nprecision mediump float;")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn all_shaders_declare_version() {
        for s in [EARTH_VERT, EARTH_FRAG, MARKER_VERT, MARKER_FRAG, LINE_VERT, LINE_FRAG,
                  SPRITE_VERT, SPRITE_FRAG] {
            assert!(s.starts_with("#version 330 core"), "fehlende Version");
        }
    }

    #[test]
    fn earth_shader_pair_matches_varyings() {
        assert!(EARTH_VERT.contains("out vec2 fragTexCoord"));
        assert!(EARTH_FRAG.contains("in vec2 fragTexCoord"));
        assert!(EARTH_VERT.contains("out float lightIntensity"));
        assert!(EARTH_FRAG.contains("in float lightIntensity"));
    }

    #[test]
    fn sprite_shader_uses_point_coord() {
        assert!(SPRITE_FRAG.contains("gl_PointCoord"));
        assert!(SPRITE_VERT.contains("gl_PointSize"));
        assert!(SPRITE_FRAG.contains("discard"), "transparente Kanten muessen weg");
    }

    #[test]
    fn gles_conversion_adds_precision() {
        let s = for_gles(EARTH_FRAG);
        assert!(s.starts_with("#version 300 es"));
        assert!(s.contains("precision mediump float;"));
    }
}
