//! Dünne, sichere Hüllen um glow. Alle `unsafe`-Blöcke des Projekts leben hier.
use glow::HasContext;

pub struct Program {
    pub raw: glow::Program,
}

impl Program {
    pub fn new(gl: &glow::Context, vert: &str, frag: &str) -> anyhow::Result<Self> {
        unsafe {
            let program = gl
                .create_program()
                .map_err(|e| anyhow::anyhow!("create_program: {e}"))?;
            let mut shaders = Vec::new();
            for (kind, src) in [(glow::VERTEX_SHADER, vert), (glow::FRAGMENT_SHADER, frag)] {
                let sh = gl
                    .create_shader(kind)
                    .map_err(|e| anyhow::anyhow!("create_shader: {e}"))?;
                gl.shader_source(sh, src);
                gl.compile_shader(sh);
                if !gl.get_shader_compile_status(sh) {
                    let log = gl.get_shader_info_log(sh);
                    gl.delete_shader(sh);
                    for s in shaders { gl.delete_shader(s); }
                    gl.delete_program(program);
                    return Err(anyhow::anyhow!("Shader-Compile fehlgeschlagen:\n{log}"));
                }
                gl.attach_shader(program, sh);
                shaders.push(sh);
            }
            gl.link_program(program);
            let ok = gl.get_program_link_status(program);
            for s in shaders {
                gl.detach_shader(program, s);
                gl.delete_shader(s);
            }
            if !ok {
                let log = gl.get_program_info_log(program);
                gl.delete_program(program);
                return Err(anyhow::anyhow!("Link fehlgeschlagen:\n{log}"));
            }
            Ok(Self { raw: program })
        }
    }

    pub fn use_it(&self, gl: &glow::Context) {
        unsafe { gl.use_program(Some(self.raw)) }
    }

    pub fn set_mat4(&self, gl: &glow::Context, name: &str, m: &glam::Mat4) {
        unsafe {
            if let Some(loc) = gl.get_uniform_location(self.raw, name) {
                // glam ist column-major, GL erwartet column-major → transpose = false.
                gl.uniform_matrix_4_f32_slice(Some(&loc), false, &m.to_cols_array());
            }
        }
    }
    pub fn set_vec3(&self, gl: &glow::Context, name: &str, v: [f32; 3]) {
        unsafe {
            if let Some(loc) = gl.get_uniform_location(self.raw, name) {
                gl.uniform_3_f32(Some(&loc), v[0], v[1], v[2]);
            }
        }
    }
    pub fn set_f32(&self, gl: &glow::Context, name: &str, v: f32) {
        unsafe {
            if let Some(loc) = gl.get_uniform_location(self.raw, name) {
                gl.uniform_1_f32(Some(&loc), v);
            }
        }
    }
    pub fn set_i32(&self, gl: &glow::Context, name: &str, v: i32) {
        unsafe {
            if let Some(loc) = gl.get_uniform_location(self.raw, name) {
                gl.uniform_1_i32(Some(&loc), v);
            }
        }
    }

    pub fn destroy(&self, gl: &glow::Context) {
        unsafe { gl.delete_program(self.raw) }
    }
}

/// Ein dynamischer Vertex-Puffer für Punkte und Linienzüge.
pub struct DynamicBuffer {
    pub vao: glow::VertexArray,
    pub vbo: glow::Buffer,
    capacity_floats: usize,
}

impl DynamicBuffer {
    pub fn new(gl: &glow::Context) -> anyhow::Result<Self> {
        unsafe {
            let vao = gl.create_vertex_array().map_err(|e| anyhow::anyhow!("{e}"))?;
            let vbo = gl.create_buffer().map_err(|e| anyhow::anyhow!("{e}"))?;
            gl.bind_vertex_array(Some(vao));
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(vbo));
            gl.enable_vertex_attrib_array(0);
            gl.vertex_attrib_pointer_f32(0, 3, glow::FLOAT, false, 12, 0);
            gl.bind_vertex_array(None);
            Ok(Self { vao, vbo, capacity_floats: 0 })
        }
    }

    /// Lädt `data` hoch (orphaning, wenn die Kapazität wächst).
    pub fn upload(&mut self, gl: &glow::Context, data: &[f32]) {
        unsafe {
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(self.vbo));
            let bytes = bytemuck::cast_slice(data);
            if data.len() > self.capacity_floats {
                gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, bytes, glow::DYNAMIC_DRAW);
                self.capacity_floats = data.len();
            } else {
                gl.buffer_sub_data_u8_slice(glow::ARRAY_BUFFER, 0, bytes);
            }
        }
    }

    pub fn destroy(&self, gl: &glow::Context) {
        unsafe {
            gl.delete_buffer(self.vbo);
            gl.delete_vertex_array(self.vao);
        }
    }
}

/// Lädt eine Textur von der Platte. Fällt auf ein prozedurales Gitter zurück,
/// wenn die Datei fehlt (das Python-Original zeigte dann eine schwarze Kugel).
pub fn load_texture(gl: &glow::Context, path: &std::path::Path) -> anyhow::Result<glow::Texture> {
    let (w, h, rgba) = match image::open(path) {
        Ok(img) => {
            let img = img.to_rgba8();
            (img.width(), img.height(), img.into_raw())
        }
        Err(e) => {
            eprintln!("⚠️  Textur nicht ladbar ({}): {e} — nutze Fallback-Gitter",
                      path.display());
            fallback_texture()
        }
    };
    upload_rgba(gl, w, h, &rgba)
}

pub fn upload_rgba(
    gl: &glow::Context,
    w: u32,
    h: u32,
    rgba: &[u8],
) -> anyhow::Result<glow::Texture> {
    unsafe {
        let tex = gl.create_texture().map_err(|e| anyhow::anyhow!("{e}"))?;
        gl.bind_texture(glow::TEXTURE_2D, Some(tex));
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_WRAP_S, glow::REPEAT as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_WRAP_T, glow::CLAMP_TO_EDGE as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MIN_FILTER,
                             glow::LINEAR_MIPMAP_LINEAR as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MAG_FILTER, glow::LINEAR as i32);
        // Anisotrope Filterung, falls die GL-Erweiterung da ist — schärft die
        // Textur an flach angeschnittenen Stellen (Kugelrand, Tiefzoom) deutlich.
        // GL_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FE, GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FF.
        {
            let max_aniso = gl.get_parameter_f32(0x84FF);
            if max_aniso > 1.0 {
                let stufe = max_aniso.min(16.0);
                gl.tex_parameter_f32(glow::TEXTURE_2D, 0x84FE, stufe);
            }
        }
        gl.tex_image_2d(
            glow::TEXTURE_2D, 0, glow::RGBA8 as i32,
            w as i32, h as i32, 0, glow::RGBA, glow::UNSIGNED_BYTE,
            glow::PixelUnpackData::Slice(Some(rgba)),
        );
        gl.generate_mipmap(glow::TEXTURE_2D);
        gl.bind_texture(glow::TEXTURE_2D, None);
        Ok(tex)
    }
}

// ── Gekapselte GL-Aufrufe ──────────────────────────────────────────────────
// Hier endet `unsafe`. Wer ausserhalb dieser Datei einen GL-Aufruf braucht,
// ergaenzt hier eine Huelle — so bleibt die Aussage in ARCHITECTURE.md wahr.

/// Zustand fuer das Zeichnen von Kugel, Linien und Punkten.
pub fn zeichenzustand_setzen(gl: &glow::Context) {
    unsafe {
        gl.enable(glow::DEPTH_TEST);
        gl.depth_func(glow::LEQUAL);
        gl.enable(glow::PROGRAM_POINT_SIZE);
        gl.enable(glow::BLEND);
        gl.blend_func(glow::SRC_ALPHA, glow::ONE_MINUS_SRC_ALPHA);
    }
}

pub fn zeichenzustand_aufheben(gl: &glow::Context) {
    unsafe {
        gl.disable(glow::BLEND);
        gl.disable(glow::DEPTH_TEST);
    }
}

/// Bildpuffer leeren — vom PaintCallback aus aufgerufen.
pub fn puffer_leeren(gl: &glow::Context, farbe: [f32; 3]) {
    unsafe {
        gl.clear_color(farbe[0], farbe[1], farbe[2], 1.0);
        gl.clear(glow::COLOR_BUFFER_BIT | glow::DEPTH_BUFFER_BIT);
    }
}

pub fn textur_binden(gl: &glow::Context, einheit: u32, tex: Option<glow::Texture>) {
    unsafe {
        gl.active_texture(glow::TEXTURE0 + einheit);
        gl.bind_texture(glow::TEXTURE_2D, tex);
    }
}

/// Indizierte Dreiecke zeichnen (die Kugel).
pub fn dreiecke_zeichnen(gl: &glow::Context, vao: glow::VertexArray, anzahl: i32) {
    unsafe {
        gl.bind_vertex_array(Some(vao));
        gl.draw_elements(glow::TRIANGLES, anzahl, glow::UNSIGNED_INT, 0);
        gl.bind_vertex_array(None);
    }
}

/// Gibt VAO+VBO+EBO frei (für die Kachel-Ebene, die Puffer dynamisch anlegt).
pub fn puffer_freigeben(
    gl: &glow::Context,
    vao: glow::VertexArray,
    vbo: glow::Buffer,
    ebo: glow::Buffer,
) {
    unsafe {
        gl.delete_vertex_array(vao);
        gl.delete_buffer(vbo);
        gl.delete_buffer(ebo);
    }
}

/// Gibt eine Textur frei.
pub fn textur_freigeben(gl: &glow::Context, tex: glow::Texture) {
    unsafe {
        gl.delete_texture(tex);
    }
}

/// Punkte oder Linienzug aus einem dynamischen Puffer zeichnen.
pub fn punkte_zeichnen(gl: &glow::Context, vao: glow::VertexArray, modus: u32, anzahl: i32) {
    unsafe {
        gl.bind_vertex_array(Some(vao));
        gl.draw_arrays(modus, 0, anzahl);
        gl.bind_vertex_array(None);
    }
}

/// ⚠️ Im Core-Profil nicht garantiert — siehe docs/RELAY.md §2.
pub fn linienbreite_setzen(gl: &glow::Context, breite: f32) {
    unsafe { gl.line_width(breite) }
}

/// Tiefenschreiben an/aus. Sprites duerfen sich nicht gegenseitig wegschneiden.
pub fn tiefe_schreiben(gl: &glow::Context, an: bool) {
    unsafe { gl.depth_mask(an) }
}

pub fn vec4_setzen(gl: &glow::Context, programm: glow::Program, name: &str, v: [f32; 4]) {
    unsafe {
        if let Some(loc) = gl.get_uniform_location(programm, name) {
            gl.uniform_4_f32(Some(&loc), v[0], v[1], v[2], v[3]);
        }
    }
}

/// Kugel-Geometrie hochladen: VAO, VBO, EBO und die drei Attributzeiger.
pub fn kugel_puffer_anlegen(
    gl: &glow::Context,
    interleaved: &[f32],
    indices: &[u32],
) -> anyhow::Result<(glow::VertexArray, glow::Buffer, glow::Buffer)> {
    unsafe {
        let vao = gl.create_vertex_array().map_err(|e| anyhow::anyhow!("{e}"))?;
        let vbo = gl.create_buffer().map_err(|e| anyhow::anyhow!("{e}"))?;
        let ebo = gl.create_buffer().map_err(|e| anyhow::anyhow!("{e}"))?;

        gl.bind_vertex_array(Some(vao));
        gl.bind_buffer(glow::ARRAY_BUFFER, Some(vbo));
        gl.buffer_data_u8_slice(
            glow::ARRAY_BUFFER, bytemuck::cast_slice(interleaved), glow::STATIC_DRAW);
        gl.bind_buffer(glow::ELEMENT_ARRAY_BUFFER, Some(ebo));
        gl.buffer_data_u8_slice(
            glow::ELEMENT_ARRAY_BUFFER, bytemuck::cast_slice(indices), glow::STATIC_DRAW);

        let stride = 8 * 4; // pos(3) + uv(2) + normal(3)
        gl.enable_vertex_attrib_array(0);
        gl.vertex_attrib_pointer_f32(0, 3, glow::FLOAT, false, stride, 0);
        gl.enable_vertex_attrib_array(1);
        gl.vertex_attrib_pointer_f32(1, 2, glow::FLOAT, false, stride, 12);
        gl.enable_vertex_attrib_array(2);
        gl.vertex_attrib_pointer_f32(2, 3, glow::FLOAT, false, stride, 20);
        gl.bind_vertex_array(None);
        Ok((vao, vbo, ebo))
    }
}

pub fn kugel_puffer_loeschen(
    gl: &glow::Context,
    vao: glow::VertexArray,
    vbo: glow::Buffer,
    ebo: glow::Buffer,
    tex: glow::Texture,
) {
    unsafe {
        gl.delete_vertex_array(vao);
        gl.delete_buffer(vbo);
        gl.delete_buffer(ebo);
        gl.delete_texture(tex);
    }
}

pub fn textur_loeschen(gl: &glow::Context, tex: glow::Texture) {
    unsafe { gl.delete_texture(tex) }
}

/// Lädt ein Sprite-Icon und legt es **mittig in eine quadratische Fläche**.
///
/// Warum quadratisch? Punkt-Sprites sind quadratisch, `gl_PointCoord` läuft
/// in beiden Achsen von 0..1. Das Original gab die 2221×1666-Datei
/// unverändert an GL — das Icon wurde dadurch um ein Viertel in die Breite
/// gestaucht. Wir betten es stattdessen randlos mittig ein, dann stimmen die
/// Proportionen. `edge` begrenzt zugleich den Speicherbedarf (die
/// Originaldatei ist 1,6 MB).
pub fn load_sprite_texture(
    gl: &glow::Context,
    path: &std::path::Path,
    edge: u32,
) -> anyhow::Result<glow::Texture> {
    let img = image::open(path)
        .map_err(|e| anyhow::anyhow!("Sprite-Icon nicht ladbar ({}): {e}", path.display()))?
        .to_rgba8();
    let square = fit_into_square(&img, edge);
    upload_rgba(gl, edge, edge, &square)
}

/// Skaliert unter Erhalt des Seitenverhältnisses und zentriert auf `edge`×`edge`.
/// Der Rand bleibt vollständig durchsichtig.
pub fn fit_into_square(img: &image::RgbaImage, edge: u32) -> Vec<u8> {
    let (w, h) = (img.width().max(1), img.height().max(1));
    let scale = (edge as f32 / w as f32).min(edge as f32 / h as f32);
    let (nw, nh) = (
        ((w as f32 * scale) as u32).clamp(1, edge),
        ((h as f32 * scale) as u32).clamp(1, edge),
    );
    let klein = image::imageops::resize(img, nw, nh, image::imageops::FilterType::Lanczos3);
    let mut leinwand = image::RgbaImage::from_pixel(edge, edge, image::Rgba([0, 0, 0, 0]));
    image::imageops::overlay(
        &mut leinwand,
        &klein,
        ((edge - nw) / 2) as i64,
        ((edge - nh) / 2) as i64,
    );
    leinwand.into_raw()
}

/// 512×256 Gradnetz in Blau/Cyan — sichtbarer Ersatz für `earth_map.jpg`.
pub fn fallback_texture() -> (u32, u32, Vec<u8>) {
    const W: u32 = 512;
    const H: u32 = 256;
    let mut buf = vec![0u8; (W * H * 4) as usize];
    for y in 0..H {
        for x in 0..W {
            let i = ((y * W + x) * 4) as usize;
            let grid = x % 32 == 0 || y % 32 == 0;
            let equator = y == H / 2;
            let (r, g, b) = if equator { (255, 200, 60) }
                            else if grid { (40, 110, 140) }
                            else { (10, 26, 48) };
            buf[i] = r; buf[i + 1] = g; buf[i + 2] = b; buf[i + 3] = 255;
        }
    }
    (W, H, buf)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fallback_texture_has_correct_size() {
        let (w, h, buf) = fallback_texture();
        assert_eq!(w, 512);
        assert_eq!(h, 256);
        assert_eq!(buf.len(), (w * h * 4) as usize);
    }

    #[test]
    fn fallback_texture_is_fully_opaque() {
        let (_, _, buf) = fallback_texture();
        assert!(buf.chunks(4).all(|p| p[3] == 255));
    }

    #[test]
    fn square_fit_keeps_aspect_and_pads() {
        // 4:3-Eingang -> quadratischer Ausgang mit durchsichtigem Rand
        let img = image::RgbaImage::from_pixel(400, 300, image::Rgba([255, 0, 0, 255]));
        let out = fit_into_square(&img, 64);
        assert_eq!(out.len(), 64 * 64 * 4);
        let px = |x: u32, y: u32| {
            let i = ((y * 64 + x) * 4) as usize;
            [out[i], out[i + 1], out[i + 2], out[i + 3]]
        };
        // Mitte gefuellt
        assert_eq!(px(32, 32)[3], 255);
        // oberer und unterer Rand durchsichtig (300/400 -> 48 px hoch, 8 px Rand)
        assert_eq!(px(32, 1)[3], 0, "oben muss Rand sein");
        assert_eq!(px(32, 62)[3], 0, "unten muss Rand sein");
        // links/rechts randlos gefuellt
        assert_eq!(px(1, 32)[3], 255);
    }

    #[test]
    fn square_fit_handles_portrait_and_square() {
        let hoch = image::RgbaImage::from_pixel(100, 400, image::Rgba([0, 255, 0, 255]));
        let out = fit_into_square(&hoch, 32);
        assert_eq!(out.len(), 32 * 32 * 4);
        let quad = image::RgbaImage::from_pixel(50, 50, image::Rgba([0, 0, 255, 255]));
        let out2 = fit_into_square(&quad, 16);
        // quadratischer Eingang -> kein Rand
        assert!(out2.chunks(4).all(|p| p[3] == 255));
    }

    #[test]
    fn fallback_texture_marks_the_equator() {
        let (w, h, buf) = fallback_texture();
        let i = (((h / 2) * w + 100) * 4) as usize;
        assert_eq!(&buf[i..i + 3], &[255, 200, 60]);
    }
}
