//! UV-Sphere-Generator — Port von `src/rendering/sphere_geometry.py`.

pub struct SphereMesh {
    pub vertices: Vec<f32>,   // xyz
    pub tex_coords: Vec<f32>, // uv
    pub normals: Vec<f32>,    // xyz
    pub indices: Vec<u32>,
}

impl SphereMesh {
    pub fn generate(radius: f32, stacks: u32, slices: u32) -> Self {
        let n_verts = ((stacks + 1) * (slices + 1)) as usize;
        let mut vertices = Vec::with_capacity(n_verts * 3);
        let mut tex_coords = Vec::with_capacity(n_verts * 2);
        let mut normals = Vec::with_capacity(n_verts * 3);
        let mut indices = Vec::with_capacity((stacks * slices * 6) as usize);

        for stack in 0..=stacks {
            let lat = 90.0 - (stack as f32 / stacks as f32) * 180.0;
            let lat_rad = lat.to_radians();
            for slice in 0..=slices {
                let lon = (slice as f32 / slices as f32) * 360.0 - 180.0;
                let lon_rad = lon.to_radians();

                let x = radius * lat_rad.cos() * lon_rad.sin();
                let y = radius * lat_rad.sin();
                let z = radius * lat_rad.cos() * lon_rad.cos();
                vertices.extend_from_slice(&[x, y, z]);

                tex_coords.extend_from_slice(&[
                    (lon + 180.0) / 360.0,
                    (90.0 - lat) / 180.0,
                ]);

                let len = (x * x + y * y + z * z).sqrt();
                if len > 0.0 {
                    normals.extend_from_slice(&[x / len, y / len, z / len]);
                } else {
                    normals.extend_from_slice(&[0.0, 1.0, 0.0]);
                }
            }
        }

        for stack in 0..stacks {
            for slice in 0..slices {
                let first = stack * (slices + 1) + slice;
                let second = first + slices + 1;
                indices.extend_from_slice(&[first, second, first + 1]);
                indices.extend_from_slice(&[second, second + 1, first + 1]);
            }
        }

        Self { vertices, tex_coords, normals, indices }
    }

    pub fn vertex_count(&self) -> usize { self.vertices.len() / 3 }
    pub fn index_count(&self) -> i32 { self.indices.len() as i32 }

    /// Interleaved [pos.xyz, uv.xy, normal.xyz] — ein einziger VBO.
    pub fn interleaved(&self) -> Vec<f32> {
        let n = self.vertex_count();
        let mut out = Vec::with_capacity(n * 8);
        for i in 0..n {
            out.extend_from_slice(&self.vertices[i * 3..i * 3 + 3]);
            out.extend_from_slice(&self.tex_coords[i * 2..i * 2 + 2]);
            out.extend_from_slice(&self.normals[i * 3..i * 3 + 3]);
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vertex_and_index_counts_match_formula() {
        let m = SphereMesh::generate(1.0, 8, 16);
        assert_eq!(m.vertex_count(), (8 + 1) * (16 + 1));
        assert_eq!(m.indices.len(), 8 * 16 * 6);
        assert_eq!(m.tex_coords.len(), m.vertex_count() * 2);
    }

    #[test]
    fn all_vertices_on_sphere() {
        let m = SphereMesh::generate(2.5, 16, 32);
        for c in m.vertices.chunks(3) {
            let r = (c[0] * c[0] + c[1] * c[1] + c[2] * c[2]).sqrt();
            assert!((r - 2.5).abs() < 1e-4, "r = {r}");
        }
    }

    #[test]
    fn normals_are_unit_length() {
        let m = SphereMesh::generate(1.0, 8, 8);
        for c in m.normals.chunks(3) {
            let r = (c[0] * c[0] + c[1] * c[1] + c[2] * c[2]).sqrt();
            assert!((r - 1.0).abs() < 1e-4, "|n| = {r}");
        }
    }

    #[test]
    fn uv_range_is_zero_to_one() {
        let m = SphereMesh::generate(1.0, 8, 8);
        assert!(m.tex_coords.iter().all(|v| (-1e-5..=1.0 + 1e-5).contains(v)));
    }

    #[test]
    fn indices_are_in_bounds() {
        let m = SphereMesh::generate(1.0, 6, 6);
        let max = m.vertex_count() as u32;
        assert!(m.indices.iter().all(|i| *i < max));
    }

    #[test]
    fn interleaved_has_eight_floats_per_vertex() {
        let m = SphereMesh::generate(1.0, 4, 4);
        assert_eq!(m.interleaved().len(), m.vertex_count() * 8);
    }

    #[test]
    fn poles_are_at_expected_positions() {
        let m = SphereMesh::generate(1.0, 4, 4);
        // Erster Vertex: lat = +90 -> Nordpol -> y = +1
        assert!((m.vertices[1] - 1.0).abs() < 1e-5);
        // Letzter Vertex: lat = -90 -> Südpol -> y = -1
        let last = m.vertices.len() - 3;
        assert!((m.vertices[last + 1] + 1.0).abs() < 1e-5);
    }
}
