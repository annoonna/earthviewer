//! `ev-render` — OpenGL-Rendering des Globus.
//! Port von `src/rendering/` (PyOpenGL → glow).
pub mod geometry;
pub mod gl_util;
pub mod globe;
pub mod scene;
pub mod shaders;
pub mod tiles;
pub mod tile_layer;

pub use globe::GlobeRenderer;
pub use scene::{LineBatch, MarkerBatch, Scene};
