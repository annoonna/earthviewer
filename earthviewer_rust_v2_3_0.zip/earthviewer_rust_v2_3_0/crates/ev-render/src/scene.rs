//! Was gezeichnet werden soll — reine Daten, kein GL.
//! Damit ist die Szene ohne GPU testbar (das ging in PyQt6 nicht).
use ev_core::GeoLocation;
use glam::Vec3;

#[derive(Clone, Debug)]
pub struct MarkerBatch {
    pub points: Vec<Vec3>,
    pub color: [f32; 3],
    pub size: f32,
}

#[derive(Clone, Debug)]
pub struct LineBatch {
    pub points: Vec<Vec3>,
    pub color: [f32; 3],
    pub alpha: f32,
    pub width: f32,
}

/// Texturierte Punkt-Sprites (Satelliten-Symbole).
#[derive(Clone, Debug)]
pub struct SpriteBatch {
    pub points: Vec<Vec3>,
    pub size: f32,
    /// RGBA-Einfaerbung; die Kategoriefarbe kommt hier hinein.
    pub tint: [f32; 4],
}

#[derive(Clone, Debug, Default)]
pub struct Scene {
    pub markers: Vec<MarkerBatch>,
    pub lines: Vec<LineBatch>,
    pub sprites: Vec<SpriteBatch>,
    pub background: [f32; 3],
}

impl Scene {
    pub fn clear(&mut self) {
        self.markers.clear();
        self.lines.clear();
        self.sprites.clear();
    }

    pub fn add_sprites(&mut self, points: Vec<Vec3>, size: f32, tint: [f32; 4]) {
        if points.is_empty() { return; }
        self.sprites.push(SpriteBatch { points, size, tint });
    }

    pub fn add_markers(&mut self, locs: &[GeoLocation], radius: f32, color: [f32; 3], size: f32) {
        if locs.is_empty() { return; }
        self.markers.push(MarkerBatch {
            points: locs.iter().map(|l| l.to_cartesian(radius)).collect(),
            color, size,
        });
    }

    pub fn add_line(&mut self, points: Vec<Vec3>, color: [f32; 3], alpha: f32, width: f32) {
        if points.len() < 2 { return; }
        self.lines.push(LineBatch { points, color, alpha, width });
    }

    /// Great-Circle-Bogen zwischen zwei Orten — Port von `_create_arc_points`.
    pub fn add_arc(
        &mut self,
        start: &GeoLocation,
        end: &GeoLocation,
        color: [f32; 3],
        alpha: f32,
    ) {
        let base_radius = ev_core::config::SPHERE_RADIUS
            + ev_core::config::MARKER_OFFSET * 1.5;
        let pts = ev_core::math::great_circle_arc(
            start.to_cartesian(base_radius),
            end.to_cartesian(base_radius),
            72,
            0.18,
        );
        self.add_line(pts, color, alpha, 1.5);
    }

    /// Sichtbarkeitskreis eines Satelliten auf der Erdoberfläche.
    /// 📌 Gpredict-Issue #94: Nutzer wollen den Fußabdruck sehen, nicht nur
    /// den Punkt. Halbwinkel = acos(R / (R + h)).
    pub fn add_footprint(&mut self, sat: Vec3, altitude_km: f64, color: [f32; 3]) {
        const R: f64 = 6371.0;
        if altitude_km <= 0.0 { return; }
        let half_angle = (R / (R + altitude_km)).clamp(-1.0, 1.0).acos() as f32;
        let n = sat.normalize_or_zero();
        if n.length_squared() < 0.5 { return; }
        // Zwei zu n senkrechte Einheitsvektoren aufspannen.
        let helper = if n.y.abs() < 0.9 { Vec3::Y } else { Vec3::X };
        let u = n.cross(helper).normalize();
        let v = n.cross(u);
        let r = 1.005_f32;
        let pts: Vec<Vec3> = (0..=64)
            .map(|i| {
                let a = i as f32 / 64.0 * std::f32::consts::TAU;
                let dir = u * a.cos() + v * a.sin();
                (n * half_angle.cos() + dir * half_angle.sin()) * r
            })
            .collect();
        self.add_line(pts, color, 0.45, 1.0);
    }

    /// Pfeilspitze entlang der Bahn — zeigt die Flugrichtung.
    /// 📌 Ebenfalls Gpredict-Issue #94.
    pub fn add_direction_arrow(&mut self, pos: Vec3, dir: Vec3, color: [f32; 3]) {
        if dir.length_squared() < 1e-12 { return; }
        let d = dir.normalize();
        let n = pos.normalize_or_zero();
        let side = d.cross(n).normalize_or_zero() * dir.length() * 0.35;
        let tip = pos + d * dir.length();
        let base = pos + d * dir.length() * 0.45;
        self.add_line(vec![pos, tip], color, 0.9, 1.5);
        self.add_line(vec![base + side, tip, base - side], color, 0.9, 1.5);
    }

    pub fn total_vertices(&self) -> usize {
        self.markers.iter().map(|m| m.points.len()).sum::<usize>()
            + self.lines.iter().map(|l| l.points.len()).sum::<usize>()
            + self.sprites.iter().map(|s| s.points.len()).sum::<usize>()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn leipzig() -> GeoLocation { GeoLocation::new("Leipzig", 51.34, 12.38) }
    fn sydney() -> GeoLocation { GeoLocation::new("Sydney", -33.87, 151.21) }

    #[test]
    fn markers_land_on_the_marker_radius() {
        let mut s = Scene::default();
        s.add_markers(&[leipzig()], 1.02, [1.0, 0.0, 0.0], 12.0);
        assert_eq!(s.markers.len(), 1);
        assert!((s.markers[0].points[0].length() - 1.02).abs() < 1e-5);
    }

    #[test]
    fn empty_marker_list_adds_no_batch() {
        let mut s = Scene::default();
        s.add_markers(&[], 1.0, [1.0; 3], 8.0);
        assert!(s.markers.is_empty());
    }

    #[test]
    fn single_point_is_not_a_line() {
        let mut s = Scene::default();
        s.add_line(vec![Vec3::X], [1.0; 3], 1.0, 1.0);
        assert!(s.lines.is_empty());
    }

    #[test]
    fn arc_has_73_points_and_is_lifted() {
        let mut s = Scene::default();
        s.add_arc(&leipzig(), &sydney(), [0.3, 0.65, 1.0], 0.8);
        assert_eq!(s.lines.len(), 1);
        assert_eq!(s.lines[0].points.len(), 73);
        let mid = s.lines[0].points[36].length();
        let end = s.lines[0].points[0].length();
        assert!(mid > end, "Bogen muss sich abheben: {mid} vs {end}");
    }

    #[test]
    fn footprint_is_a_closed_ring_above_surface() {
        let mut s = Scene::default();
        s.add_footprint(Vec3::new(0.0, 1.07, 0.0), 420.0, [1.0; 3]);
        assert_eq!(s.lines.len(), 1);
        let pts = &s.lines[0].points;
        assert_eq!(pts.len(), 65);
        assert!((pts[0] - pts[64]).length() < 1e-4, "Ring muss geschlossen sein");
        for p in pts { assert!((p.length() - 1.005).abs() < 1e-4); }
    }

    #[test]
    fn higher_orbit_gives_bigger_footprint() {
        let mut lo = Scene::default();
        let mut hi = Scene::default();
        lo.add_footprint(Vec3::Y * 1.07, 420.0, [1.0; 3]);
        hi.add_footprint(Vec3::Y * 4.6, 23000.0, [1.0; 3]);
        // Radius des Rings in der Ebene senkrecht zu Y
        let r = |s: &Scene| s.lines[0].points[0].x.hypot(s.lines[0].points[0].z);
        assert!(r(&hi) > r(&lo), "GEO-Fußabdruck muss größer sein als LEO");
    }

    #[test]
    fn zero_altitude_has_no_footprint() {
        let mut s = Scene::default();
        s.add_footprint(Vec3::Y, 0.0, [1.0; 3]);
        assert!(s.lines.is_empty());
    }

    #[test]
    fn direction_arrow_has_shaft_and_head() {
        let mut s = Scene::default();
        s.add_direction_arrow(Vec3::Z * 1.1, Vec3::X * 0.2, [1.0; 3]);
        assert_eq!(s.lines.len(), 2, "Schaft + Spitze");
        assert_eq!(s.lines[1].points.len(), 3);
    }

    #[test]
    fn zero_direction_draws_nothing() {
        let mut s = Scene::default();
        s.add_direction_arrow(Vec3::Z, Vec3::ZERO, [1.0; 3]);
        assert!(s.lines.is_empty());
    }

    #[test]
    fn sprites_are_counted_and_cleared() {
        let mut s = Scene::default();
        s.add_sprites(vec![Vec3::X, Vec3::Y], 32.0, [1.0; 4]);
        assert_eq!(s.sprites.len(), 1);
        assert_eq!(s.total_vertices(), 2);
        s.clear();
        assert!(s.sprites.is_empty());
    }

    #[test]
    fn empty_sprite_batch_is_dropped() {
        let mut s = Scene::default();
        s.add_sprites(vec![], 32.0, [1.0; 4]);
        assert!(s.sprites.is_empty());
    }

    #[test]
    fn clear_resets_everything() {
        let mut s = Scene::default();
        s.add_markers(&[leipzig()], 1.0, [1.0; 3], 8.0);
        s.add_arc(&leipzig(), &sydney(), [1.0; 3], 1.0);
        assert!(s.total_vertices() > 0);
        s.clear();
        assert_eq!(s.total_vertices(), 0);
    }
}
