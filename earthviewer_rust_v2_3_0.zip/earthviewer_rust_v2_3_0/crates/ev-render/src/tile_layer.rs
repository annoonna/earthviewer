//! GL-Kachel-Ebene (Runde D, Teil 2) — zeichnet Karten-Kacheln als gekrümmte
//! Quad-Patches auf die Kugeloberfläche, über die Basistextur.
//!
//! Jede Kachel wird zu einem eigenen kleinen VAO (Patch-Netz aus
//! `tiles::patch_mesh`) plus einer GL-Textur aus dem heruntergeladenen Bild.
//! Gezeichnet wird mit demselben Vertexlayout wie die Erde (pos/uv/normal), also
//! mit dem Erd-Shader. Die Patches liegen minimal über der Kugel (radius 1.002),
//! damit sie die Basistextur überdecken ohne Z-Fighting.
//!
//! Der Renderer kennt kein Netz — er bekommt fertige Bild-Bytes gereicht
//! (vom `tileloader` in ev-app) und lädt sie als Textur hoch.

use crate::gl_util::{self, Program};
use crate::tiles::{self, TileId};
use glam::Mat4;
use std::collections::HashMap;

/// Radius, auf dem die Kacheln liegen — knapp über der Basiskugel (1.0).
const TILE_RADIUS: f32 = 1.002;
/// Unterteilung je Kachel. 8×8 schmiegt sich gut an, bleibt aber leicht.
const TILE_SEGMENTS: u32 = 8;

struct GpuTile {
    vao: glow::VertexArray,
    vbo: glow::Buffer,
    ebo: glow::Buffer,
    tex: glow::Texture,
    index_count: i32,
}

/// Verwaltet hochgeladene Kacheln und zeichnet sie.
pub struct TileLayer {
    tiles: HashMap<TileId, GpuTile>,
    /// Welche Kacheln in diesem Frame sichtbar sein sollen (vom Aufrufer gesetzt).
    aktiv: Vec<TileId>,
    pub sichtbar: bool,
}

impl Default for TileLayer {
    fn default() -> Self {
        Self { tiles: HashMap::new(), aktiv: Vec::new(), sichtbar: false }
    }
}

impl TileLayer {
    pub fn new() -> Self {
        Self::default()
    }

    /// Ist diese Kachel schon auf der GPU?
    pub fn hat(&self, id: TileId) -> bool {
        self.tiles.contains_key(&id)
    }

    /// Setzt, welche Kacheln aktuell gezeichnet werden sollen.
    pub fn setze_aktiv(&mut self, ids: Vec<TileId>) {
        self.aktiv = ids;
    }

    /// Lädt ein dekodiertes RGBA-Bild als Kachel-Textur hoch und legt das
    /// Patch-Netz an. `w`/`h` sind Bildmaße. Idempotent (überschreibt).
    pub fn upload_rgba(
        &mut self,
        gl: &glow::Context,
        id: TileId,
        w: u32,
        h: u32,
        rgba: &[u8],
    ) {
        // Alte Version freigeben, falls vorhanden.
        self.entferne(gl, id);

        let (verts, indices) = tiles::patch_mesh(id, TILE_SEGMENTS, TILE_RADIUS);
        // Interleaved [pos.xyz, uv.xy, normal.xyz] — wie die Basiskugel.
        let mut inter = Vec::with_capacity(verts.len() * 8);
        for v in &verts {
            inter.extend_from_slice(&v.pos);
            inter.extend_from_slice(&v.uv);
            inter.extend_from_slice(&v.normal);
        }
        match gl_util::kugel_puffer_anlegen(gl, &inter, &indices) {
            Ok((vao, vbo, ebo)) => {
                match gl_util::upload_rgba(gl, w, h, rgba) {
                    Ok(tex) => {
                        self.tiles.insert(id, GpuTile {
                            vao, vbo, ebo, tex, index_count: indices.len() as i32,
                        });
                    }
                    Err(e) => eprintln!("⚠️  Kachel-Textur {id:?}: {e}"),
                }
            }
            Err(e) => eprintln!("⚠️  Kachel-Puffer {id:?}: {e}"),
        }
    }

    fn entferne(&mut self, gl: &glow::Context, id: TileId) {
        if let Some(t) = self.tiles.remove(&id) {
            gl_util::puffer_freigeben(gl, t.vao, t.vbo, t.ebo);
            gl_util::textur_freigeben(gl, t.tex);
        }
    }

    /// Gibt Kacheln frei, die nicht mehr aktiv sind — hält den Speicher im Zaum.
    /// `behalten` = zusätzlich zu den aktiven zu behaltende (z. B. Nachbarn).
    pub fn raeume_auf(&mut self, gl: &glow::Context, max: usize) {
        if self.tiles.len() <= max {
            return;
        }
        let aktiv: std::collections::HashSet<TileId> = self.aktiv.iter().copied().collect();
        let zu_entfernen: Vec<TileId> = self
            .tiles
            .keys()
            .copied()
            .filter(|id| !aktiv.contains(id))
            .collect();
        for id in zu_entfernen {
            if self.tiles.len() <= max {
                break;
            }
            self.entferne(gl, id);
        }
    }

    /// Zeichnet alle aktiven, bereits hochgeladenen Kacheln mit dem Erd-Shader.
    pub fn render(
        &self,
        gl: &glow::Context,
        earth: &Program,
        mvp: Mat4,
        model: Mat4,
        light_pos: [f32; 3],
    ) {
        if !self.sichtbar || self.aktiv.is_empty() {
            return;
        }
        earth.use_it(gl);
        earth.set_mat4(gl, "mvp", &mvp);
        earth.set_mat4(gl, "model", &model);
        earth.set_vec3(gl, "lightPos", light_pos);
        earth.set_i32(gl, "earthTexture", 0);
        for id in &self.aktiv {
            if let Some(t) = self.tiles.get(id) {
                gl_util::textur_binden(gl, 0, Some(t.tex));
                gl_util::dreiecke_zeichnen(gl, t.vao, t.index_count);
            }
        }
    }

    pub fn destroy(&mut self, gl: &glow::Context) {
        let ids: Vec<TileId> = self.tiles.keys().copied().collect();
        for id in ids {
            self.entferne(gl, id);
        }
    }
}
