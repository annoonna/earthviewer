//! Kachel-Mathematik für die zuschaltbare Karten-Ebene (Runde D, Teil 2).
//!
//! Grundlage sind „Slippy Map"-Kacheln (das Schema von OpenStreetMap und
//! NASA GIBS im GoogleMapsCompatible-Raster): Die Welt ist in Web-Mercator
//! projiziert und in ein Gitter aus 256×256-Kacheln zerlegt. Zoomstufe z hat
//! 2^z × 2^z Kacheln. Kachel (x, y) bei Zoom z deckt einen festen Längen-/
//! Breitenbereich ab.
//!
//! Dieses Modul ist **reine Rechnung** — kein GL, kein Netz — und damit voll
//! testbar. Das eigentliche Laden (HTTP) und Zeichnen (GL) baut darauf auf.
//!
//! Wichtig für unsere Kugel: OSM/GIBS liefern *flache* Mercator-Kacheln. Um sie
//! auf die Kugel zu legen, brauchen wir für jede Kachel die geografischen
//! Eckpunkte (lat/lon) und daraus die Kugelkoordinaten. Web-Mercator kappt bei
//! ±85.0511° — Pole sind nicht abgedeckt (dort bleibt die Basistextur sichtbar).

/// Maximale Web-Mercator-Breite (Grad). Jenseits davon gibt es keine Kacheln.
pub const MERCATOR_MAX_LAT: f64 = 85.05112878;

/// Eine Kachel-Adresse im Slippy-Schema.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct TileId {
    pub z: u8,
    pub x: u32,
    pub y: u32,
}

impl TileId {
    pub fn new(z: u8, x: u32, y: u32) -> Self {
        Self { z, x, y }
    }

    /// Anzahl Kacheln je Achse auf dieser Zoomstufe (2^z).
    pub fn n(z: u8) -> u32 {
        1u32 << z
    }

    /// Geografische Grenzen dieser Kachel: (lat_nord, lat_süd, lon_west, lon_ost).
    pub fn bounds(&self) -> (f64, f64, f64, f64) {
        let n = Self::n(self.z) as f64;
        let lon_w = self.x as f64 / n * 360.0 - 180.0;
        let lon_e = (self.x as f64 + 1.0) / n * 360.0 - 180.0;
        let lat_n = lat_von_y(self.y as f64, n);
        let lat_s = lat_von_y(self.y as f64 + 1.0, n);
        (lat_n, lat_s, lon_w, lon_e)
    }
}

/// Umrechnung Kachel-Y → Breitengrad (Web-Mercator, invers).
fn lat_von_y(y: f64, n: f64) -> f64 {
    let m = std::f64::consts::PI * (1.0 - 2.0 * y / n);
    m.sinh().atan().to_degrees()
}

/// lon/lat → Kachel-Koordinaten (als Fließkomma, damit man auch die Position
/// innerhalb der Kachel kennt) auf Zoomstufe z.
pub fn lonlat_zu_tile(lon: f64, lat: f64, z: u8) -> (f64, f64) {
    let n = TileId::n(z) as f64;
    let lat = lat.clamp(-MERCATOR_MAX_LAT, MERCATOR_MAX_LAT);
    let x = (lon + 180.0) / 360.0 * n;
    let lat_rad = lat.to_radians();
    let y = (1.0 - (lat_rad.tan() + 1.0 / lat_rad.cos()).ln() / std::f64::consts::PI)
        / 2.0 * n;
    (x, y)
}

/// Wählt die passende Zoomstufe zur Kamera-Entfernung. Nah an der Oberfläche
/// (kleine `distance`, Erdradien) höhere Stufe. Grob kalibriert an unserem
/// Kamerabereich (1.02 nah … 25 fern). Deckelt bei `max_z`.
pub fn zoomstufe(distance: f32, max_z: u8) -> u8 {
    // Heuristik: Höhe über der Oberfläche in Erdradien.
    let hoehe = (distance - 1.0).max(0.001);
    // Je kleiner die Höhe, desto höher die Stufe. Logarithmisch.
    let z = (2.0 - hoehe.log2()) as i32 + 2;
    z.clamp(0, max_z as i32) as u8
}

/// Liefert die sichtbaren Kacheln um einen Mittelpunkt (lon/lat) auf Stufe z,
/// mit `radius` Kacheln in jede Richtung (begrenzt die Anzahl fürs Nachladen).
/// Y wird geklemmt, X umläuft die Datumsgrenze (Modulo).
pub fn sichtbare_tiles(lon: f64, lat: f64, z: u8, radius: i32) -> Vec<TileId> {
    let (fx, fy) = lonlat_zu_tile(lon, lat, z);
    let (cx, cy) = (fx.floor() as i32, fy.floor() as i32);
    let n = TileId::n(z) as i32;
    let mut out = Vec::new();
    for dy in -radius..=radius {
        let ty = cy + dy;
        if ty < 0 || ty >= n {
            continue; // Y nicht umlaufend (Pole)
        }
        for dx in -radius..=radius {
            let tx = (cx + dx).rem_euclid(n); // X umläuft die Erde
            out.push(TileId::new(z, tx as u32, ty as u32));
        }
    }
    out
}

/// Baut die Kachel-URL für einen Anbieter. `{z}/{x}/{y}` eingesetzt.
/// Beispiele:
///   OSM:  https://tile.openstreetmap.org/{z}/{x}/{y}.png
///   GIBS: https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/
///         BlueMarble_ShadedRelief/default/GoogleMapsCompatible_Level8/{z}/{y}/{x}.jpg
/// (Achtung: GIBS nutzt {z}/{y}/{x}-Reihenfolge!)
pub fn url(vorlage: &str, t: TileId) -> String {
    vorlage
        .replace("{z}", &t.z.to_string())
        .replace("{x}", &t.x.to_string())
        .replace("{y}", &t.y.to_string())
}

/// Ein Vertex des Kachel-Netzes auf der Kugel: Position (x,y,z), Textur-UV,
/// Normale (= Position, da Einheitskugel).
#[derive(Clone, Copy, Debug)]
pub struct PatchVertex {
    pub pos: [f32; 3],
    pub uv: [f32; 2],
    pub normal: [f32; 3],
}

/// Erzeugt ein gekrümmtes Quad-Netz für eine Kachel auf der Kugeloberfläche.
/// Die Kachel deckt einen lat/lon-Bereich ab; wir unterteilen sie in `seg`×`seg`
/// Felder, damit sie sich sauber an die Kugel schmiegt (ein flaches Quad würde
/// bei großen Kacheln durch die Kugel schneiden). `radius` skaliert leicht über
/// die Basiskugel (1.001), damit die Kachel knapp darüber liegt und nicht
/// z-fightet. Gibt (Vertices, Indices) zurück.
pub fn patch_mesh(t: TileId, seg: u32, radius: f32) -> (Vec<PatchVertex>, Vec<u32>) {
    let (lat_n, lat_s, lon_w, lon_e) = t.bounds();
    let seg = seg.max(1);
    let mut verts = Vec::with_capacity(((seg + 1) * (seg + 1)) as usize);
    for iy in 0..=seg {
        let fy = iy as f64 / seg as f64;
        let lat = lat_n + (lat_s - lat_n) * fy; // oben(N) → unten(S)
        for ix in 0..=seg {
            let fx = ix as f64 / seg as f64;
            let lon = lon_w + (lon_e - lon_w) * fx;
            let (x, y, z) = lonlat_zu_kugel(lon, lat, radius as f64);
            // UV: Textur läuft von oben-links (0,0) nach unten-rechts (1,1).
            verts.push(PatchVertex {
                pos: [x as f32, y as f32, z as f32],
                uv: [fx as f32, fy as f32],
                normal: [x as f32, y as f32, z as f32],
            });
        }
    }
    let mut idx = Vec::with_capacity((seg * seg * 6) as usize);
    let stride = seg + 1;
    for iy in 0..seg {
        for ix in 0..seg {
            let a = iy * stride + ix;
            let b = a + 1;
            let c = a + stride;
            let d = c + 1;
            idx.extend_from_slice(&[a, c, b, b, c, d]);
        }
    }
    (verts, idx)
}

/// lon/lat (Grad) → Punkt auf einer Kugel mit gegebenem Radius. Nutzt exakt die
/// Parametrisierung der Basiskugel (`geometry::SphereMesh::generate`):
/// x = r·cos(lat)·sin(lon), y = r·sin(lat), z = r·cos(lat)·cos(lon). Sonst lägen
/// die Kacheln um 90° verdreht auf der Kugel.
pub fn lonlat_zu_kugel(lon: f64, lat: f64, radius: f64) -> (f64, f64, f64) {
    let lat_r = lat.to_radians();
    let lon_r = lon.to_radians();
    let x = radius * lat_r.cos() * lon_r.sin();
    let y = radius * lat_r.sin();
    let z = radius * lat_r.cos() * lon_r.cos();
    (x, y, z)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tile_null_deckt_ganze_welt() {
        let (n, s, w, e) = TileId::new(0, 0, 0).bounds();
        assert!((w - -180.0).abs() < 1e-6);
        assert!((e - 180.0).abs() < 1e-6);
        assert!((n - MERCATOR_MAX_LAT).abs() < 1e-4);
        assert!((s + MERCATOR_MAX_LAT).abs() < 1e-4);
    }

    #[test]
    fn lonlat_und_zurueck_ist_konsistent() {
        // Leipzig auf Zoom 8.
        let (x, y) = lonlat_zu_tile(12.37, 51.34, 8);
        let t = TileId::new(8, x.floor() as u32, y.floor() as u32);
        let (n, s, w, e) = t.bounds();
        assert!(51.34 <= n && 51.34 >= s, "lat {n}..{s}");
        assert!(12.37 >= w && 12.37 <= e, "lon {w}..{e}");
    }

    #[test]
    fn zoomstufe_steigt_bei_annaeherung() {
        let nah = zoomstufe(1.05, 12);
        let fern = zoomstufe(20.0, 12);
        assert!(nah > fern, "nah {nah} muss > fern {fern} sein");
        assert!(nah <= 12 && fern >= 0);
    }

    #[test]
    fn sichtbare_tiles_umlaufen_x_aber_nicht_y() {
        // Nahe der Datumsgrenze: X muss modulo umlaufen.
        let tiles = sichtbare_tiles(179.9, 0.0, 4, 1);
        assert!(!tiles.is_empty());
        let n = TileId::n(4);
        assert!(tiles.iter().all(|t| t.x < n && t.y < n));
        // Am Pol darf Y nicht über den Rand.
        let polar = sichtbare_tiles(0.0, 85.0, 4, 2);
        assert!(polar.iter().all(|t| t.y < n));
    }

    #[test]
    fn url_ersetzt_platzhalter() {
        let u = url("https://tile.osm.org/{z}/{x}/{y}.png", TileId::new(5, 17, 10));
        assert_eq!(u, "https://tile.osm.org/5/17/10.png");
        // GIBS-Reihenfolge z/y/x:
        let g = url("https://gibs/{z}/{y}/{x}.jpg", TileId::new(3, 4, 6));
        assert_eq!(g, "https://gibs/3/6/4.jpg");
    }

    #[test]
    fn anzahl_tiles_pro_stufe() {
        assert_eq!(TileId::n(0), 1);
        assert_eq!(TileId::n(1), 4 / 2); // 2 pro Achse
        assert_eq!(TileId::n(8), 256);
    }

    #[test]
    fn patch_mesh_hat_richtige_groesse() {
        let (v, i) = patch_mesh(TileId::new(3, 4, 3), 4, 1.001);
        assert_eq!(v.len(), 25); // (4+1)^2
        assert_eq!(i.len(), 4 * 4 * 6); // seg^2 * 6
        // Alle Vertices liegen ~auf der Kugel mit radius 1.001.
        for pv in &v {
            let r = (pv.pos[0].powi(2) + pv.pos[1].powi(2) + pv.pos[2].powi(2)).sqrt();
            assert!((r - 1.001).abs() < 1e-3, "radius {r}");
        }
    }

    #[test]
    fn patch_uv_deckt_null_bis_eins() {
        let (v, _) = patch_mesh(TileId::new(2, 1, 1), 2, 1.001);
        let us: Vec<f32> = v.iter().map(|p| p.uv[0]).collect();
        assert!(us.contains(&0.0) && us.contains(&1.0));
    }

    #[test]
    fn kugelpunkt_passt_zur_basis_parametrisierung() {
        // lon=0, lat=0 → vorne auf +Z (wie Basiskugel: cos·cos).
        let (x, y, z) = lonlat_zu_kugel(0.0, 0.0, 1.0);
        assert!(x.abs() < 1e-9 && y.abs() < 1e-9 && (z - 1.0).abs() < 1e-9,
                "({x},{y},{z})");
        // Nordpol.
        let (_, y2, _) = lonlat_zu_kugel(0.0, 90.0, 1.0);
        assert!((y2 - 1.0).abs() < 1e-9);
    }
}
