//! Eingebaute TLE-Notreserve — Port von `OFFLINE_TLES` aus
//! `satellite_tracker_engine.py`, plus Alterswarnung.
//!
//! 📌 Gpredict-Issue #4 („Improve TLE data management") beschreibt genau die
//! Falle: mitgelieferte TLE veralten binnen Wochen, und der Nutzer merkt es
//! nicht. Deshalb liefert `age_days()` das Alter aus der TLE-Epoche selbst,
//! und die Oberfläche warnt ab 14 Tagen. Mitgelieferte Elemente sind
//! ausdrücklich nur eine Notreserve, damit ohne Internet überhaupt etwas
//! zu sehen ist — nicht die primäre Quelle.

use crate::catalog::{parse_3le, Tle};

/// Handverlesene, langlebige Objekte. Epoche 2024-001, bewusst wenige.
pub const OFFLINE_TLES: &str = "\
ISS (ZARYA)
1 25544U 98067A   24001.50000000  .00016717  00000-0  30777-3 0  9991
2 25544  51.6416 247.4627 0006703 130.5360 325.0288 15.49514023432811
HUBBLE SPACE TELESCOPE
1 20580U 90037B   24001.50000000  .00002085  00000-0  10982-3 0  9994
2 20580  28.4700 288.8102 0002481 293.9245 156.7100 15.09802285 47108
NOAA 19
1 33591U 09005A   24001.50000000  .00000180  00000-0  12080-3 0  9990
2 33591  99.1889 306.7156 0013634 172.8442 187.2884 14.12694704767804
TERRA
1 25994U 99068A   24001.50000000  .00000268  00000-0  63337-4 0  9995
2 25994  98.1478  10.9614 0001167  95.1385 264.9928 14.57116999275955
AQUA
1 27424U 02022A   24001.50000000  .00000885  00000-0  19604-3 0  9991
2 27424  98.2853  59.5236 0001067  90.9127 269.2168 14.58085075162194
";

/// TLE der Notreserve.
pub fn builtin() -> Vec<Tle> {
    crate::catalog::stamp_group(parse_3le(OFFLINE_TLES), "Notreserve")
}

/// Epoche einer TLE-Zeile 1 als (Jahr, Tag-des-Jahres).
/// Spalten 19–32 im NORAD-Format: `YYDDD.DDDDDDDD`.
pub fn epoch(line1: &str) -> Option<(i32, f64)> {
    let raw = line1.get(18..32)?.trim();
    if raw.len() < 5 { return None; }
    let yy: i32 = raw.get(..2)?.parse().ok()?;
    let doy: f64 = raw.get(2..)?.parse().ok()?;
    // NORAD-Konvention: 57..99 => 19xx, 00..56 => 20xx
    let year = if yy < 57 { 2000 + yy } else { 1900 + yy };
    Some((year, doy))
}

/// Alter der TLE in Tagen, bezogen auf `now`.
pub fn age_days(line1: &str, now: &chrono::NaiveDateTime) -> Option<f64> {
    let (year, doy) = epoch(line1)?;
    let jan1 = chrono::NaiveDate::from_ymd_opt(year, 1, 1)?.and_hms_opt(0, 0, 0)?;
    let epoch_dt = jan1 + chrono::Duration::milliseconds(((doy - 1.0) * 86_400_000.0) as i64);
    Some((*now - epoch_dt).num_seconds() as f64 / 86_400.0)
}

/// Wie eine Alterseinstufung in der Oberfläche aussieht.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Freshness { Fresh, Aging, Stale }

impl Freshness {
    pub fn of(age_days: f64) -> Self {
        if age_days < 3.0 { Self::Fresh }
        else if age_days < 14.0 { Self::Aging }
        else { Self::Stale }
    }
    pub fn label(&self) -> &'static str {
        match self {
            Self::Fresh => "aktuell",
            Self::Aging => "wird älter",
            Self::Stale => "veraltet — bitte neu laden",
        }
    }
    pub fn rgb(&self) -> [u8; 3] {
        match self {
            Self::Fresh => [120, 220, 140],
            Self::Aging => [230, 210, 90],
            Self::Stale => [255, 110, 90],
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn at(y: i32, m: u32, d: u32) -> chrono::NaiveDateTime {
        NaiveDate::from_ymd_opt(y, m, d).unwrap().and_hms_opt(12, 0, 0).unwrap()
    }

    #[test]
    fn builtin_tles_parse() {
        let t = builtin();
        assert_eq!(t.len(), 5, "Notreserve muss 5 Objekte haben");
        assert!(t.iter().any(|x| x.norad_id == 25544), "ISS fehlt");
    }

    #[test]
    fn builtin_tles_are_propagatable() {
        // Der eigentliche Test: SGP4 muss sie annehmen (Prüfsummen inklusive).
        for tle in builtin() {
            let name = tle.name.clone();
            assert!(crate::Propagator::new(tle).is_ok(), "SGP4 lehnt {name} ab");
        }
    }

    #[test]
    fn epoch_is_parsed() {
        let l1 = "1 25544U 98067A   24001.50000000  .00016717  00000-0  30777-3 0  9992";
        let (y, d) = epoch(l1).unwrap();
        assert_eq!(y, 2024);
        assert!((d - 1.5).abs() < 1e-6);
    }

    #[test]
    fn epoch_handles_last_century() {
        let l1 = "1 20580U 90037B   98123.25000000  .00002085  00000-0  10982-3 0  9998";
        assert_eq!(epoch(l1).unwrap().0, 1998);
    }

    #[test]
    fn age_is_measured_in_days() {
        let l1 = "1 25544U 98067A   24001.50000000  .00016717  00000-0  30777-3 0  9992";
        let a = age_days(l1, &at(2024, 1, 11)).unwrap();
        assert!((a - 10.0).abs() < 0.1, "Alter = {a}");
    }

    #[test]
    fn freshness_thresholds() {
        assert_eq!(Freshness::of(1.0), Freshness::Fresh);
        assert_eq!(Freshness::of(7.0), Freshness::Aging);
        assert_eq!(Freshness::of(30.0), Freshness::Stale);
        assert!(Freshness::of(30.0).label().contains("veraltet"));
    }

    #[test]
    fn builtin_tles_are_reported_as_stale_today() {
        // Genau der Punkt aus Gpredict-Issue #4: mitgelieferte Daten sind alt.
        let t = builtin();
        let a = age_days(&t[0].line1, &at(2026, 8, 21)).unwrap();
        assert!(a > 900.0);
        assert_eq!(Freshness::of(a), Freshness::Stale);
    }

    #[test]
    fn garbage_returns_none() {
        assert!(epoch("nonsense").is_none());
        assert!(age_days("1 25544U 98067A   XXXXX", &at(2024, 1, 1)).is_none());
    }
}
