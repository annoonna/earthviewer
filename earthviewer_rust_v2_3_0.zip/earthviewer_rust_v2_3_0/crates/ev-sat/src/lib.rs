//! `ev-sat` — Satelliten-Tracking.
//! Port von `src/core/satellite_tracker_engine.py`, `src/data/satellite_manager.py`
//! und `src/utils/orbit_calculator.py`. skyfield → `sgp4`-Crate.
pub mod catalog;
pub mod frames;
pub mod offline;
pub mod propagate;
pub mod spektrum;

pub use catalog::{Category, Tle};
pub use offline::Freshness;
pub use frames::Frame;
pub use propagate::{OrbitTrack, Propagator, SatState};
