//! SGP4-Propagation — Port von `src/utils/orbit_calculator.py` (skyfield → sgp4-Crate).
use crate::catalog::{Category, Tle};
use crate::frames::{self, Frame};
use glam::Vec3;

#[derive(Clone, Debug)]
pub struct SatState {
    pub name: String,
    pub norad_id: u32,
    pub category: Category,
    /// Position in Globus-Koordinaten (Erdradien, Y = Nord).
    pub position: Vec3,
    /// Geschwindigkeit in km/s.
    pub speed_km_s: f64,
    pub altitude_km: f64,
    pub lat: f32,
    pub lon: f32,
}

#[derive(Clone, Debug)]
pub struct OrbitTrack {
    pub points: Vec<Vec3>,
    pub period_minutes: f64,
}

/// Ein propagierbarer Satellit (TLE + vorberechnete SGP4-Konstanten).
pub struct Propagator {
    pub tle: Tle,
    elements: sgp4::Elements,
    constants: sgp4::Constants,
}

impl Propagator {
    pub fn new(tle: Tle) -> anyhow::Result<Self> {
        let elements = sgp4::Elements::from_tle(
            Some(tle.name.clone()),
            tle.line1.as_bytes(),
            tle.line2.as_bytes(),
        )?;
        let constants = sgp4::Constants::from_elements(&elements)?;
        Ok(Self { tle, elements, constants })
    }

    /// Umlaufzeit in Minuten (aus der mittleren Bewegung im TLE).
    pub fn period_minutes(&self) -> f64 {
        let n = self.elements.mean_motion; // Umläufe/Tag
        if n > 0.0 { 1440.0 / n } else { 90.0 }
    }

    /// Zustand zum Zeitpunkt `when` (UTC).
    pub fn state_at(&self, when: &chrono::NaiveDateTime, frame: Frame) -> anyhow::Result<SatState> {
        let minutes = self.elements.minutes_since_epoch(when)?;
        let p = self.constants.propagate(minutes)?;
        let pos = self.frame_position(p.position, when, frame);
        let (lat, lon) = frames::ecef_to_latlon(frames::teme_to_ecef(
            p.position,
            frames::gmst_rad(frames::julian_date(when)),
        ));
        let v = p.velocity;
        Ok(SatState {
            name: self.tle.name.clone(),
            norad_id: self.tle.norad_id,
            category: self.tle.category,
            position: frames::ecef_to_globe(pos),
            speed_km_s: (v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).sqrt(),
            altitude_km: frames::altitude_km(p.position),
            lat, lon,
        })
    }

    fn frame_position(
        &self,
        teme: [f64; 3],
        when: &chrono::NaiveDateTime,
        frame: Frame,
    ) -> [f64; 3] {
        match frame {
            Frame::EarthFixed => {
                frames::teme_to_ecef(teme, frames::gmst_rad(frames::julian_date(when)))
            }
            // Original-Verhalten: TEME direkt als wären es Globus-Achsen.
            Frame::Inertial => teme,
        }
    }

    /// Bahnkurve über `span_minutes`, ab `start`. Port von `calculate_orbit_points`.
    pub fn orbit_track(
        &self,
        start: &chrono::NaiveDateTime,
        num_points: usize,
        span_minutes: f64,
        frame: Frame,
    ) -> anyhow::Result<OrbitTrack> {
        let base = self.elements.minutes_since_epoch(start)?;
        let mut points = Vec::with_capacity(num_points);
        for i in 0..num_points {
            let dt_min = i as f64 * span_minutes / num_points as f64;
            let p = self.constants.propagate(base + dt_min)?;
            let when = *start + chrono::Duration::milliseconds((dt_min * 60_000.0) as i64);
            points.push(frames::ecef_to_globe(self.frame_position(p.position, &when, frame)));
        }
        Ok(OrbitTrack { points, period_minutes: self.period_minutes() })
    }

    /// Bodenspur (Subsatellitenpunkt), leicht über der Oberfläche.
    /// Port von `calculate_ground_track` — mit korrigierter Achskonvention.
    pub fn ground_track(
        &self,
        start: &chrono::NaiveDateTime,
        num_points: usize,
        span_minutes: f64,
    ) -> anyhow::Result<Vec<Vec3>> {
        let base = self.elements.minutes_since_epoch(start)?;
        let mut pts = Vec::with_capacity(num_points);
        for i in 0..num_points {
            let dt_min = i as f64 * span_minutes / num_points as f64;
            let p = self.constants.propagate(base + dt_min)?;
            let when = *start + chrono::Duration::milliseconds((dt_min * 60_000.0) as i64);
            let ecef = frames::teme_to_ecef(p.position, frames::gmst_rad(frames::julian_date(&when)));
            let (lat, lon) = frames::ecef_to_latlon(ecef);
            let (la, lo) = (lat.to_radians(), lon.to_radians());
            pts.push(if ev_core::treue::korrigiert() {
                // Dieselbe Konvention wie GeoLocation::to_cartesian.
                Vec3::new(1.01 * la.cos() * lo.sin(), 1.01 * la.sin(), 1.01 * la.cos() * lo.cos())
            } else {
                // 1:1 wie calculate_ground_track: x=cos·cos, y=cos·sin, z=sin.
                // Passt nicht zur Kugel — genau das tat das Original.
                Vec3::new(1.01 * la.cos() * lo.cos(), 1.01 * la.cos() * lo.sin(), 1.01 * la.sin())
            });
        }
        Ok(pts)
    }

    /// Geschwindigkeitsvektor für den kleinen Pfeil am Satelliten.
    pub fn velocity_arrow(
        &self,
        when: &chrono::NaiveDateTime,
        frame: Frame,
        length: f32,
    ) -> anyhow::Result<(Vec3, Vec3)> {
        let minutes = self.elements.minutes_since_epoch(when)?;
        let a = self.constants.propagate(minutes)?;
        let b = self.constants.propagate(minutes + 0.5)?;
        let later = *when + chrono::Duration::seconds(30);
        let pa = frames::ecef_to_globe(self.frame_position(a.position, when, frame));
        let pb = frames::ecef_to_globe(self.frame_position(b.position, &later, frame));
        let dir = (pb - pa).normalize_or_zero() * length;
        Ok((pa, dir))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::catalog::parse_3le;
    use chrono::NaiveDate;

    const ISS: &str = "ISS (ZARYA)\n\
1 25544U 98067A   24001.50000000  .00016717  00000-0  30777-3 0  9991\n\
2 25544  51.6416 247.4627 0006703 130.5360 325.0288 15.49514023432811\n";

    fn prop() -> Propagator {
        Propagator::new(parse_3le(ISS).remove(0)).expect("TLE muss parsen")
    }

    fn when() -> chrono::NaiveDateTime {
        NaiveDate::from_ymd_opt(2024, 1, 1).unwrap().and_hms_opt(12, 0, 0).unwrap()
    }

    #[test]
    fn iss_period_is_about_92_minutes() {
        let p = prop().period_minutes();
        assert!((88.0..96.0).contains(&p), "period = {p}");
    }

    #[test]
    fn iss_altitude_is_leo() {
        let s = prop().state_at(&when(), Frame::EarthFixed).unwrap();
        assert!((300.0..500.0).contains(&s.altitude_km), "alt = {}", s.altitude_km);
    }

    #[test]
    fn iss_speed_is_about_7_7_km_s() {
        let s = prop().state_at(&when(), Frame::EarthFixed).unwrap();
        assert!((7.0..8.5).contains(&s.speed_km_s), "v = {}", s.speed_km_s);
    }

    #[test]
    fn iss_latitude_within_inclination() {
        let s = prop().state_at(&when(), Frame::EarthFixed).unwrap();
        assert!(s.lat.abs() <= 52.0, "lat = {}", s.lat);
        assert!((-180.0..=180.0).contains(&s.lon));
    }

    #[test]
    fn orbit_track_closes_after_one_period() {
        let p = prop();
        let t = p.orbit_track(&when(), 64, p.period_minutes(), Frame::Inertial).unwrap();
        assert_eq!(t.points.len(), 64);
        // Im inertialen System muss der Ring nach einem Umlauf wieder am Start sein.
        let d = (t.points[0] - t.points[63]).length();
        assert!(d < 0.15, "Bahn schließt sich nicht: {d}");
    }

    #[test]
    fn earthfixed_and_inertial_differ() {
        let p = prop();
        let a = p.state_at(&when(), Frame::EarthFixed).unwrap();
        let b = p.state_at(&when(), Frame::Inertial).unwrap();
        assert!((a.position - b.position).length() > 0.1,
                "Frames dürfen nicht identisch sein");
        // Aber der Radius bleibt gleich.
        assert!((a.position.length() - b.position.length()).abs() < 1e-4);
    }

    #[test]
    fn ground_track_lies_just_above_surface() {
        // Radius stimmt in beiden Betriebsarten; nur die Achsen unterscheiden sich.
        let pts = prop().ground_track(&when(), 32, 90.0).unwrap();
        assert_eq!(pts.len(), 32);
        for p in &pts {
            assert!((p.length() - 1.01).abs() < 1e-4, "r = {}", p.length());
        }
    }

    #[test]
    fn velocity_arrow_is_tangential() {
        let p = prop();
        let (pos, dir) = p.velocity_arrow(&when(), Frame::Inertial, 0.3).unwrap();
        assert!((dir.length() - 0.3).abs() < 1e-3);
        // Fast senkrecht zur Radialrichtung (Kreisbahn).
        let cos = pos.normalize().dot(dir.normalize()).abs();
        assert!(cos < 0.15, "nicht tangential: cos = {cos}");
    }

    #[test]
    fn rejects_broken_tle() {
        let bad = Tle { name: "X".into(), line1: "1 garbage".into(),
                        line2: "2 garbage".into(), category: Category::Unknown,
                        norad_id: 0, group: String::new() };
        assert!(Propagator::new(bad).is_err());
    }
}
