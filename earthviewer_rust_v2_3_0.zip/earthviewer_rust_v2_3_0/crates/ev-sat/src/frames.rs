//! Bezugssysteme & Zeit.
//!
//! 🐞 GEFUNDENER BUG IM ORIGINAL (siehe docs/PORT_NOTES.md, Punkt B3):
//! `orbit_calculator.py` lieferte Positionen im **inertialen** Bezugssystem
//! und `globe_widget.py` zeichnete sie direkt auf die **erdfeste** Kugel.
//! Dadurch wanderten alle Satelliten mit ~15°/h gegenüber ihrer echten
//! Bodenspur. Zusätzlich benutzte `calculate_ground_track()` eine andere
//! Achskonvention (`x=cos·cos, y=cos·sin, z=sin`) als `GeoLocation`
//! (`x=cos·sin, y=sin, z=cos·cos`) — Bodenspuren lagen also komplett falsch.
//! Beides ist hier korrigiert; [`Frame::Inertial`] reproduziert bei Bedarf
//! das alte Verhalten.

use glam::Vec3;

pub const EARTH_RADIUS_KM: f64 = 6371.0;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum Frame {
    /// Inertial (TEME) — Verhalten des Python-Originals. Voreinstellung,
    /// weil die Portierung 1:1 sein soll (siehe `ev_core::treue`).
    #[default]
    Inertial,
    /// Erdfest (ECEF) — korrekt für die texturierte Kugel.
    EarthFixed,
}

impl Frame {
    /// Was der Originaltreue-Schalter gerade vorgibt.
    pub fn nach_treue() -> Self {
        if ev_core::treue::korrigiert() { Self::EarthFixed } else { Self::Inertial }
    }
}

/// Julianisches Datum aus einem UTC-Zeitstempel.
pub fn julian_date(dt: &chrono::NaiveDateTime) -> f64 {
    use chrono::{Datelike, Timelike};
    let (mut y, mut m) = (dt.year() as f64, dt.month() as f64);
    let d = dt.day() as f64;
    if m <= 2.0 { y -= 1.0; m += 12.0; }
    let a = (y / 100.0).floor();
    let b = 2.0 - a + (a / 4.0).floor();
    let day_frac = (dt.hour() as f64
        + dt.minute() as f64 / 60.0
        + (dt.second() as f64 + dt.nanosecond() as f64 * 1e-9) / 3600.0)
        / 24.0;
    (365.25 * (y + 4716.0)).floor() + (30.6001 * (m + 1.0)).floor() + d + b - 1524.5 + day_frac
}

/// Greenwich Mean Sidereal Time in Radiant (IAU-1982-Reihe).
pub fn gmst_rad(jd_ut1: f64) -> f64 {
    let tu = (jd_ut1 - 2_451_545.0) / 36_525.0;
    let mut gmst_sec = 67_310.548_41
        + (876_600.0 * 3600.0 + 8_640_184.812_866) * tu
        + 0.093_104 * tu * tu
        - 6.2e-6 * tu * tu * tu;
    gmst_sec = gmst_sec.rem_euclid(86_400.0);
    (gmst_sec / 240.0).to_radians() // 240 s pro Grad
}

/// TEME → ECEF: Drehung um die Z-Achse um −GMST.
pub fn teme_to_ecef(pos_km: [f64; 3], gmst: f64) -> [f64; 3] {
    let (s, c) = gmst.sin_cos();
    [
        pos_km[0] * c + pos_km[1] * s,
        -pos_km[0] * s + pos_km[1] * c,
        pos_km[2],
    ]
}

/// ECEF (Z = Nordpol) → Globus-Achsen von [`ev_core::GeoLocation::to_cartesian`]
/// (Y = Nord). Einheit: Erdradien.
pub fn ecef_to_globe(pos_km: [f64; 3]) -> Vec3 {
    Vec3::new(
        (pos_km[1] / EARTH_RADIUS_KM) as f32,
        (pos_km[2] / EARTH_RADIUS_KM) as f32,
        (pos_km[0] / EARTH_RADIUS_KM) as f32,
    )
}

/// ECEF → geografische Breite/Länge in Grad (sphärisch).
pub fn ecef_to_latlon(pos_km: [f64; 3]) -> (f32, f32) {
    let r = (pos_km[0].powi(2) + pos_km[1].powi(2) + pos_km[2].powi(2)).sqrt();
    if r < 1e-9 { return (0.0, 0.0); }
    let lat = (pos_km[2] / r).clamp(-1.0, 1.0).asin().to_degrees();
    let lon = pos_km[1].atan2(pos_km[0]).to_degrees();
    (lat as f32, lon as f32)
}

/// Höhe über der Kugeloberfläche in km.
pub fn altitude_km(pos_km: [f64; 3]) -> f64 {
    (pos_km[0].powi(2) + pos_km[1].powi(2) + pos_km[2].powi(2)).sqrt() - EARTH_RADIUS_KM
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    fn dt(y: i32, m: u32, d: u32, h: u32, mi: u32, s: u32) -> chrono::NaiveDateTime {
        NaiveDate::from_ymd_opt(y, m, d).unwrap().and_hms_opt(h, mi, s).unwrap()
    }

    #[test]
    fn julian_date_j2000() {
        // 2000-01-01 12:00:00 UTC == JD 2451545.0
        let jd = julian_date(&dt(2000, 1, 1, 12, 0, 0));
        assert!((jd - 2_451_545.0).abs() < 1e-6, "jd = {jd}");
    }

    #[test]
    fn julian_date_known_epoch() {
        // 2024-01-01 00:00:00 UTC == JD 2460310.5
        let jd = julian_date(&dt(2024, 1, 1, 0, 0, 0));
        assert!((jd - 2_460_310.5).abs() < 1e-6, "jd = {jd}");
    }

    #[test]
    fn gmst_is_in_range_and_advances() {
        let jd = julian_date(&dt(2024, 6, 1, 0, 0, 0));
        let g0 = gmst_rad(jd);
        let g1 = gmst_rad(jd + 1.0 / 24.0); // +1 h
        assert!((0.0..std::f64::consts::TAU).contains(&g0));
        // Ein Sternstunden-Schritt ist ~15.041°
        let delta = (g1 - g0).rem_euclid(std::f64::consts::TAU).to_degrees();
        assert!((delta - 15.041).abs() < 0.01, "delta = {delta}");
    }

    #[test]
    fn teme_to_ecef_is_identity_at_zero_gmst() {
        let p = [7000.0, 0.0, 1000.0];
        let e = teme_to_ecef(p, 0.0);
        assert!((e[0] - 7000.0).abs() < 1e-9 && (e[2] - 1000.0).abs() < 1e-9);
    }

    #[test]
    fn teme_to_ecef_preserves_radius() {
        let p = [4000.0, -5000.0, 2000.0];
        let e = teme_to_ecef(p, 1.234);
        let n = |v: [f64; 3]| (v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).sqrt();
        assert!((n(p) - n(e)).abs() < 1e-6);
    }

    #[test]
    fn globe_axes_match_geolocation_convention() {
        // Nordpol in ECEF -> im Globus-System +Y
        let g = ecef_to_globe([0.0, 0.0, EARTH_RADIUS_KM]);
        assert!((g.y - 1.0).abs() < 1e-5 && g.x.abs() < 1e-5 && g.z.abs() < 1e-5, "{g:?}");
        // lon=0, lat=0 in ECEF (+X) -> im Globus-System +Z
        let g = ecef_to_globe([EARTH_RADIUS_KM, 0.0, 0.0]);
        assert!((g.z - 1.0).abs() < 1e-5 && g.x.abs() < 1e-5, "{g:?}");
    }

    #[test]
    fn ecef_roundtrip_latlon() {
        // Leipzig ~ 51.34N, 12.38E
        let (lat, lon) = (51.34f64, 12.38f64);
        let r = EARTH_RADIUS_KM;
        let p = [
            r * lat.to_radians().cos() * lon.to_radians().cos(),
            r * lat.to_radians().cos() * lon.to_radians().sin(),
            r * lat.to_radians().sin(),
        ];
        let (la, lo) = ecef_to_latlon(p);
        assert!((la as f64 - lat).abs() < 1e-3 && (lo as f64 - lon).abs() < 1e-3);
    }

    #[test]
    fn altitude_of_iss_is_plausible() {
        let a = altitude_km([EARTH_RADIUS_KM + 420.0, 0.0, 0.0]);
        assert!((a - 420.0).abs() < 1e-6);
    }
}
