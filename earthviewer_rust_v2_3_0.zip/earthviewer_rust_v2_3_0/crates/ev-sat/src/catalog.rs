//! Satelliten-Katalog: TLE laden, kategorisieren, Farben.
//! Port von `src/data/satellite_manager.py` + `SAT_COLORS`.
use std::path::{Path, PathBuf};
use std::time::Duration;

/// Kategorien wie im Original (`SAT_COLORS` in globe_widget.py).
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Category { Starlink, Gps, Weather, Science, Iss, Military, Communication, Unknown }

impl Category {
    pub fn name(&self) -> &'static str {
        match self {
            Self::Starlink => "Starlink", Self::Gps => "GPS", Self::Weather => "Weather",
            Self::Science => "Science", Self::Iss => "ISS", Self::Military => "Military",
            Self::Communication => "Communication", Self::Unknown => "Unknown",
        }
    }
    pub fn rgb(&self) -> [f32; 3] {
        match self {
            Self::Starlink      => [0.20, 0.80, 1.00],
            Self::Gps           => [1.00, 0.85, 0.20],
            Self::Weather       => [0.40, 1.00, 0.50],
            Self::Science       => [0.90, 0.40, 1.00],
            Self::Iss           => [1.00, 0.30, 0.30],
            Self::Military      => [1.00, 0.55, 0.10],
            Self::Communication => [0.55, 0.75, 1.00],
            Self::Unknown       => [0.80, 0.80, 0.80],
        }
    }
    /// Heuristik über den Objektnamen.
    pub fn classify(name: &str) -> Self {
        let n = name.to_ascii_uppercase();
        if n.contains("STARLINK") { return Self::Starlink; }
        if n.contains("ISS") || n.contains("ZARYA") || n.contains("TIANGONG") { return Self::Iss; }
        if n.contains("NAVSTAR") || n.contains("GPS") || n.contains("GALILEO")
            || n.contains("GLONASS") || n.contains("BEIDOU") { return Self::Gps; }
        if n.contains("NOAA") || n.contains("METEOR") || n.contains("METOP")
            || n.contains("GOES") || n.contains("HIMAWARI") { return Self::Weather; }
        if n.contains("HUBBLE") || n.contains("HST") || n.contains("SENTINEL")
            || n.contains("LANDSAT") || n.contains("TERRA") || n.contains("AQUA")
            || n.contains("SWARM") { return Self::Science; }
        if n.contains("USA ") || n.contains("COSMOS") || n.contains("NROL")
            || n.contains("YAOGAN") { return Self::Military; }
        if n.contains("INTELSAT") || n.contains("IRIDIUM") || n.contains("ONEWEB")
            || n.contains("SES ") || n.contains("EUTELSAT") || n.contains("ASTRA") {
            return Self::Communication;
        }
        Self::Unknown
    }
}

#[derive(Clone, Debug)]
pub struct Tle {
    pub name: String,
    pub line1: String,
    pub line2: String,
    pub category: Category,
    pub norad_id: u32,
    /// Celestrak-Gruppe, aus der dieser Eintrag stammt. Das Original hakte
    /// Gruppen einzeln an ("Space Stations", "Weather", …) und musste sie
    /// deshalb auch wieder entfernen koennen.
    pub group: String,
}

/// Parst 3LE-Text (Name, Zeile 1, Zeile 2 — wie von Celestrak geliefert).
pub fn parse_3le(text: &str) -> Vec<Tle> {
    let lines: Vec<&str> = text.lines().map(str::trim_end).filter(|l| !l.trim().is_empty()).collect();
    let mut out = Vec::new();
    let mut i = 0;
    while i + 2 < lines.len() + 1 {
        // Muster: Name / "1 ..." / "2 ..."
        if i + 2 >= lines.len() { break; }
        let (name, l1, l2) = (lines[i], lines[i + 1], lines[i + 2]);
        if l1.starts_with("1 ") && l2.starts_with("2 ") {
            let name = name.trim().to_string();
            let norad_id = l1.get(2..7).and_then(|s| s.trim().parse::<u32>().ok()).unwrap_or(0);
            out.push(Tle {
                category: Category::classify(&name),
                name,
                line1: l1.to_string(),
                line2: l2.to_string(),
                norad_id,
                group: String::new(),
            });
            i += 3;
        } else {
            i += 1;
        }
    }
    out
}

/// Stempelt die Herkunftsgruppe auf jeden Eintrag.
pub fn stamp_group(mut tles: Vec<Tle>, group: &str) -> Vec<Tle> {
    for t in &mut tles {
        t.group = group.to_string();
    }
    tles
}

/// Die vier Kategorien, die das Original als Ankreuzfelder anbot
/// (`satellite_integration.py`: `self.cats`), mit ihrer Celestrak-Gruppe.
pub const CATEGORY_GROUPS: &[(&str, &str)] = &[
    ("Space Stations", "stations"),
    ("Weather", "weather"),
    ("Starlink", "starlink"),
    ("GPS", "gnss"),
];

/// Weitere Gruppen, die Celestrak anbietet — Zugabe ueber das Original hinaus.
pub const CELESTRAK_GROUPS: &[(&str, &str)] = &[
    ("Space Stations", "stations"),
    ("Weather", "weather"),
    ("Starlink", "starlink"),
    ("GPS", "gnss"),
    ("Wissenschaft", "science"),
    ("Aktiv (alle)", "active"),
];

pub fn celestrak_url(group: &str) -> String {
    format!("https://celestrak.org/NORAD/elements/gp.php?GROUP={group}&FORMAT=tle")
}

/// Lädt eine Gruppe von Celestrak und legt sie im Cache ab.
pub fn fetch_group(group: &str, cache_dir: &Path) -> anyhow::Result<Vec<Tle>> {
    let body = ureq::get(&celestrak_url(group))
        .timeout(Duration::from_secs(30))
        .call()?
        .into_string()?;
    let _ = std::fs::create_dir_all(cache_dir);
    let _ = std::fs::write(cache_path(cache_dir, group), &body);
    Ok(parse_3le(&body))
}

pub fn cache_path(cache_dir: &Path, group: &str) -> PathBuf {
    cache_dir.join(format!("tle_{group}.txt"))
}

/// Cache lesen — für Offline-Betrieb (das Original hatte keinen).
pub fn load_cached(group: &str, cache_dir: &Path) -> Option<Vec<Tle>> {
    let text = std::fs::read_to_string(cache_path(cache_dir, group)).ok()?;
    let v = parse_3le(&text);
    if v.is_empty() { None } else { Some(v) }
}

/// Erst Cache, dann Netz — damit die App auch ohne Internet startet.
pub fn load_group(group: &str, cache_dir: &Path, allow_network: bool) -> Vec<Tle> {
    if let Some(v) = load_cached(group, cache_dir) {
        return stamp_group(v, group);
    }
    if allow_network {
        match fetch_group(group, cache_dir) {
            Ok(v) => return stamp_group(v, group),
            Err(e) => eprintln!("⚠️  TLE-Download fehlgeschlagen ({group}): {e}"),
        }
    }
    Vec::new()
}

#[cfg(test)]
mod tests {
    use super::*;

    const SAMPLE: &str = "ISS (ZARYA)\n\
1 25544U 98067A   24001.50000000  .00016717  00000-0  30777-3 0  9991\n\
2 25544  51.6416 247.4627 0006703 130.5360 325.0288 15.49514023432811\n\
STARLINK-1007\n\
1 44713U 19074A   24001.50000000  .00002182  00000-0  16538-3 0  9991\n\
2 44713  53.0544 168.5644 0001373  86.6432 273.4706 15.06393004234569\n";

    #[test]
    fn parses_three_line_elements() {
        let t = parse_3le(SAMPLE);
        assert_eq!(t.len(), 2);
        assert_eq!(t[0].name, "ISS (ZARYA)");
        assert_eq!(t[0].norad_id, 25544);
        assert_eq!(t[1].norad_id, 44713);
    }

    #[test]
    fn classifies_categories() {
        let t = parse_3le(SAMPLE);
        assert_eq!(t[0].category, Category::Iss);
        assert_eq!(t[1].category, Category::Starlink);
        assert_eq!(Category::classify("NAVSTAR 81 (USA 319)"), Category::Gps);
        assert_eq!(Category::classify("NOAA 19"), Category::Weather);
        assert_eq!(Category::classify("SOMETHING ELSE"), Category::Unknown);
    }

    #[test]
    fn tolerates_junk_lines() {
        let junk = format!("### header ###\n\n{SAMPLE}garbage\n");
        assert_eq!(parse_3le(&junk).len(), 2);
    }

    #[test]
    fn empty_input_is_empty_output() {
        assert!(parse_3le("").is_empty());
        assert!(parse_3le("nur eine zeile").is_empty());
    }

    #[test]
    fn every_category_has_a_colour() {
        for c in [Category::Starlink, Category::Gps, Category::Weather, Category::Science,
                  Category::Iss, Category::Military, Category::Communication, Category::Unknown] {
            let rgb = c.rgb();
            assert!(rgb.iter().all(|v| (0.0..=1.0).contains(v)), "{:?}", c.name());
        }
    }

    #[test]
    fn group_stamp_is_applied() {
        let t = stamp_group(parse_3le(SAMPLE), "stations");
        assert!(t.iter().all(|x| x.group == "stations"));
        assert!(parse_3le(SAMPLE).iter().all(|x| x.group.is_empty()));
    }

    #[test]
    fn original_categories_map_to_groups() {
        // Genau die vier aus satellite_integration.py::self.cats
        let namen: Vec<&str> = CATEGORY_GROUPS.iter().map(|(n, _)| *n).collect();
        assert_eq!(namen, ["Space Stations", "Weather", "Starlink", "GPS"]);
        assert!(CATEGORY_GROUPS.iter().all(|(_, g)| !g.is_empty()));
    }

    #[test]
    fn celestrak_url_is_well_formed() {
        assert!(celestrak_url("starlink").starts_with("https://celestrak.org/"));
        assert!(celestrak_url("starlink").contains("FORMAT=tle"));
    }
}
