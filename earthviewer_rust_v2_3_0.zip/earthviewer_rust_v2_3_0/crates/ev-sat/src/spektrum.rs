//! Spektrum-Simulation — 1:1-Port von `sat_monitor_window.py::SimulationWorker`.
//!
//! Das Original erzeugt in einem Qt-Thread alle 100 ms ein simuliertes
//! Leistungsdichtespektrum (PSD) und schickt es per Signal an das
//! pyqtgraph-Diagramm. numpy dort, hier reines Rust ohne Fremdcrate.
//!
//! Die sechs Signalprofile und ihre Parameter sind Zeichen für Zeichen aus dem
//! Original übernommen: Grundrauschen `N(-90, 2)`, dann profilabhängige
//! Gauß-Glocken, am Ende ein feiner Zittersummand `N(0, 0.5)`.

/// Signalprofile — genau die Liste aus `pattern_combo.addItems([...])`.
pub const MUSTER: [&str; 6] = [
    "Rauschen",
    "Sinus-Test",
    "Regen",
    "Eis",
    "Rauch/Interferenz",
    "Sat-Beacons",
];

/// Sat-Profile — `SAT_PROFILES` aus dem Original. (Mittenfrequenz, Abtastrate) in Hz.
pub const SAT_PROFILE: [(&str, f64, f64); 6] = [
    ("NOAA", 137.5e6, 2.4e6),
    ("METEOR", 137.1e6, 2.4e6),
    ("ADS-B", 1090.0e6, 2.4e6),
    ("ACARS", 131.5e6, 2.4e6),
    ("AIS", 162.0e6, 2.4e6),
    ("ISS", 145.8e6, 2.4e6),
];

/// Farbschemata der Combo — `color_combo.addItems([...])`.
pub const FARBSCHEMA: [&str; 4] = ["Grau", "Heiß", "Blau-Rot", "Viridis-ähnlich"];

/// Diagrammtypen — `diagram_combo.addItems([...])`.
pub const DIAGRAMM: [&str; 2] = ["Linie", "Linie+Wasserfall"];

/// Quellen — `source_combo.addItems([...])`. RTL-SDR ist wie im Original nur
/// wählbar; ohne angeschlossenes Gerät bleibt es bei der Simulation.
pub const QUELLE: [&str; 2] = ["Simulation", "RTL-SDR"];

/// Minimaler, deterministischer PRNG (xorshift64) — ersetzt `np.random`.
/// Kein Fremdcrate nötig; die Verteilung ist für eine Visualisierung völlig
/// ausreichend und läuft ohne `rand`.
pub struct Zufall {
    zustand: u64,
}

impl Zufall {
    pub fn neu(saat: u64) -> Self {
        Self { zustand: saat.max(1) }
    }
    fn next_u64(&mut self) -> u64 {
        let mut x = self.zustand;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.zustand = x;
        x
    }
    /// Gleichverteilt in [0, 1).
    fn uniform(&mut self) -> f64 {
        (self.next_u64() >> 11) as f64 / (1u64 << 53) as f64
    }
    /// Standardnormalverteilt via Box-Muller (ein Wert je Aufruf).
    fn normal(&mut self, mittel: f64, sigma: f64) -> f64 {
        let u1 = self.uniform().max(1e-12);
        let u2 = self.uniform();
        let z = (-2.0 * u1.ln()).sqrt() * (std::f64::consts::TAU * u2).cos();
        mittel + sigma * z
    }
}

fn gauss(x: f64, f0: f64, sigma: f64, amp: f64) -> f64 {
    amp * (-((x - f0).powi(2)) / (2.0 * sigma * sigma)).exp()
}

/// Ein Simulationsschritt — Port von `SimulationWorker.run` (ein Schleifendurchlauf).
/// Liefert `(freqs_hz, psd_db)` mit `fft_size` Punkten.
pub fn simulieren(
    muster: &str,
    center_freq: f64,
    sample_rate: f64,
    fft_size: usize,
    rng: &mut Zufall,
) -> (Vec<f64>, Vec<f64>) {
    let n = fft_size.max(2);
    let f_min = center_freq - sample_rate / 2.0;
    let f_max = center_freq + sample_rate / 2.0;
    let mut freqs = Vec::with_capacity(n);
    let mut freqs_mhz = Vec::with_capacity(n);
    for i in 0..n {
        let f = f_min + (f_max - f_min) * i as f64 / (n - 1) as f64;
        freqs.push(f);
        freqs_mhz.push(f / 1e6);
    }
    let mhz_min = freqs_mhz[0];
    let mhz_max = freqs_mhz[n - 1];
    let mhz_mean = (mhz_min + mhz_max) / 2.0;

    // Grundrauschen N(-90, 2)
    let mut psd: Vec<f64> = (0..n).map(|_| rng.normal(-90.0, 2.0)).collect();

    match muster {
        "Sinus-Test" => {
            for (i, &m) in freqs_mhz.iter().enumerate() {
                psd[i] += gauss(m, mhz_mean, 0.05, 30.0);
            }
        }
        "Regen" => {
            for k in 0..10 {
                let f0 = mhz_min + (mhz_max - mhz_min) * k as f64 / 9.0;
                for (i, &m) in freqs_mhz.iter().enumerate() {
                    psd[i] += gauss(m, f0, 0.01, 8.0);
                }
            }
        }
        "Eis" => {
            for k in 0..4 {
                let f0 = mhz_min + (mhz_max - mhz_min) * k as f64 / 3.0;
                for (i, &m) in freqs_mhz.iter().enumerate() {
                    psd[i] += gauss(m, f0, 0.005, 20.0);
                }
            }
        }
        "Rauch/Interferenz" => {
            for (i, &m) in freqs_mhz.iter().enumerate() {
                psd[i] += (m * 10.0).sin() * 5.0 + rng.normal(0.0, 5.0);
            }
        }
        "Sat-Beacons" => {
            let spanne = mhz_max - mhz_min;
            for f0 in [mhz_min + 0.1 * spanne, mhz_min + 0.3 * spanne, mhz_min + 0.7 * spanne] {
                for (i, &m) in freqs_mhz.iter().enumerate() {
                    psd[i] += gauss(m, f0, 0.01, 25.0);
                }
            }
        }
        _ => {} // "Rauschen": nur Grundrauschen
    }

    // Feiner Zittersummand N(0, 0.5)
    for v in psd.iter_mut() {
        *v += rng.normal(0.0, 0.5);
    }

    (freqs, psd)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn liefert_die_gewuenschte_laenge() {
        let mut r = Zufall::neu(42);
        let (f, p) = simulieren("Rauschen", 137e6, 2.4e6, 2048, &mut r);
        assert_eq!(f.len(), 2048);
        assert_eq!(p.len(), 2048);
    }

    #[test]
    fn frequenzachse_ist_zentriert() {
        let mut r = Zufall::neu(1);
        let (f, _) = simulieren("Rauschen", 137e6, 2.4e6, 1024, &mut r);
        let mitte = (f[0] + f[f.len() - 1]) / 2.0;
        assert!((mitte - 137e6).abs() < 1.0, "Mitte {mitte}");
        assert!((f[0] - (137e6 - 1.2e6)).abs() < 1.0);
    }

    #[test]
    fn beacons_heben_das_spektrum_an() {
        // Sat-Beacons müssen im Schnitt über dem reinen Rauschen liegen.
        let mut r = Zufall::neu(7);
        let (_, rausch) = simulieren("Rauschen", 137e6, 2.4e6, 2048, &mut r);
        let (_, beacon) = simulieren("Sat-Beacons", 137e6, 2.4e6, 2048, &mut r);
        let mx_r = rausch.iter().cloned().fold(f64::MIN, f64::max);
        let mx_b = beacon.iter().cloned().fold(f64::MIN, f64::max);
        assert!(mx_b > mx_r + 10.0, "Beacon-Spitze {mx_b} vs Rausch {mx_r}");
    }

    #[test]
    fn alle_muster_laufen_ohne_nan() {
        let mut r = Zufall::neu(99);
        for m in MUSTER {
            let (_, p) = simulieren(m, 137e6, 2.4e6, 512, &mut r);
            assert!(p.iter().all(|v| v.is_finite()), "NaN in {m}");
        }
    }

    #[test]
    fn profile_sind_vollstaendig() {
        assert_eq!(SAT_PROFILE.len(), 6);
        assert_eq!(SAT_PROFILE[0].0, "NOAA");
        assert!((SAT_PROFILE[2].1 - 1090.0e6).abs() < 1.0); // ADS-B
    }
}
