//! Belastungstest: grosse Satellitengruppe (Starlink-Groessenordnung).
fn main() {
    let basis = ev_sat::offline::OFFLINE_TLES;
    let zeilen: Vec<&str> = basis.lines().collect();
    let mut text = String::new();
    let mut n = 0;
    while n < 7000 {
        for block in zeilen.chunks(3) {
            if block.len() < 3 { continue; }
            text.push_str(&format!("STARLINK-{n:05}\n{}\n{}\n", block[1], block[2]));
            n += 1;
        }
    }

    let t = std::time::Instant::now();
    let tles = ev_sat::catalog::parse_3le(&text);
    println!("Parsen        : {:>6} TLE in {:>6.2} s", tles.len(), t.elapsed().as_secs_f64());

    let t = std::time::Instant::now();
    let props: Vec<ev_sat::Propagator> = tles.into_iter()
        .filter_map(|x| ev_sat::Propagator::new(x).ok()).collect();
    println!("SGP4-Aufbau   : {:>6} Objekte in {:>6.2} s", props.len(), t.elapsed().as_secs_f64());

    let jetzt = chrono::Utc::now().naive_utc();
    for frame in [ev_sat::Frame::Inertial, ev_sat::Frame::EarthFixed] {
        let t = std::time::Instant::now();
        let z: Vec<_> = props.iter().filter_map(|p| p.state_at(&jetzt, frame).ok()).collect();
        let s = t.elapsed().as_secs_f64();
        println!("Propagation {:<10}: {:>6} Positionen in {:>6.3} s  ({:>6.0}/s, {:>5.1} ms je Bild)",
                 format!("{frame:?}"), z.len(), s, z.len() as f64 / s, s * 1000.0);
    }

    let t = std::time::Instant::now();
    let _ = props[0].orbit_track(&jetzt, 180, 95.0, ev_sat::Frame::EarthFixed).unwrap();
    println!("Bahnkurve     : 180 Punkte in {:>6.2} ms", t.elapsed().as_secs_f64() * 1000.0);
}
