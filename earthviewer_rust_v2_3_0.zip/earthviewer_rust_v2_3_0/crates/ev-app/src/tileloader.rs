//! Kachel-Lader mit Plattenspeicher-Cache (Runde D, Teil 2).
//!
//! Lädt Karten-Kacheln (OSM/GIBS) im Hintergrund und legt sie unter
//! `sessions/tiles/<anbieter>/<z>/<x>/<y>.<ext>` ab, damit sie nur einmal aus
//! dem Netz kommen. Nur wenn der Nutzer die Kachel-Ebene einschaltet, wird
//! geladen (Sicherheitsanspruch — kein ungefragter Netzverkehr).
//!
//! STAND: Math (ev-render::tiles) + Lader + GL-Ebene (ev-render::tile_layer)
//! sind verdrahtet. Das echte Nachladen läuft, sobald der Nutzer die Ebene
//! einschaltet und Netz hat.


use std::collections::HashSet;
use std::io::Read;
use std::path::PathBuf;
use std::sync::mpsc::{Receiver, Sender};
use ev_render::tiles::TileId;

/// Ein fertig geladenes Kachelbild (rohe Bytes).
pub struct TileBytes {
    pub id: TileId,
    pub daten: Vec<u8>,
}

/// Anbieter-Konfiguration.
#[derive(Clone)]
pub struct TileQuelle {
    pub name: String,
    pub vorlage: String,
    pub ext: String,
    pub attribution: String,
}

impl TileQuelle {
    pub fn osm() -> Self {
        Self {
            name: "OpenStreetMap".into(),
            vorlage: "https://tile.openstreetmap.org/{z}/{x}/{y}.png".into(),
            ext: "png".into(),
            attribution: "© OpenStreetMap-Mitwirkende".into(),
        }
    }
    /// NASA GIBS Blue Marble Shaded Relief. Achtung: {z}/{y}/{x}-Reihenfolge.
    pub fn gibs() -> Self {
        Self {
            name: "NASA GIBS".into(),
            vorlage: "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/\
                      BlueMarble_ShadedRelief/default/GoogleMapsCompatible_Level8/\
                      {z}/{y}/{x}.jpg".into(),
            ext: "jpg".into(),
            attribution: "Bilder: NASA EOSDIS GIBS (gemeinfrei)".into(),
        }
    }
}

/// Hintergrund-Lader mit Cache und Dedup.
pub struct TileLoader {
    anfrage: Sender<TileId>,
    ergebnis: Receiver<TileBytes>,
    angefragt: HashSet<TileId>,
    pub quelle: TileQuelle,
}

impl TileLoader {
    pub fn neu(quelle: TileQuelle) -> Self {
        let (anfrage_tx, anfrage_rx) = std::sync::mpsc::channel::<TileId>();
        let (ergebnis_tx, ergebnis_rx) = std::sync::mpsc::channel::<TileBytes>();
        let cache_root = cache_dir(&quelle.name);
        let _ = std::fs::create_dir_all(&cache_root);
        let q = quelle.clone();
        std::thread::spawn(move || {
            let agent = ureq::AgentBuilder::new()
                .timeout(std::time::Duration::from_secs(12))
                .user_agent("EarthViewer/2.2 (Hobbyprojekt)")
                .build();
            for t in anfrage_rx {
                let pfad = tile_pfad(&cache_root, &q.ext, t);
                if let Ok(daten) = std::fs::read(&pfad) {
                    let _ = ergebnis_tx.send(TileBytes { id: t, daten });
                    continue;
                }
                let url = ev_render::tiles::url(&q.vorlage, t);
                if let Ok(resp) = agent.get(&url).call() {
                    let mut buf = Vec::new();
                    if resp.into_reader().read_to_end(&mut buf).is_ok() && !buf.is_empty() {
                        if let Some(dir) = pfad.parent() { let _ = std::fs::create_dir_all(dir); }
                        let _ = std::fs::write(&pfad, &buf);
                        let _ = ergebnis_tx.send(TileBytes { id: t, daten: buf });
                    }
                }
            }
        });
        Self { anfrage: anfrage_tx, ergebnis: ergebnis_rx, angefragt: HashSet::new(), quelle }
    }

    pub fn anfordern(&mut self, t: TileId) {
        if self.angefragt.insert(t) {
            let _ = self.anfrage.send(t);
        }
    }

    pub fn abholen(&self) -> Vec<TileBytes> {
        self.ergebnis.try_iter().collect()
    }
}

fn cache_dir(anbieter: &str) -> PathBuf {
    let safe: String = anbieter.chars()
        .map(|c| if c.is_ascii_alphanumeric() { c } else { '_' }).collect();
    ev_core::config::session_dir().join("tiles").join(safe)
}

fn tile_pfad(root: &std::path::Path, ext: &str, t: TileId) -> PathBuf {
    root.join(t.z.to_string()).join(t.x.to_string()).join(format!("{}.{}", t.y, ext))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn quellen_haben_platzhalter_und_attribution() {
        let osm = TileQuelle::osm();
        assert!(osm.vorlage.contains("{z}") && osm.vorlage.contains("{x}"));
        assert!(!osm.attribution.is_empty());
        let gibs = TileQuelle::gibs();
        let iz = gibs.vorlage.find("{y}").unwrap();
        let ix = gibs.vorlage.find("{x}").unwrap();
        assert!(iz < ix, "GIBS erwartet z/y/x");
    }

    #[test]
    fn cache_pfad_ist_hierarchisch() {
        let p = tile_pfad(&PathBuf::from("/tmp/ev_tiles"), "png", TileId::new(5, 17, 9));
        assert!(p.ends_with("5/17/9.png"));
    }

    #[test]
    fn anfordern_ist_idempotent() {
        let mut l = TileLoader::neu(TileQuelle::osm());
        let t = TileId::new(2, 1, 1);
        l.anfordern(t);
        l.anfordern(t);
        assert_eq!(l.angefragt.len(), 1);
    }
}
