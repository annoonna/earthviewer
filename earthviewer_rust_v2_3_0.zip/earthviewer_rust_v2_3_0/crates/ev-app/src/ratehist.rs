//! Langzeit-Durchsatzverlauf für die Dashboard-Zeitfenster (Runde D, Nachtrag).
//!
//! Problem aus Runde B: die Zeitfenster 5m/3h/24h/Woche/Monat zeigten alle
//! dieselben ≤300 Sekunden-Messpunkte, weil der Live-Puffer nur so groß ist.
//! Für echte Wochen-/Monats-Ansichten braucht es eine gröbere, aber persistente
//! Historie.
//!
//! Lösung: **Minuten-Eimer**. Der Live-Ticker liefert ~1 Punkt/Sekunde; die
//! werden pro Minute gemittelt und als ein Eintrag gespeichert. Ein Monat sind
//! ~43200 Minuten — als kompaktes JSON gut handhabbar. Persistiert in
//! `sessions/rate_history.json`, überlebt Neustarts.

use serde::{Deserialize, Serialize};

/// Ein gemittelter Messpunkt über eine Minute.
#[derive(Clone, Copy, Debug, Serialize, Deserialize)]
pub struct MinutenPunkt {
    /// Unix-Zeit (Sekunden) am Minutenbeginn.
    pub t: i64,
    pub down_bps: f64,
    pub up_bps: f64,
}

impl MinutenPunkt {
    pub fn rate(&self) -> ev_net::Rate {
        ev_net::Rate { down_bps: self.down_bps, up_bps: self.up_bps }
    }
}

/// Persistenter Langzeitverlauf mit laufender Minuten-Aggregation.
#[derive(Default)]
pub struct RateVerlauf {
    /// Fertige Minuten-Eimer (ältester zuerst).
    pub minuten: Vec<MinutenPunkt>,
    // Aggregation der laufenden Minute:
    akt_minute: i64,
    summe_down: f64,
    summe_up: f64,
    anzahl: u32,
}

impl RateVerlauf {
    /// Ein Monat Minuten + etwas Reserve.
    const MAX: usize = 45_000;

    fn pfad() -> std::path::PathBuf {
        ev_core::config::session_dir().join("rate_history.json")
    }

    pub fn laden() -> Self {
        let minuten: Vec<MinutenPunkt> = std::fs::read_to_string(Self::pfad())
            .ok()
            .and_then(|s| serde_json::from_str(&s).ok())
            .unwrap_or_default();
        Self { minuten, ..Default::default() }
    }

    fn speichern(&self) {
        let _ = std::fs::create_dir_all(ev_core::config::session_dir());
        if let Ok(s) = serde_json::to_string(&self.minuten) {
            let _ = std::fs::write(Self::pfad(), s);
        }
    }

    /// Einen Sekunden-Messwert einspeisen. `now` = Unix-Sekunden. Sobald eine
    /// Minute voll ist, wird ihr Mittel als Eimer abgelegt und gespeichert.
    pub fn speise(&mut self, now: i64, r: ev_net::Rate) {
        let minute = now - now.rem_euclid(60);
        if self.anzahl == 0 {
            self.akt_minute = minute;
        }
        if minute != self.akt_minute && self.anzahl > 0 {
            // Vorige Minute abschließen.
            self.minuten.push(MinutenPunkt {
                t: self.akt_minute,
                down_bps: self.summe_down / self.anzahl as f64,
                up_bps: self.summe_up / self.anzahl as f64,
            });
            if self.minuten.len() > Self::MAX {
                let cut = self.minuten.len() - Self::MAX;
                self.minuten.drain(..cut);
            }
            self.speichern();
            self.summe_down = 0.0;
            self.summe_up = 0.0;
            self.anzahl = 0;
            self.akt_minute = minute;
        }
        self.summe_down += r.down_bps;
        self.summe_up += r.up_bps;
        self.anzahl += 1;
    }

    /// Die Minuten-Eimer der letzten `minuten_zahl` Minuten (für ein Zeitfenster).
    /// Bei sehr großen Fenstern (Woche/Monat) wird für die Anzeige gleichmäßig
    /// ausgedünnt, damit der Graph nicht Zehntausende Punkte zeichnet.
    pub fn fenster(&self, minuten_zahl: usize, max_punkte: usize) -> Vec<ev_net::Rate> {
        let n = self.minuten.len();
        let ab = n.saturating_sub(minuten_zahl);
        let scheibe = &self.minuten[ab..];
        if scheibe.len() <= max_punkte {
            return scheibe.iter().map(|m| m.rate()).collect();
        }
        // Gleichmäßig ausdünnen auf ~max_punkte.
        let schritt = scheibe.len() as f64 / max_punkte as f64;
        (0..max_punkte)
            .map(|i| scheibe[(i as f64 * schritt) as usize].rate())
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn r(d: f64, u: f64) -> ev_net::Rate { ev_net::Rate { down_bps: d, up_bps: u } }

    #[test]
    fn aggregiert_pro_minute() {
        let mut v = RateVerlauf::default();
        // Zwei volle Minuten mit je zwei Messwerten.
        v.speise(0, r(100.0, 10.0));
        v.speise(30, r(300.0, 30.0));    // Minute 0: Mittel 200/20
        v.speise(60, r(50.0, 5.0));      // löst Abschluss von Minute 0 aus
        assert_eq!(v.minuten.len(), 1);
        assert_eq!(v.minuten[0].down_bps, 200.0);
        assert_eq!(v.minuten[0].up_bps, 20.0);
    }

    #[test]
    fn fenster_duennt_aus() {
        let mut v = RateVerlauf::default();
        for m in 0..1000 {
            v.minuten.push(MinutenPunkt { t: m * 60, down_bps: m as f64, up_bps: 0.0 });
        }
        let f = v.fenster(1000, 100);
        assert!(f.len() <= 100, "ausgedünnt auf {}", f.len());
        assert!(f.len() >= 90);
    }

    #[test]
    fn fenster_kleiner_als_verlangt_bleibt_ganz() {
        let mut v = RateVerlauf::default();
        for m in 0..10 {
            v.minuten.push(MinutenPunkt { t: m * 60, down_bps: 1.0, up_bps: 0.0 });
        }
        assert_eq!(v.fenster(300, 300).len(), 10);
    }
}
