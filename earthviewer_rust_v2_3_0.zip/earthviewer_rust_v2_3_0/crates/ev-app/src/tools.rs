//! Hintergrund-Läufe für Ping/Traceroute/WHOIS/VirusTotal.
//! Ersetzt die QThread-Konstruktionen des Originals durch mpsc-Channels.
use ev_geo::GeoDataManager;
use std::sync::mpsc::{self, Receiver};
use std::sync::Arc;

pub enum ToolMsg {
    Line(String),
    Marker(ev_core::GeoLocation),
    /// Voller Traceroute-Hop für die Detail-Tabelle (VisualTraceroute-Stil).
    Hop(ev_net::traceroute::TracerouteHop),
    Done,
}

pub struct ToolJob {
    pub rx: Receiver<ToolMsg>,
}

impl ToolJob {
    /// Holt alles, was bereitliegt. Gibt `true` zurück, wenn der Job fertig ist.
    pub fn drain(&self, sink: &mut crate::state::ToolOutput,
                 markers: &mut Vec<ev_core::GeoLocation>,
                 hops: &mut Vec<ev_net::traceroute::TracerouteHop>) -> bool {
        let mut done = false;
        while let Ok(msg) = self.rx.try_recv() {
            match msg {
                ToolMsg::Line(l) => sink.push(l),
                ToolMsg::Marker(m) => markers.push(m),
                ToolMsg::Hop(h) => hops.push(h),
                ToolMsg::Done => { done = true; }
            }
        }
        if done { sink.busy = false; }
        done
    }
}

pub fn ping(target: &str, count: u32) -> ToolJob {
    let (tx, rx) = mpsc::channel();
    let target = target.to_string();
    std::thread::spawn(move || {
        let stream = ev_net::ping::ping_stream(&target, count);
        let mut n = 0;
        let mut sum = 0.0;
        let mut best = f64::MAX;
        let mut worst: f64 = 0.0;
        for r in stream {
            n += 1;
            sum += r.rtt;
            best = best.min(r.rtt);
            worst = worst.max(r.rtt);
            let _ = tx.send(ToolMsg::Line(format!(
                "#{n}  rtt = {:.2} ms   ttl = {}", r.rtt, r.ttl
            )));
        }
        let _ = tx.send(ToolMsg::Line(if n == 0 {
            "keine Antwort (Ziel unerreichbar oder ICMP gefiltert)".into()
        } else {
            format!("— {n} Antworten · min {best:.2} / ø {:.2} / max {worst:.2} ms",
                    sum / n as f64)
        }));
        let _ = tx.send(ToolMsg::Done);
    });
    ToolJob { rx }
}

pub fn traceroute(geo: Arc<GeoDataManager>, target: &str, max_hops: u32) -> ToolJob {
    let (tx, rx) = mpsc::channel();
    let target = target.to_string();
    let hat_geoip = geo.geoip.is_some();
    std::thread::spawn(move || {
        // Ausgabeformat 1:1 aus den Original-Bildschirmfotos:
        //   Hop 10: 176.52.252.32 (176.52.252.32) - 66.8ms
        // und am Ende:  ✅ 15 Hops lokalisiert
        let mut lokalisiert = 0usize;
        for hop in ev_net::traceroute::trace_stream(geo, &target, max_hops) {
            let wirt = if hop.hostname.is_empty() { hop.ip.clone() } else { hop.hostname.clone() };
            let _ = tx.send(ToolMsg::Line(format!(
                "Hop {}: {} ({}) - {:.1}ms", hop.hop_num, wirt, hop.ip, hop.rtt
            )));
            if let Some(loc) = hop.location.clone() {
                lokalisiert += 1;
                let _ = tx.send(ToolMsg::Line(format!(
                    "        » {} {}",
                    ev_core::country::flag_badge(&loc.country), loc.name
                )));
                let _ = tx.send(ToolMsg::Marker(loc));
            }
            // Vollen Hop für die Detail-Tabelle nachschicken.
            let _ = tx.send(ToolMsg::Hop(hop));
        }
        let _ = tx.send(ToolMsg::Line(format!("✅ {lokalisiert} Hops lokalisiert")));
        if lokalisiert == 0 {
            // Ohne Ortsangaben gibt es keine Marker und damit auch keine
            // Verbindungsboegen auf dem Globus — der haeufigste Grund ist
            // eine fehlende GeoIP-Datenbank.
            let _ = tx.send(ToolMsg::Line(
                "ℹ Keine Koordinaten — deshalb keine Marker und keine Linien.".into()));
            if !hat_geoip {
                let _ = tx.send(ToolMsg::Line(
                    "ℹ GeoLite2-City.mmdb fehlt in data/geodata/".into()));
                let _ = tx.send(ToolMsg::Line(
                    "ℹ Bezug: dev.maxmind.com/geoip/geolite2-free-geolocation-data".into()));
            }
        }
        let _ = tx.send(ToolMsg::Done);
    });
    ToolJob { rx }
}

pub fn whois(query: &str) -> ToolJob {
    let (tx, rx) = mpsc::channel();
    let query = query.to_string();
    std::thread::spawn(move || {
        for line in ev_net::whois::lookup(&query).lines().take(200) {
            let _ = tx.send(ToolMsg::Line(line.to_string()));
        }
        let _ = tx.send(ToolMsg::Done);
    });
    ToolJob { rx }
}

pub fn virustotal(ip: &str) -> ToolJob {
    let (tx, rx) = mpsc::channel();
    let ip = ip.to_string();
    std::thread::spawn(move || {
        let mut vt = ev_net::virustotal::VirusTotal::from_env();
        if !vt.is_configured() {
            let _ = tx.send(ToolMsg::Line(
                "Kein API-Key. Setze EARTHVIEWER_VT_API_KEY und starte neu.".into()));
            let _ = tx.send(ToolMsg::Done);
            return;
        }
        match vt.lookup_ip(&ip) {
            Ok(v) => {
                let _ = tx.send(ToolMsg::Line(format!("IP        : {}", v.ip)));
                let _ = tx.send(ToolMsg::Line(format!("Land      : {}", v.country)));
                let _ = tx.send(ToolMsg::Line(format!("AS-Owner  : {}", v.as_owner)));
                let _ = tx.send(ToolMsg::Line(format!("Reputation: {}", v.reputation)));
                let _ = tx.send(ToolMsg::Line(format!(
                    "Engines   : {} gesamt · {} bösartig · {} verdächtig",
                    v.total_engines(), v.malicious, v.suspicious)));
                let _ = tx.send(ToolMsg::Line(format!("Risiko    : {}", v.risk().label())));
            }
            Err(e) => { let _ = tx.send(ToolMsg::Line(format!("Fehler: {e}"))); }
        }
        let _ = tx.send(ToolMsg::Done);
    });
    ToolJob { rx }
}

pub fn arp_scan() -> ToolJob {
    let (tx, rx) = mpsc::channel();
    std::thread::spawn(move || {
        if let Some(ip) = ev_net::arp::local_ipv4() {
            let _ = tx.send(ToolMsg::Line(format!("Lokale Adresse: {ip}")));
            let _ = tx.send(ToolMsg::Line("Stupse /24 an, um den ARP-Cache zu füllen…".into()));
            ev_net::arp::sweep_hint(&ev_net::arp::subnet_24(ip));
            std::thread::sleep(std::time::Duration::from_millis(1200));
        }
        let entries = ev_net::arp::read_arp_cache();
        if entries.is_empty() {
            let _ = tx.send(ToolMsg::Line("ARP-Cache leer.".into()));
        }
        for (iface, list) in ev_net::arp::group_by_iface(&entries) {
            let _ = tx.send(ToolMsg::Line(format!("— {iface} —")));
            for e in list.iter().filter(|e| e.is_complete()) {
                let _ = tx.send(ToolMsg::Line(format!(
                    "{:<16} {}  {}", e.ip, e.mac, e.vendor)));
            }
        }
        let _ = tx.send(ToolMsg::Done);
    });
    ToolJob { rx }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::state::ToolOutput;

    #[test]
    fn drain_collects_lines_and_marks_done() {
        let (tx, rx) = mpsc::channel();
        tx.send(ToolMsg::Line("a".into())).unwrap();
        tx.send(ToolMsg::Line("b".into())).unwrap();
        tx.send(ToolMsg::Done).unwrap();
        let job = ToolJob { rx };
        let mut out = ToolOutput::default();
        out.reset("Test");
        let mut markers = Vec::new();
        assert!(job.drain(&mut out, &mut markers, &mut Vec::new()));
        assert_eq!(out.lines, vec!["a", "b"]);
        assert!(!out.busy);
    }

    #[test]
    fn drain_collects_markers() {
        let (tx, rx) = mpsc::channel();
        tx.send(ToolMsg::Marker(ev_core::GeoLocation::new("Hop", 1.0, 2.0))).unwrap();
        let job = ToolJob { rx };
        let mut out = ToolOutput::default();
        let mut markers = Vec::new();
        assert!(!job.drain(&mut out, &mut markers, &mut Vec::new()));
        assert_eq!(markers.len(), 1);
        assert_eq!(markers[0].name, "Hop");
    }

    #[test]
    fn drain_on_empty_channel_is_not_done() {
        let (_tx, rx) = mpsc::channel::<ToolMsg>();
        let job = ToolJob { rx };
        let mut out = ToolOutput { busy: true, ..Default::default() };
        assert!(!job.drain(&mut out, &mut Vec::new(), &mut Vec::new()));
        assert!(out.busy);
    }
}
