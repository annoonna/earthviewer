//! Runde D — Überwachungs-Extras nach Community-Vorbild (Sniffnet/GlasWire).
//!
//! Drei zusammengehörige Bausteine, alle persistent in `sessions/`:
//! - **Favoriten für Hosts/Apps**: markierte Gegenstellen oder Programme, die
//!   der Nutzer im Blick behalten will (Sniffnet: „mark as favorite").
//! - **Benachrichtigung**: eine dezente Alarm-Liste (kein nerviges Popup, wie
//!   von GlasWire-Nutzern gewünscht), die auslöst bei Traffic eines Favoriten,
//!   bei Überschreiten einer Schwelle oder bei einer geblockten/Blacklist-IP.
//! - **Schwellwert-Alerts**: KB/s-Grenze, ab der gewarnt wird.
//!
//! Bewusst ohne Sound-Crate (rodio zöge ALSA/pulse-Abhängigkeiten nach); die
//! Benachrichtigungen sind visuell. Sound ist als optionale Erweiterung notiert.

use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

/// Persistente Überwachungs-Einstellungen (sessions/watch.json).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct WatchConfig {
    /// Favorisierte Gegenstellen (IP oder Hostname).
    pub fav_hosts: BTreeSet<String>,
    /// Favorisierte Programme (app_name).
    pub fav_apps: BTreeSet<String>,
    /// Schwelle in KB/s; 0 = aus. Übersteigt der Gesamtdurchsatz sie, gibt es
    /// einen Alarm (frühestens alle `alert_cooldown_s` Sekunden erneut).
    pub schwelle_kbs: f64,
    /// Bei Traffic eines Favoriten benachrichtigen?
    pub melde_favoriten: bool,
    /// Bei geblockten/Blacklist-Gegenstellen benachrichtigen?
    pub melde_blockiert: bool,
}

impl Default for WatchConfig {
    fn default() -> Self {
        Self {
            fav_hosts: BTreeSet::new(),
            fav_apps: BTreeSet::new(),
            schwelle_kbs: 0.0,
            melde_favoriten: true,
            melde_blockiert: true,
        }
    }
}

impl WatchConfig {
    fn pfad() -> std::path::PathBuf {
        ev_core::config::session_dir().join("watch.json")
    }
    pub fn laden() -> Self {
        std::fs::read_to_string(Self::pfad())
            .ok()
            .and_then(|s| serde_json::from_str(&s).ok())
            .unwrap_or_default()
    }
    pub fn speichern(&self) {
        let _ = std::fs::create_dir_all(ev_core::config::session_dir());
        if let Ok(s) = serde_json::to_string_pretty(self) {
            let _ = std::fs::write(Self::pfad(), s);
        }
    }
    pub fn host_fav(&self, h: &str) -> bool { self.fav_hosts.contains(h) }
    pub fn app_fav(&self, a: &str) -> bool { self.fav_apps.contains(a) }
    pub fn toggle_host(&mut self, h: &str) {
        if !self.fav_hosts.remove(h) { self.fav_hosts.insert(h.to_string()); }
        self.speichern();
    }
    #[allow(dead_code)] // Teil der Favoriten-API; App-Stern folgt in der UI.
    pub fn toggle_app(&mut self, a: &str) {
        if !self.fav_apps.remove(a) { self.fav_apps.insert(a.to_string()); }
        self.speichern();
    }
}

/// Eine Benachrichtigung in der Alarm-Liste.
#[derive(Clone, Debug)]
pub struct Alarm {
    /// Sekunden seit Programmstart (für die Anzeige „vor Xs").
    pub t: f64,
    pub stufe: Stufe,
    pub text: String,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Stufe { Info, Warnung, Kritisch }

impl Stufe {
    pub fn rgb(self) -> [u8; 3] {
        match self {
            Stufe::Info => [90, 160, 240],
            Stufe::Warnung => [240, 200, 70],
            Stufe::Kritisch => [235, 90, 80],
        }
    }
    pub fn symbol(self) -> &'static str {
        match self { Stufe::Info => "ℹ", Stufe::Warnung => "⚠", Stufe::Kritisch => "⛔" }
    }
}

/// Ringpuffer der letzten Alarme + Entprellung, damit dieselbe Warnung nicht
/// jede Sekunde neu erscheint.
#[derive(Default)]
pub struct AlarmProtokoll {
    pub eintraege: Vec<Alarm>,
    letzte_schwelle: Option<f64>,
    gemeldete_hosts: BTreeSet<String>,
}

impl AlarmProtokoll {
    const MAX: usize = 100;
    const COOLDOWN_S: f64 = 15.0;

    fn push(&mut self, t: f64, stufe: Stufe, text: String) {
        self.eintraege.push(Alarm { t, stufe, text });
        if self.eintraege.len() > Self::MAX {
            let cut = self.eintraege.len() - Self::MAX;
            self.eintraege.drain(..cut);
        }
    }

    pub fn leeren(&mut self) {
        self.eintraege.clear();
        self.gemeldete_hosts.clear();
        self.letzte_schwelle = None;
    }

    /// Pro Tick auswerten: Schwelle, Favoriten-Traffic, geblockte Gegenstellen.
    /// `t` = Sekunden seit Start, `kbs` = aktueller Gesamtdurchsatz.
    pub fn auswerten(
        &mut self,
        t: f64,
        kbs: f64,
        cfg: &WatchConfig,
        conns: &[ev_net::Connection],
        blocklist: &ev_net::BlockList,
    ) {
        // Schwellwert (entprellt). Erster Alarm feuert sofort, danach Cooldown.
        if cfg.schwelle_kbs > 0.0 && kbs > cfg.schwelle_kbs
            && self.letzte_schwelle.map_or(true, |l| t - l > Self::COOLDOWN_S)
        {
            self.letzte_schwelle = Some(t);
            self.push(t, Stufe::Warnung,
                format!("Durchsatz {kbs:.0} KB/s über Schwelle {:.0} KB/s", cfg.schwelle_kbs));
        }
        // Favoriten-Traffic + geblockte Gegenstellen (je Host einmal pro Sitzung,
        // bis „leeren"), damit die Liste nicht überläuft.
        for c in conns {
            let host_fav = cfg.melde_favoriten
                && (cfg.host_fav(&c.remote_ip) || cfg.app_fav(&c.app_name));
            if host_fav {
                let key = format!("fav:{}:{}", c.app_name, c.remote_ip);
                if self.gemeldete_hosts.insert(key) {
                    self.push(t, Stufe::Info,
                        format!("Favorit aktiv: {} → {}", c.app_name, c.remote_ip));
                }
            }
            if cfg.melde_blockiert && blocklist.is_blocked(&c.remote_ip) {
                let key = format!("block:{}", c.remote_ip);
                if self.gemeldete_hosts.insert(key) {
                    self.push(t, Stufe::Kritisch,
                        format!("Geblockte Gegenstelle spricht: {}", c.remote_ip));
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn conn(ip: &str, app: &str) -> ev_net::Connection {
        ev_net::Connection {
            local_ip: "127.0.0.1".into(), local_port: 1, remote_ip: ip.into(),
            remote_port: 443, protocol: "TCP".into(),
            direction: ev_net::Direction::Outgoing, app_name: app.into(),
            pid: 1, bytes_sent: 0, bytes_recv: 0, timestamp: 0.0,
            country: String::new(), city: String::new(), lat: 0.0, lon: 0.0,
        }
    }

    #[test]
    fn schwelle_loest_aus_und_entprellt() {
        let mut p = AlarmProtokoll::default();
        let mut cfg = WatchConfig::default();
        cfg.schwelle_kbs = 100.0;
        let bl = ev_net::BlockList::default();
        p.auswerten(1.0, 150.0, &cfg, &[], &bl);
        assert_eq!(p.eintraege.len(), 1);
        // Sofort danach: Entprellung greift, kein zweiter Alarm.
        p.auswerten(2.0, 150.0, &cfg, &[], &bl);
        assert_eq!(p.eintraege.len(), 1);
        // Nach dem Cooldown wieder.
        p.auswerten(20.0, 150.0, &cfg, &[], &bl);
        assert_eq!(p.eintraege.len(), 2);
    }

    #[test]
    fn favorit_meldet_einmal() {
        let mut p = AlarmProtokoll::default();
        let mut cfg = WatchConfig::default();
        cfg.fav_hosts.insert("1.2.3.4".into());
        let bl = ev_net::BlockList::default();
        let c = vec![conn("1.2.3.4", "firefox")];
        p.auswerten(1.0, 0.0, &cfg, &c, &bl);
        p.auswerten(2.0, 0.0, &cfg, &c, &bl);
        assert_eq!(p.eintraege.len(), 1, "Favorit darf nur einmal melden");
    }

    #[test]
    fn toggle_host_persistiert_im_set() {
        let mut cfg = WatchConfig::default();
        cfg.toggle_host("8.8.8.8");
        assert!(cfg.host_fav("8.8.8.8"));
        cfg.toggle_host("8.8.8.8");
        assert!(!cfg.host_fav("8.8.8.8"));
    }
}
