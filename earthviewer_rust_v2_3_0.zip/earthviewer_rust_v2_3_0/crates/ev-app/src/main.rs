//! EarthViewer 2.0 — Rust Edition. Einstiegspunkt (Port von `main.py`).
mod alerts;
mod app;
mod dashboard;
mod fenster;
mod detail;
mod globe_view;
mod glyphen;
mod state;
mod tabs;
mod ratehist;
mod tileloader;
mod tools;

use ev_core::config;

/// Multisampling-Stufen, die der Reihe nach probiert werden.
///
/// Warum überhaupt eine Kette? `eframe`/`glutin` fordert die gewünschte
/// Sample-Zahl **hart** an und bricht mit `NoGlutinConfigs` ab, wenn der
/// Treiber sie nicht anbietet. Das passiert real bei:
///
/// - llvmpipe / Xvfb (Software-Rendering, CI, Server ohne GPU)
/// - virtuellen GPUs (VMware SVGA, QXL, virtio-gpu ohne Venus)
/// - älteren Intel-iGPUs mit begrenzten FBConfigs
///
/// Das Python-Original hatte dasselbe Problem — dort stand
/// `fmt.setSamples(4)` fest im Code und Qt fiel still auf 0 zurück.
/// Wir machen den Rückfall explizit und sichtbar.
const MSAA_LADDER: [u16; 3] = [4, 2, 0];

fn main() -> eframe::Result<()> {
    ev_core::treue::init_from_env();
    banner();
    config::ensure_runtime_dirs();

    // Erlaubt Erzwingen von außen: EARTHVIEWER_MSAA=0 ./start.sh
    let ladder: Vec<u16> = match std::env::var("EARTHVIEWER_MSAA") {
        Ok(v) => match v.trim().parse::<u16>() {
            Ok(n) => vec![n],
            Err(_) => MSAA_LADDER.to_vec(),
        },
        Err(_) => MSAA_LADDER.to_vec(),
    };

    let last = ladder.len() - 1;
    for (i, samples) in ladder.iter().copied().enumerate() {
        match eframe::run_native(
            config::WINDOW_TITLE,
            native_options(samples),
            Box::new(|cc| Ok(Box::new(app::EarthViewerApp::new(cc)))),
        ) {
            Ok(()) => return Ok(()),
            Err(e) if i < last && is_config_error(&e) => {
                eprintln!("⚠️  Kein GL-Kontext mit {samples}× Multisampling — versuche {}×",
                          ladder[i + 1]);
            }
            Err(e) => {
                explain(&e);
                return Err(e);
            }
        }
    }
    unreachable!("Leiter enthält mindestens einen Eintrag")
}

fn native_options(multisampling: u16) -> eframe::NativeOptions {
    eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([config::WINDOW_WIDTH, config::WINDOW_HEIGHT])
            .with_min_inner_size([config::WINDOW_MIN_WIDTH, config::WINDOW_MIN_HEIGHT])
            .with_title(config::WINDOW_TITLE),
        renderer: eframe::Renderer::Glow,
        depth_buffer: 24,
        stencil_buffer: 8,
        multisampling,
        ..Default::default()
    }
}

/// Erkennt Fehler, bei denen eine andere Sample-Zahl helfen kann.
///
/// Achtung: auf die `Display`-Ausgabe zu matchen wäre falsch — die lautet
/// „Found no glutin configs matching the template…" und enthält gerade *nicht*
/// den Variantennamen. Deshalb direkt auf die Enum-Variante prüfen.
fn is_config_error(e: &eframe::Error) -> bool {
    matches!(e, eframe::Error::NoGlutinConfigs(..))
}

/// Übersetzt die üblichen Startfehler in etwas Handlungsfähiges.
fn explain(e: &eframe::Error) {
    let s = e.to_string();
    eprintln!();
    if s.contains("neither WAYLAND_DISPLAY") || s.contains("DISPLAY is not set") {
        eprintln!("❌ Kein Display gefunden.");
        eprintln!("   Über SSH:  ssh -X ...  oder  export DISPLAY=:0");
        eprintln!("   Headless:  xvfb-run -s '-screen 0 1400x900x24' ./start.sh 1");
    } else if matches!(e, eframe::Error::NoGlutinConfigs(..)) {
        eprintln!("❌ Kein passender OpenGL-Kontext.");
        eprintln!("   Software-Rendering erzwingen:");
        eprintln!("     LIBGL_ALWAYS_SOFTWARE=1 EARTHVIEWER_MSAA=0 ./start.sh 1");
        eprintln!("   Treiber prüfen:  glxinfo -B");
    } else if matches!(e, eframe::Error::Glutin(..)) || s.contains("libGL") {
        eprintln!("❌ OpenGL-Bibliothek fehlt oder ist unbrauchbar.");
        eprintln!("   ./start.sh --setup");
    }
}

fn banner() {
    println!("{}", "=".repeat(70));
    println!("🌍 EarthViewer {} — Rust Edition", ev_core::VERSION);
    println!("{}", "=".repeat(70));
    println!("📁 Projektwurzel : {}", config::project_root().display());
    println!("🎨 Renderer      : OpenGL 3.3 via glow/eframe");
    println!(
        "📐 Verhalten     : {}",
        if ev_core::treue::korrigiert() {
            "korrigiert (Abweichungen aktiv — siehe Einstellungen)"
        } else {
            "1:1 wie EarthViewer 2.0"
        }
    );
    if std::env::var("EARTHVIEWER_VT_API_KEY").is_ok() {
        println!("🛡  VirusTotal    : Key aus Umgebung geladen");
    } else {
        println!("🛡  VirusTotal    : kein Key (EARTHVIEWER_VT_API_KEY setzen)");
    }
    println!("{}", "=".repeat(70));
}
