//! Hauptfenster — Port von `src/ui/widgets/main_window.py` + `sidebar.py`
//! + der diversen Tab-/Fenster-Klassen.
use crate::globe_view::{self, Camera, GlobeGl};
use crate::state::{self, AppState, NetTool, Tab};
use crate::tabs::{self, ControlAction, FavAction, SearchAction};
use crate::tools::{self, ToolJob};
use ev_core::config;
use ev_core::GeoLocation;
use ev_render::Scene;
use ev_sat::{Frame, Propagator};
use glam::Vec3;
use std::sync::Arc;

pub struct EarthViewerApp {
    geo: Arc<ev_geo::GeoDataManager>,
    gl: GlobeGl,
    camera: Camera,
    state: AppState,
    job: Option<ToolJob>,
    last_frame: std::time::Instant,
    sat_props: Vec<Propagator>,
    sat_last_update: std::time::Instant,
    /// Läuft von 0..1 und steuert das Pulsieren der Verbindungsbögen.
    anim_phase: f32,
    scan: Option<ev_net::portscan::ScanHandle>,
    next_loop_run: Option<std::time::Instant>,
    pending_screenshot: bool,
    throughput_due: std::time::Instant,
    /// Theme-Auswahl als eigenes Fenster (Port von `theme_dialog.py`).
    theme_offen: bool,
    /// Waagerechte Lage der Reiterleiste (Pfeile « »).
    tab_offset: f32,
    /// Groesste sinnvolle Lage — steuert, ob « » anklickbar sind.
    tab_max_offset: f32,
    /// PRNG für die Spektrum-Simulation im SatMonitor PRO.
    spektrum_rng: ev_sat::spektrum::Zufall,
}

impl EarthViewerApp {
    pub fn new(cc: &eframe::CreationContext<'_>) -> Self {
        let geo = Arc::new(ev_geo::GeoDataManager::new());
        let gl_handle = GlobeGl::new();
        if let Some(gl) = cc.gl.as_ref() {
            gl_handle.init(gl);
        }
        let mut state = AppState::new(Arc::clone(&geo));
        state.tracker.start();
        setup_style(&cc.egui_ctx, ev_core::theme::UiPalette::fuer_theme(state.theme.name));

        let mut me = Self {
            geo,
            gl: gl_handle,
            camera: Camera::default(),
            state,
            job: None,
            last_frame: std::time::Instant::now(),
            sat_props: Vec::new(),
            sat_last_update: std::time::Instant::now(),
            anim_phase: 0.0,
            scan: None,
            next_loop_run: None,
            pending_screenshot: false,
            throughput_due: std::time::Instant::now(),
            theme_offen: false,
            tab_offset: 0.0,
            tab_max_offset: 0.0,
            spektrum_rng: ev_sat::spektrum::Zufall::neu(0x51A7_C0DE),
        };
        // Das Original zeigte beim Start bereits Satelliten ("21/21 aktiv").
        // Deshalb offline laden: erst Cache, sonst Notreserve. Kein Netzzugriff
        // beim Start — der kostet Sekunden und kann haengen.
        me.autoload_satellites();
        if me.geo.geoip.is_none() {
            me.state.status = "GeoIP fehlt — keine Marker".into();
        }
        me
    }

    /// Satelliten ohne Netz besorgen. Reihenfolge: Cache -> Notreserve.
    fn autoload_satellites(&mut self) {
        let cache = config::session_dir();
        for gruppe in ["stations", "active", "starlink"] {
            if ev_sat::catalog::load_cached(gruppe, &cache).is_some() {
                self.state.sat_active_groups.push(gruppe.to_string());
                self.reload_active_groups();
                return;
            }
        }
        self.load_builtin_satellites();
    }

    fn run_search(&mut self) {
        let q = self.state.search_query.trim().to_string();
        // main_window._on_search: leeres Feld -> nichts tun.
        if q.is_empty() { return; }
        // main_window._on_search ruft self.globe.clear_markers() VOR der Suche.
        self.state.clear_markers();
        let results = self.geo.search(&q);
        self.state.status = if results.is_empty() {
            format!("keine Treffer für '{q}'")
        } else {
            format!("{} Ergebnisse gefunden", results.len())
        };
        if let Some(first) = results.first().cloned() {
            self.camera.align_to(first.lat, first.lon);
            self.state.target_marker = Some(first);
        }
        self.state.search_results = results;
    }

    /// Eingebaute TLE (Port von `OFFLINE_TLES`) — damit ohne Netz etwas zu sehen ist.
    fn load_builtin_satellites(&mut self) {
        self.install_tles(ev_sat::offline::builtin(), "Notreserve");
    }

    fn install_tles(&mut self, tles: Vec<ev_sat::Tle>, quelle: &str) {
        let total = tles.len();
        let now = chrono::Utc::now().naive_utc();
        self.state.sat_tle_age = tles
            .first()
            .and_then(|t| ev_sat::offline::age_days(&t.line1, &now));
        self.sat_props = tles.into_iter().filter_map(|t| Propagator::new(t).ok()).collect();
        self.state.sat_selected = None;
        self.state.sat_orbit.clear();
        self.state.sat_track.clear();
        self.state.sat_status =
            format!("{quelle}: {} von {total} TLE übernommen", self.sat_props.len());
        self.update_satellites(true);
    }

    /// Bahn und Bodenspur des gewählten Satelliten neu berechnen.
    /// Port von `orbit_renderer.add_orbit` / `update_orbit`.
    fn rebuild_orbit(&mut self) {
        self.state.sat_orbit.clear();
        self.state.sat_track.clear();
        let Some(i) = self.state.sat_selected else { return };
        let Some(p) = self.sat_props.get(i) else { return };
        let now = chrono::Utc::now().naive_utc();
        let period = p.period_minutes();
        if let Ok(t) = p.orbit_track(&now, 180, period, self.state.sat_frame) {
            self.state.sat_orbit = t.points;
        }
        if let Ok(g) = p.ground_track(&now, 180, period) {
            self.state.sat_track = g;
        }
    }

    fn update_satellites(&mut self, force: bool) {
        if self.sat_props.is_empty() { return; }
        if !force && self.sat_last_update.elapsed().as_secs_f32() < 1.0 { return; }
        self.sat_last_update = std::time::Instant::now();
        let now = chrono::Utc::now().naive_utc();
        let frame = self.state.sat_frame;
        self.state.satellites = self
            .sat_props
            .iter()
            .filter_map(|p| p.state_at(&now, frame).ok())
            .collect();
        if force && self.state.sat_selected.is_some() {
            self.rebuild_orbit();
        }
    }

    /// Baut die GL-Szene aus dem Zustand — das Gegenstück zu `paintGL`.
    fn build_scene(&self) -> Scene {
        let mut scene = Scene { background: to_f32(self.state.theme.background), ..Default::default() };
        let radius = config::SPHERE_RADIUS + self.state.marker_offset;

        if self.state.show_markers {
            scene.add_markers(&self.state.search_results, radius,
                              to_f32(self.state.theme.search_marker), config::MARKER_SIZE_SEARCH);
            scene.add_markers(&self.state.traceroute_markers, radius,
                              to_f32(self.state.theme.traceroute_marker),
                              config::MARKER_SIZE_TRACEROUTE);
            if let Some(t) = &self.state.target_marker {
                scene.add_markers(std::slice::from_ref(t), radius,
                                  to_f32(self.state.theme.target_marker),
                                  config::MARKER_SIZE_TARGET);
            }
            let conn_markers: Vec<GeoLocation> = self
                .state
                .locatable_connections()
                .iter()
                .map(|c| GeoLocation::new(c.city.clone(), c.lat, c.lon))
                .collect();
            scene.add_markers(&conn_markers, radius, [0.3, 0.65, 1.0], 8.0);
        }

        // Traceroute-Pfad als Linienzug, latenzfarbig (OVTR-Idee):
        // grün<50ms, gelb<150ms, rot darüber. Fällt auf die Themefarbe zurück,
        // wenn keine Hop-Latenzen vorliegen (nur Marker gesetzt).
        if self.state.traceroute_markers.len() >= 2 {
            let pts: Vec<Vec3> = self
                .state
                .traceroute_markers
                .iter()
                .map(|l| l.to_cartesian(radius))
                .collect();
            let hops = &self.state.traceroute_hops;
            let lokalisierte: Vec<&ev_net::traceroute::TracerouteHop> =
                hops.iter().filter(|h| h.location.is_some()).collect();
            if lokalisierte.len() == pts.len() && pts.len() >= 2 {
                // Jedes Segment in der Farbe seines Zielhops.
                for i in 1..pts.len() {
                    let c = lokalisierte[i].latenz_rgb();
                    scene.add_line(vec![pts[i - 1], pts[i]], c, 0.9, 2.5);
                }
            } else {
                scene.add_line(pts, to_f32(self.state.theme.traceroute_line), 0.9, 2.0);
            }
        }

        // Live-Verbindungen als Great-Circle-Bögen.
        // Das Original berechnete in `_render_connection_lines` einen
        // `animation_offset`, benutzte ihn aber nie. Hier pulsiert damit die
        // Deckkraft — jeder Bogen leicht phasenversetzt, damit man sieht,
        // dass die Anzeige lebt.
        let phase = self.anim_phase;
        for (i, c) in self.state.locatable_connections().iter().enumerate() {
            let end = GeoLocation::new(c.city.clone(), c.lat, c.lon);
            let color = if c.is_incoming() { [0.30, 0.65, 1.00] } else { [0.30, 1.00, 0.55] };
            let offset = i as f32 * 0.15;
            let alpha = 0.55 + 0.30
                * (std::f32::consts::TAU * (phase + offset)).sin().abs();
            scene.add_arc(&self.state.home, &end, color, alpha);
        }

        // Satelliten, nach Kategorie gruppiert (ein Batch pro Farbe).
        // Kategoriefilter greift hier, nicht erst in der Tabelle.
        if self.state.show_satellites && !self.state.satellites.is_empty() {
            let mut by_cat: std::collections::BTreeMap<ev_sat::Category, Vec<Vec3>> =
                Default::default();
            for (_, s) in self.state.visible_satellites() {
                by_cat.entry(s.category).or_default().push(s.position);
            }
            // Als texturierte Symbole zeichnen, wenn ein Icon geladen wurde
            // (Port von satellite_sprites.py), sonst einfarbige Punkte.
            let sprites_da = self
                .gl
                .0
                .lock()
                .ok()
                .and_then(|g| g.as_ref().map(|r| r.has_sprites()))
                .unwrap_or(false);
            for (cat, points) in by_cat {
                let c = cat.rgb();
                if sprites_da {
                    // Das Icon ist grau/gruen; die Kategoriefarbe kommt als
                    // Einfaerbung dazu, leicht aufgehellt damit es leuchtet.
                    scene.add_sprites(
                        points,
                        self.state.sat_sprite_size,
                        [
                            (c[0] * 0.5 + 0.5).min(1.0),
                            (c[1] * 0.5 + 0.5).min(1.0),
                            (c[2] * 0.5 + 0.5).min(1.0),
                            1.0,
                        ],
                    );
                } else {
                    scene.markers.push(ev_render::MarkerBatch {
                        points, color: c, size: 7.0,
                    });
                }
            }

            // Ausgewählter Satellit: Bahn, Bodenspur, Fußabdruck, Richtungspfeil.
            // (Port von orbit_renderer.py + Gpredict-Issue #94)
            if let Some(sel) = self.state.sat_selected {
                if let Some(s) = self.state.satellites.get(sel) {
                    let c = s.category.rgb();
                    scene.add_markers(
                        &[GeoLocation::new(s.name.clone(), s.lat, s.lon)],
                        1.0 + self.state.marker_offset, [1.0, 1.0, 1.0], 14.0);
                    if self.state.sat_show_orbit && self.state.sat_orbit.len() > 1 {
                        scene.add_line(self.state.sat_orbit.clone(), c, 0.75, 1.5);
                    }
                    if self.state.sat_show_ground_track && self.state.sat_track.len() > 1 {
                        scene.add_line(self.state.sat_track.clone(),
                                       [c[0] * 0.6, c[1] * 0.6, 1.0], 0.6, 1.0);
                    }
                    if self.state.sat_show_footprint {
                        scene.add_footprint(s.position, s.altitude_km, c);
                    }
                    if let Some(p) = self.sat_props.get(sel) {
                        let now = chrono::Utc::now().naive_utc();
                        if let Ok((pos, dir)) =
                            p.velocity_arrow(&now, self.state.sat_frame, 0.22)
                        {
                            scene.add_direction_arrow(pos, dir, [1.0, 1.0, 1.0]);
                        }
                    }
                }
            }
        }
        scene
    }

    fn poll_background(&mut self) {
        // Durchsatz aus /proc/net/dev — das Original zeigt KB/s, nicht Zahlen.
        if self.throughput_due <= std::time::Instant::now() {
            self.throughput_due =
                std::time::Instant::now() + std::time::Duration::from_secs(1);
            let r = self.state.meter.tick();
            self.state.push_rate(r);
            // Langzeitverlauf (Minuten-Eimer) für echte Wochen-/Monats-Fenster.
            let now = chrono::Utc::now().timestamp();
            self.state.rate_verlauf.speise(now, r);
            // Runde D: Alarme auswerten (Schwelle, Favoriten, geblockte Hosts).
            let t = self.state.started.elapsed().as_secs_f64();
            let kbs = r.total_kbs();
            let conns = self.state.connections.clone();
            let cfg = self.state.watch.clone();
            let bl = &self.state.blocklist;
            self.state.alarme.auswerten(t, kbs, &cfg, &conns, bl);
        }

        if let Some(snapshot) = self.state.tracker.try_recv() {
            let elapsed = self.state.started.elapsed().as_secs_f64();
            self.state.monitor.ingest(&snapshot, elapsed);
            self.state.connections = snapshot;
        }

        let mut finished = false;
        if let Some(job) = &self.job {
            finished = job.drain(&mut self.state.tool_output,
                                 &mut self.state.traceroute_markers,
                                 &mut self.state.traceroute_hops);
        }
        if finished { self.job = None; }

        // Wiederholungs-Modus des Netzwerk-Tabs (Port von `_on_loop_tick`).
        if self.job.is_none() && self.state.loop_enabled {
            if let Some(due) = self.next_loop_run {
                if std::time::Instant::now() >= due {
                    self.start_net_tool();
                }
            }
        }
        // network_tab.py: "\n⏹️ Loop-Modus gestoppt.\n"
        if !self.state.loop_enabled && self.next_loop_run.take().is_some() {
            self.state.tool_output.push("⏹ Loop-Modus gestoppt.");
        }

        // Port-Scanner
        let mut scan_done = false;
        if let Some(h) = &self.scan {
            while let Ok(msg) = h.rx.try_recv() {
                match msg {
                    ev_net::portscan::ScanMsg::Found(p) => self.state.scan_results.push(p),
                    ev_net::portscan::ScanMsg::Progress { scanned, total } => {
                        self.state.scan_progress = (scanned, total);
                    }
                    ev_net::portscan::ScanMsg::Error(e) => {
                        self.state.scan_status = format!("Fehler: {e}");
                    }
                    ev_net::portscan::ScanMsg::Done { open } => {
                        self.state.scan_status = format!("fertig — {open} offene Ports");
                        scan_done = true;
                    }
                }
            }
        }
        if scan_done { self.scan = None; }
    }

    /// Speichert ein per ViewportCommand angefordertes Bildschirmfoto.
    /// Port von `main_window.take_screenshot`.
    fn save_screenshot(&mut self, ctx: &egui::Context) {
        if !self.pending_screenshot { return; }
        let shot = ctx.input(|i| {
            i.events.iter().find_map(|e| match e {
                egui::Event::Screenshot { image, .. } => Some(image.clone()),
                _ => None,
            })
        });
        let Some(img) = shot else { return };
        self.pending_screenshot = false;

        let dir = config::screenshot_dir();
        let _ = std::fs::create_dir_all(&dir);
        let name = format!("earthviewer_{}.png",
                           chrono::Local::now().format("%Y%m%d_%H%M%S"));
        let path = dir.join(&name);
        let (w, h) = (img.width() as u32, img.height() as u32);
        let raw: Vec<u8> = img.pixels.iter().flat_map(|p| p.to_array()).collect();
        match image::RgbaImage::from_raw(w, h, raw) {
            Some(buf) => match buf.save(&path) {
                Ok(_) => eprintln!("📸 Screenshot: {}", path.display()),
                Err(e) => eprintln!("❌ Screenshot fehlgeschlagen: {e}"),
            },
            None => eprintln!("❌ Screenshot: Puffergröße passt nicht"),
        }
    }
}

fn to_f32(c: [u8; 3]) -> [f32; 3] {
    [c[0] as f32 / 255.0, c[1] as f32 / 255.0, c[2] as f32 / 255.0]
}

/// Farben, Schriftgroessen und Abstaende. Chrome-Farben kommen aus der
/// übergebenen `UiPalette` — Standard = 1:1 wie `config.py`, GlasWire = voller
/// GlasWire-Look. Nur die Palette wechselt; Layout/Größen bleiben gleich.
fn setup_style(ctx: &egui::Context, pal: ev_core::theme::UiPalette) {
    use ev_core::theme::ui;
    let f = |c: [u8; 3]| egui::Color32::from_rgb(c[0], c[1], c[2]);

    let mut style = (*ctx.style()).clone();
    style.visuals = egui::Visuals::dark();

    // ── Schriftgroessen ────────────────────────────────────────────────────
    use egui::{FontFamily::Monospace, FontFamily::Proportional, FontId, TextStyle};
    style.text_styles = [
        (TextStyle::Heading, FontId::new(ui::FONT_GROSS, Proportional)),
        (TextStyle::Body, FontId::new(ui::FONT_NORMAL, Proportional)),
        (TextStyle::Button, FontId::new(ui::FONT_NORMAL, Proportional)),
        (TextStyle::Small, FontId::new(ui::FONT_KLEIN, Proportional)),
        (TextStyle::Monospace, FontId::new(ui::FONT_MONO, Monospace)),
    ]
    .into();

    // ── Flaechen ───────────────────────────────────────────────────────────
    style.visuals.panel_fill = f(pal.surface);
    style.visuals.window_fill = f(pal.background);
    style.visuals.extreme_bg_color = f(pal.background); // Eingabefelder
    style.visuals.faint_bg_color = f(pal.surface_variant); // Zebrastreifen
    style.visuals.override_text_color = Some(f(pal.text));
    style.visuals.window_stroke = egui::Stroke::new(1.0, f(pal.border));

    // ── Bedienelemente ─────────────────────────────────────────────────────
    let rand = egui::Stroke::new(1.0, f(pal.border));
    style.visuals.widgets.noninteractive.bg_fill = f(pal.surface);
    style.visuals.widgets.noninteractive.bg_stroke = rand;
    style.visuals.widgets.noninteractive.fg_stroke =
        egui::Stroke::new(1.0, f(pal.text_secondary));

    style.visuals.widgets.inactive.bg_fill = f(pal.surface_variant);
    style.visuals.widgets.inactive.weak_bg_fill = f(pal.surface_variant);
    style.visuals.widgets.inactive.bg_stroke = rand;
    style.visuals.widgets.inactive.fg_stroke = egui::Stroke::new(1.0, f(pal.text));

    style.visuals.widgets.hovered.bg_fill = f(pal.primary_hover);
    style.visuals.widgets.hovered.weak_bg_fill = f(pal.primary_hover);
    style.visuals.widgets.hovered.bg_stroke = egui::Stroke::new(1.0, f(pal.primary_hover));
    style.visuals.widgets.hovered.fg_stroke = egui::Stroke::new(1.0, f(pal.text));

    style.visuals.widgets.active.bg_fill = f(pal.primary);
    style.visuals.widgets.active.weak_bg_fill = f(pal.primary);
    style.visuals.widgets.active.bg_stroke = egui::Stroke::new(1.0, f(pal.primary));

    style.visuals.selection.bg_fill = f(pal.primary);
    style.visuals.selection.stroke = egui::Stroke::new(1.0, f(pal.text));

    // ── Scrollbalken ───────────────────────────────────────────────────────
    // 🐞 BEHOBEN in v0.7.0: egui benutzt von Haus aus einen *schwebenden*
    // Balken, der ueber dem Inhalt liegt. Dadurch verschwand Text hinter dem
    // Balken — genau der von Anno gemeldete Fehler. Qt reserviert stattdessen
    // Platz. `ScrollStyle::solid()` tut dasselbe: der Balken bekommt eine
    // eigene Spalte, der Inhalt endet davor.
    style.spacing.scroll = egui::style::ScrollStyle::solid();
    style.spacing.scroll.bar_width = 11.0;
    style.spacing.scroll.bar_inner_margin = 4.0;
    style.spacing.scroll.bar_outer_margin = 2.0;
    for w in [
        &mut style.visuals.widgets.inactive,
        &mut style.visuals.widgets.hovered,
        &mut style.visuals.widgets.active,
        &mut style.visuals.widgets.noninteractive,
    ] {
        w.corner_radius = egui::CornerRadius::same(3);
    }

    // ── Abstaende ──────────────────────────────────────────────────────────
    style.spacing.item_spacing = egui::vec2(6.0, 5.0);
    style.spacing.button_padding = egui::vec2(8.0, 5.0);
    style.spacing.interact_size.y = 22.0;

    ctx.set_style(style);
}

impl eframe::App for EarthViewerApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        let dt = self.last_frame.elapsed().as_secs_f32();
        self.last_frame = std::time::Instant::now();

        self.poll_background();
        self.save_screenshot(ctx);
        self.update_satellites(false);
        self.anim_phase = (self.anim_phase + dt * self.state.animation_speed * 0.5).fract();

        if self.camera.auto_rotate {
            self.camera.rotate(-self.camera.auto_rotate_speed * dt * 60.0, Vec3::Y);
        }
        // Weiches Heranzoomen (Google-Earth-Gefühl) pro Frame nachführen.
        let zoom_bewegt = self.camera.tick_zoom(dt);

        self.top_bar(ctx);
        match self.state.layout {
            crate::state::LayoutModus::Klassisch => {
                self.side_panel(ctx);
                self.globe_panel(ctx);
            }
            crate::state::LayoutModus::Dashboard => {
                self.dashboard_layout(ctx);
            }
        }

        self.theme_fenster(ctx);

        // Große Ansichten (Ports der freistehenden QDialog-Fenster).
        crate::fenster::network_monitor(ctx, &mut self.state);
        crate::fenster::live_connections(ctx, &mut self.state);
        crate::fenster::control_center(ctx, &mut self.state);
        crate::fenster::clients(ctx, &mut self.state);
        crate::fenster::graph(ctx, &mut self.state);
        crate::fenster::protection(ctx, &mut self.state);
        crate::fenster::protocol(ctx, &mut self.state);
        let (_, scan_act) =
            crate::fenster::scanner(ctx, &mut self.state, self.scan.is_some());
        if let Some(a) = scan_act { self.handle_scan_action(a); }

        // SatMonitor PRO (Spektrum · Sat-Tracking · Spectator API).
        let sichtbare: Vec<ev_sat::SatState> =
            self.state.visible_satellites().into_iter().map(|(_, s)| s.clone()).collect();
        crate::fenster::sat_monitor(ctx, &mut self.state, &sichtbare, &mut self.spektrum_rng);

        // Zahnrad-Dialog „⚙️ Erweiterte Einstellungen".
        let mut rotate = self.camera.auto_rotate_speed;
        let mut reset = false;
        crate::fenster::settings(ctx, &mut self.state, &mut rotate, &mut reset);
        self.camera.auto_rotate_speed = rotate;
        if reset {
            self.camera = crate::globe_view::Camera::default();
            self.state.sat_frame = Frame::nach_treue();
            self.update_satellites(true);
        }

        // Detailfenster (Port der drei QDialog-Klassen)
        if let Some(d) = self.state.detail.clone() {
            if !crate::detail::zeige(ctx, &self.state, &d) {
                self.state.detail = None;
            }
        }

        // ~60 fps, solange sich etwas bewegt.
        if zoom_bewegt || self.camera.auto_rotate {
            ctx.request_repaint(); // sofort nachzeichnen, damit der Zoom flüssig läuft
        } else {
            ctx.request_repaint_after(std::time::Duration::from_millis(16));
        }
    }

    fn on_exit(&mut self, gl: Option<&glow::Context>) {
        self.state.tracker.stop();
        if let Some(gl) = gl { self.gl.destroy(gl); }
    }
}

// ── UI-Bausteine ───────────────────────────────────────────────────────────
impl EarthViewerApp {
    /// Theme-Auswahl — Port von `theme_dialog.py`, inklusive Vorschau der
    /// Markerfarben und der freien Farbwahl (`_pick_color`).
    fn theme_fenster(&mut self, ctx: &egui::Context) {
        if !self.theme_offen { return; }
        let mut offen = true;
        egui::Window::new("🎨 Theme")
            .open(&mut offen)
            .resizable(false)
            .default_width(300.0)
            .show(ctx, |ui| {
                for name in ev_core::theme::theme_names() {
                    let th = ev_core::theme::theme_by_name(name);
                    ui.horizontal(|ui| {
                        let gewaehlt = self.state.theme.name == name;
                        if ui.selectable_label(gewaehlt, name).clicked() {
                            self.state.theme = th.clone();
                            if let Ok(mut s) = ev_core::settings::global().lock() {
                                s.set("theme", name);
                            }
                            // Ganzes Fenster-Chrome auf die Theme-Palette
                            // umstellen (GlasWire färbt alles, andere = Standard).
                            setup_style(ui.ctx(),
                                ev_core::theme::UiPalette::fuer_theme(name));
                            self.state.status = format!("Theme: {name}");
                        }
                        // Vorschau: die vier Markerfarben als Kacheln
                        for c in [th.search_marker, th.traceroute_marker,
                                  th.target_marker, th.background] {
                            let (r, _) = ui.allocate_exact_size(
                                egui::vec2(13.0, 13.0), egui::Sense::hover());
                            ui.painter().rect_filled(
                                r, 2.0, egui::Color32::from_rgb(c[0], c[1], c[2]));
                        }
                    });
                    ui.small(th.description);
                }
                ui.separator();
                ui.small(format!("Aktuell: {}", self.state.theme.name));
            });
        self.theme_offen = offen;
    }

    /// Kopfzeile — 1:1 nach dem Original: Lupe, ein breites Eingabefeld,
    /// tuerkiser Knopf "Suchen", dahinter Zahnrad und Palette. **Sonst nichts.**
    /// „Marker loeschen", „Auto-Rotation" und die Verbindungszahl standen dort
    /// nie; sie gehoeren in die Reiter Suche, Steuerung und Live Verbindungen.
    /// Nachgemessen: die Zeile ist im Original 113 px hoch, meine war 57.
    fn top_bar(&mut self, ctx: &egui::Context) {
        let p = ev_core::theme::ui::PRIMARY;
        let tuerkis = egui::Color32::from_rgb(p[0], p[1], p[2]);
        egui::TopBottomPanel::top("topbar")
            .exact_height(56.0)
            .show(ctx, |ui| {
                ui.add_space(6.0);
                ui.horizontal(|ui| {
                    ui.add_space(8.0);
                    ui.label(egui::RichText::new("🔍").size(18.0));
                    ui.add_space(6.0);

                    // Knoepfe rechts zuerst belegen, das Feld bekommt den Rest.
                    let knopfhoehe = 34.0;
                    ui.with_layout(
                        egui::Layout::right_to_left(egui::Align::Center),
                        |ui| {
                            ui.add_space(8.0);
                            if ui
                                .add_sized([36.0, knopfhoehe], egui::Button::new("🎨"))
                                .on_hover_text("Theme wechseln")
                                .clicked()
                            {
                                self.theme_offen = !self.theme_offen;
                            }
                            if ui
                                .add_sized([36.0, knopfhoehe], egui::Button::new("⚙"))
                                .on_hover_text("Einstellungen")
                                .clicked()
                            {
                                self.state.win_settings = true;
                            }
                            // Layout-Umschalter direkt sichtbar (nicht im Dialog
                            // vergraben) — ein Klick zwischen Globus und GlasWire.
                            let dash = self.state.layout
                                == crate::state::LayoutModus::Dashboard;
                            let (txt, tip) = if dash {
                                ("🌍 Globus", "Zurück zur klassischen Globus-Ansicht")
                            } else {
                                ("📊 Dashboard", "Zur GlasWire-Dashboard-Ansicht wechseln")
                            };
                            if ui
                                .add_sized([120.0, knopfhoehe],
                                    egui::Button::new(egui::RichText::new(txt)
                                        .color(egui::Color32::WHITE))
                                    .fill(if dash { tuerkis }
                                          else { egui::Color32::from_rgb(70, 70, 78) }))
                                .on_hover_text(tip)
                                .clicked()
                            {
                                self.state.layout = if dash {
                                    crate::state::LayoutModus::Klassisch
                                } else {
                                    crate::state::LayoutModus::Dashboard
                                };
                            }
                            if ui
                                .add_sized(
                                    [96.0, knopfhoehe],
                                    egui::Button::new(
                                        egui::RichText::new("🔍 Suchen")
                                            .color(egui::Color32::WHITE),
                                    )
                                    .fill(tuerkis),
                                )
                                .clicked()
                            {
                                self.run_search();
                            }
                            ui.add_space(6.0);

                            ui.with_layout(
                                egui::Layout::left_to_right(egui::Align::Center),
                                |ui| {
                                    let te = ui.add_sized(
                                        [ui.available_width(), knopfhoehe],
                                        egui::TextEdit::singleline(
                                            &mut self.state.search_query,
                                        )
                                        .hint_text(
                                            "Stadt, Land, IP oder mehrere Städte \
                                             (z.B. 'berlin leipzig koblenz' oder \
                                             '52.52, 13.405')",
                                        ),
                                    );
                                    if te.lost_focus()
                                        && ui.input(|i| i.key_pressed(egui::Key::Enter))
                                    {
                                        self.run_search();
                                    }
                                },
                            );
                        },
                    );
                });
            });
    }

    fn side_panel(&mut self, ctx: &egui::Context) {
        egui::SidePanel::right("sidebar")
            .default_width(ev_core::theme::ui::SEITENLEISTE_STANDARD)
            .min_width(ev_core::theme::ui::SEITENLEISTE_MIN)
            .max_width(ev_core::theme::ui::SEITENLEISTE_MAX)
            .show(ctx, |ui| {
                // Kopf wie im Original: Titel + Statuszeile
                ui.add_space(4.0);
                ui.label(
                    // sidebar.py Zeile 39: QLabel("🌍 EarthViewer 2.0") — genau so.
                    // NICHT die Crate-Version; die war die Quelle der "1.9.0"-Anzeige.
                    egui::RichText::new(ev_core::config::WINDOW_TITLE)
                        .size(ev_core::theme::ui::FONT_TITEL)
                        .strong()
                        .color(egui::Color32::from_rgb(
                            ev_core::theme::ui::PRIMARY_HOVER[0],
                            ev_core::theme::ui::PRIMARY_HOVER[1],
                            ev_core::theme::ui::PRIMARY_HOVER[2],
                        )),
                );
                egui::Frame::new()
                    .fill(egui::Color32::from_gray(38))
                    .inner_margin(egui::Margin::symmetric(6, 3))
                    .show(ui, |ui| {
                        ui.label(
                            egui::RichText::new(format!("Status: {}", self.state.status))
                                .size(ev_core::theme::ui::FONT_KLEIN)
                                .color(egui::Color32::from_rgb(
                                    ev_core::theme::ui::PRIMARY_HOVER[0],
                                    ev_core::theme::ui::PRIMARY_HOVER[1],
                                    ev_core::theme::ui::PRIMARY_HOVER[2],
                                )),
                        );
                    });
                ui.add_space(4.0);

                // Zoom-Fussleiste zuerst reservieren, damit sie unten klebt
                let zoom = crate::state::AppState::zoom_factor(self.camera.distance);
                egui::TopBottomPanel::bottom("zoomleiste").show_inside(ui, |ui| {
                    ui.label(
                        egui::RichText::new(format!("Zoom: {zoom:.1}x"))
                            .size(ev_core::theme::ui::FONT_KLEIN)
                            .color(egui::Color32::from_gray(140)),
                    );
                });

                // Reiterleiste — nachgemessen am Original (werkzeug/farben.py,
                // Zeile y=286): aktiver Reiter #0D7377, inaktive #3A3A3A,
                // 2 px Luecke, rechts zwei Pfeile zum Blaettern.
                //
                // 🐞 In v1.5.0 hatte ich den Rollbalken versteckt und die
                // Pfeile vergessen — damit waren 8 von 13 Reitern unerreichbar.
                let pf = ev_core::theme::ui::PRIMARY;
                let un = ev_core::theme::ui::SURFACE_VARIANT;
                let aktiv = egui::Color32::from_rgb(pf[0], pf[1], pf[2]);
                let inaktiv = egui::Color32::from_rgb(un[0], un[1], un[2]);
                let hoehe = ev_core::theme::ui::HOEHE_REITER;

                ui.horizontal(|ui| {
                    let pfeilbreite = 24.0;
                    let schritt = 150.0;
                    // Erst von rechts belegen (Pfeile), der Rest bleibt fuer
                    // die Leiste. `max_width` allein reichte nicht — die
                    // Rollflaeche nahm trotzdem die volle Breite.
                    ui.with_layout(
                        egui::Layout::right_to_left(egui::Align::Center),
                        |ui| {
                            let max = self.tab_max_offset;
                            if ui
                                .add_enabled(
                                    self.tab_offset < max - 0.5,
                                    egui::Button::new("»")
                                        .min_size(egui::vec2(pfeilbreite, hoehe)),
                                )
                                .on_hover_text("weiter nach rechts")
                                .clicked()
                            {
                                self.tab_offset = (self.tab_offset + schritt).min(max);
                            }
                            if ui
                                .add_enabled(
                                    self.tab_offset > 0.5,
                                    egui::Button::new("«")
                                        .min_size(egui::vec2(pfeilbreite, hoehe)),
                                )
                                .on_hover_text("weiter nach links")
                                .clicked()
                            {
                                self.tab_offset = (self.tab_offset - schritt).max(0.0);
                            }

                            ui.with_layout(
                                egui::Layout::left_to_right(egui::Align::Center),
                                |ui| {
                                    let ausgabe = egui::ScrollArea::horizontal()
                                        .id_salt("reiterleiste")
                                        .auto_shrink([false, true])
                                        .scroll_bar_visibility(
                                            egui::scroll_area::ScrollBarVisibility::AlwaysHidden,
                                        )
                                        .horizontal_scroll_offset(self.tab_offset)
                                        .show(ui, |ui| {
                                            ui.horizontal(|ui| {
                                                ui.spacing_mut().item_spacing.x = 2.0;
                                                for t in Tab::ALL {
                                                    let gewaehlt = self.state.tab == t;
                                                    let knopf = egui::Button::new(
                                                        egui::RichText::new(t.label())
                                                            .size(ev_core::theme::ui::FONT_NORMAL)
                                                            .color(egui::Color32::WHITE),
                                                    )
                                                    .fill(if gewaehlt { aktiv } else { inaktiv })
                                                    .min_size(egui::vec2(0.0, hoehe));
                                                    if ui.add(knopf).clicked() {
                                                        self.state.tab = t;
                                                    }
                                                }
                                            });
                                        });
                                    // Lage und Grenze fuer die Pfeile merken.
                                    self.tab_offset = ausgabe.state.offset.x;
                                    self.tab_max_offset = (ausgabe.content_size.x
                                        - ausgabe.inner_rect.width())
                                    .max(0.0);
                                },
                            );
                        },
                    );
                });
                ui.separator();
                // 🐞 BEHOBEN in v0.7.0: hier lag frueher ein *aeusserer*
                // ScrollArea um alle Reiter — und die meisten Reiter bringen
                // ihren eigenen mit. Zwei senkrechte Balken uebereinander,
                // und der aeussere lag ueber dem Text des inneren. Jetzt
                // scrollt genau eine Ebene: Reiter mit eigenem Bereich
                // bekommen keinen zweiten uebergestuelpt.
                let eigener_scroll = matches!(
                    self.state.tab,
                    Tab::Search
                        | Tab::Favorites
                        | Tab::Network
                        | Tab::LiveConnections
                        | Tab::Monitoring
                        | Tab::Scanner
                        | Tab::Satellites
                );
                let inhalt = |s: &mut Self, ui: &mut egui::Ui| s.render_tab_body(ui);
                if eigener_scroll {
                    inhalt(self, ui);
                } else {
                    egui::ScrollArea::vertical()
                        .id_salt("tabbody")
                        .auto_shrink([false, false])
                        .show(ui, |ui| inhalt(self, ui));
                }
            });
    }

    /// Zeichnet den Inhalt des aktuell gewählten Reiters. Geteilt zwischen der
    /// klassischen Seitenleiste und dem Dashboard-Layout.
    fn render_tab_body(&mut self, ui: &mut egui::Ui) {
        match self.state.tab {
            Tab::Control => self.control_tab(ui),
            Tab::Search => self.search_tab(ui),
            Tab::Favorites => self.favorites_tab(ui),
            Tab::Network => self.network_tab(ui),
            Tab::LiveConnections => self.live_connections_tab(ui),
            Tab::Monitoring => tabs::monitoring(ui, &mut self.state),
            Tab::ControlCenter => {
                let geo = std::sync::Arc::clone(&self.geo);
                tabs::control_center(ui, &mut self.state, &geo)
            }
            Tab::Graph => tabs::graph(ui, &mut self.state),
            Tab::Protection => tabs::protection(ui, &mut self.state),
            Tab::Protocol => tabs::protocol(ui, &mut self.state),
            Tab::Scanner => self.scanner_tab(ui),
            Tab::Satellites => self.satellite_tab(ui),
        }
    }

    /// GlasWire-artiges Layout: Icon-Navleiste links, Zeit-Graph oben,
    /// Reiterinhalt darunter. Zuschaltbar; ersetzt Seitenleiste + Globus.
    fn dashboard_layout(&mut self, ctx: &egui::Context) {
        crate::dashboard::nav_leiste(ctx, &mut self.state);
        egui::CentralPanel::default().show(ctx, |ui| {
            crate::dashboard::kopf_und_graph(ui, &mut self.state);
            egui::ScrollArea::vertical()
                .id_salt("dash_body")
                .auto_shrink([false, false])
                .show(ui, |ui| {
                    self.render_tab_body(ui);
                });
        });
    }

    /// Kachel-Ebene pro Frame aktualisieren. Gibt (sichtbar?, aktive Kacheln,
    /// neu dekodierte Kacheln zum Hochladen) zurück. Nur aktiv, wenn der Nutzer
    /// die Ebene eingeschaltet hat — sonst kein Netzverkehr (Sicherheitsanspruch).
    fn update_tiles(&mut self)
        -> (bool, Vec<ev_render::tiles::TileId>, Vec<globe_view::FertigeKachel>)
    {
        use ev_render::tiles;
        if !self.state.tiles_an {
            return (false, Vec::new(), Vec::new());
        }
        // Lader bei Bedarf erzeugen bzw. Quelle wechseln.
        let quelle_name = if self.state.tile_quelle_osm { "OpenStreetMap" } else { "NASA GIBS" };
        let neu_noetig = match &self.state.tile_loader {
            Some(l) => l.quelle.name != quelle_name,
            None => true,
        };
        if neu_noetig {
            let q = if self.state.tile_quelle_osm {
                crate::tileloader::TileQuelle::osm()
            } else {
                crate::tileloader::TileQuelle::gibs()
            };
            self.state.tile_loader = Some(crate::tileloader::TileLoader::neu(q));
        }

        // Zoomstufe aus Kamera-Entfernung; nur ab mittlerer Nähe Kacheln laden
        // (weit draußen reicht die Basistextur — spart Netz).
        let z = tiles::zoomstufe(self.camera.distance, 7);
        let (lon, lat) = self.camera.blickpunkt();
        // Sichtbare Kacheln um den Blickpunkt (kleiner Radius = wenige Anfragen).
        let aktiv = tiles::sichtbare_tiles(lon, lat, z, 2);

        // Anfordern + fertige einsammeln.
        let mut neu = Vec::new();
        if let Some(loader) = self.state.tile_loader.as_mut() {
            for t in &aktiv {
                loader.anfordern(*t);
            }
            for tb in loader.abholen() {
                // Bild dekodieren (auf App-Seite; Upload passt später im GL-CB).
                if let Ok(img) = image::load_from_memory(&tb.daten) {
                    let rgba = img.to_rgba8();
                    let (w, h) = (rgba.width(), rgba.height());
                    neu.push(globe_view::FertigeKachel {
                        id: tb.id, w, h, rgba: rgba.into_raw(),
                    });
                }
            }
        }
        (true, aktiv, neu)
    }

    fn globe_panel(&mut self, ctx: &egui::Context) {
        let scene = self.build_scene();
        let bg = scene.background;
        // Kachel-Ebene vorbereiten (Runde D): sichtbare Kacheln bestimmen,
        // anfordern, fertige einsammeln + dekodieren.
        let (tiles_sichtbar, tile_aktiv, tile_neu) = self.update_tiles();
        egui::CentralPanel::default()
            .frame(egui::Frame::NONE)
            .show(ctx, |ui| {
                let resp = globe_view::paint_globe(
                    ui, &self.gl, &self.camera, scene, bg,
                    tiles_sichtbar, tile_aktiv, tile_neu);

                if resp.dragged() {
                    let d = resp.drag_delta();
                    let rot_y = ev_core::math::rotation(d.x * config::ROTATION_SENSITIVITY, Vec3::Y);
                    let rot_x = ev_core::math::rotation(d.y * config::ROTATION_SENSITIVITY, Vec3::X);
                    self.camera.rotation = rot_x * rot_y * self.camera.rotation;
                }
                if resp.hovered() {
                    let scroll = ui.input(|i| i.smooth_scroll_delta.y);
                    self.camera.zoom(scroll);
                }

                // Hover-Tooltip und Klick-Auswahl (Port von _check_hover /
                // _check_satellite_click aus globe_widget.py)
                if let Some(cur) = resp.hover_pos() {
                    // Einmal filtern, zweimal auslesen — bei 7000 Satelliten
                    // war das vorher zweimal derselbe Durchlauf je Bild.
                    let sichtbar = self.state.visible_satellites();
                    let sat_pts: Vec<Vec3> = sichtbar.iter().map(|(_, s)| s.position).collect();
                    let sat_idx: Vec<usize> = sichtbar.iter().map(|(i, _)| *i).collect();
                    let hit_sat = if self.state.show_satellites {
                        globe_view::hover_pick(&self.camera, resp.rect, cur, &sat_pts, 12.0)
                    } else {
                        None
                    };

                    if let Some(k) = hit_sat {
                        let i = sat_idx[k];
                        if let Some(s) = self.state.satellites.get(i) {
                            let txt = format!(
                                "{}\n{} · NORAD {}\n{:.0} km · {:.2} km/s\n{:.2}°, {:.2}°",
                                s.name, s.category.name(), s.norad_id,
                                s.altitude_km, s.speed_km_s, s.lat, s.lon);
                            egui::show_tooltip_at_pointer(
                                ui.ctx(), ui.layer_id(), egui::Id::new("sat_tip"),
                                |ui| { ui.label(txt); });
                        }
                        if resp.clicked() {
                            self.state.sat_selected =
                                if self.state.sat_selected == Some(i) { None } else { Some(i) };
                            self.rebuild_orbit();
                        }
                    } else {
                        // Endpunkte der Verbindungsbögen zuerst prüfen — sie
                        // tragen die volle Netzinfo (VisualTraceroute-Idee:
                        // Anfangs-/Endpunkt zeigt IP, Ort, Land, Port, Protokoll,
                        // Prozess, Richtung).
                        let radius = config::SPHERE_RADIUS + self.state.marker_offset;
                        let conns = self.state.locatable_connections();
                        let conn_pts: Vec<Vec3> = conns
                            .iter()
                            .map(|c| GeoLocation::new(String::new(), c.lat, c.lon)
                                .to_cartesian(radius))
                            .collect();
                        let hit_conn =
                            globe_view::hover_pick(&self.camera, resp.rect, cur, &conn_pts, 11.0);

                        if let Some(k) = hit_conn {
                            let mut treffer_ip = None;
                            if let Some(c) = conns.get(k) {
                                let richtung = if c.is_incoming() { "⬇ eingehend" } else { "⬆ ausgehend" };
                                let ort = if c.city.is_empty() {
                                    ev_core::country::flag_and_name(&c.country)
                                } else {
                                    format!("{} · {}", c.city,
                                            ev_core::country::flag_and_name(&c.country))
                                };
                                let txt = format!(
                                    "{}  (PID {})\n{}:{}  {}\n{}\n{}\n{:.4}, {:.4}",
                                    if c.app_name.is_empty() { "—" } else { &c.app_name },
                                    c.pid, c.remote_ip, c.remote_port, c.protocol,
                                    ort, richtung, c.lat, c.lon);
                                egui::show_tooltip_at_pointer(
                                    ui.ctx(), ui.layer_id(), egui::Id::new("conn_tip"),
                                    |ui| { ui.label(txt); });
                                if resp.clicked() {
                                    treffer_ip = Some((c.remote_ip.clone(), c.remote_port));
                                }
                            }
                            // Klick wählt die Verbindung (fürs Blockieren im
                            // Schützen-Reiter) — Endpunkt wird interaktiv.
                            if let Some((ip, port)) = treffer_ip {
                                if let Some(idx) = self.state.connections.iter().position(
                                    |x| x.remote_ip == ip && x.remote_port == port)
                                {
                                    self.state.selected_connection = Some(idx);
                                }
                            }
                        } else {
                        // Marker der Orte
                        let entries = self.state.marker_entries();
                        let pts: Vec<Vec3> =
                            entries.iter().map(|(l, _)| l.to_cartesian(radius)).collect();
                        if let Some(i) =
                            globe_view::hover_pick(&self.camera, resp.rect, cur, &pts, 12.0)
                        {
                            if let Some((loc, _)) = entries.get(i) {
                                let txt = format!(
                                    "{}\n{}\n{:.4}, {:.4}",
                                    loc.name,
                                    ev_core::country::flag_and_name(&loc.country),
                                    loc.lat, loc.lon);
                                egui::show_tooltip_at_pointer(
                                    ui.ctx(), ui.layer_id(), egui::Id::new("loc_tip"),
                                    |ui| { ui.label(txt); });
                            }
                        }
                        } // Ende: else (kein Verbindungs-Endpunkt getroffen)
                    }
                }

                if self.state.show_labels {
                    let labels = globe_view::build_labels(
                        &self.camera, resp.rect,
                        &self.state.marker_entries(), self.state.marker_offset,
                    );
                    let painter = ui.painter_at(resp.rect);
                    for l in labels {
                        painter.text(
                            egui::pos2(l.x + 10.0, l.y),
                            egui::Align2::LEFT_CENTER,
                            &l.text,
                            egui::FontId::proportional(12.0),
                            egui::Color32::from_rgb(l.color[0], l.color[1], l.color[2]),
                        );
                    }
                }
            });
    }

    // ── Reiter, die eigenen Zustand der App anfassen ───────────────────────
    fn control_tab(&mut self, ui: &mut egui::Ui) {
        let mut auto = self.camera.auto_rotate;
        let mut speed = self.camera.auto_rotate_speed;
        let action = tabs::control(ui, &mut self.state, &mut auto, &mut speed);
        self.camera.auto_rotate = auto;
        self.camera.auto_rotate_speed = speed;
        match action {
            Some(ControlAction::Rotate(dx, dy)) => {
                let rot_y = ev_core::math::rotation(dx, Vec3::Y);
                let rot_x = ev_core::math::rotation(dy, Vec3::X);
                self.camera.rotation = rot_x * rot_y * self.camera.rotation;
            }
            Some(ControlAction::Reset) => {
                self.camera = crate::globe_view::Camera::default();
            }
            Some(ControlAction::Screenshot) => {
                ui.ctx().send_viewport_cmd(egui::ViewportCommand::Screenshot(
                    egui::UserData::default(),
                ));
                self.pending_screenshot = true;
            }
            Some(ControlAction::Preset(p)) => {
                self.camera.align_preset(p, self.state.target_marker.as_ref());
                self.state.status = format!("Ansicht: {p}");
            }
            None => {}
        }
    }

    fn search_tab(&mut self, ui: &mut egui::Ui) {
        match tabs::search(ui, &mut self.state) {
            Some(SearchAction::Run) => self.run_search(),
            Some(SearchAction::Goto(i)) => {
                if let Some(l) = self.state.search_results.get(i).cloned() {
                    self.camera.align_to(l.lat, l.lon);
                    self.state.target_marker = Some(l);
                }
            }
            Some(SearchAction::Favorite(i)) => {
                if let Some(l) = self.state.search_results.get(i).cloned() {
                    if !self.state.favorites.iter().any(|f| f.name == l.name) {
                        self.state.favorites.push(l);
                        state::save_favorites(&self.state.favorites);
                    }
                }
            }
            None => {}
        }
    }

    fn favorites_tab(&mut self, ui: &mut egui::Ui) {
        match tabs::favorites(ui, &self.state) {
            Some(FavAction::Goto(i)) => {
                if let Some(f) = self.state.favorites.get(i).cloned() {
                    self.camera.align_to(f.lat, f.lon);
                    self.state.target_marker = Some(f);
                }
            }
            Some(FavAction::Remove(i)) => {
                if i < self.state.favorites.len() {
                    self.state.favorites.remove(i);
                    state::save_favorites(&self.state.favorites);
                }
            }
            Some(FavAction::AddCurrent) => {
                if let Some(t) = self.state.target_marker.clone() {
                    if !self.state.favorites.iter().any(|f| f.name == t.name) {
                        self.state.favorites.push(t);
                        state::save_favorites(&self.state.favorites);
                    }
                }
            }
            None => {}
        }
    }

    fn network_tab(&mut self, ui: &mut egui::Ui) {
        if tabs::network(ui, &mut self.state, self.job.is_some(), self.geo.geoip.is_some()) {
            self.start_net_tool();
        }
    }

    fn live_connections_tab(&mut self, ui: &mut egui::Ui) {
        if tabs::live_connections(ui, &mut self.state, self.geo.geoip.is_some()) {
            self.state.tracker.set_filters(
                self.state.show_incoming, self.state.show_outgoing);
            self.state.tracker.set_direction_mode(self.state.direction_mode);
        }
    }

    fn scanner_tab(&mut self, ui: &mut egui::Ui) {
        if let Some(a) = tabs::scanner(ui, &mut self.state, self.scan.is_some()) {
            self.handle_scan_action(a);
        }
    }

    /// Gemeinsame Auswertung der Scanner-Aktion — genutzt vom Reiter und von
    /// der großen Ansicht (`fenster::scanner`).
    fn handle_scan_action(&mut self, a: tabs::ScanAction) {
        match a {
            tabs::ScanAction::Start => {
                let (from, to) = match tabs::pruefe_bereich(
                    self.state.scan_from, self.state.scan_to)
                {
                    Ok(v) => v,
                    Err(e) => {
                        self.state.scan_status = format!("❌ {e}");
                        return;
                    }
                };
                self.state.scan_results.clear();
                self.state.scan_progress = (0, 0);
                // Meldung und Zeitgrenze 1:1: "📊 Port-Range: a-b", 500 ms.
                self.state.scan_status =
                    format!("📊 Port-Range: {from}-{to} — scanne {} …", self.state.scan_target);
                self.scan = Some(ev_net::portscan::scan(
                    &self.state.scan_target, from, to, self.state.scan_threads, 500));
            }
            tabs::ScanAction::Stop => {
                if let Some(h) = &self.scan { h.stop(); }
                self.state.scan_status = "abgebrochen".into();
            }
            tabs::ScanAction::UseCommon => {
                // Erster und letzter Eintrag der gebräuchlichen Ports.
                let g = ev_net::portscan::COMMON_PORTS;
                self.state.scan_from = *g.first().unwrap_or(&1);
                self.state.scan_to = *g.last().unwrap_or(&1024);
            }
            tabs::ScanAction::UseAll => {
                self.state.scan_from = 1;
                self.state.scan_to = 65535;
            }
        }
    }

    /// Startet das im Netzwerk-Tab gewählte Werkzeug.
    fn start_net_tool(&mut self) {
        let target = self.state.tool_target.trim().to_string();
        if target.is_empty() {
            // network_tab.py: setText("❌ Bitte Ziel eingeben")
            self.state.tool_output.reset("");
            self.state.tool_output.push("❌ Bitte Ziel eingeben");
            self.state.tool_output.busy = false;
            return;
        }
        self.state.tool_output.reset(format!("{} {}", self.state.net_tool.label(), target));
        self.state.push_history(&target);
        self.job = Some(match self.state.net_tool {
            NetTool::Ping => tools::ping(&target, config::PING_COUNT),
            NetTool::Traceroute => {
                self.state.traceroute_markers.clear();
                self.state.traceroute_hops.clear();
                tools::traceroute(Arc::clone(&self.geo), &target, config::TRACEROUTE_MAX_HOPS)
            }
            NetTool::Whois => tools::whois(&target),
            NetTool::VirusTotal => tools::virustotal(&target),
            NetTool::Arp => tools::arp_scan(),
        });
        if self.state.loop_enabled {
            // network_tab.py: "\n🔄 Loop-Modus gestartet.\n"
            self.state.tool_output.push("🔄 Loop-Modus gestartet.");
            self.next_loop_run = Some(std::time::Instant::now()
                + std::time::Duration::from_secs_f32(self.state.loop_interval_s));
        }
    }

    /// Satelliten-Zentrale — Aufbau nach `satellite_integration.py`:
    /// Gruppen als Ankreuzfelder, darunter Einzelauswahl je Objekt.
    /// Satelliten-Zentrale — Aufbau nach `satellite_integration.py`:
    /// grosse Ueberschrift, Knopf „PRO Monitor oeffnen", darunter zwei
    /// umrahmte Gruppen („Globus Anzeige", „Aktive Satelliten").
    fn satellite_tab(&mut self, ui: &mut egui::Ui) {
        // Der ganze Reiter in einer Scrollfläche — sonst ist der eingeklappte
        // „Mehr"-Bereich unter der langen Satellitenliste nicht erreichbar
        // (Anno-Feedback: kein Scrollen möglich, nichts sichtbar).
        egui::ScrollArea::vertical()
            .id_salt("sat_tab_outer")
            .auto_shrink([false, false])
            .show(ui, |ui| {
        ui.label(
            egui::RichText::new("📡 Satelliten-Zentrale")
                .size(ev_core::theme::ui::FONT_GROSS)
                .strong(),
        );
        ui.add_space(4.0);
        // Tuerkiser Knopf ueber die volle Breite — oeffnet das SatMonitor-PRO-
        // Fenster (sat_monitor_window.py) mit Spektrum, Sat-Tracking und
        // Spectator API. Seit v2.1 vollstaendig portiert (fenster::sat_monitor).
        if tabs::breiter_knopf(ui, "🖥 PRO Monitor öffnen", true) {
            self.state.sat_pro_offen = !self.state.sat_pro_offen;
        }

        let mut umschalten: Option<&'static str> = None;
        tabs::gruppe(ui, "Globus Anzeige", |ui| {
            ui.checkbox(&mut self.state.show_satellites, "Auf Globus anzeigen");
            ui.add_space(2.0);
            ui.label("Kategorien:");
            for (anzeige, gruppe) in ev_sat::catalog::CATEGORY_GROUPS {
                let mut an = self.state.group_is_active(gruppe);
                if ui.checkbox(&mut an, *anzeige).changed() {
                    umschalten = Some(gruppe);
                }
            }
        });

        tabs::gruppe(ui, "Aktive Satelliten:", |ui| {
            ui.horizontal(|ui| {
                let b = (ui.available_width() - 8.0) / 2.0;
                if ui.add_sized([b, ev_core::theme::ui::HOEHE_KNOPF],
                                egui::Button::new("Alle auswählen")).clicked() {
                    self.state.sat_select_all();
                }
                if ui.add_sized([b, ev_core::theme::ui::HOEHE_KNOPF],
                                egui::Button::new("Alle abwählen")).clicked() {
                    self.state.sat_deselect_all();
                }
            });
            ui.add_space(4.0);

            let f = self.state.sat_filter.trim().to_lowercase();
            let zeilen: Vec<(usize, String, ev_sat::Category, bool, f64)> = self
                .state
                .satellites
                .iter()
                .enumerate()
                .filter(|(_, s)| f.is_empty() || s.name.to_lowercase().contains(&f))
                .take(500)
                .map(|(i, s)| {
                    (i, s.name.clone(), s.category,
                     self.state.sat_is_enabled(&s.name), s.altitude_km)
                })
                .collect();

            let mut geklickt: Option<String> = None;
            let mut gewaehlt: Option<usize> = None;
            egui::ScrollArea::vertical()
                .id_salt("satliste")
                .auto_shrink([false, false])
                .max_height(260.0)
                .show(ui, |ui| {
                    for (i, name, cat, an, alt) in &zeilen {
                        ui.horizontal(|ui| {
                            let mut c = *an;
                            if ui.checkbox(&mut c, "").changed() {
                                geklickt = Some(name.clone());
                            }
                            let rgb = cat.rgb();
                            let farbe = egui::Color32::from_rgb(
                                (rgb[0] * 255.0) as u8,
                                (rgb[1] * 255.0) as u8,
                                (rgb[2] * 255.0) as u8);
                            let sel = self.state.sat_selected == Some(*i);
                            let txt = egui::RichText::new(
                                format!("{name} ({})", cat.name()))
                                .size(ev_core::theme::ui::FONT_NORMAL)
                                .color(if *an { farbe }
                                       else { egui::Color32::from_gray(110) });
                            if ui.selectable_label(sel, txt)
                                .on_hover_text(format!("{alt:.0} km")).clicked()
                            {
                                gewaehlt = Some(*i);
                            }
                        });
                    }
                    if zeilen.is_empty() {
                        ui.weak("Keine TLE geladen — Kategorie anhaken.");
                    }
                });

            if let Some(n) = geklickt { self.state.sat_toggle(&n); }
            if let Some(i) = gewaehlt {
                self.state.sat_selected =
                    if self.state.sat_selected == Some(i) { None } else { Some(i) };
                self.rebuild_orbit();
                if let Some(s) = self.state.satellites.get(i) {
                    self.camera.align_to(s.lat, s.lon);
                }
            }

            let (aktiv, gesamt) = self.state.sat_active_count();
            ui.colored_label(
                egui::Color32::from_rgb(120, 220, 140),
                egui::RichText::new(format!("✅ {aktiv}/{gesamt} Satelliten aktiv"))
                    .size(ev_core::theme::ui::FONT_KLEIN),
            );
        });

        // Alles Folgende geht ueber das Original hinaus und ist deshalb
        // eingeklappt — sonst waere der Reiter nicht mehr 1:1.
        ui.collapsing("Mehr (über das Original hinaus)", |ui| {
            ui.horizontal_wrapped(|ui| {
                if ui.button("📦 Notreserve").on_hover_text(
                    "Eingebaute TLE — funktioniert ohne Internet").clicked()
                {
                    self.load_builtin_satellites();
                }
                for (anzeige, gruppe) in &ev_sat::catalog::CELESTRAK_GROUPS[4..] {
                    let mut an = self.state.group_is_active(gruppe);
                    if ui.checkbox(&mut an, *anzeige).changed() {
                        umschalten = Some(gruppe);
                    }
                }
            });
            if let Some(age) = self.state.sat_tle_age {
                let fr = ev_sat::Freshness::of(age);
                let c = fr.rgb();
                ui.horizontal(|ui| {
                    ui.small("TLE-Alter:");
                    ui.colored_label(egui::Color32::from_rgb(c[0], c[1], c[2]),
                        egui::RichText::new(format!("{age:.1} Tage — {}", fr.label()))
                            .size(ev_core::theme::ui::FONT_KLEIN));
                });
            }
            ui.small(&self.state.sat_status);
            ui.horizontal_wrapped(|ui| {
                ui.checkbox(&mut self.state.sat_show_orbit, "Bahn");
                ui.checkbox(&mut self.state.sat_show_ground_track, "Bodenspur");
                ui.checkbox(&mut self.state.sat_show_footprint, "Fußabdruck");
                let mut fest = self.state.sat_frame == Frame::EarthFixed;
                if ui.checkbox(&mut fest, "erdfest").changed() {
                    self.state.sat_frame =
                        if fest { Frame::EarthFixed } else { Frame::Inertial };
                    self.update_satellites(true);
                }
            });
            ui.add(egui::Slider::new(&mut self.state.sat_sprite_size, 8.0..=64.0)
                .text("Symbolgröße"));
            ui.horizontal(|ui| {
                ui.label("Filter:");
                ui.add(egui::TextEdit::singleline(&mut self.state.sat_filter)
                    .hint_text("Name…").desired_width(140.0));
            });
        });

        if let Some(g) = umschalten {
            self.toggle_group(g);
        }
        }); // Ende äußere ScrollArea
    }

    /// Gruppe an- oder abschalten. Port von `_toggle_category`.
    fn toggle_group(&mut self, gruppe: &str) {
        if let Some(i) = self.state.sat_active_groups.iter().position(|g| g == gruppe) {
            self.state.sat_active_groups.remove(i);
        } else {
            self.state.sat_active_groups.push(gruppe.to_string());
        }
        self.reload_active_groups();
    }

    /// Baut den Satellitenbestand aus allen angehakten Gruppen neu auf.
    fn reload_active_groups(&mut self) {
        let cache = config::session_dir();
        let mut alle: Vec<ev_sat::Tle> = Vec::new();
        let mut gesehen: Vec<u32> = Vec::new();
        for g in self.state.sat_active_groups.clone() {
            for tle in ev_sat::catalog::load_group(&g, &cache, true) {
                if tle.norad_id != 0 && gesehen.contains(&tle.norad_id) {
                    continue; // dieselbe ISS nicht dreimal
                }
                gesehen.push(tle.norad_id);
                alle.push(tle);
            }
        }
        if alle.is_empty() {
            self.sat_props.clear();
            self.state.satellites.clear();
            self.state.sat_selected = None;
            self.state.sat_orbit.clear();
            self.state.sat_track.clear();
            self.state.sat_tle_age = None;
            self.state.sat_status = if self.state.sat_active_groups.is_empty() {
                "Keine Kategorie angehakt".into()
            } else {
                "Keine TLE gefunden — offline? Notreserve nutzen.".into()
            };
            return;
        }
        let quelle = self.state.sat_active_groups.join(", ");
        self.install_tles(alle, &quelle);
    }

}
