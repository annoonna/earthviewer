//! Anwendungszustand — was im Python quer über MainWindow, Sidebar und
//! ein Dutzend Tab-Klassen verteilt lag, liegt hier an einer Stelle.
use ev_core::{GeoLocation, Theme};
use ev_net::{Connection, ConnectionTracker, DirectionMode};
use ev_sat::{Frame, SatState};
use std::sync::Arc;

/// Ansichts-Layout: klassisch (1:1-Original) oder GlasWire-artiges Dashboard.
/// Standard ist jetzt das Dashboard (Anno-Wunsch) — der klassische Modus
/// bleibt per Knopf oben bzw. Zahnrad-Dialog jederzeit erreichbar.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum LayoutModus {
    Klassisch,
    #[default]
    Dashboard,
}

/// Zeitfenster für den Dashboard-Graph — GlasWire: 5 Min / 3 Std / 24 Std /
/// Woche / Monat. Bestimmt, wie viele der 300 Messpunkte gezeigt werden.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum Zeitfenster {
    #[default]
    Min5,
    Std3,
    Std24,
    Woche,
    Monat,
}

impl Zeitfenster {
    pub const ALL: [Zeitfenster; 5] = [
        Zeitfenster::Min5, Zeitfenster::Std3, Zeitfenster::Std24,
        Zeitfenster::Woche, Zeitfenster::Monat,
    ];
    pub fn label(self) -> &'static str {
        match self {
            Zeitfenster::Min5 => "5 Min",
            Zeitfenster::Std3 => "3 Std",
            Zeitfenster::Std24 => "24 Std",
            Zeitfenster::Woche => "Woche",
            Zeitfenster::Monat => "Monat",
        }
    }
    /// Wie viele der jüngsten Messpunkte dieses Fenster zeigt. Der Tracker misst
    /// ~1 Punkt/s und hält 300; für längere Fenster nehmen wir alles, was da ist
    /// (echte Wochen-/Monatshistorie bräuchte Persistenz — Runde D).
    pub fn punkte(self) -> usize {
        match self {
            Zeitfenster::Min5 => 300,   // 5 min ~ 300 s bei 1 Hz
            _ => 300,                    // aktuell alles; mehr mit Persistenz
        }
    }
    /// Länge des Fensters in Minuten — für den persistenten Langzeitverlauf.
    /// `Min5` nutzt weiter den Sekunden-Livepuffer (siehe `nutzt_live`).
    pub fn minuten(self) -> usize {
        match self {
            Zeitfenster::Min5 => 5,
            Zeitfenster::Std3 => 3 * 60,
            Zeitfenster::Std24 => 24 * 60,
            Zeitfenster::Woche => 7 * 24 * 60,
            Zeitfenster::Monat => 30 * 24 * 60,
        }
    }
    /// 5-Minuten-Fenster nutzt den feinen Sekunden-Livepuffer, alle größeren
    /// den gemittelten Minutenverlauf.
    pub fn nutzt_live(self) -> bool {
        matches!(self, Zeitfenster::Min5)
    }
}

/// Die Tab-Leiste. Reihenfolge und Beschriftung 1:1 aus `sidebar.py`
/// (Zeilen 78–119), ergänzt um Satelliten und Einstellungen, die im Original
/// eigene Fenster bzw. Dialoge waren.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Tab {
    Control,        // ⚙ Steuerung
    Search,         // 🔍 Suche
    Favorites,      // ⭐ Favoriten
    Network,        // 🌐 Netzwerk
    LiveConnections,// 🔴 Live Verbindungen
    Monitoring,     // 📊 Monitoring
    ControlCenter,  // 🖥 Control Center
    Graph,          // 📈 Graph
    Protection,     // 🔒 Schützen
    Protocol,       // 📊 Protokoll Analyse
    Scanner,        // 🔍 Netzwerk Scanner
    Satellites,     // 📡 Satelliten  (Original: sat_monitor_window.py)
}

impl Tab {
    /// Genau die zwölf Reiter des Originals (sidebar.py + satellite_integration.py).
    /// „Einstellungen" ist KEIN Reiter — das Zahnrad öffnet wie im Original den
    /// Dialog „⚙️ Erweiterte Einstellungen" (main_window._show_settings).
    pub const ALL: [Tab; 12] = [
        Tab::Control, Tab::Search, Tab::Favorites, Tab::Network,
        Tab::LiveConnections, Tab::Monitoring, Tab::ControlCenter, Tab::Graph,
        Tab::Protection, Tab::Protocol, Tab::Scanner, Tab::Satellites,
    ];
    /// Kurzname für `$EARTHVIEWER_TAB` — erlaubt Screenshot-Tests einzelner
    /// Reiter ohne Mausklick. Beispiel: `EARTHVIEWER_TAB=graph ./start.sh 1`
    pub fn slug(&self) -> &'static str {
        match self {
            Self::Control => "control",
            Self::Search => "search",
            Self::Favorites => "favorites",
            Self::Network => "network",
            Self::LiveConnections => "live",
            Self::Monitoring => "monitoring",
            Self::ControlCenter => "center",
            Self::Graph => "graph",
            Self::Protection => "protection",
            Self::Protocol => "protocol",
            Self::Scanner => "scanner",
            Self::Satellites => "satellites",
        }
    }

    pub fn from_slug(s: &str) -> Option<Tab> {
        let s = s.trim().to_ascii_lowercase();
        Tab::ALL.iter().copied().find(|t| t.slug() == s)
    }

    fn from_env() -> Option<Tab> {
        Tab::from_slug(&std::env::var("EARTHVIEWER_TAB").ok()?)
    }

    pub fn label(&self) -> &'static str {
        match self {
            Self::Control => "⚙ Steuerung",
            Self::Search => "🔍 Suche",
            Self::Favorites => "⭐ Favoriten",
            Self::Network => "🌐 Netzwerk",
            Self::LiveConnections => "🔴 Live Verbindungen",
            Self::Monitoring => "📊 Monitoring",
            Self::ControlCenter => "🖥 Control Center",
            Self::Graph => "📈 Graph",
            Self::Protection => "🔒 Schützen",
            Self::Protocol => "📊 Protokoll Analyse",
            Self::Scanner => "🔍 Netzwerk Scanner",
            Self::Satellites => "📡 Satelliten",
        }
    }
}

/// Werkzeug im Netzwerk-Tab — Port des Combo-Feldes aus `network_tab.py`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[allow(dead_code)] // VirusTotal/Arp bleiben als Werkzeug-Varianten (Detailfenster).
pub enum NetTool { Ping, Traceroute, Whois, VirusTotal, Arp }

impl NetTool {
    /// Exakt das Original-Auswahlfeld (network_tab.py, Zeile 40):
    /// Traceroute, Ping, WHOIS — nicht mehr. VirusTotal und ARP bleiben als
    /// Varianten für Detailfenster/Control-Center erreichbar, stehen aber
    /// nicht in der Combo, weil sie dort im Original nicht standen.
    pub const ALL: [NetTool; 3] = [
        NetTool::Traceroute, NetTool::Ping, NetTool::Whois,
    ];
    pub fn label(&self) -> &'static str {
        match self {
            Self::Ping => "Ping",
            Self::Traceroute => "Traceroute",
            Self::Whois => "WHOIS",
            Self::VirusTotal => "VirusTotal",
            Self::Arp => "ARP-Nachbarschaft",
        }
    }
}

/// Ergebnis eines Werkzeug-Laufs (Ping/Traceroute/WHOIS/VirusTotal).
#[derive(Clone, Debug, Default)]
pub struct ToolOutput {
    pub title: String,
    pub lines: Vec<String>,
    pub busy: bool,
}

impl ToolOutput {
    pub fn push(&mut self, line: impl Into<String>) {
        self.lines.push(line.into());
        if self.lines.len() > 500 { self.lines.drain(..100); }
    }
    pub fn reset(&mut self, title: impl Into<String>) {
        self.title = title.into();
        self.lines.clear();
        self.busy = true;
    }
}

pub struct AppState {
    // Suche & Marker
    pub search_query: String,
    pub search_results: Vec<GeoLocation>,
    pub target_marker: Option<GeoLocation>,
    pub traceroute_markers: Vec<GeoLocation>,
    /// Volle Hop-Daten der letzten Traceroute (VisualTraceroute-Tabelle).
    pub traceroute_hops: Vec<ev_net::traceroute::TracerouteHop>,
    /// Ziel-Verlauf für Autocomplete (jüngste zuerst), persistent.
    pub tool_history: Vec<String>,

    // Netzwerk
    pub tracker: ConnectionTracker,
    /// Geodaten (für ASN-/Provider-Lookups in Detailfenstern).
    pub geo: std::sync::Arc<ev_geo::GeoDataManager>,
    pub connections: Vec<Connection>,
    pub show_incoming: bool,
    pub show_outgoing: bool,
    pub direction_mode: DirectionMode,
    pub home: GeoLocation,

    // Satelliten
    pub satellites: Vec<SatState>,
    pub sat_frame: Frame,
    pub show_satellites: bool,
    pub sat_status: String,
    /// Ausgewählter Satellit -> Orbit, Bodenspur und Fußabdruck zeichnen.
    /// (Gpredict-Issue #94: pro Satellit ein/ausschaltbar.)
    pub sat_selected: Option<usize>,
    pub sat_show_orbit: bool,
    pub sat_show_ground_track: bool,
    pub sat_show_footprint: bool,
    /// Kantenlaenge der Satelliten-Symbole in Pixeln (Original: 32).
    pub sat_sprite_size: f32,
    /// Merker fuer den Knopf „PRO Monitor oeffnen".
    pub sat_pro_offen: bool,
    // ── SatMonitor PRO (sat_monitor_window.py) ──────────────────────────────
    pub pro_tab: u8,             // 0 Spektrum · 1 Sat-Tracking · 2 Spectator API
    pub spec_freq: String,       // Center Freq (Hz) — Textfeld wie im Original
    pub spec_rate: String,       // Sample Rate (Hz)
    pub spec_fft: usize,         // FFT Size 256..8192
    pub spec_profile: usize,     // Index in ["— kein Sat-Profil —", NOAA, …]
    pub spec_source: usize,      // 0 Simulation · 1 RTL-SDR
    pub spec_pattern: usize,     // Index in spektrum::MUSTER
    pub spec_diagram: usize,     // 0 Linie · 1 Linie+Wasserfall
    pub spec_color: usize,       // Index in spektrum::FARBSCHEMA
    pub spec_running: bool,
    pub spec_status: String,
    pub spec_psd: Vec<f64>,      // letztes Spektrum (dB)
    pub spec_freqs: Vec<f64>,    // zugehörige Frequenzachse (Hz)
    pub spec_wasserfall: Vec<Vec<f64>>, // Verlaufszeilen für den Wasserfall
    pub track_filter: String,    // Sat-Tracking: Namensfilter
    /// Angehakte Celestrak-Gruppen — Port von `satellite_integration.cat_checks`.
    pub sat_active_groups: Vec<String>,
    /// Einzeln abgewaehlte Satelliten (Name). Port von `sat_checkboxes`;
    /// standardmaessig ist alles an, deshalb wird nur das Abgewaehlte gehalten.
    pub sat_disabled: std::collections::BTreeSet<String>,
    pub sat_filter: String,
    /// Alter der geladenen TLE in Tagen (Gpredict-Issue #4).
    pub sat_tle_age: Option<f64>,
    pub sat_orbit: Vec<glam::Vec3>,
    pub sat_track: Vec<glam::Vec3>,

    // Darstellung
    pub theme: Theme,
    pub show_markers: bool,
    pub show_labels: bool,
    pub marker_offset: f32,
    pub animation_speed: f32,

    /// Statuszeile unter dem Kopf ("Status: 50 Ergebnisse gefunden").
    pub status: String,
    /// Gewaehlte Ansicht im Auswahlfeld des Steuerungs-Reiters.
    pub ansicht: String,
    /// Durchsatzmessung fuer Monitoring und Graph (KB/s, wie im Original).
    pub meter: ev_net::ThroughputMeter,
    pub rate_history: Vec<ev_net::Rate>,

    // Monitoring / Graph / Protokoll
    pub monitor: ev_net::NetworkMonitor,
    pub started: std::time::Instant,

    // Schützen
    pub blocklist: ev_net::BlockList,
    pub block_input: String,
    pub selected_blocked: Option<usize>,

    // Scanner
    pub scan_target: String,
    pub scan_from: u16,
    pub scan_to: u16,
    pub scan_threads: usize,
    pub scan_results: Vec<ev_net::portscan::OpenPort>,
    pub scan_progress: (u32, u32),
    pub scan_status: String,

    // Favoriten
    pub favorites: Vec<GeoLocation>,

    // Netzwerk-Tab
    pub net_tool: NetTool,
    pub tool_target: String,
    pub loop_enabled: bool,
    pub loop_interval_s: f32,

    // UI
    pub tab: Tab,
    /// Ansichts-Layout. `Klassisch` = 1:1-Seitenleiste des Originals (Standard,
    /// erhält die Parität). `Dashboard` = GlasWire-artige moderne Ansicht mit
    /// Zeit-Graph und Icon-Navleiste. Umschaltbar im Zahnrad-Dialog.
    pub layout: LayoutModus,
    /// Gewähltes Zeitfenster im Dashboard-Graph (GlasWire: 5m/3h/24h/Woche/Monat).
    pub zeitfenster: Zeitfenster,
    /// Überwachungs-Einstellungen (Favoriten, Schwelle) — Runde D.
    pub watch: crate::alerts::WatchConfig,
    /// Alarm-/Benachrichtigungsprotokoll — Runde D.
    pub alarme: crate::alerts::AlarmProtokoll,
    /// Persistenter Langzeit-Durchsatzverlauf (Minuten-Eimer) — für echte
    /// Wochen-/Monats-Zeitfenster im Dashboard.
    pub rate_verlauf: crate::ratehist::RateVerlauf,
    /// Karten-Kachel-Ebene an? (Runde D Teil 2 — Google-Earth-artiges Nachladen)
    pub tiles_an: bool,
    /// Gewählte Kachel-Quelle (OSM Straße / NASA GIBS Satellit).
    pub tile_quelle_osm: bool,
    /// Kachel-Lader (lazy, erst bei Einschalten erzeugt).
    pub tile_loader: Option<crate::tileloader::TileLoader>,

    // ── Große Ansichten (Ports der QDialog-Fenster des Originals) ──────────
    pub win_monitor: bool,     // network_monitor_window.py  „Network Monitor (Live)"
    pub win_live: bool,        // live_connections_window.py „Große Live-Analyse"
    pub win_cc: bool,          // control_center_window.py   „WLAN Control Center – Erweiterte Ansicht"
    pub win_graph: bool,       // graph_large_window.py
    pub win_protection: bool,  // protection_large_window.py
    pub win_protocol: bool,    // protocol_large_window.py
    pub win_scanner: bool,     // scanner_large_window.py
    pub win_clients: bool,     // Netzwerk-Clients (Unterfenster des Control Centers)
    pub win_settings: bool,    // „⚙️ Erweiterte Einstellungen" (main_window._show_settings)

    // ── Control-Center-Zustand (WLAN Control Center) ───────────────────────
    pub cc_tab: u8,            // 0 WiFi Monitor · 1 Live Statistiken · 2 Einstellungen
    pub cc_interface: String,  // z. B. wlan0
    pub cc_aggressive: bool,   // „Aggressiver Modus (airmon-ng check kill)"
    pub cc_console: Vec<String>,
    pub vt_api_key: String,
    pub vt_autoscan: bool,
    pub vt_status: String,

    // ── Live-Verbindungen (Reiter) ─────────────────────────────────────────
    pub tracking_on: bool,     // ▶ Tracking starten / ⏸ Tracking pausieren
    pub live_speed: i32,       // 🎬 Animations-Geschwindigkeit 1..10 (Original: 5)
    /// Offenes Detailfenster — Port von `_show_*_details`.
    pub detail: Option<crate::detail::Detail>,
    pub tool_output: ToolOutput,
    pub selected_connection: Option<usize>,
}

impl AppState {
    pub fn new(geo: Arc<ev_geo::GeoDataManager>) -> Self {
        let s = ev_core::settings::global();
        let (theme_name, show_markers, show_labels, marker_offset, rotate_speed) = {
            let g = s.lock().expect("settings poisoned");
            (
                g.get_string("theme", ev_core::theme::DEFAULT_THEME),
                g.get_bool("show_markers", true),
                g.get_bool("show_labels", true),
                g.get_f32("marker_offset", ev_core::config::MARKER_OFFSET),
                g.get_f32("auto_rotate_speed", ev_core::config::AUTO_ROTATE_SPEED),
            )
        };
        let _ = rotate_speed;

        Self {
            search_query: String::new(),
            search_results: Vec::new(),
            target_marker: None,
            traceroute_markers: Vec::new(),
            traceroute_hops: Vec::new(),
            tool_history: load_history(),

            tracker: ConnectionTracker::new(Arc::clone(&geo)),
            geo,
            connections: Vec::new(),
            show_incoming: true,
            show_outgoing: true,
            direction_mode: DirectionMode::Balanced5050,
            // Heimatpunkt für die Verbindungsbögen. Ohne GeoIP auf die
            // eigene IP gibt es keinen besseren Startwert als Leipzig.
            home: GeoLocation::new("Hier", 51.3397, 12.3731).with_country("Germany"),

            satellites: Vec::new(),
            sat_frame: Frame::nach_treue(),
            show_satellites: true,
            sat_status: "Keine TLE geladen".into(),
            sat_selected: None,
            sat_show_orbit: true,
            sat_show_ground_track: false,
            sat_show_footprint: true,
            sat_sprite_size: 32.0,
            sat_pro_offen: false,
            pro_tab: 0,
            // Originalvorgaben aus sat_monitor_window.py:
            spec_freq: "137000000".into(),
            spec_rate: "2400000".into(),
            spec_fft: 2048,
            spec_profile: 0,
            spec_source: 0,
            spec_pattern: 0,
            spec_diagram: 0,
            spec_color: 0,
            spec_running: false,
            spec_status: "Bereit".into(),
            spec_psd: Vec::new(),
            spec_freqs: Vec::new(),
            spec_wasserfall: Vec::new(),
            track_filter: String::new(),
            sat_active_groups: Vec::new(),
            sat_disabled: Default::default(),
            sat_filter: String::new(),
            sat_tle_age: None,
            sat_orbit: Vec::new(),
            sat_track: Vec::new(),

            theme: ev_core::theme::theme_by_name(&theme_name),
            show_markers,
            show_labels,
            marker_offset,
            animation_speed: 0.5,

            status: "Bereit".into(),
            ansicht: "Deutschland".into(),
            meter: ev_net::ThroughputMeter::new(),
            rate_history: Vec::new(),
            monitor: ev_net::NetworkMonitor::new(),
            started: std::time::Instant::now(),

            blocklist: ev_net::BlockList::load(&ev_core::config::session_dir().join("blocklist.txt")),
            block_input: String::new(),
            selected_blocked: None,

            scan_target: "127.0.0.1".into(),
            // 1:1 wie network_scanner_tab.py: port_start=1, port_end=65535.
            scan_from: 1,
            scan_to: 65535,
            scan_threads: 100,
            scan_results: Vec::new(),
            scan_progress: (0, 0),
            scan_status: "bereit".into(),

            favorites: load_favorites(),

            net_tool: NetTool::Traceroute,
            // network_tab.py: Feld startet LEER, Platzhalter "z.B. golem.de oder 8.8.8.8".
            tool_target: String::new(),
            loop_enabled: false,
            // network_tab.py: setRange(5, 300), setValue(30), setSuffix(" s")
            loop_interval_s: 30.0,

            tab: Tab::from_env().unwrap_or(Tab::Control),
            layout: match std::env::var("EARTHVIEWER_LAYOUT").as_deref() {
                Ok("dashboard") => LayoutModus::Dashboard,
                Ok("klassisch") | Ok("classic") => LayoutModus::Klassisch,
                _ => LayoutModus::default(),
            },
            zeitfenster: Zeitfenster::default(),
            watch: crate::alerts::WatchConfig::laden(),
            alarme: crate::alerts::AlarmProtokoll::default(),
            rate_verlauf: crate::ratehist::RateVerlauf::laden(),
            tiles_an: false,
            tile_quelle_osm: true,
            tile_loader: None,
            detail: None,
            tool_output: ToolOutput::default(),
            selected_connection: None,

            win_monitor: false,
            win_live: false,
            win_cc: false,
            win_graph: false,
            win_protection: false,
            win_protocol: false,
            win_scanner: false,
            win_clients: false,
            win_settings: false,

            cc_tab: 0,
            cc_interface: "wlan0".into(),
            cc_aggressive: false,
            cc_console: vec!["🔍 Gefundene Interfaces: wlan0".into()],
            vt_api_key: std::env::var("EARTHVIEWER_VT_API_KEY").unwrap_or_default(),
            vt_autoscan: true,
            vt_status: String::new(),

            tracking_on: true,
            live_speed: 5,
        }
    }

    /// Alle Marker mit ihrer Theme-Farbe — Grundlage für Labels und GL-Batches.
    pub fn marker_entries(&self) -> Vec<(GeoLocation, [u8; 3])> {
        let mut v = Vec::new();
        for l in &self.search_results {
            v.push((l.clone(), self.theme.label_search));
        }
        for l in &self.traceroute_markers {
            v.push((l.clone(), self.theme.label_traceroute));
        }
        if let Some(t) = &self.target_marker {
            v.push((t.clone(), self.theme.label_target));
        }
        v
    }

    /// Verbindungen mit bekannter Position — nur die kann man zeichnen.
    pub fn locatable_connections(&self) -> Vec<&Connection> {
        self.connections.iter().filter(|c| c.lat != 0.0 || c.lon != 0.0).collect()
    }

    pub fn clear_markers(&mut self) {
        self.search_results.clear();
        self.target_marker = None;
        self.traceroute_markers.clear();
    }

    /// Sichtbare Satelliten: Einzelauswahl, Kategorie- und Namensfilter.
    pub fn visible_satellites(&self) -> Vec<(usize, &ev_sat::SatState)> {
        let f = self.sat_filter.trim().to_lowercase();
        self.satellites
            .iter()
            .enumerate()
            .filter(|(_, s)| !self.sat_disabled.contains(&s.name))
            .filter(|(_, s)| f.is_empty() || s.name.to_lowercase().contains(&f))
            .collect()
    }

    /// Ist dieser Satellit angehakt? Port von `sat_checkboxes[name].isChecked()`.
    pub fn sat_is_enabled(&self, name: &str) -> bool {
        !self.sat_disabled.contains(name)
    }

    pub fn sat_toggle(&mut self, name: &str) {
        if !self.sat_disabled.remove(name) {
            self.sat_disabled.insert(name.to_string());
        }
    }

    /// Port von `_select_all`.
    pub fn sat_select_all(&mut self) {
        self.sat_disabled.clear();
    }

    /// Port von `_deselect_all`.
    pub fn sat_deselect_all(&mut self) {
        self.sat_disabled = self.satellites.iter().map(|s| s.name.clone()).collect();
    }

    /// Zaehler fuer die Fusszeile: `✅ 21/21 Satelliten aktiv`.
    pub fn sat_active_count(&self) -> (usize, usize) {
        let aktiv = self.satellites.iter().filter(|s| self.sat_is_enabled(&s.name)).count();
        (aktiv, self.satellites.len())
    }

    pub fn group_is_active(&self, group: &str) -> bool {
        self.sat_active_groups.iter().any(|g| g == group)
    }

    /// Zoomfaktor wie in der Fusszeile des Originals ("Zoom: 5.9x").
    /// Bezugspunkt ist der Standardabstand der Kamera.
    pub fn zoom_factor(distance: f32) -> f32 {
        (ev_core::config::CAMERA_MAX_DISTANCE / distance.max(1e-3)).max(0.1)
    }

    /// Haengt eine Rate an den Verlauf. Das Original haelt 300 Punkte.
    pub fn push_rate(&mut self, r: ev_net::Rate) {
        if self.monitor.paused { return; }
        self.rate_history.push(r);
        if self.rate_history.len() > 300 {
            let cut = self.rate_history.len() - 300;
            self.rate_history.drain(..cut);
        }
    }

    pub fn connection_stats(&self) -> (usize, usize, usize) {
        let inc = self.connections.iter().filter(|c| c.is_incoming()).count();
        let out = self.connections.len() - inc;
        (self.connections.len(), inc, out)
    }
}

// ── Favoriten ───────────────────────────────────────────────────────────────
// Das Original hielt sie nur im Speicher (`sidebar._create_favorites_tab`),
// beim Beenden waren sie weg. Hier landen sie in sessions/favorites.json.
fn favorites_path() -> std::path::PathBuf {
    ev_core::config::session_dir().join("favorites.json")
}

pub fn load_favorites() -> Vec<GeoLocation> {
    std::fs::read_to_string(favorites_path())
        .ok()
        .and_then(|s| serde_json::from_str::<Vec<GeoLocation>>(&s).ok())
        .unwrap_or_default()
}

pub fn save_favorites(favs: &[GeoLocation]) {
    let _ = std::fs::create_dir_all(ev_core::config::session_dir());
    if let Ok(s) = serde_json::to_string_pretty(favs) {
        let _ = std::fs::write(favorites_path(), s);
    }
}

// ── Werkzeug-Verlauf (Autocomplete für Traceroute/Ping/WHOIS-Ziele) ──────────
// VisualTraceroute-Idee: jüngste Ziele merken und als Vorschläge anbieten.
fn history_path() -> std::path::PathBuf {
    ev_core::config::session_dir().join("tool_history.json")
}

pub fn load_history() -> Vec<String> {
    std::fs::read_to_string(history_path())
        .ok()
        .and_then(|s| serde_json::from_str::<Vec<String>>(&s).ok())
        .unwrap_or_default()
}

pub fn save_history(hist: &[String]) {
    let _ = std::fs::create_dir_all(ev_core::config::session_dir());
    if let Ok(s) = serde_json::to_string_pretty(hist) {
        let _ = std::fs::write(history_path(), s);
    }
}

impl AppState {
    /// Ein Ziel in den Verlauf aufnehmen (jüngstes zuerst, max. 20, dedupliziert).
    pub fn push_history(&mut self, ziel: &str) {
        let z = ziel.trim();
        if z.is_empty() { return; }
        self.tool_history.retain(|h| h != z);
        self.tool_history.insert(0, z.to_string());
        self.tool_history.truncate(20);
        save_history(&self.tool_history);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn state() -> AppState {
        let geo = Arc::new(ev_geo::GeoDataManager {
            data_root: "/nonexistent".into(), locations: vec![], geoip: None, asn: None,
        });
        AppState::new(geo)
    }

    #[test]
    fn all_original_tabs_are_present() {
        // Die 11 Reiter aus sidebar.py (Zeilen 78-119) + Satelliten aus
        // satellite_integration.py (addTab "🛰️ Satelliten") = 12 Reiter.
        // "Einstellungen" ist KEIN Reiter, sondern der Zahnrad-Dialog.
        let labels: Vec<&str> = Tab::ALL.iter().map(|t| t.label()).collect();
        for expected in [
            "⚙ Steuerung", "🔍 Suche", "⭐ Favoriten", "🌐 Netzwerk",
            "🔴 Live Verbindungen", "📊 Monitoring", "🖥 Control Center",
            "📈 Graph", "🔒 Schützen", "📊 Protokoll Analyse",
            "🔍 Netzwerk Scanner", "📡 Satelliten",
        ] {
            assert!(labels.contains(&expected), "Reiter fehlt: {expected}");
        }
        assert_eq!(Tab::ALL.len(), 12);
    }

    #[test]
    fn tab_labels_are_unique() {
        let mut labels: Vec<&str> = Tab::ALL.iter().map(|t| t.label()).collect();
        labels.sort_unstable();
        let before = labels.len();
        labels.dedup();
        assert_eq!(labels.len(), before, "doppelte Reiter-Beschriftung");
    }

    #[test]
    fn slugs_are_unique_and_roundtrip() {
        let mut slugs: Vec<&str> = Tab::ALL.iter().map(|t| t.slug()).collect();
        for t in Tab::ALL {
            assert_eq!(Tab::from_slug(t.slug()), Some(t));
            assert_eq!(Tab::from_slug(&t.slug().to_uppercase()), Some(t));
        }
        slugs.sort_unstable();
        let n = slugs.len();
        slugs.dedup();
        assert_eq!(slugs.len(), n, "doppelter Slug");
        assert_eq!(Tab::from_slug("gibtsnicht"), None);
    }

    #[test]
    fn labels_have_no_variation_selectors() {
        // U+FE0F rendert in egui als leeres Kästchen hinter dem Symbol.
        for t in Tab::ALL {
            assert!(!t.label().contains('\u{fe0f}'), "FE0F in {:?}", t.slug());
        }
    }

    #[test]
    fn zoom_factor_grows_when_zooming_in() {
        let weit = AppState::zoom_factor(ev_core::config::CAMERA_MAX_DISTANCE);
        let nah = AppState::zoom_factor(ev_core::config::CAMERA_MIN_DISTANCE);
        assert!((weit - 1.0).abs() < 1e-4, "ganz raus = 1.0x, ist {weit}");
        assert!(nah > weit, "reinzoomen muss den Faktor erhoehen");
    }

    #[test]
    fn rate_history_is_capped_at_300() {
        let mut s = state();
        for i in 0..500 {
            s.push_rate(ev_net::Rate { down_bps: i as f64, up_bps: 0.0 });
        }
        assert_eq!(s.rate_history.len(), 300);
        assert_eq!(s.rate_history.last().unwrap().down_bps, 499.0);
    }

    #[test]
    fn pause_stops_rate_history() {
        let mut s = state();
        s.push_rate(ev_net::Rate { down_bps: 1.0, up_bps: 0.0 });
        s.monitor.paused = true;
        s.push_rate(ev_net::Rate { down_bps: 2.0, up_bps: 0.0 });
        assert_eq!(s.rate_history.len(), 1);
    }

    fn mit_satelliten() -> AppState {
        let mut s = state();
        let mk = |n: &str, c| ev_sat::SatState {
            name: n.into(), norad_id: 1, category: c,
            position: glam::Vec3::Y, speed_km_s: 7.6, altitude_km: 420.0,
            lat: 0.0, lon: 0.0,
        };
        s.satellites = vec![
            mk("ISS (ZARYA)", ev_sat::Category::Iss),
            mk("STARLINK-1007", ev_sat::Category::Starlink),
            mk("NOAA 19", ev_sat::Category::Weather),
        ];
        s
    }

    #[test]
    fn name_filter_narrows_the_list() {
        let mut s = mit_satelliten();
        assert_eq!(s.visible_satellites().len(), 3);
        s.sat_filter = "starlink".into();
        assert_eq!(s.visible_satellites().len(), 1);
        s.sat_filter.clear();
        s.sat_toggle("NOAA 19");
        assert_eq!(s.visible_satellites().len(), 2);
    }

    #[test]
    fn net_tools_are_complete() {
        // network_tab.py: addItems(["Traceroute", "Ping", "WHOIS"]) — exakt drei.
        assert_eq!(NetTool::ALL.len(), 3);
        assert_eq!(NetTool::ALL[0], NetTool::Traceroute);
        assert!(NetTool::ALL.iter().all(|t| !t.label().is_empty()));
    }

    #[test]
    fn marker_entries_collect_all_kinds() {
        let mut s = state();
        s.search_results.push(GeoLocation::new("A", 1.0, 2.0));
        s.traceroute_markers.push(GeoLocation::new("B", 3.0, 4.0));
        s.target_marker = Some(GeoLocation::new("C", 5.0, 6.0));
        assert_eq!(s.marker_entries().len(), 3);
        s.clear_markers();
        assert!(s.marker_entries().is_empty());
    }

    #[test]
    fn tool_output_ring_buffer_caps_at_500() {
        let mut o = ToolOutput::default();
        o.reset("Ping");
        for i in 0..700 { o.push(format!("line {i}")); }
        assert!(o.lines.len() <= 500, "len = {}", o.lines.len());
        assert!(o.lines.last().unwrap().ends_with("699"));
    }

    #[test]
    fn tool_output_reset_clears_and_marks_busy() {
        let mut o = ToolOutput::default();
        o.push("alt");
        o.reset("Traceroute");
        assert!(o.lines.is_empty() && o.busy);
        assert_eq!(o.title, "Traceroute");
    }

    #[test]
    fn locatable_filters_zero_coordinates() {
        let mut s = state();
        let mk = |lat: f32, lon: f32| ev_net::Connection {
            local_ip: "10.0.0.1".into(), local_port: 1, remote_ip: "1.1.1.1".into(),
            remote_port: 443, protocol: "TCP".into(), direction: ev_net::Direction::Outgoing,
            app_name: "x".into(), pid: 1, bytes_sent: 0, bytes_recv: 0, timestamp: 0.0,
            country: "".into(), city: "".into(), lat, lon,
        };
        s.connections = vec![mk(0.0, 0.0), mk(51.3, 12.4)];
        assert_eq!(s.locatable_connections().len(), 1);
    }

    #[test]
    fn connection_stats_split_directions() {
        let mut s = state();
        let mk = |d: ev_net::Direction| ev_net::Connection {
            local_ip: "10.0.0.1".into(), local_port: 1, remote_ip: "1.1.1.1".into(),
            remote_port: 443, protocol: "TCP".into(), direction: d,
            app_name: "x".into(), pid: 1, bytes_sent: 0, bytes_recv: 0, timestamp: 0.0,
            country: "".into(), city: "".into(), lat: 1.0, lon: 1.0,
        };
        s.connections = vec![
            mk(ev_net::Direction::Incoming),
            mk(ev_net::Direction::Outgoing),
            mk(ev_net::Direction::Outgoing),
        ];
        assert_eq!(s.connection_stats(), (3, 1, 2));
    }
}

