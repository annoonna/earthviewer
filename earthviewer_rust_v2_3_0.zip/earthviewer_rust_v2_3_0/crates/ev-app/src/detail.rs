//! Detailfenster — Port von `host_detail_window.py`, `country_detail_window.py`
//! und `process_detail_window.py`.
//!
//! In PyQt6 waren das drei `QDialog`-Klassen, geoeffnet ueber `itemClicked`
//! in `network_stats_widget.py`. In egui sind es schwebende `egui::Window`;
//! welches offen ist, haelt [`Detail`] fest.

use crate::state::AppState;
use ev_net::monitor::format_bytes;

/// Welches Detailfenster gerade offen ist. Hoechstens eines, wie im Original.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Detail {
    Host(String),
    Land(String),
    Prozess(String),
}

impl Detail {
    pub fn titel(&self) -> String {
        match self {
            Self::Host(ip) => format!("🖥 Host Details - {ip}"),
            Self::Land(l) => format!("{} - Details", l),
            Self::Prozess(p) => format!("📊 {p} - Details"),
        }
    }
}

/// Herausgeber aus dem Prozessnamen — Port von `_update_all_data`.
/// Das Original kannte genau diese drei Faelle.
pub fn herausgeber(prozess: &str) -> &'static str {
    let p = prozess.to_ascii_lowercase();
    if p.contains("firefox") {
        "Mozilla Corporation"
    } else if p.contains("chrome") || p.contains("chromium") {
        "Google LLC / Chromium"
    } else {
        "Unknown"
    }
}

/// Pfad zur ausfuehrbaren Datei ueber `/proc/<pid>/exe`.
/// Ersetzt `psutil.Process(pid).exe()`.
pub fn programmpfad(pid: i32) -> Option<String> {
    if pid <= 0 {
        return None;
    }
    std::fs::read_link(format!("/proc/{pid}/exe"))
        .ok()
        .map(|p| p.to_string_lossy().into_owned())
}

/// Verbindungen eines Prozesses.
fn conns_von_app<'a>(st: &'a AppState, app: &str) -> Vec<&'a ev_net::Connection> {
    st.connections.iter().filter(|c| c.app_name == app).collect()
}

/// Verbindungen zu einem Host.
fn conns_zu_host<'a>(st: &'a AppState, ip: &str) -> Vec<&'a ev_net::Connection> {
    st.connections.iter().filter(|c| c.remote_ip == ip).collect()
}

/// Verbindungen in ein Land. `land` ist der angezeigte Name (Fahne + Klartext).
fn conns_in_land<'a>(st: &'a AppState, land: &str) -> Vec<&'a ev_net::Connection> {
    st.connections
        .iter()
        .filter(|c| ev_core::country::flag_and_name(&c.country) == land)
        .collect()
}

/// Zeichnet das offene Detailfenster. Gibt `false` zurueck, wenn geschlossen.
pub fn zeige(ctx: &egui::Context, st: &AppState, detail: &Detail) -> bool {
    let mut offen = true;
    egui::Window::new(detail.titel())
        .open(&mut offen)
        .resizable(true)
        .default_width(430.0)
        .default_height(360.0)
        .show(ctx, |ui| match detail {
            Detail::Host(ip) => host(ui, st, ip),
            Detail::Land(l) => land(ui, st, l),
            Detail::Prozess(p) => prozess(ui, st, p),
        });
    offen
}

fn zeile(ui: &mut egui::Ui, k: &str, v: String) {
    ui.horizontal(|ui| {
        ui.label(egui::RichText::new(k).color(egui::Color32::from_gray(170)));
        ui.strong(v);
    });
}

// ── 🖥 Host Details ─────────────────────────────────────────────────────────
fn host(ui: &mut egui::Ui, st: &AppState, ip: &str) {
    let conns = conns_zu_host(st, ip);
    let hostname = ev_net::classify::reverse_dns(ip);
    let klasse = ev_net::classify(ip);

    zeile(ui, "Hostname:", hostname.unwrap_or_else(|| "Nicht verfügbar".into()));
    zeile(
        ui,
        "Land:",
        conns
            .first()
            .filter(|c| !c.country.is_empty())
            .map(|c| ev_core::country::flag_and_name(&c.country))
            .unwrap_or_else(|| "Unbekannt".into()),
    );
    zeile(ui, "Adresstyp:", klasse.map(|k| k.label().to_string())
        .unwrap_or_else(|| "unbekannt".into()));
    // Provider/Netzbetreiber aus der ASN-Datenbank (Runde D).
    if let Some((asn, org)) = st.geo.asn_lookup(ip) {
        if !org.is_empty() {
            zeile(ui, "Provider:", format!("AS{asn} · {org}"));
        }
    }
    zeile(ui, "Total Traffic:", format_bytes(
        st.monitor.hosts.get(ip).map(|b| b.total).unwrap_or(0.0) * 1024.0));
    // 🟢 (U+1F7E2, Unicode 12.0) fehlt in egui's NotoEmoji und erschien als
    // leeres Kaestchen — deshalb farbiger Text statt Emoji.
    ui.horizontal(|ui| {
        ui.label(egui::RichText::new("Status:").color(egui::Color32::from_gray(170)));
        if conns.is_empty() {
            ui.colored_label(egui::Color32::from_gray(150), "inaktiv");
        } else {
            ui.colored_label(egui::Color32::from_rgb(120, 220, 140), "Active");
        }
    });
    zeile(ui, "Verbindungen:", conns.len().to_string());

    ui.add_space(6.0);
    ui.separator();
    ui.strong("📊 Traffic Details");
    egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
        egui::Grid::new("hostdet").striped(true).num_columns(4).show(ui, |ui| {
            for h in ["Prozess", "Port", "Prot.", "Ort"] { ui.strong(h); }
            ui.end_row();
            for c in &conns {
                ui.label(&c.app_name);
                ui.label(c.remote_port.to_string());
                ui.label(&c.protocol);
                ui.label(if c.city.is_empty() { "—".into() } else { c.city.clone() });
                ui.end_row();
            }
        });
        if conns.is_empty() { ui.weak("Keine offenen Verbindungen zu diesem Host."); }
    });

    ui.separator();
    ui.horizontal(|ui| {
        let blockiert = st.blocklist.is_blocked(ip);
        ui.label(if blockiert { "🚫 blockiert" } else { "nicht blockiert" });
    });
}

// ── Land Details ────────────────────────────────────────────────────────────
fn land(ui: &mut egui::Ui, st: &AppState, name: &str) {
    let conns = conns_in_land(st, name);
    let gesamt: f64 = st.monitor.countries.values().map(|b| b.total).sum();
    let eigen = conns.len() as f64;
    let anteil = if gesamt > 0.0 { eigen / gesamt * 100.0 } else { 0.0 };

    let mut hosts: Vec<&str> = conns.iter().map(|c| c.remote_ip.as_str()).collect();
    hosts.sort_unstable();
    hosts.dedup();

    zeile(ui, "Total Traffic:", format_bytes(eigen * 1024.0));
    zeile(ui, "Anteil:", format!("{anteil:.1}%"));
    zeile(ui, "Hosts:", hosts.len().to_string());
    zeile(ui, "Verbindungen:", conns.len().to_string());

    ui.add_space(6.0);
    ui.separator();
    ui.strong("🖥 Hosts aus diesem Land");
    egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
        egui::Grid::new("landdet").striped(true).num_columns(3).show(ui, |ui| {
            for h in ["Host", "Stadt", "Prozess"] { ui.strong(h); }
            ui.end_row();
            for ip in &hosts {
                let erste = conns.iter().find(|c| c.remote_ip == **ip);
                ui.label(egui::RichText::new(*ip).monospace());
                ui.label(erste.map(|c| c.city.clone()).unwrap_or_default());
                ui.label(erste.map(|c| c.app_name.clone()).unwrap_or_default());
                ui.end_row();
            }
        });
        if hosts.is_empty() { ui.weak("Keine Hosts erfasst."); }
    });
}

// ── 📊 Prozess Details ──────────────────────────────────────────────────────
fn prozess(ui: &mut egui::Ui, st: &AppState, name: &str) {
    let conns = conns_von_app(st, name);
    let pid = conns.first().map(|c| c.pid).unwrap_or(0);

    // Das Original hatte drei Reiter: Info, Hosts, Alarme.
    ui.horizontal(|ui| {
        ui.strong(name);
        ui.weak(format!("PID {pid}"));
    });
    ui.horizontal(|ui| {
        ui.label(format!("⬇ {}", format_bytes(st.meter.session_rx as f64)));
        ui.label(format!("⬆ {}", format_bytes(st.meter.session_tx as f64)));
    });
    ui.separator();

    ui.collapsing("Info", |ui| {
        zeile(ui, "Name:", name.to_string());
        zeile(ui, "Pfad:", programmpfad(pid).unwrap_or_else(|| "Nicht verfügbar".into()));
        zeile(ui, "Version:", "N/A".into());
        zeile(ui, "Herausgeber:", herausgeber(name).to_string());
        zeile(ui, "VirusTotal:", if std::env::var("EARTHVIEWER_VT_API_KEY").is_ok() {
            "Werkzeuge-Reiter nutzen".into()
        } else {
            "–".into()
        });
    });

    ui.collapsing("Hosts", |ui| {
        ui.small("Verbundene Hosts für diesen Prozess");
        egui::Grid::new("prozhosts").striped(true).num_columns(3).show(ui, |ui| {
            for h in ["Host", "Port", "Ort"] { ui.strong(h); }
            ui.end_row();
            for c in &conns {
                ui.label(egui::RichText::new(&c.remote_ip).monospace());
                ui.label(c.remote_port.to_string());
                ui.label(if c.country.is_empty() { "—".into() }
                         else { ev_core::country::flag_and_name(&c.country) });
                ui.end_row();
            }
        });
        if conns.is_empty() { ui.weak("Keine Verbindungen."); }
    });

    ui.collapsing("Alarme", |ui| {
        ui.small("Verdächtige Aktivitäten und Warnungen");
        let alarme = alarme_fuer(st, &conns);
        for a in &alarme {
            ui.colored_label(egui::Color32::from_rgb(230, 180, 90), a);
        }
        if alarme.is_empty() {
            ui.colored_label(egui::Color32::from_rgb(120, 220, 140), "Keine Auffälligkeiten.");
        }
    });
}

/// Auffaelligkeiten eines Prozesses. Das Original zeigte den Reiter leer;
/// die Regeln hier sind bewusst schlicht und nachvollziehbar.
pub fn alarme_fuer(st: &AppState, conns: &[&ev_net::Connection]) -> Vec<String> {
    let mut out = Vec::new();
    for c in conns {
        if st.blocklist.is_blocked(&c.remote_ip) {
            out.push(format!("Gegenstelle {} steht auf der Blockliste", c.remote_ip));
        }
        if let Some(k) = ev_net::classify(&c.remote_ip) {
            if k == ev_net::IpClass::Cgnat {
                out.push(format!("{} liegt im CGNAT-Bereich (RFC 6598)", c.remote_ip));
            }
        }
    }
    out.sort_unstable();
    out.dedup();
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn publisher_matches_original_heuristic() {
        assert_eq!(herausgeber("firefox"), "Mozilla Corporation");
        assert_eq!(herausgeber("Firefox-bin"), "Mozilla Corporation");
        assert_eq!(herausgeber("chrome"), "Google LLC / Chromium");
        assert_eq!(herausgeber("chromium-browser"), "Google LLC / Chromium");
        assert_eq!(herausgeber("sshd"), "Unknown");
        assert_eq!(herausgeber(""), "Unknown");
    }

    #[test]
    fn titles_match_the_original_format() {
        assert_eq!(Detail::Host("1.2.3.4".into()).titel(), "🖥 Host Details - 1.2.3.4");
        assert_eq!(Detail::Prozess("firefox".into()).titel(), "📊 firefox - Details");
        assert!(Detail::Land("🇩🇪 Deutschland".into()).titel().ends_with("- Details"));
    }

    #[test]
    fn titles_use_only_safe_glyphs() {
        for d in [
            Detail::Host("1.2.3.4".into()),
            Detail::Land("🇩🇪 Deutschland".into()),
            Detail::Prozess("firefox".into()),
        ] {
            assert_eq!(crate::glyphen::pruefe(&d.titel()), None, "{}", d.titel());
        }
    }

    #[test]
    fn detail_strings_are_clean() {
        for s in ["🖥 Hosts aus diesem Land", "📊 Traffic Details", "Active",
                  "⬇ 0 B", "⬆ 0 B", "🚫 blockiert"] {
            assert_eq!(crate::glyphen::pruefe(s), None, "unsicheres Zeichen in {s:?}");
        }
    }

    #[test]
    fn exe_path_of_invalid_pid_is_none() {
        assert!(programmpfad(0).is_none());
        assert!(programmpfad(-1).is_none());
    }

    #[test]
    fn exe_path_of_self_resolves() {
        let pid = std::process::id() as i32;
        assert!(programmpfad(pid).is_some(), "eigener Prozess muss auffindbar sein");
    }
}
