//! Der Globus als egui-Widget — Ersatz für `QOpenGLWidget` + `globe_widget.py`.
//!
//! Kamera-Logik, Maus-Interaktion und die 2D-Label-Overlays sind 1:1 portiert;
//! gezeichnet wird über einen `egui_glow`-PaintCallback.
use ev_core::config::*;
use ev_core::{math, GeoLocation};
use ev_render::{GlobeRenderer, Scene};
use glam::{Mat4, Vec3};
use std::sync::{Arc, Mutex};

pub struct Camera {
    pub rotation: Mat4,
    pub distance: f32,
    /// Zielentfernung für weiches Zoomen (Google-Earth-Gefühl). `distance`
    /// nähert sich ihr pro Frame exponentiell an.
    pub target_distance: f32,
    pub auto_rotate: bool,
    pub auto_rotate_speed: f32,
}

impl Default for Camera {
    fn default() -> Self {
        Self {
            // 1:1 startet das Original mit `rotation(90, X)` — Blick auf den
            // Nordpol. Mit aktiven Korrekturen stattdessen Mitteleuropa,
            // weil der Polblick aussieht, als sei die Textur kaputt.
            rotation: if ev_core::treue::korrigiert() {
                let base = math::rotation(90.0, Vec3::X);
                math::rotation(51.1657 - 90.0, Vec3::X) * math::rotation(-10.4515, Vec3::Y) * base
            } else {
                math::rotation(90.0, Vec3::X)
            },
            distance: CAMERA_DISTANCE,
            target_distance: CAMERA_DISTANCE,
            auto_rotate: false,
            auto_rotate_speed: AUTO_ROTATE_SPEED,
        }
    }
}

impl Camera {
    pub fn rotate(&mut self, angle_deg: f32, axis: Vec3) {
        self.rotation = math::rotation(angle_deg, axis) * self.rotation;
    }

    /// lon/lat (Grad) des aktuell dem Betrachter zugewandten Kugelpunkts.
    /// Für die Kachel-Ebene: welche Region ist im Blick? Die Kamera schaut aus
    /// +Z auf den Ursprung; der zugewandte Oberflächenpunkt ist die inverse
    /// Modellrotation angewandt auf +Z. Umrechnung passt zur Basiskugel
    /// (x = cos·sin, y = sin, z = cos·cos).
    pub fn blickpunkt(&self) -> (f64, f64) {
        let inv = self.rotation.inverse();
        let v = inv.transform_vector3(Vec3::new(0.0, 0.0, 1.0)).normalize();
        let lat = (v.y as f64).clamp(-1.0, 1.0).asin().to_degrees();
        let lon = (v.x as f64).atan2(v.z as f64).to_degrees();
        (lon, lat)
    }

    /// Setzt das Zoom-*Ziel*. Der eigentliche Anflug passiert in `tick_zoom`.
    ///
    /// Google-Earth-Prinzip: der Schritt skaliert mit der Entfernung. Nah am
    /// Boden wird pro Rasterklick nur ein winziges Stück gezoomt, weit draußen
    /// ein großes — dadurch fühlt es sich auf jeder Höhe gleich fein an.
    /// `scroll_y` ist der (geglättete) Rad-Delta-Wert von egui.
    pub fn zoom(&mut self, scroll_y: f32) {
        if scroll_y == 0.0 { return; }
        // Empfindlichkeit: 1 „Rasten" (~50 px) ≈ 12 % Entfernungsänderung.
        // Exponentiell, damit die Skala über den ganzen Bereich gleichmäßig ist.
        let schritte = scroll_y / 50.0;
        let faktor = (0.88_f32).powf(schritte); // rein = kleiner, raus = größer
        self.target_distance =
            (self.target_distance * faktor).clamp(CAMERA_MIN_DISTANCE, CAMERA_MAX_DISTANCE);
    }

    /// Direktes Setzen (Knopf „Zurücksetzen", Presets): Ziel = Ist.
    #[allow(dead_code)]
    pub fn set_distance(&mut self, d: f32) {
        self.distance = d.clamp(CAMERA_MIN_DISTANCE, CAMERA_MAX_DISTANCE);
        self.target_distance = self.distance;
    }

    /// Pro Frame: `distance` weich an `target_distance` heranführen. `dt` in
    /// Sekunden. Kehrt `true` zurück, solange sich noch etwas bewegt (dann muss
    /// neu gezeichnet werden).
    pub fn tick_zoom(&mut self, dt: f32) -> bool {
        let diff = self.target_distance - self.distance;
        if diff.abs() < 1e-4 {
            self.distance = self.target_distance;
            return false;
        }
        // Exponentielle Annäherung, zeitschrittunabhängig. 14/s ≈ ~70 ms bis fast am Ziel.
        let t = 1.0 - (-14.0 * dt).exp();
        self.distance = (self.distance + diff * t)
            .clamp(CAMERA_MIN_DISTANCE, CAMERA_MAX_DISTANCE);
        true
    }

    /// Dreht den Globus so, dass lat/lon zum Betrachter zeigt.
    /// Port von `_align_to_location`.
    pub fn align_to(&mut self, lat: f32, lon: f32) {
        let base = math::rotation(90.0, Vec3::X);
        let rot_y = math::rotation(-lon, Vec3::Y);
        let rot_x = math::rotation(lat - 90.0, Vec3::X);
        self.rotation = rot_x * rot_y * base;
    }

    /// Port von `align_view`.
    ///
    /// 🐞 GEFUNDENER BUG IM ORIGINAL (docs/PORT_NOTES.md, Punkt B5):
    /// `align_view()` benutzte fest verdrahtete Matrizen, die nicht zu
    /// `_align_to_location()` passten. Drei von fünf Presets zeigten etwas
    /// anderes als ihr Name versprach:
    ///
    /// | Preset  | Original                | zeigte tatsächlich |
    /// |---------|-------------------------|--------------------|
    /// | Nordpol | `rotation(180, X)`      | Äquator bei 180°   |
    /// | Südpol  | `IDENTITY`              | Äquator bei 0°     |
    /// | Äquator | `rotation(90, X)`       | **Nordpol**        |
    ///
    /// Herleitung der richtigen Werte direkt aus `align_to`:
    /// `align_to(lat, lon) = rot_x(lat-90) · rot_y(-lon) · rot_x(90)`
    ///
    /// - lat=+90 → `rotation(90, X)`   (Nordpol)
    /// - lat=  0 → `IDENTITY`          (Äquator)
    /// - lat=-90 → `rotation(-90, X)`  (Südpol)
    ///
    /// Deshalb rufen wir jetzt schlicht `align_to` auf — eine Quelle der
    /// Wahrheit statt zweier, die auseinanderlaufen können.
    pub fn align_preset(&mut self, mode: &str, target: Option<&GeoLocation>) {
        let treu = !ev_core::treue::korrigiert();
        match mode {
            "Deutschland" => self.align_to(51.1657, 10.4515),
            // Die drei fest verdrahteten Matrizen des Originals — inklusive
            // ihres Fehlers, solange die Korrekturen aus sind.
            "Nordpol" if treu => self.rotation = math::rotation(180.0, Vec3::X),
            "Südpol" if treu => self.rotation = Mat4::IDENTITY,
            "Äquator" if treu => self.rotation = math::rotation(90.0, Vec3::X),
            "Nordpol" => self.align_to(90.0, 0.0),
            "Südpol" => self.align_to(-90.0, 0.0),
            "Äquator" => self.align_to(0.0, 0.0),
            "Ziel" => { if let Some(t) = target { self.align_to(t.lat, t.lon); } }
            _ => {}
        }
    }

    pub fn matrices(&self, aspect: f32) -> (Mat4, Mat4, Mat4) {
        let projection = math::projection(CAMERA_FOV, aspect, CAMERA_NEAR, CAMERA_FAR);
        let view = math::view(self.distance);
        (projection, view, self.rotation)
    }

    pub fn mvp(&self, aspect: f32) -> Mat4 {
        let (p, v, m) = self.matrices(aspect);
        p * v * m
    }

    pub fn view_model(&self, aspect: f32) -> Mat4 {
        let (_, v, m) = self.matrices(aspect);
        v * m
    }
}

/// Ein Label, das über dem Globus schwebt.
#[derive(Clone, Debug)]
pub struct ScreenLabel {
    pub text: String,
    pub x: f32,
    pub y: f32,
    pub color: [u8; 3],
}

/// Hält die GL-Ressourcen. `Arc<Mutex<…>>`, weil der PaintCallback
/// `Send + Sync` sein muss.
#[derive(Clone)]
/// Eine dekodierte, hochladebereite Kachel (RGBA) für die GL-Ebene.
pub struct FertigeKachel {
    pub id: ev_render::tiles::TileId,
    pub w: u32,
    pub h: u32,
    pub rgba: Vec<u8>,
}

pub struct GlobeGl(pub Arc<Mutex<Option<GlobeRenderer>>>);

impl GlobeGl {
    pub fn new() -> Self { Self(Arc::new(Mutex::new(None))) }

    pub fn init(&self, gl: &glow::Context) {
        let mut guard = self.0.lock().expect("globe gl poisoned");
        if guard.is_some() { return; }
        let tex = ev_core::config::earth_texture();
        // Welche Textur (und wie groß) tatsächlich geladen wird — hilft beim
        // Prüfen, ob die eigene HD-Textur greift.
        if let Ok(dim) = image::image_dimensions(&tex) {
            eprintln!("🗺  Erdtextur: {} ({}×{})",
                      tex.file_name().and_then(|n| n.to_str()).unwrap_or("?"),
                      dim.0, dim.1);
        } else {
            eprintln!("🗺  Erdtextur: keine ladbare Datei — Fallback-Gitter");
        }
        match GlobeRenderer::new(gl, &tex) {
            Ok(r) => { *guard = Some(r); eprintln!("✅ OpenGL-Renderer initialisiert"); }
            Err(e) => eprintln!("❌ Renderer-Init fehlgeschlagen: {e}"),
        }
    }

    pub fn destroy(&self, gl: &glow::Context) {
        if let Ok(mut g) = self.0.lock() {
            if let Some(r) = g.take() { r.destroy(gl); }
        }
    }
}

impl Default for GlobeGl {
    fn default() -> Self { Self::new() }
}

/// Zeichnet den Globus in `rect` und gibt die Interaktions-Response zurück.
pub fn paint_globe(
    ui: &mut egui::Ui,
    gl_handle: &GlobeGl,
    camera: &Camera,
    scene: Scene,
    background: [f32; 3],
    tiles_sichtbar: bool,
    tile_aktiv: Vec<ev_render::tiles::TileId>,
    tile_neu: Vec<FertigeKachel>,
) -> egui::Response {
    let (rect, response) =
        ui.allocate_exact_size(ui.available_size(), egui::Sense::click_and_drag());
    let aspect = (rect.width() / rect.height().max(1.0)).max(1e-3);
    let mvp = camera.mvp(aspect);
    let model = camera.rotation;

    let handle = gl_handle.0.clone();
    let cb = eframe::egui_glow::CallbackFn::new(move |_info, painter| {
        let gl = painter.gl();
        ev_render::gl_util::puffer_leeren(gl, background);
        if let Ok(mut guard) = handle.lock() {
            if let Some(r) = guard.as_mut() {
                // Neue Kacheln hochladen (nur hier ist der GL-Kontext gültig).
                for k in &tile_neu {
                    r.tiles.upload_rgba(gl, k.id, k.w, k.h, &k.rgba);
                }
                r.tiles.sichtbar = tiles_sichtbar;
                r.tiles.setze_aktiv(tile_aktiv.clone());
                r.tiles.raeume_auf(gl, 160);
                r.render(gl, mvp, model, &scene);
            }
        }
    });

    ui.painter().add(egui::PaintCallback { rect, callback: Arc::new(cb) });
    response
}

/// Projiziert Marker auf den Bildschirm — Port von `_render_labels`.
pub fn build_labels(
    camera: &Camera,
    rect: egui::Rect,
    entries: &[(GeoLocation, [u8; 3])],
    marker_offset: f32,
) -> Vec<ScreenLabel> {
    let aspect = (rect.width() / rect.height().max(1.0)).max(1e-3);
    let mvp = camera.mvp(aspect);
    let vm = camera.view_model(aspect);
    let radius = SPHERE_RADIUS + marker_offset;

    let mut out = Vec::new();
    for (loc, color) in entries {
        let pos = loc.to_cartesian(radius);
        if let Some((sx, sy)) =
            math::project_to_screen(pos, mvp, vm, rect.width(), rect.height())
        {
            out.push(ScreenLabel {
                text: label_text(&loc.name, &loc.country),
                x: rect.left() + sx,
                y: rect.top() + sy,
                color: *color,
            });
        }
    }
    // Das Original zeichnete alle Beschriftungen, auch übereinander.
    if ev_core::treue::korrigiert() {
        thin_out(out, MIN_LABEL_DISTANCE)
    } else {
        out
    }
}

/// Mindestabstand zweier Beschriftungen in Pixeln.
pub const MIN_LABEL_DISTANCE: f32 = 26.0;

/// Verwirft Beschriftungen, die einer bereits gesetzten zu nahe kommen.
///
/// 📸 Im Original sichtbar kaputt: bei 50 Suchtreffern lagen die Namen
/// uebereinander und waren unlesbar (`Hop 18: IP: 129.250...` verdeckte drei
/// weitere). Das ist keine Nachbau-Aufgabe, sondern eine Verbesserung —
/// die Marker bleiben alle, nur die Schrift wird ausgeduennt.
pub fn thin_out(mut labels: Vec<ScreenLabel>, min_distance: f32) -> Vec<ScreenLabel> {
    if min_distance <= 0.0 || labels.len() < 2 {
        return labels;
    }
    // Von oben nach unten, damit die Auswahl bei gleicher Lage stabil bleibt
    // und nicht bei jedem Bild flackert.
    labels.sort_by(|a, b| {
        a.y.partial_cmp(&b.y)
            .unwrap_or(std::cmp::Ordering::Equal)
            .then_with(|| a.x.partial_cmp(&b.x).unwrap_or(std::cmp::Ordering::Equal))
            .then_with(|| a.text.cmp(&b.text))
    });
    let min2 = min_distance * min_distance;
    let mut behalten: Vec<ScreenLabel> = Vec::with_capacity(labels.len());
    for l in labels {
        let frei = behalten.iter().all(|k| {
            let (dx, dy) = (k.x - l.x, k.y - l.y);
            dx * dx + dy * dy >= min2
        });
        if frei {
            behalten.push(l);
        }
    }
    behalten
}

/// Projiziert Punkte und sucht den, der dem Zeiger am nächsten liegt.
/// Port von `_check_hover` / `_check_satellite_click`.
pub fn hover_pick(
    camera: &Camera,
    rect: egui::Rect,
    cursor: egui::Pos2,
    world: &[Vec3],
    radius_px: f32,
) -> Option<usize> {
    let aspect = (rect.width() / rect.height().max(1.0)).max(1e-3);
    let mvp = camera.mvp(aspect);
    let vm = camera.view_model(aspect);
    let mut screen = Vec::with_capacity(world.len());
    let mut index = Vec::with_capacity(world.len());
    for (i, p) in world.iter().enumerate() {
        if let Some((x, y)) = math::project_to_screen(*p, mvp, vm, rect.width(), rect.height()) {
            screen.push((rect.left() + x, rect.top() + y));
            index.push(i);
        }
    }
    math::pick_nearest((cursor.x, cursor.y), &screen, radius_px).map(|k| index[k])
}

/// Port von `make_label_text` — kürzt lange Namen.
pub fn label_text(name: &str, country: &str) -> String {
    let name = name.trim();
    let short: String = if name.chars().count() > 24 {
        format!("{}…", name.chars().take(23).collect::<String>())
    } else {
        name.to_string()
    };
    if country.trim().is_empty() { short } else { format!("{short} ({})", country.trim()) }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn zoom_respects_limits() {
        let mut c = Camera::default();
        // Weit reinzoomen: das Ziel muss am Minimum kleben, und tick_zoom
        // führt die Ist-Entfernung dorthin.
        for _ in 0..400 { c.zoom(200.0); }
        for _ in 0..200 { c.tick_zoom(0.05); }
        assert!((c.distance - CAMERA_MIN_DISTANCE).abs() < 1e-3,
                "nah: {} statt {}", c.distance, CAMERA_MIN_DISTANCE);
        for _ in 0..400 { c.zoom(-200.0); }
        for _ in 0..200 { c.tick_zoom(0.05); }
        assert!((c.distance - CAMERA_MAX_DISTANCE).abs() < 1e-2,
                "fern: {} statt {}", c.distance, CAMERA_MAX_DISTANCE);
    }

    #[test]
    fn zoom_steps_are_finer_when_closer() {
        // Kernversprechen des Google-Earth-Zooms: derselbe Rad-Delta ändert
        // nah am Boden weniger Absolutentfernung als weit draußen.
        let mut nah = Camera::default();
        nah.set_distance(CAMERA_MIN_DISTANCE + 0.3);
        let d0 = nah.distance;
        nah.zoom(50.0);
        let delta_nah = (nah.target_distance - d0).abs();

        let mut fern = Camera::default();
        fern.set_distance(CAMERA_MAX_DISTANCE - 3.0);
        let d1 = fern.distance;
        fern.zoom(50.0);
        let delta_fern = (fern.target_distance - d1).abs();

        assert!(delta_nah < delta_fern,
                "nah {delta_nah} sollte feiner sein als fern {delta_fern}");
    }

    #[test]
    fn zero_scroll_does_nothing() {
        let mut c = Camera::default();
        let d = c.target_distance;
        c.zoom(0.0);
        assert_eq!(c.target_distance, d);
    }

    #[test]
    fn align_to_brings_location_to_front() {
        ev_core::treue::set(ev_core::Treue::Korrigiert);
        let mut c = Camera::default();
        let leipzig = GeoLocation::new("Leipzig", 51.34, 12.38);
        c.align_to(leipzig.lat, leipzig.lon);
        // Nach dem Ausrichten muss der Punkt im View-Raum nach +Z zeigen.
        let vm = c.view_model(1.0);
        let n = leipzig.to_cartesian(1.0).normalize();
        let nv = vm * n.extend(0.0);
        assert!(nv.z > 0.95, "nicht zentriert: z = {}", nv.z);
    }

    /// Zentriert das Preset wirklich den Punkt, den sein Name verspricht?
    /// Genau das war im Original bei 3 von 5 Presets nicht der Fall.
    fn preset_centers(mode: &str, lat: f32, lon: f32) -> f32 {
        ev_core::treue::set(ev_core::Treue::Korrigiert);
        let mut c = Camera::default();
        c.align_preset(mode, None);
        let n = GeoLocation::new("x", lat, lon).to_cartesian(1.0).normalize();
        (c.view_model(1.0) * n.extend(0.0)).z
    }

    #[test]
    fn north_pole_preset_shows_the_north_pole() {
        assert!(preset_centers("Nordpol", 90.0, 0.0) > 0.99);
    }

    #[test]
    fn south_pole_preset_shows_the_south_pole() {
        assert!(preset_centers("Südpol", -90.0, 0.0) > 0.99);
    }

    #[test]
    fn equator_preset_shows_the_equator() {
        assert!(preset_centers("Äquator", 0.0, 0.0) > 0.99);
    }

    #[test]
    fn germany_preset_shows_germany() {
        assert!(preset_centers("Deutschland", 51.1657, 10.4515) > 0.99);
    }

    #[test]
    fn fidelity_mode_reproduces_the_original_presets() {
        // 1:1-Betrieb: "Äquator" muss den Nordpol zeigen, wie im Original.
        ev_core::treue::set(ev_core::Treue::Original);
        let mut c = Camera::default();
        c.align_preset("Äquator", None);
        let pol = GeoLocation::new("N", 90.0, 0.0).to_cartesian(1.0).normalize();
        let z = (c.view_model(1.0) * pol.extend(0.0)).z;
        ev_core::treue::set(ev_core::Treue::Korrigiert);
        assert!(z > 0.99, "1:1-Betrieb muss den Originalfehler zeigen, z = {z}");
    }

    #[test]
    fn original_hardcoded_matrices_were_wrong() {
        // Dokumentiert den Fehler: rotation(90, X) zentriert den Nordpol,
        // war im Original aber als "Äquator" gelabelt.
        let c = Camera { rotation: math::rotation(90.0, Vec3::X), ..Default::default() };
        let pole = GeoLocation::new("N", 90.0, 0.0).to_cartesian(1.0).normalize();
        assert!((c.view_model(1.0) * pole.extend(0.0)).z > 0.99,
                "rotation(90,X) zeigt den Nordpol, nicht den Äquator");
    }

    #[test]
    fn startup_view_shows_central_europe() {
        ev_core::treue::set(ev_core::Treue::Korrigiert);
        let c = Camera::default();
        let n = GeoLocation::new("DE", 51.1657, 10.4515).to_cartesian(1.0).normalize();
        assert!((c.view_model(1.0) * n.extend(0.0)).z > 0.99);
    }

    #[test]
    fn unknown_preset_is_a_noop() {
        let mut c = Camera::default();
        let before = c.rotation;
        c.align_preset("Nirgendwo", None);
        assert_eq!(before, c.rotation);
    }

    #[test]
    fn rotation_composes_left() {
        let mut c = Camera::default();
        let before = c.rotation;
        c.rotate(10.0, Vec3::Y);
        let expected = math::rotation(10.0, Vec3::Y) * before;
        assert!((c.rotation - expected).to_cols_array().iter().all(|v| v.abs() < 1e-5));
    }

    #[test]
    fn label_text_truncates_and_appends_country() {
        assert_eq!(label_text("Leipzig", "Germany"), "Leipzig (Germany)");
        assert_eq!(label_text("Leipzig", "  "), "Leipzig");
        let long = label_text(&"A".repeat(40), "");
        assert_eq!(long.chars().count(), 24);
        assert!(long.ends_with('…'));
    }

    fn label(x: f32, y: f32, text: &str) -> ScreenLabel {
        ScreenLabel { text: text.into(), x, y, color: [255; 3] }
    }

    #[test]
    fn thinning_drops_overlapping_labels() {
        let l = vec![
            label(100.0, 100.0, "A"),
            label(105.0, 102.0, "B"), // zu nah an A
            label(100.0, 200.0, "C"), // weit genug weg
        ];
        let r = thin_out(l, 26.0);
        assert_eq!(r.len(), 2);
        assert!(r.iter().any(|x| x.text == "A"));
        assert!(r.iter().any(|x| x.text == "C"));
    }

    #[test]
    fn thinning_keeps_everything_when_spread_out() {
        let l: Vec<ScreenLabel> = (0..10)
            .map(|i| label(50.0, i as f32 * 40.0, &format!("L{i}")))
            .collect();
        assert_eq!(thin_out(l, 26.0).len(), 10);
    }

    #[test]
    fn thinning_is_deterministic() {
        // Zweimal dieselbe Eingabe in anderer Reihenfolge -> gleiches Ergebnis,
        // sonst flackert die Anzeige von Bild zu Bild.
        let a = vec![label(10.0, 10.0, "A"), label(12.0, 11.0, "B"), label(80.0, 80.0, "C")];
        let mut b = a.clone();
        b.reverse();
        let ra: Vec<String> = thin_out(a, 26.0).into_iter().map(|l| l.text).collect();
        let rb: Vec<String> = thin_out(b, 26.0).into_iter().map(|l| l.text).collect();
        assert_eq!(ra, rb);
    }

    #[test]
    fn thinning_off_keeps_all() {
        let l = vec![label(1.0, 1.0, "A"), label(1.0, 1.0, "B")];
        assert_eq!(thin_out(l, 0.0).len(), 2);
    }

    #[test]
    fn many_labels_at_one_spot_collapse_to_one() {
        // Genau der Fall aus dem Original-Bildschirmfoto.
        let l: Vec<ScreenLabel> = (0..30)
            .map(|i| label(200.0 + i as f32 * 0.3, 150.0, &format!("Hop {i}")))
            .collect();
        assert_eq!(thin_out(l, 26.0).len(), 1);
    }

    #[test]
    fn labels_hide_the_far_side_of_the_globe() {
        let c = Camera::default();
        let rect = egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(800.0, 600.0));
        // Gegenüberliegende Punkte: genau einer darf sichtbar sein.
        let front = GeoLocation::new("Front", 0.0, 0.0);
        let back = GeoLocation::new("Back", 0.0, 180.0);
        let mut cam = c;
        cam.align_to(0.0, 0.0);
        let vis = build_labels(&cam, rect, &[(front, [255; 3]), (back, [255; 3])], 0.02);
        assert_eq!(vis.len(), 1, "Rückseite muss ausgeblendet sein");
        assert_eq!(vis[0].text, "Front");
    }
}
