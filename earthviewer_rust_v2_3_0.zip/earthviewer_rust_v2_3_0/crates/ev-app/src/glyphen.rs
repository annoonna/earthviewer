//! Zeichenvorrat der Oberflaeche.
//!
//! Die Konstanten hier werden nur von den Tests gelesen — sie sind die
//! Sollvorgabe, gegen die geprueft wird, nicht Laufzeitcode.
//!
//! 🐞 Hintergrund: egui liefert Ubuntu-Light + NotoEmoji + emoji-icon-font aus.
//! Was dort fehlt, erscheint als leeres Kaestchen — im Control Center stand
//! `□ □ eth0 □ □` statt `── eth0 ──`, weil U+2500 (Kaestchen-Striche) nicht
//! abgedeckt ist. Frueher hatte U+FE0F (Variations-Selektor) dasselbe Problem.
//!
//! Deshalb: alle Nicht-ASCII-Zeichen der Oberflaeche stehen hier, und
//! [`pruefe`] laesst nur nach, was in Bildschirmfotos tatsaechlich sauber
//! dargestellt wurde. Neue Symbole erst in `SICHER` eintragen, dann benutzen.

#[allow(dead_code)]
/// Lateinische Zusatzzeichen, die Ubuntu-Light sicher hat.
const LATEIN: &str = "äöüÄÖÜßéèêàçñ°²³µ«»–—…·×ø";

#[allow(dead_code)]
/// Symbole und Emoji, die in unseren Bildschirmfotos sauber erschienen.
const SYMBOLE: &str = concat!(
    "🌍🌐🔍⚙🔧🎮👁⚡📍🏷📡🛡🖧",
    "⭐⬆⬇⬅➡↺📸🔄",
    "📊📈📉🖥🔒🩺💡🪄",
    "🎯🚫✅⚠️❌ℹ",
    "🔴",
    "⏸⏹⏭",
    "🗑📦⤓💾🔁",
);

#[allow(dead_code)]
/// Bewusst verbotene Zeichen mit Ersatzvorschlag.
pub const VERBOTEN: &[(char, &str)] = &[
    ('\u{25B6}', "Wiedergabe-Dreieck — unbestaetigt, stattdessen Klartext"),
    ('\u{1F6E3}', "Autobahn — fehlt wie 🛰 in NotoEmoji, stattdessen Klartext"),
    ('\u{2500}', "Kaestchen-Striche — stattdessen ui.separator() oder '—'"),
    ('\u{FE0F}', "Variations-Selektor — erzeugt ein leeres Kaestchen dahinter"),
    ('\u{21B3}', "Pfeil mit Knick — stattdessen '»'"),
    ('\u{FF0B}', "Vollbreites Plus — stattdessen '+'"),
    ('\u{1F6F0}', "Satellit — fehlt in NotoEmoji, stattdessen 📡"),
    ('\u{1F3F3}', "Weisse Fahne — fehlt in NotoEmoji, stattdessen Klartext"),
    ('\u{1F50C}', "Stecker — erscheint entstellt, stattdessen 📊"),
    // Unicode 12.0 (2019) — NotoEmoji in egui ist aelter.
    ('\u{1F7E2}', "Gruener Kreis — fehlt; stattdessen farbiger Text"),
    ('\u{1F7E1}', "Gelber Kreis — fehlt; stattdessen farbiger Text"),
    ('\u{1F7E0}', "Oranger Kreis — fehlt; stattdessen farbiger Text"),
    ('\u{2302}', "Haus-Zeichen — fehlt; stattdessen Klartext"),
];

#[allow(dead_code)]
pub fn ist_sicher(c: char) -> bool {
    if c.is_ascii() {
        return true;
    }
    if VERBOTEN.iter().any(|(v, _)| *v == c) {
        return false;
    }
    // Regional-Indicator-Symbole: Laenderfahnen, rechnerisch erzeugt.
    if ('\u{1F1E6}'..='\u{1F1FF}').contains(&c) {
        return true;
    }
    LATEIN.contains(c) || SYMBOLE.contains(c)
}

#[allow(dead_code)]
/// Gibt das erste unsichere Zeichen zurueck.
pub fn pruefe(s: &str) -> Option<char> {
    s.chars().find(|c| !ist_sicher(*c))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::state::{NetTool, Tab};

    #[test]
    fn tab_labels_use_only_safe_glyphs() {
        for t in Tab::ALL {
            assert_eq!(pruefe(t.label()), None, "unsicheres Zeichen in {:?}", t.label());
        }
    }

    #[test]
    fn tool_labels_use_only_safe_glyphs() {
        for t in NetTool::ALL {
            assert_eq!(pruefe(t.label()), None, "unsicheres Zeichen in {:?}", t.label());
        }
    }

    /// Die Beschriftungen, die frueher als Kaestchen erschienen sind.
    #[test]
    fn known_ui_strings_are_clean() {
        for s in [
            "🎮 Navigation", "🔧 Funktionen", "👁 Ansicht", "⚡ Optionen",
            "🔄 Auto-Rotation", "↺ Zurücksetzen", "📸 Screenshot",
            "📍 Marker anzeigen", "🏷 Namen anzeigen",
            "🎯 Ziel", "Starten", "⏸ Pausieren", "🗑 Löschen",
            "🌐 Netzwerk-Schnittstellen", "📦 Notreserve", "⤓ Laden",
            "＋ Aktuelles Ziel merken",
        ] {
            let ergebnis = pruefe(s);
            if s.contains('＋') {
                assert!(ergebnis.is_some(), "vollbreites Plus muss auffallen");
            } else {
                assert_eq!(ergebnis, None, "unsicheres Zeichen in {s:?}");
            }
        }
    }

    #[test]
    fn house_sign_is_rejected() {
        // Im Scanner-Reiter erschien "⌂ lokal" als leeres Kaestchen.
        assert!(!ist_sicher('\u{2302}'));
        assert_eq!(pruefe("⌂ lokal"), Some('\u{2302}'));
    }

    #[test]
    fn unicode12_circles_are_rejected() {
        // Im Host-Detailfenster erschien "🟢 Active" als leeres Kaestchen.
        // 🔴 (Unicode 6.0) ist dagegen vorhanden.
        for c in ['\u{1F7E2}', '\u{1F7E1}', '\u{1F7E0}'] {
            assert!(!ist_sicher(c), "U+{:04X} muesste abgelehnt werden", c as u32);
        }
        assert!(ist_sicher('\u{1F534}'), "🔴 ist in NotoEmoji vorhanden");
        assert_eq!(pruefe("🟢 Active"), Some('\u{1F7E2}'));
    }

    #[test]
    fn white_flag_and_plug_are_rejected() {
        // Beide im Monitoring-Reiter als leeres Kaestchen aufgetaucht.
        assert!(!ist_sicher('\u{1F3F3}'));
        assert!(!ist_sicher('\u{1F50C}'));
        assert_eq!(pruefe("🏳 Top Länder"), Some('\u{1F3F3}'));
    }

    #[test]
    fn monitoring_headings_are_clean() {
        for s in ["📊 Top Apps", "🌐 Top Hosts", "🌍 Top Länder", "📊 Protokolle",
                  "📈 Network Traffic Graph", "📊 Live Network Monitoring"] {
            assert_eq!(pruefe(s), None, "unsicheres Zeichen in {s:?}");
        }
    }

    #[test]
    fn box_drawing_is_rejected() {
        assert_eq!(pruefe("── eth0 ──"), Some('─'));
        assert!(!ist_sicher('\u{2500}'));
    }

    #[test]
    fn variation_selector_is_rejected() {
        assert_eq!(pruefe("⚙\u{FE0F} Steuerung"), Some('\u{FE0F}'));
    }

    #[test]
    fn flags_and_ascii_pass() {
        assert_eq!(pruefe("🇩🇪 Deutschland"), None);
        assert_eq!(pruefe("Hop 10: 1.2.3.4 (1.2.3.4) - 66.8ms"), None);
        assert_eq!(pruefe("min 1.02 / ø 3.4 / max 9.9 ms"), None);
    }

    #[test]
    fn every_forbidden_char_has_a_hint() {
        for (c, hinweis) in VERBOTEN {
            assert!(!hinweis.is_empty(), "kein Hinweis fuer U+{:04X}", *c as u32);
            assert!(!ist_sicher(*c));
        }
    }
}
