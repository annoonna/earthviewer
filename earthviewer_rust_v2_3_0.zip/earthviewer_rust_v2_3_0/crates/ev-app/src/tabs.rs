//! Die Reiter der Seitenleiste — Port von `src/ui/widgets/*_tab.py`.
//!
//! Jede Python-Tab-Klasse hat hier genau eine Funktion. Die „Große Ansicht"-
//! Knöpfe des Originals (`*_large_window.py`) sind entfallen: in egui zieht man
//! die Seitenleiste einfach breiter, dafür braucht es kein zweites Fenster.
use crate::state::{AppState, NetTool};
use ev_net::monitor::format_bytes;

/// Umrahmter Gruppenkasten — das Gegenstueck zu `QGroupBox`.
///
/// Das Original gliedert die Seitenleiste in solche Kaesten (Rahmen #555555,
/// Titel darueber). Ohne sie wirkt die Leiste wie eine dichte flache Liste —
/// genau der Unterschied, den Anno im Vergleich gesehen hat.
pub fn gruppe<R>(
    ui: &mut egui::Ui,
    titel: &str,
    inhalt: impl FnOnce(&mut egui::Ui) -> R,
) -> R {
    let rand = ev_core::theme::ui::BORDER;
    ui.add_space(4.0);
    if !titel.is_empty() {
        ui.label(
            egui::RichText::new(titel)
                .size(ev_core::theme::ui::FONT_UEBERSCHRIFT)
                .strong(),
        );
    }
    let r = egui::Frame::new()
        .stroke(egui::Stroke::new(
            1.0,
            egui::Color32::from_rgb(rand[0], rand[1], rand[2]),
        ))
        .corner_radius(egui::CornerRadius::same(4))
        .inner_margin(egui::Margin::same(8))
        .show(ui, |ui| {
            ui.set_width(ui.available_width() - 16.0);
            inhalt(ui)
        })
        .inner;
    ui.add_space(4.0);
    r
}

/// Umrahmter Kasten ohne Titel — im Original bekommt jeder Reiter genau
/// einen davon fuer seinen Inhaltsbereich (nachgemessen: waagerechte
/// Rahmenlinien bei y=459 und y=1011 im Suche-Reiter).
pub fn rahmen<R>(ui: &mut egui::Ui, inhalt: impl FnOnce(&mut egui::Ui) -> R) -> R {
    gruppe(ui, "", inhalt)
}

/// Knopf ueber die volle Breite, wie sie das Original durchgehend benutzt.
pub fn breiter_knopf(ui: &mut egui::Ui, text: &str, tuerkis: bool) -> bool {
    let p = ev_core::theme::ui::PRIMARY;
    let v = ev_core::theme::ui::SURFACE_VARIANT;
    let f = if tuerkis { p } else { v };
    ui.add_sized(
        [ui.available_width(), ev_core::theme::ui::HOEHE_KNOPF],
        egui::Button::new(
            egui::RichText::new(text)
                .size(ev_core::theme::ui::FONT_NORMAL)
                .color(egui::Color32::WHITE),
        )
        .fill(egui::Color32::from_rgb(f[0], f[1], f[2])),
    )
    .clicked()
}

/// Kleiner Balken für Top-Listen — ersetzt die QProgressBar-Spalten.
// ── ⚙ Steuerung ────────────────────────────────────────────────────────────
pub enum ControlAction {
    Rotate(f32, f32),
    Reset,
    Screenshot,
    Preset(&'static str),
}

pub fn control(ui: &mut egui::Ui, st: &mut AppState, auto: &mut bool, speed: &mut f32)
    -> Option<ControlAction>
{
    let mut action = None;
    let breite = ui.available_width();

    ui.strong("🎮 Navigation");
    ui.add_space(4.0);

    // Steuerkreuz. Nachgemessen im Original (werkzeug/farben.py, 1920x1080,
    // 1:1): Knoepfe 137x90 px bei 485 px Leistenbreite — Verhaeltnis 0.65.
    let schritt = 15.0;
    let abstand = ui.spacing().item_spacing.x;
    let kb = ((breite - 2.0 * abstand) / 3.0).clamp(60.0, 150.0);
    let kh = (kb * ev_core::theme::ui::KREUZ_VERHAELTNIS).clamp(44.0, 96.0);
    ui.horizontal(|ui| {
        ui.add_space(kb + abstand);
        if ui.add_sized([kb, kh], egui::Button::new("⬆")).clicked() {
            action = Some(ControlAction::Rotate(0.0, -schritt));
        }
    });
    ui.horizontal(|ui| {
        if ui.add_sized([kb, kh], egui::Button::new("⬅")).clicked() {
            action = Some(ControlAction::Rotate(-schritt, 0.0));
        }
        if ui.add_sized([kb, kh], egui::Button::new("⬇")).clicked() {
            action = Some(ControlAction::Rotate(0.0, schritt));
        }
        if ui.add_sized([kb, kh], egui::Button::new("➡")).clicked() {
            action = Some(ControlAction::Rotate(schritt, 0.0));
        }
    });

    ui.add_space(10.0);
    ui.strong("🔧 Funktionen");
    // Auto-Rotation ist im Original ein Umschalt-KNOPF, kein Ankreuzfeld.
    let hk = ev_core::theme::ui::HOEHE_KNOPF;
    // Umschaltknopf mit Rahmen — SelectableLabel hat im Ruhezustand keinen,
    // im Original ist es aber ein vollwertiger Knopf.
    let an = ev_core::theme::ui::PRIMARY;
    let aus = ev_core::theme::ui::SURFACE_VARIANT;
    let f = if *auto { an } else { aus };
    if ui
        .add_sized(
            [breite, hk],
            egui::Button::new("🔄 Auto-Rotation")
                .fill(egui::Color32::from_rgb(f[0], f[1], f[2])),
        )
        .clicked()
    {
        *auto = !*auto;
    }
    if ui.add_sized([breite, hk], egui::Button::new("↺ Zurücksetzen")).clicked() {
        action = Some(ControlAction::Reset);
    }
    if ui.add_sized([breite, hk], egui::Button::new("📸 Screenshot")).clicked() {
        action = Some(ControlAction::Screenshot);
    }

    ui.add_space(10.0);
    ui.strong("👁 Ansicht");
    // Im Original EIN Auswahlfeld, nicht fuenf Knoepfe.
    const ANSICHTEN: [&str; 5] = ["Deutschland", "Nordpol", "Südpol", "Äquator", "Ziel"];
    let mut gewaehlt = st.ansicht.clone();
    egui::ComboBox::from_id_salt("ansicht")
        .selected_text(gewaehlt.clone())
        .width(breite - 16.0)
        .show_ui(ui, |ui| {
            for a in ANSICHTEN {
                ui.selectable_value(&mut gewaehlt, a.to_string(), a);
            }
        });
    if gewaehlt != st.ansicht {
        st.ansicht = gewaehlt.clone();
        if let Some(p) = ANSICHTEN.iter().find(|x| **x == gewaehlt) {
            action = Some(ControlAction::Preset(p));
        }
    }

    ui.add_space(10.0);
    ui.strong("⚡ Optionen");
    // sidebar.py: "🏷️ Marker anzeigen" und "📝 Namen anzeigen" — genau diese Zeichen.
    ui.checkbox(&mut st.show_markers, "🏷 Marker anzeigen");
    ui.checkbox(&mut st.show_labels, "📝 Namen anzeigen");

    // Ueber das Original hinaus, deshalb eingeklappt. Marker-Hoehe und
    // Rotationstempo liegen wie im Original im Zahnrad-Dialog, nicht hier.
    let _ = speed;
    ui.collapsing("Mehr (über das Original hinaus)", |ui| {
        ui.checkbox(&mut st.show_satellites, "🛰 Satelliten anzeigen");
    });
    action
}

// ── 🔍 Suche ────────────────────────────────────────────────────────────────
pub enum SearchAction { Run, Goto(usize), Favorite(usize) }

pub fn search(ui: &mut egui::Ui, st: &mut AppState) -> Option<SearchAction> {
    // 1:1 nach sidebar.py `_create_search_tab`: Eingabefeld mit Platzhalter
    // "Stadt, IP, Koordinaten...", tuerkiser Knopf "🔍 Suchen", Ueberschrift
    // "📍 Suchergebnisse", darunter die dunkle Liste. Keine Kopfzeile, kein
    // Hinweistext, kein "Marker loeschen" — das gab es dort nicht.
    // Treffer wie "🏙️ Berlin [Germany] (52.5°, 13.4°)" (update_results).
    let mut action = None;
    let te = ui.add(
        egui::TextEdit::singleline(&mut st.search_query)
            .hint_text("Stadt, IP, Koordinaten...")
            .desired_width(f32::INFINITY),
    );
    if te.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
        action = Some(SearchAction::Run);
    }
    if breiter_knopf(ui, "🔍 Suchen", true) { action = Some(SearchAction::Run); }

    ui.add_space(4.0);
    ui.label(
        egui::RichText::new("📍 Suchergebnisse")
            .size(ev_core::theme::ui::FONT_UEBERSCHRIFT)
            .strong(),
    );
    rahmen(ui, |ui| {
    egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
        for (i, loc) in st.search_results.iter().enumerate() {
            ui.horizontal(|ui| {
                if ui.button("⭐").on_hover_text("zu Favoriten").clicked() {
                    action = Some(SearchAction::Favorite(i));
                }
                let label = if loc.country.is_empty() {
                    format!("🏙 {}", loc.name)
                } else {
                    format!("🏙 {} [{}] ({:.1}°, {:.1}°)",
                            loc.name, loc.country, loc.lat, loc.lon)
                };
                if ui.selectable_label(false, label).clicked() {
                    action = Some(SearchAction::Goto(i));
                }
            });
        }
        // Leerer Zustand: im Original einfach eine leere dunkle Flaeche.
    });
    });
    action
}

// ── ⭐ Favoriten ────────────────────────────────────────────────────────────
pub enum FavAction { Goto(usize), Remove(usize), AddCurrent }

pub fn favorites(ui: &mut egui::Ui, st: &AppState) -> Option<FavAction> {
    let mut action = None;
    ui.label(egui::RichText::new("⭐ Favoriten")
        .size(ev_core::theme::ui::FONT_GROSS).strong());
    ui.small("Bleiben in sessions/favorites.json erhalten");
    ui.add_space(4.0);
    ui.add_enabled_ui(st.target_marker.is_some(), |ui| {
        if breiter_knopf(ui, "+ Aktuelles Ziel merken", true) {
            action = Some(FavAction::AddCurrent);
        }
    });
    rahmen(ui, |ui| {
    if st.favorites.is_empty() {
        ui.weak("Noch keine Favoriten. In der Suche auf ⭐ klicken.");
    }
    egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
        for (i, f) in st.favorites.iter().enumerate() {
            ui.horizontal(|ui| {
                if ui.button("🗑").clicked() { action = Some(FavAction::Remove(i)); }
                if ui.selectable_label(false, &f.name).clicked() {
                    action = Some(FavAction::Goto(i));
                }
            });
            ui.small(format!("   {:.3}, {:.3}  {}", f.lat, f.lon, f.country));
        }
    });
    });
    action
}

// ── 🌐 Netzwerk ─────────────────────────────────────────────────────────────
/// Warnbalken, wenn die GeoIP-Datenbank fehlt. Ohne sie bleiben Marker,
/// Linien und Boegen aus — das ist die haeufigste Ursache fuer einen
/// "leeren" Globus und stand vorher nur im Control Center.
pub fn geoip_hinweis(ui: &mut egui::Ui, vorhanden: bool) {
    if vorhanden { return; }
    egui::Frame::new()
        .fill(egui::Color32::from_rgb(60, 44, 20))
        .inner_margin(egui::Margin::same(5))
        .show(ui, |ui| {
            ui.label(
                egui::RichText::new("⚠ GeoIP fehlt — keine Marker, keine Bögen")
                    .color(egui::Color32::from_rgb(253, 216, 53))
                    .size(ev_core::theme::ui::FONT_KLEIN),
            );
            ui.small("GeoLite2-City.mmdb nach data/geodata/ legen");
        });
    ui.add_space(4.0);
}

pub fn network(ui: &mut egui::Ui, st: &mut AppState, busy: bool, hat_geoip: bool) -> bool {
    let mut start = false;
    geoip_hinweis(ui, hat_geoip);
    // network_tab.py: "🌐 Netzwerk-Tool" — genau dieser Titel.
    ui.label(egui::RichText::new("🌐 Netzwerk-Tool").size(ev_core::theme::ui::FONT_GROSS).strong());
    ui.add_space(4.0);

    egui::ComboBox::from_id_salt("nettool")
        .selected_text(st.net_tool.label())
        .width(220.0)
        .show_ui(ui, |ui| {
            for t in NetTool::ALL {
                ui.selectable_value(&mut st.net_tool, t, t.label());
            }
        });

    ui.add_space(6.0);
    ui.strong("🎯 Ziel");
    ui.add(egui::TextEdit::singleline(&mut st.tool_target)
        .hint_text("z.B. golem.de oder 8.8.8.8")
        .desired_width(f32::INFINITY));
    // Verlauf als anklickbare Vorschläge (VisualTraceroute-Autocomplete).
    if !st.tool_history.is_empty() {
        ui.horizontal_wrapped(|ui| {
            ui.small("Verlauf:");
            for z in st.tool_history.clone().iter().take(8) {
                if ui.small_button(z).clicked() {
                    st.tool_target = z.clone();
                }
            }
        });
    }

    ui.horizontal(|ui| {
        ui.checkbox(&mut st.loop_enabled, "🔄 Loop");
        ui.label("Intervall:");
        // network_tab.py: setRange(5, 300), setValue(30), setSuffix(" s")
        ui.add(egui::DragValue::new(&mut st.loop_interval_s)
            .speed(1.0).range(5.0..=300.0).suffix(" s"));
    });

    ui.add_space(4.0);
    ui.add_enabled_ui(!busy, |ui| {
        // network_tab.py: "▶️ Starten" — normaler dunkler Knopf, nicht tuerkis.
        if breiter_knopf(ui, "▶ Starten", false) {
            start = true;
        }
    });

    ui.add_space(6.0);
    ui.horizontal(|ui| {
        ui.strong("📊 Ergebnis");
        if st.tool_output.busy { ui.spinner(); }
        if !st.tool_output.title.is_empty() { ui.weak(&st.tool_output.title); }
    });

    // 1:1 aus network_tab.py:
    //   "font-family: monospace; color: #0f0; background: #1e1e1e;"
    const GRUEN: egui::Color32 = egui::Color32::from_rgb(0x00, 0xFF, 0x00);
    egui::Frame::new()
        .fill(egui::Color32::from_rgb(0x1e, 0x1e, 0x1e))
        .inner_margin(egui::Margin::same(5))
        .show(ui, |ui| {
            egui::ScrollArea::vertical()
                .auto_shrink([false, false])
                .stick_to_bottom(true)
                .show(ui, |ui| {
                    for line in &st.tool_output.lines {
                        // Hinweiszeilen bleiben farbig, alles andere gruen.
                        let farbe = if line.starts_with('❌') {
                            egui::Color32::from_rgb(255, 110, 90)
                        } else if line.starts_with('✅') || line.starts_with('ℹ') {
                            egui::Color32::from_rgb(253, 216, 53)
                        } else {
                            GRUEN
                        };
                        ui.label(egui::RichText::new(line).monospace()
                            .size(ev_core::theme::ui::FONT_KLEIN).color(farbe));
                    }
                });
        });

    // ── Hop-Tabelle (VisualTraceroute-Stil) ──────────────────────────────
    // Erscheint, sobald Traceroute-Hops vorliegen. Spalten wie OVTR:
    // # · IP · Hostname · Ort · Land · Lat · Lon · Latenz · DNS · Distanz.
    if !st.traceroute_hops.is_empty() {
        ui.add_space(8.0);
        ui.separator();
        ui.horizontal(|ui| {
            ui.strong(format!("🧭 Route — {} Hops", st.traceroute_hops.len()));
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui.button("⬇ CSV kopieren").on_hover_text(
                    "Route als CSV in die Zwischenablage").clicked() {
                    ui.ctx().copy_text(hops_als_csv(&st.traceroute_hops));
                }
            });
        });
        hop_tabelle(ui, &st.traceroute_hops);
    }

    start
}

/// Die Hop-Tabelle. Latenz farbcodiert (grün/gelb/rot), Whois-Knopf pro Hop
/// ist bewusst weggelassen (WHOIS läuft über das Netzwerk-Tool selbst — man
/// tippt die IP ins Ziel und wählt WHOIS). Distanz per Haversine zum Vorgänger.
pub fn hop_tabelle(ui: &mut egui::Ui, hops: &[ev_net::traceroute::TracerouteHop]) {
    rahmen(ui, |ui| {
    egui::ScrollArea::horizontal().show(ui, |ui| {
    egui::Grid::new("hops").striped(true).num_columns(10).show(ui, |ui| {
        for h in ["#", "IP", "Hostname", "Ort", "Land", "Lat", "Lon",
                  "Latenz", "DNS", "Distanz"] {
            ui.strong(egui::RichText::new(h).size(ev_core::theme::ui::FONT_KLEIN));
        }
        ui.end_row();
        for h in hops {
            let k = ev_core::theme::ui::FONT_KLEIN;
            ui.label(egui::RichText::new(format!("{}", h.hop_num)).size(k));
            ui.label(egui::RichText::new(&h.ip).monospace().size(k));
            let host = if h.hostname == h.ip { "—".to_string() } else { h.hostname.clone() };
            ui.label(egui::RichText::new(host).size(k));
            let ort = h.location.as_ref().map(|l| l.name.clone()).unwrap_or_default();
            ui.label(egui::RichText::new(if ort.is_empty() { "—".into() } else { ort }).size(k));
            let land = h.land();
            ui.label(egui::RichText::new(
                if land.is_empty() { "—".to_string() }
                else { format!("{} {}", ev_core::country::flag_badge(&land), land) }).size(k));
            ui.label(egui::RichText::new(
                h.lat().map(|v| format!("{v:.2}")).unwrap_or_else(|| "—".into())).size(k));
            ui.label(egui::RichText::new(
                h.lon().map(|v| format!("{v:.2}")).unwrap_or_else(|| "—".into())).size(k));
            // Latenz farbig.
            let c = h.latenz_rgb();
            let farbe = egui::Color32::from_rgb(
                (c[0] * 255.0) as u8, (c[1] * 255.0) as u8, (c[2] * 255.0) as u8);
            ui.label(egui::RichText::new(
                if h.rtt > 0.0 { format!("{:.1} ms", h.rtt) } else { "*".into() })
                .color(farbe).size(k));
            ui.label(egui::RichText::new(
                if h.dns_ms > 0.0 { format!("{:.0} ms", h.dns_ms) } else { "—".into() }).size(k));
            ui.label(egui::RichText::new(
                if h.dist_prev_km > 0.0 { format!("{:.0} km", h.dist_prev_km) } else { "—".into() })
                .size(k));
            ui.end_row();
        }
    });
    });
    });
}

/// Route als CSV (OVTR-Export). Semikolon-getrennt, deutsche Kopfzeile.
pub fn hops_als_csv(hops: &[ev_net::traceroute::TracerouteHop]) -> String {
    let mut s = String::from(
        "Hop;IP;Hostname;Ort;Land;Lat;Lon;Latenz_ms;DNS_ms;Distanz_km\n");
    for h in hops {
        let ort = h.location.as_ref().map(|l| l.name.clone()).unwrap_or_default();
        s.push_str(&format!(
            "{};{};{};{};{};{};{};{:.1};{:.0};{:.0}\n",
            h.hop_num, h.ip,
            if h.hostname == h.ip { "" } else { &h.hostname },
            ort, h.land(),
            h.lat().map(|v| format!("{v:.4}")).unwrap_or_default(),
            h.lon().map(|v| format!("{v:.4}")).unwrap_or_default(),
            h.rtt, h.dns_ms, h.dist_prev_km));
    }
    s
}

// ── 🔴 Live Verbindungen ────────────────────────────────────────────────────
pub fn live_connections(ui: &mut egui::Ui, st: &mut AppState, hat_geoip: bool) -> bool {
    // 1:1 nach live_connections_tab.py: tuerkiser Knopf "Grosse Live-Analyse",
    // Titel, Erklaertext, Anzeigeoptionen (Tracking rot/gruen + Loeschen orange),
    // farbige Incoming/Outgoing-Haken, Tempo-Schieber, Statistik-Kasten,
    // Tabelle Stadt/Land | Richtung | Protokoll | VirusTotal.
    let mut filters_changed = false;
    geoip_hinweis(ui, hat_geoip);

    if breiter_knopf(ui, "📈 Große Live-Analyse öffnen", true) { st.win_live = true; }
    ui.label(egui::RichText::new("🌐 Live Verbindungen")
        .size(ev_core::theme::ui::FONT_GROSS).strong());
    ui.small("Zeigt alle aktiven Netzwerkverbindungen in Echtzeit auf dem Globus.");
    ui.small("VirusTotal-Status wird pro Remote-IP angezeigt (wenn API-Key konfiguriert).");
    ui.add_space(4.0);

    ui.strong("⚙ Anzeigeoptionen");
    ui.horizontal(|ui| {
        // Original: gruen "▶️ Tracking starten" / rot "⏸️ Tracking pausieren".
        let (txt, farbe) = if st.tracking_on {
            ("⏸ Tracking pausieren", egui::Color32::from_rgb(0xE7, 0x4C, 0x3C))
        } else {
            ("▶ Tracking starten", egui::Color32::from_rgb(0x27, 0xAE, 0x60))
        };
        if ui.add(egui::Button::new(egui::RichText::new(txt)
                .color(egui::Color32::WHITE).strong()).fill(farbe)).clicked() {
            st.tracking_on = !st.tracking_on;
        }
        // Original: oranger "🗑️ Löschen"-Knopf.
        if ui.add(egui::Button::new(egui::RichText::new("🗑 Löschen")
                .color(egui::Color32::WHITE).strong())
                .fill(egui::Color32::from_rgb(0xD3, 0x54, 0x00))).clicked() {
            st.connections.clear();
            st.selected_connection = None;
        }
    });
    const BLAU:  egui::Color32 = egui::Color32::from_rgb(0x64, 0xB5, 0xF6);
    const GRUEN: egui::Color32 = egui::Color32::from_rgb(0x81, 0xC7, 0x84);
    ui.horizontal(|ui| {
        filters_changed |= ui.checkbox(&mut st.show_incoming,
            egui::RichText::new("📥 Incoming (Blau)").color(BLAU)).changed();
        filters_changed |= ui.checkbox(&mut st.show_outgoing,
            egui::RichText::new("📤 Outgoing (Grün)").color(GRUEN)).changed();
    });
    ui.horizontal(|ui| {
        ui.label("🎬 Animations-Geschwindigkeit:");
        ui.add(egui::Slider::new(&mut st.live_speed, 1..=10).show_value(false));
        ui.strong(format!("{}", st.live_speed));
    });

    // 📊 Statistiken — dunkler Kasten wie im Original.
    rahmen(ui, |ui| {
        ui.strong("📊 Statistiken");
        let (total, inc, out) = st.connection_stats();
        ui.label(format!("Gesamt: {total}"));
        ui.label(egui::RichText::new(format!("📥 Incoming: {inc}")).color(BLAU));
        ui.label(egui::RichText::new(format!("📤 Outgoing: {out}")).color(GRUEN));
    });

    ui.add_space(4.0);
    ui.strong("📋 Aktive Verbindungen");
    let mut toggle_host: Option<String> = None;
    rahmen(ui, |ui| {
    egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
        egui::Grid::new("liveconns").striped(true).num_columns(4).show(ui, |ui| {
            for h in ["Stadt/Land", "Richtung", "Protokoll", "VirusTotal"] { ui.strong(h); }
            ui.end_row();
            for (i, c) in st.connections.iter().enumerate() {
                let blocked = st.blocklist.is_blocked(&c.remote_ip);
                let sel = st.selected_connection == Some(i);
                let ort = if !c.city.is_empty() {
                    format!("{}, {}", c.city, c.country)
                } else if !c.country.is_empty() {
                    c.country.clone()
                } else {
                    format!("IP: {}", c.remote_ip)
                };
                // Favoriten-Stern (Runde D): markiert Host für Benachrichtigung.
                ui.horizontal(|ui| {
                    let fav = st.watch.host_fav(&c.remote_ip);
                    let stern = if fav { "★" } else { "☆" };
                    if ui.small_button(stern).on_hover_text(
                        "Als Favorit markieren (benachrichtigt bei Traffic)").clicked() {
                        toggle_host = Some(c.remote_ip.clone());
                    }
                    let mut rt = egui::RichText::new(ort).size(ev_core::theme::ui::FONT_KLEIN);
                    if blocked { rt = rt.color(egui::Color32::from_rgb(255, 90, 90)); }
                    if ui.selectable_label(sel, rt)
                        .on_hover_text(format!("{} → {}:{} ({})",
                            c.app_name, c.remote_ip, c.remote_port, c.protocol))
                        .clicked() {
                        st.selected_connection = Some(i);
                    }
                });
                if c.is_incoming() {
                    ui.label(egui::RichText::new("📥 IN").color(BLAU)
                        .size(ev_core::theme::ui::FONT_KLEIN));
                } else {
                    ui.label(egui::RichText::new("📤 OUT").color(GRUEN)
                        .size(ev_core::theme::ui::FONT_KLEIN));
                }
                ui.label(egui::RichText::new(&c.protocol)
                    .size(ev_core::theme::ui::FONT_KLEIN));
                ui.label(egui::RichText::new("–").size(ev_core::theme::ui::FONT_KLEIN));
                ui.end_row();
            }
        });
    });
    });
    if let Some(h) = toggle_host { st.watch.toggle_host(&h); }

    // Zugabe der Rust-Edition, deshalb eingeklappt und zuunterst.
    ui.collapsing("Mehr (über das Original hinaus)", |ui| {
        let mut real = st.direction_mode == ev_net::DirectionMode::Real;
        if ui.checkbox(&mut real, "Richtung technisch korrekt (statt 50/50-Optik)").changed() {
            st.direction_mode = if real {
                ev_net::DirectionMode::Real
            } else {
                ev_net::DirectionMode::Balanced5050
            };
            filters_changed = true;
        }
        ui.small("Ohne root sieht der Tracker nur Sockets eigener Prozesse.");
    });
    filters_changed
}

// ── 📊 Monitoring ───────────────────────────────────────────────────────────
// Nach dem Original-Bildschirmfoto: vier Tabellen **nebeneinander**
// (Apps | Hosts | Verkehr | Länder), darüber Titel und Pausenknopf.
/// Die vier Tabellen (Apps | Hosts | Verkehr | Länder) — geteilt zwischen
/// dem Reiter und der großen Ansicht (`fenster::network_monitor`), damit klein
/// und groß nie auseinanderlaufen. `n` = Zeilen je Spalte, `hoehe` = Scrollhöhe.
pub fn monitoring_spalten(ui: &mut egui::Ui, st: &mut AppState, n: usize, hoehe: f32) {
    let apps = st.monitor.top_apps(n);
    let hosts = st.monitor.top_hosts(n);
    let protos = st.monitor.top_protocols(n);
    let laender: Vec<(String, ev_net::monitor::Bucket)> = st
        .monitor
        .top_countries(n)
        .into_iter()
        .map(|(iso, b)| (ev_core::country::flag_and_name(&iso), b))
        .collect();

    let mut geklickt: Option<crate::detail::Detail> = None;
    let spalte = |ui: &mut egui::Ui,
                  titel: &str,
                  id: &str,
                  zeilen: &[(String, ev_net::monitor::Bucket)],
                  farbe: egui::Color32,
                  bauen: Option<fn(&str) -> crate::detail::Detail>,
                  treffer: &mut Option<crate::detail::Detail>| {
        // Kopfzeile mit Titel + Spaltenüberschriften „Name / Anz." und Trennlinie.
        ui.label(egui::RichText::new(titel).strong().size(ev_core::theme::ui::FONT_KLEIN)
            .color(farbe));
        ui.horizontal(|ui| {
            ui.label(egui::RichText::new("Name").size(9.0).color(egui::Color32::from_gray(130)));
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                ui.label(egui::RichText::new("Anz.").size(9.0)
                    .color(egui::Color32::from_gray(130)));
            });
        });
        ui.separator();
        let max = zeilen.first().map(|z| z.1.total).unwrap_or(1.0).max(1.0);
        egui::ScrollArea::vertical()
            .id_salt(id)
            .max_height(hoehe)
            .auto_shrink([false, false])
            .show(ui, |ui| {
                if zeilen.is_empty() {
                    ui.weak(egui::RichText::new("—").size(ev_core::theme::ui::FONT_KLEIN));
                }
                for (name, b) in zeilen {
                    let kurz: String = if name.chars().count() > 16 {
                        format!("{}…", name.chars().take(15).collect::<String>())
                    } else {
                        name.clone()
                    };
                    // Name links, Zähler rechtsbündig — echte Spaltenausrichtung.
                    let antwort = ui.horizontal(|ui| {
                        let n = egui::RichText::new(kurz)
                            .size(ev_core::theme::ui::FONT_KLEIN);
                        let a = if bauen.is_some() {
                            ui.selectable_label(false, n)
                                .on_hover_text(format!("{name}\n(anklicken für Details)"))
                        } else {
                            ui.label(n).on_hover_text(name)
                        };
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            ui.label(egui::RichText::new(format!("{}", b.count))
                                .size(ev_core::theme::ui::FONT_KLEIN)
                                .color(egui::Color32::from_gray(180)));
                        });
                        a
                    }).inner;
                    if antwort.clicked() {
                        if let Some(f) = bauen { *treffer = Some(f(name)); }
                    }
                    // Balken darunter, volle Spaltenbreite.
                    let (rect, _) =
                        ui.allocate_exact_size(egui::vec2(ui.available_width(), 5.0),
                                               egui::Sense::hover());
                    let p = ui.painter();
                    p.rect_filled(rect, 2.0, egui::Color32::from_gray(50));
                    let mut fill = rect;
                    fill.set_width(rect.width() * (b.total / max) as f32);
                    p.rect_filled(fill, 2.0, farbe);
                    ui.add_space(3.0);
                }
            });
    };

    rahmen(ui, |ui| {
    ui.columns(4, |sp| {
        spalte(&mut sp[0], "📊 Apps", "m_apps", &apps,
               egui::Color32::from_rgb(80, 190, 255),
               Some(|n| crate::detail::Detail::Prozess(n.to_string())), &mut geklickt);
        spalte(&mut sp[1], "🌐 Hosts", "m_hosts", &hosts,
               egui::Color32::from_rgb(120, 220, 140),
               Some(|n| crate::detail::Detail::Host(n.to_string())), &mut geklickt);
        spalte(&mut sp[2], "🚦 Verkehr", "m_proto", &protos,
               egui::Color32::from_rgb(200, 140, 255), None, &mut geklickt);
        spalte(&mut sp[3], "🌍 Länder", "m_countries", &laender,
               egui::Color32::from_rgb(255, 200, 90),
               Some(|n| crate::detail::Detail::Land(n.to_string())), &mut geklickt);
    });
    });
    if geklickt.is_some() {
        st.detail = geklickt;
    }
}

pub fn monitoring(ui: &mut egui::Ui, st: &mut AppState) {
    // 1:1 nach monitoring_tab.py: Titel + tuerkiser "Grosse Ansicht"-Knopf in
    // einer Zeile, Infozeile darunter, vier Spalten, "Pausieren" ZUUNTERST.
    ui.horizontal(|ui| {
        ui.label(egui::RichText::new("📊 Live Network Monitoring").size(ev_core::theme::ui::FONT_GROSS).strong());
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            let p = ev_core::theme::ui::PRIMARY;
            if ui.add(egui::Button::new(egui::RichText::new("🔍 Große Ansicht öffnen")
                    .color(egui::Color32::WHITE).strong())
                    .fill(egui::Color32::from_rgb(p[0], p[1], p[2]))).clicked() {
                st.win_monitor = true;
            }
        });
    });
    ui.small("Live-Traffic von Apps, Hosts, Protokollen und Ländern");
    ui.separator();

    monitoring_spalten(ui, st, 12, 300.0);

    // monitoring_tab.py: "⏸️ Pausieren"/"▶️ Fortsetzen" steht UNTER den Tabellen.
    let label = if st.monitor.paused { "▶ Fortsetzen" } else { "⏸ Pausieren" };
    if ui.button(label).clicked() { st.monitor.paused = !st.monitor.paused; }
}

// ── 🖥 Control Center ───────────────────────────────────────────────────────
pub fn control_center(ui: &mut egui::Ui, st: &mut AppState, geo: &ev_geo::GeoDataManager) {
    // 1:1 nach control_center_tab.py: Titel, Beschreibung, tuerkiser Knopf
    // "Grosse Ansicht oeffnen", leere Flaeche, unten der graue Tipp.
    ui.label(egui::RichText::new("🖥 WLAN Control Center")
        .size(ev_core::theme::ui::FONT_GROSS).strong());
    rahmen(ui, |ui| {
        ui.small("Hier kannst du das vollständige WLAN Control Center in einer \
großen Ansicht öffnen. Die große Ansicht enthält das WLAN-Monitor-Panel, \
Live-Statistiken und Verbindungsübersicht.");
    });
    if breiter_knopf(ui, "🔍 Große Ansicht öffnen", true) { st.win_cc = true; }

    // Unten festgeklebter Tipp wie im Original.
    egui::TopBottomPanel::bottom("cc_tipp").show_inside(ui, |ui| {
        ui.small("Tipp: Du kannst das große Control Center auf einen zweiten Monitor legen");
        ui.small("und EarthViewer weiter normal bedienen.");
    });

    // Zugabe der Rust-Edition (Systemueberblick), deshalb eingeklappt.
    ui.collapsing("Mehr (über das Original hinaus)", |ui| {
        let (total, inc, out) = st.connection_stats();
        let up = st.started.elapsed().as_secs();
        egui::Grid::new("cc").striped(true).num_columns(2).show(ui, |ui| {
            let mut row = |k: &str, v: String| { ui.label(k); ui.strong(v); ui.end_row(); };
            row("Laufzeit", format!("{:02}:{:02}:{:02}", up / 3600, (up / 60) % 60, up % 60));
            row("Verbindungen", format!("{total}  (⬇ {inc} / ⬆ {out})"));
            row("Beobachtete Hosts", st.monitor.hosts.len().to_string());
            row("Beobachtete Apps", st.monitor.apps.len().to_string());
            row("Länder", st.monitor.countries.len().to_string());
            row("Blockierte IPs", st.blocklist.len().to_string());
            row("Orte im Index", geo.locations.len().to_string());
            row("GeoIP", if geo.geoip.is_some() { "aktiv".into() } else { "keine MMDB".into() });
            row("Satelliten", st.satellites.len().to_string());
            row("Tracker", if st.tracker.is_running() { "läuft".into() } else { "gestoppt".into() });
        });
        let arp = ev_net::arp::read_arp_cache();
        if arp.is_empty() {
            ui.weak("ARP-Cache leer — im Scanner-Tab einen Sweep anstoßen.");
        }
        for (iface, list) in ev_net::arp::group_by_iface(&arp) {
            ui.strong(format!("— {iface} —"));
            egui::Grid::new(format!("cc_{iface}")).striped(true).num_columns(3).show(ui, |ui| {
                for e in list.iter().filter(|e| e.is_complete()) {
                    ui.label(&e.ip);
                    ui.label(egui::RichText::new(&e.mac).monospace().size(11.0));
                    ui.label(&e.vendor);
                    ui.end_row();
                }
            });
        }
    });
}

// ── 📈 Graph ────────────────────────────────────────────────────────────────
// Nach dem Original-Bildschirmfoto: gestapeltes Flaechendiagramm in KB/s
// mit Upload / Download / Total, 300 Datenpunkte.
pub fn graph(ui: &mut egui::Ui, st: &mut AppState) {
    // 1:1 nach graph_tab.py: Titel + tuerkiser "Grosse Ansicht"-Knopf oben,
    // "Pausieren"/"Loeschen" stehen UNTER der Legende.
    ui.horizontal(|ui| {
        ui.label(egui::RichText::new("📈 Network Traffic Graph").size(ev_core::theme::ui::FONT_GROSS).strong());
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            let p = ev_core::theme::ui::PRIMARY;
            if ui.add(egui::Button::new(egui::RichText::new("🔍 Große Ansicht öffnen")
                    .color(egui::Color32::WHITE).strong())
                    .fill(egui::Color32::from_rgb(p[0], p[1], p[2]))).clicked() {
                st.win_graph = true;
            }
        });
    });

    const UP: egui::Color32 = egui::Color32::from_rgb(240, 200, 60);
    const DOWN: egui::Color32 = egui::Color32::from_rgb(235, 140, 40);
    const TOTAL: egui::Color32 = egui::Color32::from_rgb(235, 110, 175);

    let jetzt = st.rate_history.last().copied().unwrap_or_default();
    ui.horizontal_wrapped(|ui| {
        for (c, v) in [(UP, jetzt.up_kbs()), (DOWN, jetzt.down_kbs()),
                       (TOTAL, jetzt.total_kbs())] {
            let (r, _) = ui.allocate_exact_size(egui::vec2(9.0, 9.0), egui::Sense::hover());
            ui.painter().rect_filled(r, 1.0, c);
            ui.label(egui::RichText::new(format!("{v:.1} KB/s")).size(10.5));
        }
        ui.label(egui::RichText::new(
            format!("| Datenpunkte: {}/300", st.rate_history.len())).size(10.5));
    });
    ui.separator();

    let h = st.rate_history.clone();
    let (rect, _) = ui.allocate_exact_size(
        egui::vec2(ui.available_width(), 250.0), egui::Sense::hover());
    let p = ui.painter_at(rect);
    p.rect_filled(rect, 3.0, egui::Color32::from_gray(22));

    if h.len() < 2 {
        p.text(rect.center(), egui::Align2::CENTER_CENTER, "sammle Messwerte…",
               egui::FontId::proportional(13.0), egui::Color32::from_gray(120));
    } else {

    // Linker Rand muss die Achsenbeschriftung fassen — vorher war "KB/s"
    // angeschnitten und stand als "B/s" da.
    let plot = egui::Rect::from_min_max(
        egui::pos2(rect.left() + 62.0, rect.top() + 8.0),
        egui::pos2(rect.right() - 8.0, rect.bottom() - 22.0));
    let max = h.iter().map(|r| r.total_kbs()).fold(0.0_f64, f64::max).max(0.1) * 1.15;
    // Nachkommastellen an die Groessenordnung anpassen, sonst steht bei
    // kleinen Werten viermal dieselbe "1" an der Achse.
    let stellen = if max >= 100.0 { 0 } else if max >= 10.0 { 1 } else { 2 };

    for i in 0..=4 {
        let y = plot.top() + plot.height() * i as f32 / 4.0;
        p.line_segment([egui::pos2(plot.left(), y), egui::pos2(plot.right(), y)],
                       egui::Stroke::new(1.0, egui::Color32::from_gray(40)));
        p.text(egui::pos2(plot.left() - 6.0, y), egui::Align2::RIGHT_CENTER,
               format!("{:.*}", stellen, max * (4 - i) as f64 / 4.0),
               egui::FontId::monospace(9.0), egui::Color32::from_gray(120));
    }
    p.text(egui::pos2(rect.left() + 6.0, rect.top() + 6.0), egui::Align2::LEFT_TOP,
           "KB/s", egui::FontId::proportional(9.0), egui::Color32::from_gray(140));
    p.text(egui::pos2(plot.center().x, rect.bottom() - 10.0), egui::Align2::CENTER_CENTER,
           "Zeit (s)", egui::FontId::proportional(9.0), egui::Color32::from_gray(140));

    // Gestapelte Flaechen: erst Total, dann Download, dann Upload darueber.
    let flaeche = |sel: &dyn Fn(&ev_net::Rate) -> f64, farbe: egui::Color32| {
        let mut pts: Vec<egui::Pos2> = h.iter().enumerate().map(|(i, r)| {
            let x = plot.left() + plot.width() * i as f32 / (h.len() - 1) as f32;
            let y = plot.bottom() - plot.height() * (sel(r) / max).min(1.0) as f32;
            egui::pos2(x, y)
        }).collect();
        pts.push(egui::pos2(plot.right(), plot.bottom()));
        pts.push(egui::pos2(plot.left(), plot.bottom()));
        p.add(egui::Shape::convex_polygon(pts.clone(), farbe.gamma_multiply(0.55),
                                          egui::Stroke::new(1.4, farbe)));
    };
    flaeche(&|r| r.total_kbs(), TOTAL);
    flaeche(&|r| r.down_kbs(), DOWN);
    flaeche(&|r| r.up_kbs(), UP);
    }

    ui.horizontal_wrapped(|ui| {
        for (t, c) in [("Upload", UP), ("Download", DOWN), ("Total", TOTAL)] {
            let (r, _) = ui.allocate_exact_size(egui::vec2(10.0, 10.0), egui::Sense::hover());
            ui.painter().rect_filled(r, 5.0, c);
            ui.label(egui::RichText::new(t).size(10.5));
        }
    });
    // graph_tab.py: "⏸️ Pausieren" und "🗑️ Löschen" unter der Legende.
    ui.horizontal(|ui| {
        let label = if st.monitor.paused { "▶ Fortsetzen" } else { "⏸ Pausieren" };
        if ui.button(label).clicked() { st.monitor.paused = !st.monitor.paused; }
        if ui.button("🗑 Löschen").clicked() {
            st.rate_history.clear();
            st.monitor.clear_history();
        }
    });
}

// ── 🔒 Schützen ─────────────────────────────────────────────────────────────
pub fn protection(ui: &mut egui::Ui, st: &mut AppState) {
    // 1:1 nach protection_tab.py: Titel + tuerkiser "Grosse Ansicht"-Knopf,
    // Infozeile, IP-Feld + roter "Blockieren"-Knopf, Liste, gruener
    // Freigeben-Knopf, Statuszeile "✅ Firewall aktiv | n IPs blockiert".
    ui.horizontal(|ui| {
        ui.label(egui::RichText::new("🔒 Netzwerk Schutz")
            .size(ev_core::theme::ui::FONT_GROSS).strong());
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            let p = ev_core::theme::ui::PRIMARY;
            if ui.add(egui::Button::new(egui::RichText::new("🔍 Große Ansicht")
                    .color(egui::Color32::WHITE).strong())
                    .fill(egui::Color32::from_rgb(p[0], p[1], p[2]))).clicked() {
                st.win_protection = true;
            }
        });
    });
    ui.small("Blockiere IPs und überwache verdächtige Aktivitäten");
    ui.separator();

    ui.horizontal(|ui| {
        ui.add(egui::TextEdit::singleline(&mut st.block_input)
            .hint_text("IP-Adresse eingeben (z.B. 192.168.1.100)")
            .desired_width(ui.available_width() - 118.0));
        if ui.add(egui::Button::new(egui::RichText::new("🚫 Blockieren")
                .color(egui::Color32::WHITE).strong())
                .fill(egui::Color32::from_rgb(0xE7, 0x4C, 0x3C))).clicked() {
            let ok = st.blocklist.block(&st.block_input.clone());
            if ok {
                st.block_input.clear();
                st.blocklist.save(&ev_core::config::session_dir().join("blocklist.txt")).ok();
            }
        }
    });

    let entries: Vec<String> = st.blocklist.iter().cloned().collect();
    rahmen(ui, |ui| {
    egui::ScrollArea::vertical().max_height(220.0).auto_shrink([false, false]).show(ui, |ui| {
        for (i, ip) in entries.iter().enumerate() {
            let sel = st.selected_blocked == Some(i);
            if ui.selectable_label(sel, egui::RichText::new(format!("🚫 {ip}")).monospace())
                .clicked() {
                st.selected_blocked = Some(i);
            }
        }
        if entries.is_empty() { ui.weak(""); }
    });
    });

    if breiter_knopf(ui, "✅ Ausgewählte IP freigeben", false) {
        if let Some(i) = st.selected_blocked.take() {
            if let Some(ip) = entries.get(i) {
                st.blocklist.unblock(ip);
                st.blocklist.save(&ev_core::config::session_dir().join("blocklist.txt")).ok();
            }
        }
    }

    let n = st.blocklist.len();
    ui.label(egui::RichText::new(
        format!("✅ Firewall aktiv | {n} IP{} blockiert", if n == 1 { "" } else { "s" }))
        .color(egui::Color32::from_rgb(0x27, 0xAE, 0x60)));

    // ── 🔔 Benachrichtigungen (Runde D) ──────────────────────────────────
    ui.add_space(6.0);
    ui.separator();
    ui.horizontal(|ui| {
        let anz = st.alarme.eintraege.len();
        ui.strong(format!("🔔 Benachrichtigungen ({anz})"));
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if ui.small_button("🗑 Leeren").clicked() { st.alarme.leeren(); }
        });
    });
    if st.watch.schwelle_kbs > 0.0 {
        ui.small(format!("Schwelle: {:.0} KB/s (im Zahnrad-Dialog einstellbar)",
                         st.watch.schwelle_kbs));
    } else {
        ui.small("Schwelle aus — im Zahnrad-Dialog (⚙) aktivierbar.");
    }
    rahmen(ui, |ui| {
    egui::ScrollArea::vertical().max_height(160.0).auto_shrink([false, false]).show(ui, |ui| {
        if st.alarme.eintraege.is_empty() {
            ui.weak("Keine Auffälligkeiten.");
        }
        // Jüngste zuerst.
        let jetzt = st.started.elapsed().as_secs_f64();
        for a in st.alarme.eintraege.iter().rev() {
            let c = a.stufe.rgb();
            let vor = (jetzt - a.t).max(0.0) as u64;
            ui.horizontal(|ui| {
                ui.label(egui::RichText::new(a.stufe.symbol())
                    .color(egui::Color32::from_rgb(c[0], c[1], c[2])));
                ui.label(egui::RichText::new(&a.text).size(ev_core::theme::ui::FONT_KLEIN));
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.weak(egui::RichText::new(format!("vor {vor}s")).size(10.0));
                });
            });
        }
    });
    });

    // Zugabe der Rust-Edition, deshalb eingeklappt.
    ui.collapsing("Mehr (über das Original hinaus)", |ui| {
        if let Some(i) = st.selected_connection {
            if let Some(c) = st.connections.get(i) {
                let ip = c.remote_ip.clone();
                if ui.button(format!("🚫 Ausgewählte Gegenstelle blockieren ({ip})")).clicked() {
                    st.blocklist.block(&ip);
                    st.blocklist.save(&ev_core::config::session_dir().join("blocklist.txt")).ok();
                }
            }
        }
        ui.small("Das Original setzte iptables-Regeln selbst — mit root-Rechten und \
dauerhaft. Hier bekommst du sie nur zum Kopieren, damit die Entscheidung bei \
dir bleibt und im Shell-Verlauf steht.");
        let rules = st.blocklist.iptables_rules().join("\n");
        if rules.is_empty() {
            ui.weak("— Blockliste leer —");
        } else {
            ui.add(egui::TextEdit::multiline(&mut rules.clone())
                .font(egui::TextStyle::Monospace).desired_rows(4)
                .desired_width(f32::INFINITY));
            if ui.button("📋 In die Zwischenablage").clicked() {
                ui.ctx().copy_text(rules);
            }
        }
    });
}

// ── 📊 Protokoll Analyse ────────────────────────────────────────────────────
pub fn protocol(ui: &mut egui::Ui, st: &mut AppState) {
    // 1:1 nach protocol_analysis_tab.py: Titel + tuerkiser "Grosse Ansicht",
    // Infozeile, Tabelle Protokoll/Traffic/Pakete/Anteil %, darunter Details.
    ui.horizontal(|ui| {
        ui.label(egui::RichText::new("📊 Protokoll Analyse").size(ev_core::theme::ui::FONT_GROSS).strong());
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            let p = ev_core::theme::ui::PRIMARY;
            if ui.add(egui::Button::new(egui::RichText::new("🔍 Große Ansicht")
                    .color(egui::Color32::WHITE).strong())
                    .fill(egui::Color32::from_rgb(p[0], p[1], p[2]))).clicked() {
                st.win_protocol = true;
            }
        });
    });
    ui.small("Detaillierte Analyse aller Netzwerk-Protokolle");
    ui.separator();

    let protos = st.monitor.top_protocols(20);
    let total: f64 = protos.iter().map(|(_, b)| b.total).sum();

    rahmen(ui, |ui| {
    egui::Grid::new("proto").striped(true).num_columns(4).show(ui, |ui| {
        // protocol_analysis_tab.py: "Protokoll", "Traffic", "Pakete", "Anteil %".
        for h in ["Protokoll", "Traffic", "Pakete", "Anteil %"] { ui.strong(h); }
        ui.end_row();
        for (name, b) in &protos {
            let share = if total > 0.0 { b.total / total } else { 0.0 };
            ui.label(name);
            ui.label(format_bytes(b.total * 1024.0));
            ui.label(format!("{}", b.count));
            ui.label(format!("{:.1} %", share * 100.0));
            ui.end_row();
        }
    });
    if protos.is_empty() { ui.weak("— noch keine Daten —"); }
    });

    ui.add_space(10.0);
    ui.separator();
    ui.strong("📋 Protokoll Details");
    let (t, i, o) = st.connection_stats();
    rahmen(ui, |ui| {
    egui::Grid::new("protodet").striped(true).num_columns(2).show(ui, |ui| {
        let mut row = |k: &str, v: String| { ui.label(k); ui.strong(v); ui.end_row(); };
        row("Verbindungen gesamt", t.to_string());
        row("davon eingehend", i.to_string());
        row("davon ausgehend", o.to_string());
        row("TCP-Anteil", format!("{:.1} %", st.monitor.protocol_share("TCP")));
        row("UDP-Anteil", format!("{:.1} %", st.monitor.protocol_share("UDP")));
        row("Verschiedene Hosts", st.monitor.hosts.len().to_string());
        row("Datenvolumen (geschätzt)", format_bytes(total * 1024.0));
    });
    });
}

// ── 🔍 Netzwerk Scanner ─────────────────────────────────────────────────────
pub enum ScanAction { Start, Stop, UseCommon, UseAll }

pub fn scanner(ui: &mut egui::Ui, st: &mut AppState, running: bool) -> Option<ScanAction> {
    let mut action = None;
    // 1:1 nach network_scanner_tab.py: Titel + tuerkiser "Grosse Ansicht"-Knopf.
    ui.horizontal(|ui| {
        ui.label(egui::RichText::new("🔍 Netzwerk Scanner").size(ev_core::theme::ui::FONT_GROSS).strong());
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            let p = ev_core::theme::ui::PRIMARY;
            if ui.add(egui::Button::new(egui::RichText::new("🔍 Große Ansicht")
                    .color(egui::Color32::WHITE).strong())
                    .fill(egui::Color32::from_rgb(p[0], p[1], p[2]))).clicked() {
                st.win_scanner = true;
            }
        });
    });
    ui.small("Scanne Netzwerke, finde Geräte und prüfe Ports (1-65535)");
    ui.separator();

    ui.horizontal(|ui| {
        ui.label("Ziel:");
        ui.add(egui::TextEdit::singleline(&mut st.scan_target).desired_width(160.0));
        if ui.small_button("lokal").clicked() {
            if let Some(ip) = ev_net::arp::local_ipv4() {
                st.scan_target = ip.to_string();
            }
        }
    });
    ui.horizontal(|ui| {
        ui.label("Ports:");
        ui.add(egui::DragValue::new(&mut st.scan_from).range(1..=65535));
        ui.label("–");
        ui.add(egui::DragValue::new(&mut st.scan_to).range(1..=65535));
        if ui.small_button("häufige").on_hover_text(
            "Sprung auf die 22 gebräuchlichen Dienstports").clicked() {
            action = Some(ScanAction::UseCommon);
        }
        if ui.small_button("alle").on_hover_text("1-65535 wie im Original").clicked() {
            action = Some(ScanAction::UseAll);
        }
    });
    ui.horizontal(|ui| {
        ui.label("Threads:");
        ui.add(egui::DragValue::new(&mut st.scan_threads).range(1..=256));
    });

    ui.add_space(4.0);
    if !running {
        if breiter_knopf(ui, "Scan starten", true) { action = Some(ScanAction::Start); }
    } else if breiter_knopf(ui, "⏹ Abbrechen", false) {
        action = Some(ScanAction::Stop);
    }

    let (done, total) = st.scan_progress;
    if total > 0 {
        ui.add(egui::ProgressBar::new(done as f32 / total as f32)
            .text(format!("{done}/{total}")));
    }
    ui.label(&st.scan_status);
    ui.separator();

    ui.label(
        egui::RichText::new(format!("📊 Offene Ports: {}", st.scan_results.len()))
            .size(ev_core::theme::ui::FONT_UEBERSCHRIFT).strong(),
    );
    rahmen(ui, |ui| {
    egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
        egui::Grid::new("ports").striped(true).num_columns(2).show(ui, |ui| {
            ui.strong("Port"); ui.strong("Dienst"); ui.end_row();
            for p in &st.scan_results {
                ui.label(egui::RichText::new(format!("{}", p.port)).monospace());
                ui.label(&p.service);
                ui.end_row();
            }
        });
        if st.scan_results.is_empty() && !running {
            ui.weak("— kein Ergebnis —");
        }
    });
    });
    action
}

/// Portspanne prüfen. Das Original lehnt `start > end` ab
/// (`network_scanner_tab.py`, Zeile 236) statt still zu tauschen.
pub fn pruefe_bereich(from: u16, to: u16) -> Result<(u16, u16), String> {
    if from == 0 || to == 0 {
        return Err("Ports beginnen bei 1".into());
    }
    if from > to {
        return Err(format!("Startport {from} liegt hinter Endport {to}"));
    }
    Ok((from, to))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn range_check_matches_original() {
        assert_eq!(pruefe_bereich(80, 443), Ok((80, 443)));
        assert!(pruefe_bereich(1024, 1).is_err(), "start > end muss abgelehnt werden");
        assert!(pruefe_bereich(0, 100).is_err());
        assert_eq!(pruefe_bereich(1, 65535), Ok((1, 65535)));
    }

    #[test]
    fn full_range_is_the_default() {
        // network_scanner_tab.py: port_start=1, port_end=65535
        let geo = std::sync::Arc::new(ev_geo::GeoDataManager {
            data_root: "/nonexistent".into(), locations: vec![], geoip: None, asn: None });
        let s = AppState::new(geo);
        assert_eq!((s.scan_from, s.scan_to), (1, 65535));
    }

    #[test]
    fn common_ports_cover_the_usual_suspects() {
        for p in [22u16, 80, 443, 3306] {
            assert!(ev_net::portscan::COMMON_PORTS.contains(&p), "Port {p} fehlt");
        }
    }

    #[test]
    fn monitor_feeds_the_tables() {
        let m = ev_net::NetworkMonitor::new();
        assert!(m.top_apps(5).is_empty());
        assert_eq!(m.protocol_share("TCP"), 0.0);
    }
}
