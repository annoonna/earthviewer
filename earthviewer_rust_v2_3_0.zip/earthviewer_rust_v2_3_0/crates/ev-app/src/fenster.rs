//! Große Ansichten — 1:1-Ports der freistehenden `QDialog`-Fenster des
//! Python-Originals. Jede „Große Ansicht öffnen"-Schaltfläche in der
//! Seitenleiste hat hier ihr Gegenstück:
//!
//! | Reiter            | Original-Datei                     | Fenstertitel |
//! |-------------------|-----------------------------------|--------------|
//! | Monitoring        | `network_monitor_window.py`       | 📊 EarthViewer - Network Monitor (Live) |
//! | Live Verbindungen | `live_connections_window.py`      | 🔴 Live Netzwerk Verbindungen - Große Ansicht |
//! | Control Center    | `control_center_window.py`        | WLAN Control Center – Erweiterte Ansicht |
//! | Control Center ▸  | `control_center_window.py` (Clients) | 🖧 Netzwerk-Clients |
//! | Graph             | `graph_large_window.py`           | 📈 Network Traffic Graph - Große Ansicht |
//! | Schützen          | `protection_large_window.py`      | 🔒 Schutz - Große Ansicht |
//! | Protokoll Analyse | `protocol_large_window.py`        | 📊 Protokoll Analyse - Große Ansicht |
//! | Netzwerk Scanner  | `scanner_large_window.py`         | 🔍 Scanner - Große Ansicht |
//! | Zahnrad           | `main_window._show_settings`      | ⚙️ Erweiterte Einstellungen |
//!
//! Die Fenster teilen sich Zeichenroutinen mit den Reitern (`crate::tabs`),
//! damit „groß" und „klein" nicht auseinanderlaufen — genau der Fehler, den
//! das Original mit doppeltem Code hatte.

use crate::state::AppState;
use ev_net::monitor::format_bytes;

const PRIMARY: [u8; 3] = ev_core::theme::ui::PRIMARY;

fn schliessknopf(ui: &mut egui::Ui, offen: &mut bool) {
    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
        if ui.add(egui::Button::new(egui::RichText::new("✖ Schließen")
                .color(egui::Color32::WHITE).strong())
                .fill(egui::Color32::from_rgb(0xE7, 0x4C, 0x3C))).clicked() {
            *offen = false;
        }
    });
}

/// 📊 Network Monitor (Live) — vier Tabellen nebeneinander, groß.
pub fn network_monitor(ctx: &egui::Context, st: &mut AppState) {
    if !st.win_monitor { return; }
    let mut offen = st.win_monitor;
    egui::Window::new("📊 EarthViewer - Network Monitor (Live)")
        .open(&mut offen)
        .default_size([900.0, 560.0])
        .collapsible(false)
        .show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label(egui::RichText::new("📊 Network Monitor - Live View")
                    .size(ev_core::theme::ui::FONT_GROSS).strong());
                let pause = if st.monitor.paused { "▶ Pause" } else { "⏸ Pause" };
                if ui.button(pause).clicked() { st.monitor.paused = !st.monitor.paused; }
            });
            ui.colored_label(egui::Color32::from_rgb(0xE7, 0x4C, 0x3C),
                "🔴 Live - Aktualisiert alle 2 Sekunden");
            ui.separator();
            crate::tabs::monitoring_spalten(ui, st, 20, 380.0);
        });
    st.win_monitor = offen;
}

/// 🔴 Live Netzwerk Verbindungen — große Tabelle.
pub fn live_connections(ctx: &egui::Context, st: &mut AppState) {
    if !st.win_live { return; }
    let mut offen = st.win_live;
    egui::Window::new("🔴 Live Netzwerk Verbindungen - Große Ansicht")
        .open(&mut offen)
        .default_size([860.0, 560.0])
        .collapsible(false)
        .show(ctx, |ui| {
            let (total, inc, out) = st.connection_stats();
            ui.horizontal(|ui| {
                ui.label(egui::RichText::new("🌐 Live Verbindungen")
                    .size(ev_core::theme::ui::FONT_GROSS).strong());
                schliessknopf(ui, &mut st.win_live);
            });
            ui.label(format!("Gesamt: {total} · 📥 {inc} · 📤 {out}"));
            ui.separator();
            egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
                egui::Grid::new("live_gross").striped(true).num_columns(6).show(ui, |ui| {
                    for h in ["Prozess", "Gegenstelle", "Port", "Ort", "Protokoll", "Richtung"] {
                        ui.strong(h);
                    }
                    ui.end_row();
                    for c in &st.connections {
                        ui.label(&c.app_name);
                        ui.label(egui::RichText::new(&c.remote_ip).monospace());
                        ui.label(format!("{}", c.remote_port));
                        ui.label(if c.city.is_empty() {
                            c.country.clone()
                        } else {
                            format!("{}, {}", c.city, c.country)
                        });
                        ui.label(&c.protocol);
                        ui.label(if c.is_incoming() { "📥 IN" } else { "📤 OUT" });
                        ui.end_row();
                    }
                });
                if st.connections.is_empty() {
                    ui.weak("Noch keine etablierten Verbindungen erfasst.");
                }
            });
        });
    if offen != st.win_live { st.win_live = offen && st.win_live; }
    if !offen { st.win_live = false; }
}

/// WLAN Control Center – Erweiterte Ansicht (control_center_window.py).
/// Drei Reiter: WiFi Monitor · Live Statistiken · Einstellungen.
pub fn control_center(ctx: &egui::Context, st: &mut AppState) {
    if !st.win_cc { return; }
    let mut offen = st.win_cc;
    egui::Window::new("WLAN Control Center – Erweiterte Ansicht")
        .open(&mut offen)
        .default_size([820.0, 560.0])
        .collapsible(false)
        .show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label(egui::RichText::new("WLAN Control Center – Professional Edition")
                    .size(ev_core::theme::ui::FONT_GROSS).strong());
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.colored_label(egui::Color32::from_rgb(0xF3, 0x9C, 0x12),
                        egui::RichText::new("Status: Bereit").strong());
                });
            });
            ui.separator();
            ui.horizontal(|ui| {
                for (i, name) in ["🔍 WiFi Monitor", "📊 Live Statistiken", "⚙ Einstellungen"]
                    .iter().enumerate()
                {
                    let sel = st.cc_tab == i as u8;
                    let f = if sel { PRIMARY } else { ev_core::theme::ui::SURFACE_VARIANT };
                    if ui.add(egui::Button::new(egui::RichText::new(*name).color(egui::Color32::WHITE))
                            .fill(egui::Color32::from_rgb(f[0], f[1], f[2]))).clicked() {
                        st.cc_tab = i as u8;
                    }
                }
            });
            ui.separator();
            match st.cc_tab {
                0 => cc_wifi_monitor(ui, st),
                1 => cc_live_stats(ui, st),
                _ => cc_einstellungen(ui, st),
            }
            ui.separator();
            ui.small("Tipp: Du kannst das große Control Center auf einen zweiten \
                      Monitor legen und EarthViewer weiter normal bedienen.");
        });
    st.win_cc = offen;
}

fn cc_wifi_monitor(ui: &mut egui::Ui, st: &mut AppState) {
    ui.strong("WLAN Monitor-Mode");
    ui.small("Monitor-Mode Steuerung via airmon-ng.");
    ui.small("Wähle dein WLAN-Interface (wlan0/wlan1):");
    ui.horizontal(|ui| {
        ui.label("🖧 Interface:");
        ui.add(egui::TextEdit::singleline(&mut st.cc_interface).desired_width(200.0));
    });
    ui.colored_label(egui::Color32::from_rgb(80, 190, 255),
        format!("🖧 Modus: MANAGED (normal)"));
    ui.checkbox(&mut st.cc_aggressive, "Aggressiver Modus (airmon-ng check kill)");
    ui.horizontal(|ui| {
        if ui.add(egui::Button::new(egui::RichText::new("▶ Start Monitor")
                .color(egui::Color32::WHITE)).fill(egui::Color32::from_rgb(0x27, 0xAE, 0x60)))
            .clicked() {
            st.cc_console.push(format!("▶ Monitor-Mode auf {} — braucht root/airmon-ng.",
                                       st.cc_interface));
        }
        if ui.add(egui::Button::new(egui::RichText::new("⏹ Stop Monitor")
                .color(egui::Color32::WHITE)).fill(egui::Color32::from_rgb(0xE7, 0x4C, 0x3C)))
            .clicked() {
            st.cc_console.push("⏹ Monitor-Mode beendet.".into());
        }
        if ui.add(egui::Button::new(egui::RichText::new("🔄 WLAN Reset")
                .color(egui::Color32::WHITE)).fill(egui::Color32::from_rgb(0x29, 0x80, 0xB9)))
            .clicked() {
            st.cc_console.push("🔄 WLAN zurückgesetzt.".into());
        }
    });
    egui::Frame::new().fill(egui::Color32::from_rgb(0x1e, 0x1e, 0x1e))
        .inner_margin(egui::Margin::same(5)).show(ui, |ui| {
        egui::ScrollArea::vertical().max_height(180.0).auto_shrink([false, false])
            .stick_to_bottom(true).show(ui, |ui| {
            for line in &st.cc_console {
                ui.label(egui::RichText::new(line).monospace()
                    .color(egui::Color32::from_rgb(0, 255, 0))
                    .size(ev_core::theme::ui::FONT_KLEIN));
            }
        });
    });
}

fn cc_live_stats(ui: &mut egui::Ui, st: &mut AppState) {
    ui.strong("📊 Live-Statistiken");
    let r = st.rate_history.last().copied().unwrap_or_default();
    ui.label(format!("Durchsatz jetzt: {:.1} KB/s", r.total_kbs()));
    ui.label(format!("Sitzung: ⬇ {} · ⬆ {}",
        format_bytes(st.meter.session_rx as f64),
        format_bytes(st.meter.session_tx as f64)));
    ui.separator();
    crate::tabs::monitoring_spalten(ui, st, 20, 300.0);
}

fn cc_einstellungen(ui: &mut egui::Ui, st: &mut AppState) {
    // VirusTotal API Configuration — 1:1 nach control_center_window.py.
    ui.strong("🔑 VirusTotal API Configuration");
    ui.horizontal(|ui| {
        ui.label("API Key:");
        ui.add(egui::TextEdit::singleline(&mut st.vt_api_key)
            .password(true).desired_width(320.0));
        if ui.button("Test").clicked() {
            st.vt_status = if st.vt_api_key.trim().is_empty() {
                "Status: kein Key eingegeben".into()
            } else {
                "Status: Key gespeichert — Test braucht Netzugang.".into()
            };
        }
        if ui.button("Speichern").clicked() {
            if let Ok(mut s) = ev_core::settings::global().lock() {
                s.set("vt_api_key", st.vt_api_key.as_str());
            }
            st.vt_status = "Status: gespeichert.".into();
        }
    });
    ui.checkbox(&mut st.vt_autoscan, "Automatisch alle neuen IPs scannen");
    if !st.vt_status.is_empty() {
        ui.colored_label(egui::Color32::from_rgb(0x27, 0xAE, 0x60), &st.vt_status);
    }
    ui.add_space(8.0);
    ui.strong("Aktionen");
    ui.horizontal(|ui| {
        if ui.add(egui::Button::new(egui::RichText::new("🖧 Netzwerk-Clients scannen")
                .color(egui::Color32::WHITE)).fill(egui::Color32::from_rgb(PRIMARY[0], PRIMARY[1], PRIMARY[2])))
            .clicked() {
            st.win_clients = true;
        }
        if ui.add(egui::Button::new(egui::RichText::new("🖧 Live WiFi-Capture starten")
                .color(egui::Color32::WHITE)).fill(egui::Color32::from_rgb(0x29, 0x80, 0xB9)))
            .clicked() {
            st.cc_console.push("🖧 WiFi-Capture — braucht Monitor-Mode + root.".into());
            st.cc_tab = 0;
        }
    });
}

/// 🖧 Netzwerk-Clients (Unterfenster des Control Centers).
/// Port von control_center_window.py — ARP-Sweep der lokalen Geräte.
pub fn clients(ctx: &egui::Context, st: &mut AppState) {
    if !st.win_clients { return; }
    let mut offen = st.win_clients;
    egui::Window::new("🖧 Netzwerk-Clients")
        .open(&mut offen)
        .default_size([760.0, 500.0])
        .collapsible(false)
        .show(ctx, |ui| {
            ui.strong("🖧 Lokale Netzwerk-Geräte");
            ui.separator();
            let arp = ev_net::arp::read_arp_cache();
            let geraete: Vec<_> = arp.iter().filter(|e| e.is_complete()).collect();
            egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
                egui::Grid::new("clients").striped(true).num_columns(6).show(ui, |ui| {
                    for h in ["#", "IP-Adresse", "MAC-Adresse", "Hersteller", "Signal", "VirusTotal"] {
                        ui.strong(h);
                    }
                    ui.end_row();
                    for (i, e) in geraete.iter().enumerate() {
                        ui.label(format!("{}", i + 1));
                        ui.label(&e.ip);
                        ui.label(egui::RichText::new(&e.mac).monospace()
                            .size(ev_core::theme::ui::FONT_KLEIN));
                        ui.label(if e.vendor.is_empty() { "Unknown" } else { &e.vendor });
                        ui.label("—");
                        ui.label(egui::RichText::new("🔍 Scan").color(
                            egui::Color32::from_rgb(80, 190, 255)));
                        ui.end_row();
                    }
                });
                if geraete.is_empty() {
                    ui.weak("Keine Geräte im ARP-Cache — erst im Scanner einen Sweep starten.");
                }
            });
            ui.small(format!("{} Geräte gefunden", geraete.len()));
        });
    st.win_clients = offen;
}

/// 📈 Network Traffic Graph — Große Ansicht.
pub fn graph(ctx: &egui::Context, st: &mut AppState) {
    if !st.win_graph { return; }
    let mut offen = st.win_graph;
    egui::Window::new("📈 Network Traffic Graph - Große Ansicht")
        .open(&mut offen)
        .default_size([880.0, 560.0])
        .collapsible(false)
        .show(ctx, |ui| {
            crate::tabs::graph(ui, st);
        });
    st.win_graph = offen;
}

/// 🔒 Schutz - Große Ansicht.
pub fn protection(ctx: &egui::Context, st: &mut AppState) {
    if !st.win_protection { return; }
    let mut offen = st.win_protection;
    egui::Window::new("🔒 Schutz - Große Ansicht")
        .open(&mut offen)
        .default_size([700.0, 520.0])
        .collapsible(false)
        .show(ctx, |ui| {
            crate::tabs::protection(ui, st);
        });
    st.win_protection = offen;
}

/// 📊 Protokoll Analyse - Große Ansicht.
pub fn protocol(ctx: &egui::Context, st: &mut AppState) {
    if !st.win_protocol { return; }
    let mut offen = st.win_protocol;
    egui::Window::new("📊 Protokoll Analyse - Große Ansicht")
        .open(&mut offen)
        .default_size([760.0, 520.0])
        .collapsible(false)
        .show(ctx, |ui| {
            crate::tabs::protocol(ui, st);
        });
    st.win_protocol = offen;
}

/// 🔍 Scanner - Große Ansicht. Nimmt `ScanAction` entgegen wie der Reiter.
pub fn scanner(ctx: &egui::Context, st: &mut AppState, running: bool)
    -> (bool, Option<crate::tabs::ScanAction>)
{
    if !st.win_scanner { return (false, None); }
    let mut offen = st.win_scanner;
    let mut act = None;
    egui::Window::new("🔍 Scanner - Große Ansicht")
        .open(&mut offen)
        .default_size([780.0, 540.0])
        .collapsible(false)
        .show(ctx, |ui| {
            act = crate::tabs::scanner(ui, st, running);
        });
    st.win_scanner = offen;
    (true, act)
}

/// ⚙️ Erweiterte Einstellungen — Port von main_window._show_settings.
/// Enthält im Original: 🎬 Animationen (Rotations-Slider) und 🏷️ Marker
/// (Marker-Höhe). Die Rust-Zugaben (Theme, Puls, Heimatpunkt, Originaltreue)
/// stehen darunter, klar als solche gekennzeichnet.
pub fn settings(ctx: &egui::Context, st: &mut AppState, rotate_speed: &mut f32,
                camera_reset: &mut bool)
{
    if !st.win_settings { return; }
    let mut offen = st.win_settings;
    egui::Window::new("⚙ Erweiterte Einstellungen")
        .open(&mut offen)
        .default_width(500.0)
        .collapsible(false)
        .show(ctx, |ui| {
            // 🎬 Animationen
            ui.strong("🎬 Animationen");
            ui.horizontal(|ui| {
                ui.label("Rotations-Geschwindigkeit:");
                ui.add(egui::Slider::new(rotate_speed, 0.01..=1.0).show_value(false));
                ui.label(format!("{:.2}°/Frame", rotate_speed));
            });
            ui.add_space(6.0);

            // 🏷️ Marker
            ui.strong("🏷 Marker");
            ui.horizontal(|ui| {
                ui.label("Marker-Höhe:");
                ui.add(egui::DragValue::new(&mut st.marker_offset)
                    .speed(0.005).range(0.001..=0.1).max_decimals(3));
            });
            ui.separator();

            // Rust-Zugaben
            ui.collapsing("Darstellung & Verhalten (Rust-Edition)", |ui| {
                // Layout-Umschalter: klassisch (1:1-Original) ↔ GlasWire-Dashboard.
                ui.horizontal(|ui| {
                    ui.label("Layout:");
                    let mut dash = st.layout == crate::state::LayoutModus::Dashboard;
                    if ui.selectable_label(!dash, "Klassisch (1:1)").clicked() {
                        st.layout = crate::state::LayoutModus::Klassisch;
                        dash = false;
                    }
                    if ui.selectable_label(dash, "Dashboard (GlasWire-Stil)").clicked() {
                        st.layout = crate::state::LayoutModus::Dashboard;
                    }
                });
                ui.small("Dashboard: Zeit-Graph + Icon-Navleiste. Klassisch: \
                          Globus + Original-Seitenleiste. Umschaltbar jederzeit.");
                ui.separator();
                // Runde D Teil 2: Karten-Kachel-Ebene (Google-Earth-artig).
                ui.strong("🗺 Karten-Ebene (zoombare Karte)");
                let vorher = st.tiles_an;
                ui.checkbox(&mut st.tiles_an,
                    "Karten beim Zoomen nachladen (braucht Internet)");
                if st.tiles_an {
                    ui.horizontal(|ui| {
                        ui.label("Quelle:");
                        ui.selectable_value(&mut st.tile_quelle_osm, true,
                            "OpenStreetMap (Straßen)");
                        ui.selectable_value(&mut st.tile_quelle_osm, false,
                            "NASA GIBS (Satellit)");
                    });
                    // Attribution ist Pflicht — direkt aus der Quelle.
                    let attr = if st.tile_quelle_osm {
                        crate::tileloader::TileQuelle::osm().attribution
                    } else {
                        crate::tileloader::TileQuelle::gibs().attribution
                    };
                    ui.small(&attr);
                    ui.small("Tiefer zoomen zeigt mehr Details (Länder → Städte → Straßen). \
                              Kacheln werden lokal zwischengespeichert.");
                    if st.layout == crate::state::LayoutModus::Dashboard {
                        ui.small("Hinweis: Zum Sehen in die Globus-Ansicht wechseln (Knopf oben).");
                    }
                }
                if vorher != st.tiles_an && !st.tiles_an {
                    st.status = "Karten-Ebene aus".into();
                }
                ui.separator();
                egui::ComboBox::from_label("Theme")
                    .selected_text(st.theme.name)
                    .show_ui(ui, |ui| {
                        for name in ev_core::theme::theme_names() {
                            if ui.selectable_label(st.theme.name == name, name).clicked() {
                                st.theme = ev_core::theme::theme_by_name(name);
                                if let Ok(mut s) = ev_core::settings::global().lock() {
                                    s.set("theme", name);
                                }
                            }
                        }
                    });
                ui.add(egui::Slider::new(&mut st.animation_speed, 0.0..=3.0)
                    .text("Puls der Verbindungsbögen"));
                ui.separator();
                // Runde D: Überwachung / Alarme.
                ui.strong("🔔 Überwachung & Alarme");
                let mut geaendert = false;
                ui.horizontal(|ui| {
                    ui.label("Schwelle:");
                    geaendert |= ui.add(egui::Slider::new(&mut st.watch.schwelle_kbs, 0.0..=5000.0)
                        .suffix(" KB/s").text("(0 = aus)")).changed();
                });
                geaendert |= ui.checkbox(&mut st.watch.melde_favoriten,
                    "Bei Traffic eines Favoriten benachrichtigen").changed();
                geaendert |= ui.checkbox(&mut st.watch.melde_blockiert,
                    "Bei geblockter Gegenstelle benachrichtigen").changed();
                if geaendert { st.watch.speichern(); }
                ui.horizontal(|ui| {
                    ui.label("Heimatpunkt:");
                    ui.add(egui::DragValue::new(&mut st.home.lat)
                        .speed(0.1).range(-90.0..=90.0).prefix("lat "));
                    ui.add(egui::DragValue::new(&mut st.home.lon)
                        .speed(0.1).range(-180.0..=180.0).prefix("lon "));
                });
                let mut korr = ev_core::treue::korrigiert();
                if ui.checkbox(&mut korr, "Korrekturen aktivieren (statt 1:1)")
                    .on_hover_text("Aus = exakt wie EarthViewer 2.0, mit seinen Fehlern.")
                    .changed()
                {
                    ev_core::treue::set(if korr {
                        ev_core::Treue::Korrigiert
                    } else {
                        ev_core::Treue::Original
                    });
                    *camera_reset = true;
                }
            });

            ui.separator();
            if ui.add(egui::Button::new(egui::RichText::new("✓ Schließen")
                    .color(egui::Color32::WHITE).strong())
                    .fill(egui::Color32::from_rgb(PRIMARY[0], PRIMARY[1], PRIMARY[2]))).clicked() {
                if let Ok(mut s) = ev_core::settings::global().lock() {
                    s.set("marker_offset", st.marker_offset as f64);
                    s.set("auto_rotate_speed", *rotate_speed as f64);
                }
                st.win_settings = false;
            }
        });
    if offen { st.win_settings = st.win_settings; } else { st.win_settings = false; }
}

/// SatMonitor PRO — 1:1-Port von `sat_monitor_window.py::SatMonitorWindow`.
/// Drei Reiter: Spektrum · Sat-Tracking · Spectator API. Öffnet über den
/// türkisen „🖥 PRO Monitor öffnen"-Knopf im Satelliten-Reiter.
///
/// `sats` sind die aktuell sichtbaren Satelliten (für den Tracking-Reiter),
/// `rng` treibt die Spektrum-Simulation (ein Schritt pro Frame, solange „läuft").
pub fn sat_monitor(ctx: &egui::Context, st: &mut AppState,
                   sats: &[ev_sat::SatState], rng: &mut ev_sat::spektrum::Zufall) {
    if !st.sat_pro_offen { return; }
    let mut offen = st.sat_pro_offen;
    egui::Window::new("SatMonitor – Satelliten & Spektrum")
        .open(&mut offen)
        .default_size([1000.0, 620.0])
        .collapsible(false)
        .show(ctx, |ui| {
            // Menüleiste (Datei · Ansicht · Hilfe) wie im Original.
            egui::menu::bar(ui, |ui| {
                ui.menu_button("Datei", |ui| {
                    if ui.button("Beenden").clicked() {
                        st.sat_pro_offen = false;
                        ui.close_menu();
                    }
                });
                ui.menu_button("Ansicht", |_ui| {});
                ui.menu_button("Hilfe", |ui| {
                    if ui.button("Über SatMonitor").clicked() {
                        st.spec_status = "SatMonitor v0.2.0 — Spektrum, SGP4-Tracking, \
                                          Spectator-Earth. Integriert in EarthViewer 2.0."
                            .into();
                        ui.close_menu();
                    }
                });
            });
            ui.separator();

            // Reiterleiste
            ui.horizontal(|ui| {
                for (i, name) in ["Spektrum", "Sat-Tracking", "Spectator API"]
                    .iter().enumerate()
                {
                    let sel = st.pro_tab == i as u8;
                    let f = if sel { PRIMARY } else { ev_core::theme::ui::SURFACE_VARIANT };
                    if ui.add(egui::Button::new(egui::RichText::new(*name).color(egui::Color32::WHITE))
                            .fill(egui::Color32::from_rgb(f[0], f[1], f[2]))).clicked() {
                        st.pro_tab = i as u8;
                    }
                }
            });
            ui.separator();

            match st.pro_tab {
                0 => spektrum_tab(ui, st, rng),
                1 => tracking_tab(ui, st, sats),
                _ => spectator_tab(ui, st),
            }

            // Statusleiste unten.
            egui::TopBottomPanel::bottom("pro_status").show_inside(ui, |ui| {
                ui.colored_label(egui::Color32::from_rgb(PRIMARY[0], PRIMARY[1], PRIMARY[2]),
                    if st.spec_status.is_empty() { "Bereit" } else { &st.spec_status });
            });
        });
    st.sat_pro_offen = offen;
}

fn spektrum_tab(ui: &mut egui::Ui, st: &mut AppState, rng: &mut ev_sat::spektrum::Zufall) {
    use ev_sat::spektrum;
    // ── Steuerreihe 1: Center Freq · Sample Rate · FFT Size · Sat-Profil ──
    ui.horizontal(|ui| {
        ui.label("Center Freq (Hz):");
        ui.add(egui::TextEdit::singleline(&mut st.spec_freq).desired_width(120.0));
        ui.label("Sample Rate (Hz):");
        ui.add(egui::TextEdit::singleline(&mut st.spec_rate).desired_width(100.0));
        ui.label("FFT Size:");
        egui::ComboBox::from_id_salt("fft")
            .selected_text(format!("{}", st.spec_fft))
            .show_ui(ui, |ui| {
                for n in [256usize, 512, 1024, 2048, 4096, 8192] {
                    ui.selectable_value(&mut st.spec_fft, n, format!("{n}"));
                }
            });
        ui.label("Sat-Profil:");
        let profile_namen: Vec<&str> = std::iter::once("— kein Sat-Profil —")
            .chain(spektrum::SAT_PROFILE.iter().map(|p| p.0)).collect();
        egui::ComboBox::from_id_salt("satprofil")
            .selected_text(profile_namen[st.spec_profile])
            .show_ui(ui, |ui| {
                for (i, name) in profile_namen.iter().enumerate() {
                    if ui.selectable_value(&mut st.spec_profile, i, *name).clicked() && i > 0 {
                        // _apply_profile: Frequenz + Rate aus dem Profil setzen.
                        let (_, cf, sr) = spektrum::SAT_PROFILE[i - 1];
                        st.spec_freq = format!("{}", cf as i64);
                        st.spec_rate = format!("{}", sr as i64);
                        st.spec_status = format!("Profil geladen: {}", spektrum::SAT_PROFILE[i - 1].0);
                    }
                }
            });
    });

    // ── Steuerreihe 2: Quelle · Signalprofil · Diagramm · Farbschema · Start/Stop ──
    ui.horizontal(|ui| {
        ui.label("Quelle:");
        egui::ComboBox::from_id_salt("quelle")
            .selected_text(spektrum::QUELLE[st.spec_source])
            .show_ui(ui, |ui| {
                for (i, q) in spektrum::QUELLE.iter().enumerate() {
                    ui.selectable_value(&mut st.spec_source, i, *q);
                }
            });
        ui.label("Signalprofil (Simulation):");
        egui::ComboBox::from_id_salt("muster")
            .selected_text(spektrum::MUSTER[st.spec_pattern])
            .show_ui(ui, |ui| {
                for (i, m) in spektrum::MUSTER.iter().enumerate() {
                    ui.selectable_value(&mut st.spec_pattern, i, *m);
                }
            });
        ui.label("Diagramm:");
        egui::ComboBox::from_id_salt("diagramm")
            .selected_text(spektrum::DIAGRAMM[st.spec_diagram])
            .show_ui(ui, |ui| {
                for (i, d) in spektrum::DIAGRAMM.iter().enumerate() {
                    ui.selectable_value(&mut st.spec_diagram, i, *d);
                }
            });
        ui.label("Farbschema:");
        egui::ComboBox::from_id_salt("farbe")
            .selected_text(spektrum::FARBSCHEMA[st.spec_color])
            .show_ui(ui, |ui| {
                for (i, c) in spektrum::FARBSCHEMA.iter().enumerate() {
                    ui.selectable_value(&mut st.spec_color, i, *c);
                }
            });
        let p = PRIMARY;
        if ui.add_enabled(!st.spec_running, egui::Button::new(
                egui::RichText::new("Start").color(egui::Color32::WHITE))
                .fill(egui::Color32::from_rgb(p[0], p[1], p[2]))).clicked() {
            match (st.spec_freq.trim().parse::<f64>(), st.spec_rate.trim().parse::<f64>()) {
                (Ok(_), Ok(_)) => {
                    st.spec_running = true;
                    st.spec_wasserfall.clear();
                    st.spec_status = "Läuft...".into();
                }
                _ => st.spec_status = "Ungültige Parameter!".into(),
            }
        }
        if ui.add_enabled(st.spec_running, egui::Button::new("Stop")).clicked() {
            st.spec_running = false;
            st.spec_status = "Gestoppt".into();
        }
    });

    // ── Simulationsschritt (im Original der 100-ms-Thread) ──
    if st.spec_running {
        if let (Ok(cf), Ok(sr)) =
            (st.spec_freq.trim().parse::<f64>(), st.spec_rate.trim().parse::<f64>())
        {
            let (freqs, psd) = spektrum::simulieren(
                spektrum::MUSTER[st.spec_pattern], cf, sr, st.spec_fft, rng);
            st.spec_freqs = freqs;
            st.spec_psd = psd.clone();
            if st.spec_diagram == 1 {
                st.spec_wasserfall.push(psd);
                let max = 120;
                if st.spec_wasserfall.len() > max {
                    let drop = st.spec_wasserfall.len() - max;
                    st.spec_wasserfall.drain(0..drop);
                }
            }
        }
    }

    // ── Diagramm: Leistung (dB) über Frequenz (MHz) ──
    spektrum_zeichnen(ui, st);

    ui.add_space(4.0);
    egui::Frame::new().fill(egui::Color32::from_gray(51))
        .inner_margin(egui::Margin::same(8)).show(ui, |ui| {
        ui.colored_label(egui::Color32::from_rgb(PRIMARY[0], PRIMARY[1], PRIMARY[2]),
            "💡 Hinweis: Wähle ein Sat-Profil, um typische Frequenz-, Sample-Rate- \
             und FFT-Werte für NOAA, METEOR, ADS-B, ACARS, AIS oder ISS zu setzen.");
    });
}

/// Farbschema-Abbildung (color_combo) auf eine Kurvenfarbe.
fn spektrum_farbe(schema: usize) -> egui::Color32 {
    match schema {
        1 => egui::Color32::from_rgb(0xF3, 0x9C, 0x12), // Heiß
        2 => egui::Color32::from_rgb(0xE7, 0x4C, 0x3C), // Blau-Rot (Rot-Ende)
        3 => egui::Color32::from_rgb(0x5D, 0xC8, 0x63), // Viridis-ähnlich
        _ => egui::Color32::from_rgb(PRIMARY[0], PRIMARY[1], PRIMARY[2]), // Grau→Türkis (Original-Pen #0d7377)
    }
}

fn spektrum_zeichnen(ui: &mut egui::Ui, st: &AppState) {
    let (rect, _) = ui.allocate_exact_size(
        egui::vec2(ui.available_width(), 300.0), egui::Sense::hover());
    let p = ui.painter_at(rect);
    p.rect_filled(rect, 3.0, egui::Color32::from_rgb(0x1e, 0x1e, 0x1e));

    if st.spec_psd.len() < 2 {
        p.text(rect.center(), egui::Align2::CENTER_CENTER,
            "Start drücken — Simulation liefert das Spektrum.",
            egui::FontId::proportional(13.0), egui::Color32::from_gray(120));
        return;
    }

    let plot = egui::Rect::from_min_max(
        egui::pos2(rect.left() + 56.0, rect.top() + 10.0),
        egui::pos2(rect.right() - 10.0, rect.bottom() - 26.0));

    // Optionaler Wasserfall als Hintergrund (Linie+Wasserfall).
    if st.spec_diagram == 1 && !st.spec_wasserfall.is_empty() {
        let zeilen = st.spec_wasserfall.len();
        let cols = st.spec_wasserfall[0].len().max(1);
        let (mut lo, mut hi) = (f64::MAX, f64::MIN);
        for row in &st.spec_wasserfall {
            for &v in row { lo = lo.min(v); hi = hi.max(v); }
        }
        let span = (hi - lo).max(1e-6);
        let zh = plot.height() / zeilen as f32;
        let cw = plot.width() / cols as f32;
        for (zi, row) in st.spec_wasserfall.iter().enumerate() {
            let y = plot.top() + zi as f32 * zh;
            for (ci, &v) in row.iter().enumerate() {
                let t = ((v - lo) / span) as f32;
                let x = plot.left() + ci as f32 * cw;
                p.rect_filled(
                    egui::Rect::from_min_size(egui::pos2(x, y), egui::vec2(cw + 1.0, zh + 1.0)),
                    0.0, wasserfall_farbe(st.spec_color, t));
            }
        }
    }

    // Achsen dB (Leistung) — Bereich aus den Daten.
    let (mut lo, mut hi) = (f64::MAX, f64::MIN);
    for &v in &st.spec_psd { lo = lo.min(v); hi = hi.max(v); }
    if !lo.is_finite() || !hi.is_finite() { return; }
    let pad = ((hi - lo) * 0.1).max(1.0);
    lo -= pad; hi += pad;
    let span = (hi - lo).max(1e-6);

    for i in 0..=4 {
        let y = plot.top() + plot.height() * i as f32 / 4.0;
        p.line_segment([egui::pos2(plot.left(), y), egui::pos2(plot.right(), y)],
            egui::Stroke::new(1.0, egui::Color32::from_gray(40)));
        let val = hi - span * i as f64 / 4.0;
        p.text(egui::pos2(plot.left() - 6.0, y), egui::Align2::RIGHT_CENTER,
            format!("{val:.0}"), egui::FontId::monospace(9.0), egui::Color32::from_gray(130));
    }
    p.text(egui::pos2(rect.left() + 6.0, rect.top() + 6.0), egui::Align2::LEFT_TOP,
        "Leistung (dB)", egui::FontId::proportional(9.0), egui::Color32::from_gray(140));
    // Frequenzachse (MHz).
    let f_lo = st.spec_freqs.first().copied().unwrap_or(0.0) / 1e6;
    let f_hi = st.spec_freqs.last().copied().unwrap_or(1.0) / 1e6;
    for i in 0..=4 {
        let x = plot.left() + plot.width() * i as f32 / 4.0;
        let f = f_lo + (f_hi - f_lo) * i as f64 / 4.0;
        p.text(egui::pos2(x, plot.bottom() + 4.0), egui::Align2::CENTER_TOP,
            format!("{f:.1}"), egui::FontId::monospace(9.0), egui::Color32::from_gray(130));
    }
    p.text(egui::pos2(plot.center().x, rect.bottom() - 9.0), egui::Align2::CENTER_CENTER,
        "Frequenz (MHz)", egui::FontId::proportional(9.0), egui::Color32::from_gray(140));

    // Kurve (Pen #0d7377 im Original, hier je Farbschema).
    let farbe = spektrum_farbe(st.spec_color);
    let n = st.spec_psd.len();
    let pts: Vec<egui::Pos2> = st.spec_psd.iter().enumerate().map(|(i, &v)| {
        let x = plot.left() + plot.width() * i as f32 / (n - 1) as f32;
        let y = plot.bottom() - plot.height() * ((v - lo) / span) as f32;
        egui::pos2(x, y)
    }).collect();
    p.add(egui::Shape::line(pts, egui::Stroke::new(1.6, farbe)));
}

fn wasserfall_farbe(schema: usize, t: f32) -> egui::Color32 {
    let t = t.clamp(0.0, 1.0);
    let b = |a: u8, c: u8| (a as f32 + (c as f32 - a as f32) * t) as u8;
    match schema {
        1 => egui::Color32::from_rgb(b(0, 255), b(0, 200), b(40, 0)),      // Heiß
        2 => egui::Color32::from_rgb(b(30, 230), b(60, 40), b(200, 40)),   // Blau-Rot
        3 => egui::Color32::from_rgb(b(40, 250), b(40, 230), b(90, 30)),   // Viridis-ähnlich
        _ => egui::Color32::from_rgb(b(20, 200), b(20, 200), b(20, 200)),  // Grau
    }
}

fn tracking_tab(ui: &mut egui::Ui, st: &mut AppState, sats: &[ev_sat::SatState]) {
    // 1:1 nach TrackingTab: Statuszeile, Filter, Tabelle
    // Name | Azimut | Elevation | Distanz | Methode | Zeit (UTC).
    ui.horizontal(|ui| {
        ui.label(if sats.is_empty() {
            "TLEs noch nicht geladen.".to_string()
        } else {
            format!("{} Satelliten geladen.", sats.len())
        });
        ui.add(egui::TextEdit::singleline(&mut st.track_filter)
            .hint_text("Satellitennamen filtern...").desired_width(200.0));
    });
    let f = st.track_filter.trim().to_lowercase();
    let now = chrono::Utc::now().format("%H:%M:%S").to_string();
    crate::tabs::rahmen(ui, |ui| {
    egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
        egui::Grid::new("track").striped(true).num_columns(6).show(ui, |ui| {
            for h in ["Name", "Azimut (°)", "Elevation (°)", "Distanz (km)", "Methode", "Zeit (UTC)"] {
                ui.strong(h);
            }
            ui.end_row();
            for s in sats.iter().filter(|s| f.is_empty() || s.name.to_lowercase().contains(&f)) {
                // Az/El brauchen einen Beobachterstandort; das Original ließ sie
                // in der vereinfachten Fassung leer. Distanz = Bahnhöhe + Erdradius
                // als grobe Schrägentfernung im Zenit.
                ui.label(&s.name);
                ui.label("—");
                ui.label("—");
                ui.label(format!("{:.0}", s.altitude_km));
                ui.label("SGP4");
                ui.label(&now);
                ui.end_row();
            }
        });
    });
    });
}

fn spectator_tab(ui: &mut egui::Ui, st: &mut AppState) {
    // 1:1 nach SpectatorTab: Eingabefelder + Buttons, die einen Platzhalter
    // zeigen (spectator.earth-API im Original ebenfalls nur Platzhalter).
    ui.horizontal(|ui| {
        ui.label("API-Key:");
        ui.add(egui::TextEdit::singleline(&mut st.vt_api_key)
            .password(true).desired_width(200.0));
        ui.label("Box (*):");
        let mut box_v = "2.0".to_string();
        ui.add(egui::TextEdit::singleline(&mut box_v).desired_width(50.0));
        ui.label("Overpass Tage -/+:");
        let mut a = 0i32; ui.add(egui::DragValue::new(&mut a));
        let mut b = 3i32; ui.add(egui::DragValue::new(&mut b));
    });
    ui.horizontal(|ui| {
        ui.label("Imagery Tage zurück:");
        let mut im = 7i32; ui.add(egui::DragValue::new(&mut im).range(1..=30));
        ui.label("Beobachter: lat=52.0, lon=13.0");
        ui.label("Satelliten:");
        let mut sats = "Sentinel-2A,Sentinel-2B,Landsat-8".to_string();
        ui.add(egui::TextEdit::singleline(&mut sats).desired_width(200.0));
    });
    ui.horizontal(|ui| {
        for t in ["Overpasses abrufen", "Imagery suchen", "Preview anzeigen"] {
            if ui.button(t).clicked() {
                st.spec_status = "Spectator API: benötigt spectator.earth-Zugriff \
                                  (Platzhalter-Implementierung).".into();
            }
        }
    });
    crate::tabs::rahmen(ui, |ui| {
    egui::Grid::new("spectator").striped(true).num_columns(6).show(ui, |ui| {
        for h in ["Typ", "Datum/Zeit", "Satellit", "Zusatz", "Detail 1", "Detail 2"] {
            ui.strong(h);
        }
        ui.end_row();
    });
    ui.weak("Diese Funktion benötigt spectator.earth API-Zugriff. \
             Derzeit Platzhalter-Implementierung.");
    });
}
