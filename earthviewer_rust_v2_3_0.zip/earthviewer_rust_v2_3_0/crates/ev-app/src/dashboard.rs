//! GlasWire-artiges Dashboard — eine **zuschaltbare** moderne Ansicht.
//!
//! WICHTIG: Das ist kein Ersatz des Original-Layouts, sondern eine Alternative.
//! Der klassische Modus (1:1-Seitenleiste des Python-Originals) bleibt Standard
//! und unangetastet, damit die mühsam erreichte Parität erhalten bleibt. Der
//! Nutzer schaltet im Zahnrad-Dialog um.
//!
//! Aufbau nach GlasWire (aus der Community-Recherche, siehe FORTSCHRITT.md):
//! - linke schmale Icon-Navigationsleiste statt der schmalen Reiter oben
//! - großer Zeit-Graph oben mit Zeitfenster-Umschaltern (5m/3h/24h/Woche/Monat)
//! - darunter die Inhaltsfläche des gewählten Bereichs
//! Klick in den Graph zeigt den Wert an der Stelle (GlasWire-Detail-Idee).

use crate::state::{AppState, Tab, Zeitfenster};

const PRIMARY: [u8; 3] = ev_core::theme::ui::PRIMARY;

/// Die Bereiche der Icon-Navleiste (Symbol, Tooltip, Ziel-Reiter).
const NAV: &[(&str, &str, Tab)] = &[
    ("🖥", "Control Center", Tab::ControlCenter),
    ("📈", "Graph", Tab::Graph),
    ("📊", "Monitoring", Tab::Monitoring),
    ("🌐", "Live Verbindungen", Tab::LiveConnections),
    ("🔒", "Schützen", Tab::Protection),
    ("📋", "Protokoll", Tab::Protocol),
    ("🌍", "Netzwerk", Tab::Network),
    ("🔍", "Scanner", Tab::Scanner),
    ("🛰", "Satelliten", Tab::Satellites),
    ("⭐", "Favoriten", Tab::Favorites),
    ("🔎", "Suche", Tab::Search),
    ("⚙", "Steuerung", Tab::Control),
];

/// Zeichnet die linke Icon-Navleiste. Gibt den evtl. neu gewählten Reiter zurück.
pub fn nav_leiste(ctx: &egui::Context, st: &mut AppState) {
    egui::SidePanel::left("dash_nav")
        .exact_width(56.0)
        .resizable(false)
        .show(ctx, |ui| {
            ui.add_space(6.0);
            ui.vertical_centered(|ui| {
                ui.label(egui::RichText::new("🌍").size(22.0).color(
                    egui::Color32::from_rgb(PRIMARY[0], PRIMARY[1], PRIMARY[2])));
            });
            ui.add_space(8.0);
            for (icon, tip, tab) in NAV {
                let aktiv = st.tab == *tab;
                let f = if aktiv { PRIMARY } else { ev_core::theme::ui::SURFACE_VARIANT };
                let resp = ui.add_sized(
                    [44.0, 40.0],
                    egui::Button::new(egui::RichText::new(*icon).size(18.0)
                        .color(egui::Color32::WHITE))
                        .fill(egui::Color32::from_rgb(f[0], f[1], f[2])),
                ).on_hover_text(*tip);
                if resp.clicked() { st.tab = *tab; }
                ui.add_space(2.0);
            }
        });
}

/// Zeichnet Kopfzeile (Titel + Zeitfenster) und den großen Graph in `ui`.
/// Danach rendert der Aufrufer den Reiterinhalt darunter.
pub fn kopf_und_graph(ui: &mut egui::Ui, st: &mut AppState) {
    ui.horizontal(|ui| {
        ui.label(egui::RichText::new("🌍 EarthViewer 2.0")
            .size(ev_core::theme::ui::FONT_TITEL).strong()
            .color(egui::Color32::from_rgb(PRIMARY[0], PRIMARY[1], PRIMARY[2])));
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            for zf in Zeitfenster::ALL.iter().rev() {
                let aktiv = st.zeitfenster == *zf;
                let f = if aktiv { PRIMARY } else { ev_core::theme::ui::SURFACE_VARIANT };
                if ui.add(egui::Button::new(egui::RichText::new(zf.label())
                        .size(ev_core::theme::ui::FONT_KLEIN)
                        .color(egui::Color32::WHITE))
                        .fill(egui::Color32::from_rgb(f[0], f[1], f[2]))).clicked() {
                    st.zeitfenster = *zf;
                }
            }
            ui.label(egui::RichText::new("Zeitfenster:")
                .size(ev_core::theme::ui::FONT_KLEIN).color(egui::Color32::from_gray(150)));
        });
    });
    ui.small(egui::RichText::new(format!("Status: {}", st.status))
        .color(egui::Color32::from_gray(140)));
    ui.separator();

    let graph_h = (ui.available_height() * 0.42).clamp(140.0, 320.0);
    dashboard_graph(ui, st, graph_h);
    ui.separator();
}

/// Der große GlasWire-Zeit-Graph: gestapelte Flächen Upload/Download/Total,
/// gewähltes Zeitfenster, Klick zeigt den Wert an der Stelle.
fn dashboard_graph(ui: &mut egui::Ui, st: &AppState, hoehe: f32) {
    const UP: egui::Color32 = egui::Color32::from_rgb(240, 200, 60);
    const DOWN: egui::Color32 = egui::Color32::from_rgb(235, 140, 40);
    const TOTAL: egui::Color32 = egui::Color32::from_rgb(235, 110, 175);

    // Kopf: aktuelle Raten + Legende.
    let jetzt = st.rate_history.last().copied().unwrap_or_default();
    ui.horizontal_wrapped(|ui| {
        for (c, t, v) in [
            (UP, "Up", jetzt.up_kbs()),
            (DOWN, "Down", jetzt.down_kbs()),
            (TOTAL, "Total", jetzt.total_kbs()),
        ] {
            let (r, _) = ui.allocate_exact_size(egui::vec2(10.0, 10.0), egui::Sense::hover());
            ui.painter().rect_filled(r, 2.0, c);
            ui.label(egui::RichText::new(format!("{t}: {v:.1} KB/s")).size(11.0));
            ui.add_space(6.0);
        }
        ui.label(egui::RichText::new(format!("· Fenster: {}", st.zeitfenster.label()))
            .size(11.0).color(egui::Color32::from_gray(150)));
    });

    let (rect, resp) = ui.allocate_exact_size(
        egui::vec2(ui.available_width(), hoehe), egui::Sense::hover());
    let p = ui.painter_at(rect);
    p.rect_filled(rect, 4.0, egui::Color32::from_gray(20));

    // Datenquelle je Zeitfenster: 5 Min = feiner Sekunden-Livepuffer,
    // größere Fenster = gemittelter Langzeitverlauf (persistent).
    let hist: Vec<ev_net::Rate> = if st.zeitfenster.nutzt_live() {
        let n_ganz = st.rate_history.len();
        let n_zeige = st.zeitfenster.punkte().min(n_ganz);
        st.rate_history[n_ganz - n_zeige..].to_vec()
    } else {
        st.rate_verlauf.fenster(st.zeitfenster.minuten(), 400)
    };
    if hist.len() < 2 {
        p.text(rect.center(), egui::Align2::CENTER_CENTER,
            if st.zeitfenster.nutzt_live() { "sammle Messwerte…" }
            else { "noch zu wenig Verlauf für dieses Fenster — sammelt sich mit der Zeit" },
            egui::FontId::proportional(13.0), egui::Color32::from_gray(120));
        return;
    }
    let hist = &hist[..];

    let plot = egui::Rect::from_min_max(
        egui::pos2(rect.left() + 56.0, rect.top() + 8.0),
        egui::pos2(rect.right() - 10.0, rect.bottom() - 20.0));
    let max = hist.iter().map(|r| r.total_kbs()).fold(0.0_f64, f64::max).max(0.1) * 1.15;
    let stellen = if max >= 100.0 { 0 } else if max >= 10.0 { 1 } else { 2 };

    for i in 0..=4 {
        let y = plot.top() + plot.height() * i as f32 / 4.0;
        p.line_segment([egui::pos2(plot.left(), y), egui::pos2(plot.right(), y)],
            egui::Stroke::new(1.0, egui::Color32::from_gray(38)));
        p.text(egui::pos2(plot.left() - 6.0, y), egui::Align2::RIGHT_CENTER,
            format!("{:.*}", stellen, max * (4 - i) as f64 / 4.0),
            egui::FontId::monospace(9.0), egui::Color32::from_gray(125));
    }
    p.text(egui::pos2(rect.left() + 6.0, rect.top() + 6.0), egui::Align2::LEFT_TOP,
        "KB/s", egui::FontId::proportional(9.0), egui::Color32::from_gray(140));

    let flaeche = |sel: &dyn Fn(&ev_net::Rate) -> f64, farbe: egui::Color32| {
        let mut pts: Vec<egui::Pos2> = hist.iter().enumerate().map(|(i, r)| {
            let x = plot.left() + plot.width() * i as f32 / (hist.len() - 1) as f32;
            let y = plot.bottom() - plot.height() * (sel(r) / max).min(1.0) as f32;
            egui::pos2(x, y)
        }).collect();
        pts.push(egui::pos2(plot.right(), plot.bottom()));
        pts.push(egui::pos2(plot.left(), plot.bottom()));
        p.add(egui::Shape::convex_polygon(pts, farbe.gamma_multiply(0.5),
            egui::Stroke::new(1.4, farbe)));
    };
    flaeche(&|r| r.total_kbs(), TOTAL);
    flaeche(&|r| r.down_kbs(), DOWN);
    flaeche(&|r| r.up_kbs(), UP);

    // GlasWire-Detail: Klick/Hover zeigt den Wert an der Stelle.
    if let Some(pos) = resp.hover_pos() {
        if plot.contains(pos) {
            let frac = ((pos.x - plot.left()) / plot.width()).clamp(0.0, 1.0);
            let idx = ((frac * (hist.len() - 1) as f32).round() as usize).min(hist.len() - 1);
            let r = hist[idx];
            p.line_segment(
                [egui::pos2(pos.x, plot.top()), egui::pos2(pos.x, plot.bottom())],
                egui::Stroke::new(1.0, egui::Color32::from_gray(90)));
            let txt = format!("▲{:.1}  ▼{:.1}  Σ{:.1} KB/s",
                r.up_kbs(), r.down_kbs(), r.total_kbs());
            p.text(egui::pos2(pos.x + 6.0, plot.top() + 10.0), egui::Align2::LEFT_TOP,
                txt, egui::FontId::proportional(11.0), egui::Color32::WHITE);
        }
    }
}
