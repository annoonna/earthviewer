# Changelog

## v2.3.0 — 2026-08-22 · Kachel-Ebene, volles GlasWire-Theme, Feedback-Fixes

### Karten-Kachel-Ebene (Google-Earth-artig) — Runde D Teil 2
Zuschaltbare Karten-Ebene, die beim Zoomen Kacheln von OpenStreetMap (Straßen)
oder NASA GIBS (Satellit) nachlädt — je tiefer der Zoom, desto mehr Details
(Länder → Städte → Straßen). Key-frei, mit Pflicht-Attribution, standardmäßig
AUS (kein ungefragter Netzverkehr). Lokaler Cache in `sessions/tiles/`.
- `ev-render::tiles`: Slippy/Web-Mercator-Mathematik + gekrümmte Patch-Geometrie
  auf der Kugel (an die Basiskugel-Parametrisierung angepasst).
- `ev-render::tile_layer`: GL-Ebene, lädt Kachelbilder als Texturen hoch, zeichnet
  sie knapp über der Basistextur, räumt alte Kacheln auf.
- `ev-app::tileloader`: Hintergrund-Download (ureq) mit Disk-Cache und Dedup.
- Kamera-`blickpunkt()` + Zoomstufen-Wahl pro Frame; UI-Umschalter im
  Zahnrad-Dialog (An/Aus + OSM/GIBS + Attribution).
- **Hinweis:** echtes Nachladen braucht Internet; im Build-Container nicht live
  testbar (Server gesperrt), Logik voll getestet.

### Volles GlasWire-Theme (Chrome-weit)
`UiPalette` färbt das komplette Fenster-Chrome (Panels, Knöpfe, Ränder, Akzente),
nicht nur Globus-Marker. GlasWire (dunkles Marineblau, Teal) ist Standard-Theme.

### Feedback-Fixes (Annos Screenshots)
- Flaggen als Textkürzel „[DE]" statt fehlender Emoji (egui-Font).
- Monitoring mit echten Tabellenspalten (Name/Anz., Trennlinien).
- Layout-Umschalter „Dashboard/Globus" prominent in der oberen Leiste.
- Dashboard ist Standard-Layout (GlasWire-Stil), Globus per Knopf.
- Satelliten-Reiter: Scroll-Bug behoben — „Mehr" jetzt erreichbar (innere Liste
  begrenzt + äußere Scrollfläche).

### Runde D Teil 1 — Überwachungs-Extras
Favoriten-Sterne, Benachrichtigungs-Panel (kein Popup), Schwellwert-Alarme,
Rate-History-Persistenz (echte Wochen-/Monats-Zeitfenster), ASN/Provider-Anzeige.

---

## v2.2.0 — 2026-08-22 · Erweiterungen: Zoom, VisualTraceroute, GlasWire-Layout, Alarme

Erste Ausbaustufe über die 1:1-Portierung hinaus — inspiriert von GlasWire,
Open Visual Traceroute und Sniffnet (Community-Recherche im Projekt
dokumentiert). **Alle Erweiterungen sind Zugaben; der 1:1-Modus bleibt Standard
und unangetastet.**

### Runde A — Bugfixes + Zoom
- **Länder-Suche gefixt:** „Deutschland" zeigt jetzt alle 16 Bundesländer statt
  fälschlich „Deutschlandsberg [Austria]". Neues Länder-Register
  (`ev-geo::countries`) mit dt./engl. Aliassen, exaktem Alias-Match (kein
  `contains`) und kuratierten Landeshauptstädten (DE 16, AT 9, CH 8).
- **Google-Earth-Zoom:** stufenlos, weich (pro Frame interpolierter Anflug),
  Schrittweite skaliert mit der Entfernung — nah fein, fern grob. Nähere
  Mindestdistanz (1.02 statt 1.2).
- **Klickbare Bogen-Endpunkte:** Hover zeigt Prozess/IP:Port/Protokoll/Ort+Flagge/
  Richtung/Koordinaten; Klick wählt die Verbindung.

### Runde C — VisualTraceroute-Tiefe
- Hop-Tabelle mit # / IP / Hostname / Ort / Land / Lat / Lon / Latenz / DNS /
  Distanz (Haversine zum Vorgänger). Latenz farbcodiert (grün<50/gelb<150/rot).
- DNS-Rückwärtsauflösung gemessen, CSV-Export der Route, Ziel-Verlauf mit
  anklickbaren Vorschlägen (persistent). Traceroute-Linie latenzfarbig pro Segment.

### Höher aufgelöste Offline-Textur
- `earth_texture()` nutzt eine Prioritätenliste und nimmt automatisch die beste
  vorhandene (jetzt `earth_map1.jpg`, 5400×2700). Eigene `earth_hd.jpg` wird
  bevorzugt. Anisotrope Filterung ergänzt. Anleitung in `data/textures/README.md`.

### Runde B — GlasWire-Layout (zuschaltbar)
- Neues Dashboard: linke Icon-Navleiste, großer Zeit-Graph mit Zeitfenster-
  Umschaltern (5m/3h/24h/Woche/Monat), Hover-Wertanzeige. Umschaltbar im
  Zahnrad-Dialog; klassisches 1:1-Layout bleibt Standard.

### Runde D Teil 1 — Überwachungs-Extras
- Favoriten-Sterne (★/☆) in Live-Verbindungen, dezentes Benachrichtigungs-Panel
  im Schützen-Reiter (kein Popup), Schwellwert-Alarme, Warnung bei Favoriten-
  Traffic und geblockten Gegenstellen. Persistent in `sessions/watch.json`.

**Offen (dokumentiert in FORTSCHRITT.md):** Runde D Teil 2 — echtes Kachelsystem
(NASA GIBS / OSM, key-frei, abschaltbar) für scharfen Tiefzoom. Großes eigenes
Vorhaben, bewusst zuletzt.

---

## v2.1.0 — 2026-08-22 · SatMonitor PRO + SDR-Spektrum portiert

Der zuvor bewusst ausgelassene SDR-Spektrum-Tab ist jetzt **vollständig
portiert**. Damit ist auch das letzte freistehende Fenster des Originals da.

### Neu: SatMonitor PRO (`fenster::sat_monitor`)
1:1-Port von `sat_monitor_window.py::SatMonitorWindow`: Titel „SatMonitor –
Satelliten & Spektrum", Menü Datei/Ansicht/Hilfe, Statusleiste, drei Reiter:

- **Spektrum** — beide Steuerreihen wie im Original (Center Freq, Sample Rate,
  FFT Size, Sat-Profil / Quelle, Signalprofil, Diagramm, Farbschema, Start/Stop),
  Live-Diagramm „Leistung (dB)" über „Frequenz (MHz)", optionaler Wasserfall.
- **Sat-Tracking** — Filter + Tabelle Name/Azimut/Elevation/Distanz/Methode/Zeit.
- **Spectator API** — Eingabefelder + Platzhalter (wie im Original).

### Neu: `ev-sat::spektrum` — Simulation ohne numpy/pyqtgraph
1:1-Port von `SimulationWorker.run`: Grundrauschen N(-90, 2), die sechs
Signalprofile (Rauschen/Sinus-Test/Regen/Eis/Rauch/Sat-Beacons) mit identischen
Gauß-Parametern, Zittersummand N(0, 0.5). Eigener xorshift64-PRNG statt `rand`,
Box-Muller für die Normalverteilung. 5 neue Tests (223 gesamt, alle grün).

### Gegenprüfung
FEHLT weiterhin 0,0 %; portiert von 76,8 % auf **78,2 %** gestiegen (die 8
SpectrumTab-Symbole sind aus `ausgelassen` nach `abgebildet` gewandert).

---

## v2.0.0 — 2026-08-22 · Vollständige 1:1-Treue, alle Fenster portiert

Der beanstandete 1:1-Nachbau ist jetzt vollständig und **gegen das Original
gemessen** (`gegenpruefung.py`: FEHLT 0,0 %, 450/586 portiert, 136 dokumentiert
ausgelassen). 218 Tests grün, Build ohne Warnungen.

### Titel/Version korrigiert
Fenstertitel **und** Sidebar-Kopf zeigen jetzt exakt „🌍 EarthViewer 2.0"
(`config.py::WINDOW_TITLE`). Vorher lief die Crate-Version durch — Quelle der
beanstandeten „1.6/1.7/1.9"-Anzeigen. Der Titel-Test prüft nun den Klon-String,
nicht die Crate-Version.

### 12 Reiter statt 13
„Einstellungen" ist kein Reiter mehr — das Zahnrad öffnet den Dialog
„⚙ Erweiterte Einstellungen" (`main_window._show_settings`). Der Test, der
fälschlich auf 13 Reitern bestand (die eingebaute Rechtfertigung des überzähligen
Reiters), ist auf die korrekten 12 berichtigt.

### Neun freistehende Fenster portiert (`fenster.rs`, NEU)
Die `QDialog`-Klassen, die zuvor fehlten: Network Monitor (Live), Große
Live-Analyse, **WLAN Control Center** (Erweiterte Ansicht, 3 Reiter),
Netzwerk-Clients, Graph/Schutz/Protokoll/Scanner groß, Zahnrad-Dialog. Alle
„Große Ansicht öffnen"-Knöpfe verkabelt. Reiter und Großfenster teilen sich die
Zeichenroutinen — kein Doppelcode (der Fehler des Originals).

### Sechs Netzwerk-Reiter 1:1 nachgezogen
Live Verbindungen, Monitoring, Control Center, Graph, Schützen, Protokoll:
türkise Aktionsknöpfe, rot/grün/orange Zustände, Original-Tabellenspalten,
Pausieren jeweils unten. Netzwerk-Combo exakt Traceroute/Ping/WHOIS.
Steuerungs-Emojis und Suche-Reiter 1:1. Rust-Zugaben unter „Mehr" eingeklappt.

### Werkzeuge
`werkzeug/shot.sh` (Xvfb-Screenshot je Reiter), `abbildung.json` um 124 Einträge
ergänzt. Übergabedokument `UEBERGABE.md` für den nächsten Chat.

---

## v1.9.0 — 2026-08-22 · Alle Reiter auf das Original-Muster

Fortsetzung von v1.8.0: dort waren Kopfzeile und Satelliten-Reiter umgestellt,
die uebrigen elf noch flach. Jetzt sind alle durch.

### Das Muster erst gemessen, dann angewandt
Statt zu raten, wo das Original Rahmen setzt: waagerechte Rahmenlinien in der
Seitenleiste gezaehlt (`werkzeug/farben.py`).

| Reiter | Rahmenlinien bei y | Schluss |
|---|---|---|
| Suche | 459, 1011 | ein Kasten um die Trefferliste |
| Netzwerk | 305, 1021 | ein Kasten um das Ergebnis |
| Steuerung | 460, 558, 617, 658, 669, 710 | **kein** Kasten, nur umrahmte Knoepfe |

Daraus die Regel: **Inhaltsbereiche bekommen einen Rahmen, reine
Bedienabschnitte nicht.** Das erklaert auch, warum der Steuerungs-Reiter schon
vorher passte — dort gibt es tatsaechlich keine Gruppenkaesten.

### 22 Stellen umgestellt
Suche, Favoriten, Netzwerk, Live Verbindungen, Monitoring, Control Center,
Graph, Schuetzen, Protokoll Analyse, Netzwerk Scanner und Einstellungen haben
jetzt umrahmte Inhaltsbereiche (`tabs::rahmen()`), Ueberschriften in 18 px und
Hauptaktionen als tuerkise Knoepfe ueber die volle Breite
(`tabs::breiter_knopf()`).

Konkret unter anderem: „🔍 Suchen" und „✖ Marker loeschen" im Suche-Reiter,
„Starten" im Netzwerk-Reiter, „Scan starten" im Scanner, „+ Aktuelles Ziel
merken" bei den Favoriten, „💾 Einstellungen speichern".

218 Tests, clippy `-D warnings` sauber.

---

## v1.8.0 — 2026-08-22 · Gruppenkaesten und Kopfzeile

Anno hat beide Bildersammlungen nebeneinandergelegt: „nichts davon ist genau
so". Er hatte recht, und der Grund war grundsaetzlicher als meine bisherigen
Einzelkorrekturen.

### Der eigentliche Unterschied
Das Original gliedert die Seitenleiste in **umrahmte Gruppenkaesten**
(`QGroupBox`, Rahmen `#555555`) mit **grossen Knoepfen ueber die volle
Breite**. Meine Fassung war eine dichte, flache Liste ohne Rahmen. Das ist
kein Pixelunterschied, das ist eine andere Bildsprache.

Neu in `tabs.rs`:
- **`gruppe(ui, titel, inhalt)`** — das Gegenstueck zu `QGroupBox`
- **`breiter_knopf(ui, text, tuerkis)`** — Knopf ueber die volle Breite

### 🐞 Kopfzeile: 57 px statt 113 px, und zu viel drin
Gemessen (`werkzeug/farben.py`): die Kopfzeile ist im Original **113 px**
hoch, meine war **57 px**. Zudem standen bei mir Dinge darin, die dort nie
waren: „Marker loeschen", „Auto-Rotation" und die Verbindungszahl.

Jetzt exakt wie die Vorlage: Lupe, **ein breites Eingabefeld**, tuerkiser
Knopf „Suchen", dahinter Zahnrad und Palette — sonst nichts. Der Platzhalter
ist wortgleich uebernommen, samt Beispiel `'berlin leipzig koblenz'`, das auf
die Mehrfachsuche hinweist. Die drei entfernten Bedienelemente stehen dort,
wo sie im Original stehen: Suche, Steuerung, Live Verbindungen.

### Satelliten-Reiter neu aufgebaut
- grosse Ueberschrift „📡 Satelliten-Zentrale"
- **„🖥 PRO Monitor oeffnen"** — der tuerkise Knopf hatte bei mir komplett
  gefehlt
- zwei Gruppenkaesten „Globus Anzeige" und „Aktive Satelliten:"
- „Alle auswaehlen" / „Alle abwaehlen" als zwei halbbreite Knoepfe
- **Meine Zusaetze sind weggeklappt** — TLE-Alter, zusaetzliche Gruppen,
  Bahn/Bodenspur/Fussabdruck, Symbolgroesse und Filter stehen unter
  „Mehr (ueber das Original hinaus)". Sie standen vorher mitten im Reiter und
  waren damit selbst eine Abweichung.

218 Tests, clippy `-D warnings` sauber.

### Offen
Die uebrigen elf Reiter sind noch nicht auf Gruppenkaesten umgestellt.
`gruppe()` und `breiter_knopf()` liegen bereit, es ist Fleissarbeit je Reiter.

---

## v1.7.0 — 2026-08-22 · Reiterleiste repariert

### 🐞 Acht Reiter waren unerreichbar
In v1.5.0 hatte ich den waagerechten Rollbalken unter den Reitern versteckt
und in den Kommentar geschrieben, das Original habe „stattdessen zwei kleine
Pfeile" — **die Pfeile aber nie eingebaut**. Sichtbar waren damit nur fuenf
von dreizehn Reitern, der Rest war ohne Mausrad nicht erreichbar.

Jetzt stehen « und » rechts in der Leiste, ausgegraut, wenn es in die
Richtung nichts mehr zu sehen gibt.

Der erste Versuch schlug fehl: `ScrollArea::max_width()` allein reicht nicht,
die Rollflaeche nahm trotzdem die volle Breite und schob die Pfeile aus dem
Bild. Gemessen statt vermutet — die letzten 120 px waren reiner
Panel-Hintergrund. Loesung ist das uebliche egui-Muster: erst von rechts
belegen (`Layout::right_to_left`), der Rest bleibt fuer die Leiste.

### Reiterfarben nach Vorlage
`werkzeug/farben.py` auf Zeile y=286 des Originals angesetzt:

| | Original | vorher bei mir |
|---|---|---|
| aktiver Reiter | `#0D7377` | `#0D7377` ✅ |
| **inaktiver Reiter** | **`#3A3A3A`** | **ohne Hintergrund** ❌ |
| Luecke | `#2B2B2B`, 2 px | ohne |

Das war der Layout-Unterschied, den Anno gesehen hat: meine inaktiven Reiter
waren flache Beschriftungen, im Original sind es richtige Reiter mit
Flaeche. Nachgemessen bestaetigt: aktiv bei x=942–1032, Luecke bei 1036–1038,
inaktiv ab 1041 — Zahl fuer Zahl wie in der Vorlage.

218 Tests, clippy `-D warnings` sauber.

---

## v1.6.0 — 2026-08-22 · Schlanke Fassung zum Selberbefuellen

Anno will seine echten Daten selbst einkopieren — meine erzeugten Listen
wuerden sich damit nur beissen.

### `./paket_bauen.sh --schlank`
Baut ein Paket **ohne Nutzdaten**: 228 KB statt 12 MB, 101 statt 602 Dateien.
Enthalten sind alle sechs Crates (45 Rust-Dateien), die Werkzeuge und die
Anleitungen; `data/geodata/` und `data/textures/` bleiben leer bis auf ihre
LIESMICH-Dateien.

### `./pruefe_daten.sh` (neu)
Prueft nach dem Kopieren, ob alles am richtigen Platz liegt — und aendert
dabei nichts:

- **Erdtextur**: vorhanden? Wirklich ein Bild? Plausible Groesse?
- **GeoIP**: `.mmdb` gefunden? Traegt eine davon `city` im Namen?
  (Country/ASN werden ignoriert — wie im Original.)
- **Staedtelisten**: Anzahl Ordner und Orte, **Kopfzeile geprueft**, und der
  haeufige Fehler „CSV liegt direkt in geodata/ statt in einem Landesordner"
- **Schreibrechte** auf `sessions/`, `screenshots/`, `logs/` — sonst gehen
  Favoriten und TLE-Cache still verloren

Rueckgabewert ist die Zahl der offenen Punkte, taugt also fuer Skripte.

### `data/KOPIEREN.md` (neu)
Eine Tabelle „was gehoert wohin", fertige `cp`-Befehle, und die drei Regeln,
an denen es sonst scheitert: Ordnername ist das Land, die MMDB braucht `city`
im Namen, und welche Spaltennamen die CSV haben darf.

218 Tests, clippy `-D warnings` sauber.

---

## v1.5.0 — 2026-08-22 · Ordnerstruktur wie im Original

Annos Bildschirmfotos seiner echten Installation zeigten, was im
ausgelieferten ZIP fehlte.

### 242 Laenderordner statt einem
`data/geodata/` hatte im Original **242 Ordner**, einen je Land, jeweils mit
`staedte.csv`. Das hochgeladene Archiv enthielt nur `Germany`. Neues Werkzeug
**`werkzeug/staedte_erzeugen.py`** erzeugt sie aus der mitgelieferten
`worldcities.xlsx`:

- liest xlsx **ohne Fremdbibliothek** (eine xlsx ist ein ZIP aus XML —
  `zipfile` + `xml.etree` reichen, `sharedStrings` aufgeloest)
- nimmt auch `worldcities.csv` oder das simplemaps-Archiv als Quelle
- **242 Laender, 47.867 Orte**, Ladezeit 0,03 s, Suche 4–5 ms
- Vorhandene `staedte.csv` bleiben unangetastet (`--ueberschreiben` erzwingt)

### Schreibweise: ASCII, wie im Original
Beim Abgleich mit Annos `Germany/staedte.csv` fiel auf: die Datei enthaelt
**kein einziges Nicht-ASCII-Zeichen** und schreibt „Nuremberg", „Munich",
„Cologne". Die Listen sind deshalb mit `--ascii` erzeugt (Spalte
`city_ascii`). Nebeneffekt: `Reykjavik` und `Malmo` sind jetzt auch ohne
Akzent auffindbar. Ohne `--ascii` gibt es die Landessprache.

### `Geodaten/` (grosses G) als Download-Ordner
Angelegt mit `LIESMICH.md`, das die Struktur aus Annos Installation
beschreibt (`GeoLite2-City_20251017/`, `simplemaps_worldcities…zip`, …).
Das Programm liest ihn **nicht** — er ist Zwischenlager, wie im Original.
`geodaten_einrichten.sh` holt von dort die `GeoLite2-City.mmdb` nach
`data/geodata/` und legt fehlende Laenderordner an.

### 🐞 Fenstertitel zeigte die falsche Version
Im Rahmen stand „EarthViewer 3.0 — Rust Edition", in der Seitenleiste
„1.4.0". Der Titel war seit v0.3.0 fest verdrahtet. Jetzt aus
`CARGO_PKG_VERSION` abgeleitet, mit Test.

218 Tests, clippy `-D warnings` sauber.

---

## v1.4.0 — 2026-08-22 · Belastungstests nachgeholt

Die beiden Punkte, die ich in v1.2.0 offen eingeraeumt hatte, sind gemessen.
Zwei neue Messwerkzeuge liegen dauerhaft im Paket:

```bash
cargo run --release -p ev-net --example scanbench    # Portscanner
cargo run --release -p ev-sat --example satbench     # 7000 Satelliten
```

### Portscanner
- **1–65535 gegen einen antwortenden Host: 0,5 s** (~140 000 Ports/s)
- Kontrollierte Gegenprobe: zehn eigene Horcher aufgemacht, **alle zehn
  gefunden**, und der `Done`-Zaehler stimmt mit der Zahl der `Found`-Meldungen
  ueberein. Das war mir wichtig, weil zwei fruehe Laeufe unterschiedliche
  Trefferzahlen zeigten — die Ursache waren fremde Dienste im Container, nicht
  der Scanner.

⚠️ Der *stille* Host liess sich hier **nicht** messen: das Sandbox-Netz
antwortet sofort mit einem Fehler, statt Pakete zu verwerfen. Rechnerisch
65535 / 100 Threads x 0,5 s = **rund 5,5 Minuten**. In `RELAY.md` vermerkt.

### Satelliten in Starlink-Groessenordnung
7000 Objekte: TLE lesen unter 0,01 s, SGP4-Aufbau 0,01 s,
**Propagation 3,9 ms je Durchlauf** (~1,8 Mio Positionen/s), Bahnkurve mit
180 Punkten 0,08 ms. Da die Propagation nur einmal je Sekunde laeuft, sind das
rund 4 ms Last pro Sekunde — unkritisch, und das auf einem Einkern-Container.

### Dabei aufgefallen
In der Trefferpruefung am Globus wurde `visible_satellites()` **zweimal je
Bild** durchlaufen, um Positionen und Indizes zu sammeln. Bei 7000 Objekten
ist das ein vollstaendiger Durchlauf zu viel. Einmal filtern, zweimal
auslesen.

217 Tests, clippy `-D warnings` sauber.

---

## v1.3.0 — 2026-08-22 · Nach Annos Praxistest

Vier Bildschirmfotos von echter Hardware — ergiebiger als alles, was sich im
Container messen laesst.

### Warum die Boegen fehlten
In den Aufnahmen stand `✓ 0 Hops lokalisiert`, und jede Verbindung zeigte
`? Unknown` als Ort. **Ohne GeoIP-Datenbank gibt es keine Koordinaten, ohne
Koordinaten keine Marker und ohne Marker keine Boegen.**

Der Renderpfad selbst war in Ordnung — belegt in `docs/screenshot_boegen.png`.
Mein Fehler lag in der Bedienfuehrung: der Hinweis stand nur klein im Control
Center. Jetzt:

- gelber Warnbalken in den Reitern Netzwerk und Live Verbindungen
- Statuszeile beim Start: „GeoIP fehlt — keine Marker"
- Traceroute erklaert es in der Ausgabe, samt Bezugsquelle
- Live Verbindungen zaehlt mit: „12 Verbindungen · ⬇ 8 · ⬆ 4 · **12 mit Ort**"

**Diagnosehilfe:** `EARTHVIEWER_DEMO_ORT=51.3,12.4 ./start.sh 1` verteilt
Verbindungen ohne GeoIP faecherfoermig um diesen Punkt. Damit laesst sich
pruefen, ob die Bogendarstellung auf der eigenen Grafikkarte funktioniert,
bevor man die MaxMind-Datenbank besorgt. Ohne die Variable passiert nichts.

### Nachgeprueft: Traceroute-Pfad ist kein Bogen
`gl_renderer.render_line` zeichnet einen schlichten `GL_LINE_STRIP` mit
`glLineWidth(1.0)` und Alpha 0.6. Gekruemmt sind **nur** die
Live-Verbindungen (`_create_arc_points`, 72 Segmente, Anhebung 0.18). Beides
stimmt bei mir — hier war nichts zu aendern.

### Design 1:1 nachgezogen (aus `network_tab.py`)
| | Original | vorher bei mir |
|---|---|---|
| Ergebnistext | `color: #0f0` auf `#1e1e1e` | weiss, ohne Rahmen |
| Loop-Feld | `🔄 Loop` + `Intervall:` | „Wiederholen" |
| Intervall | **30 s** (Bereich 5–300) | 5 s |
| Ziel | eigene Ueberschrift `🎯 Ziel` | Zeile mit Doppelpunkt |

Meldungen jetzt wortgleich: `🔄 Loop-Modus gestartet.`,
`⏹ Loop-Modus gestoppt.`, `❌ Bitte Ziel eingeben`.

### 🐞 Globus-Hintergrund kam aus dem falschen Ort
`glClearColor(0.02, 0.02, 0.05, 1.0)` steht in `paintGL` **fest verdrahtet** —
das Theme aendert den Globus-Hintergrund gar nicht. Ich hatte
`theme.background` genommen. Jetzt `config::GLOBE_CLEAR_COLOR`, nachgemessen
als #05050D.

### Reiterleiste
Der waagerechte Scrollbalken unter den Reitern ist weg — im Original stehen
dort zwei kleine Pfeile, ein Balken kostet nur Hoehe.

218 Tests, clippy `-D warnings` sauber.

*Hinweis:* Der Build lief zweimal gegen `No space left on device` (7,9 GB
`target/`). `cargo clean` gehoert vor lange Sitzungen.

---

## v1.3.0 — 2026-08-22 · Geodaten-Ablage geklaert

Anno fragte, wohin mit den GeoLite2-Daten — das Rust-Paket hat keinen Ordner
`Geodaten/`. Die Antwort war ueberraschend: **das Original liest ihn nicht.**

`config.py` setzt `GEODATA_DIR = PROJECT_ROOT/"data"/"geodata"`, und
`geo_manager.py` sucht ausschliesslich dort. `Geodaten/` (grosses G) war der
private Download-Ordner, der beim Packen mit ins Archiv rutschte — im
ausgelieferten ZIP enthaelt er nur leere Verzeichnisse.

### 🐞 Eigene Abweichung gefunden
Beim Nachlesen fiel auf: das Original nimmt **nur** MMDB mit `city` im Namen
(`if "city" in mmdb_file.name.lower()`). Meine Fassung akzeptierte auch
Country und als letzten Ausweg jede beliebige — eine stille Abweichung.
Jetzt 1:1; der Country-Rueckfall greift nur mit eingeschalteten Korrekturen.

### Diagnose statt Raten
Der Loader nennt jetzt den Suchpfad, jede gefundene Datei und den Grund, wenn
nichts geladen wurde. Vorher stand da nur „GeoIP: keine MMDB" — ohne Hinweis,
wo gesucht wurde.

### Zwei Helfer
- **`geodaten_einrichten.sh`** legt MMDB und CSV aus einem beliebigen
  `Geodaten/`-Ordner nach `data/geodata/`. Zeigt dabei an, welche Datei
  ausgewertet wird und welche das Original ignoriert. `--pruefen` sieht nur
  nach, ohne zu kopieren.
- **`werkzeug/staedte_aufteilen.py`** macht aus der simplemaps-Datei
  `worldcities.csv` eine Ordnerstruktur je Land. Noetig, weil
  `geo_manager.py` den **Ordnernamen** als Land nimmt und eine Spalte
  `country` ignoriert — eine einzelne grosse CSV bekaeme sonst durchgehend
  dasselbe Land. Mit `--min-einwohner` laesst sich eindampfen.

Beide gegen eine nachgebaute Kopie von Annos Ordnerstruktur getestet.

### Neu: `docs/GEOIP_EINRICHTEN.md`
Mit den Quelltextstellen als Beleg, Tabelle welche MMDB genutzt wird, und
dem erwarteten Startprotokoll zur Kontrolle.

216 Tests, clippy `-D warnings` sauber.

---

## v1.2.0 — 2026-08-21 · Portbereich, VT-Cache, unsafe konsolidiert

Anno hatte recht mit der Nachfrage: der Portscanner stand auf 1–1024.

### 🐞 Portscanner: 1–65535 statt 1–1024
`network_scanner_tab.py` setzt `port_start=1` und `port_end=65535` — der
Klassenkommentar sagt sogar ausdruecklich „scannt 1-65535 ohne UI freeze".
Meine Voreinstellung war schlicht falsch. Mit korrigiert:

- Voreinstellung **1–65535**, Knopf „alle" springt dorthin zurueck
- Zeitgrenze **500 ms** statt 400 (`sock.settimeout(0.5)`)
- `start > end` wird jetzt **abgelehnt** statt still getauscht — das Original
  meldet dort einen Fehler (`network_scanner_tab.py`, Zeile 236).
  `normalize_range` ist durch `pruefe_bereich() -> Result` ersetzt.
- Statuszeile im Originalformat: `📊 Port-Range: 1-65535 …`
- Untertitel wortgleich: „Scanne Netzwerke, finde Geräte und prüfe Ports (1-65535)"

Threads standen mit 100 bereits richtig.

### VirusTotal-Zwischenspeicher (RELAY 2e)
Port von `self._cache` samt `_make_cache_key`:

- Schluessel `"{kind}:{value}"`, 1:1
- Lebensdauer **3600 s**, exakt die Grenze aus `scan_ip`
- `force`-Umgehung als `lookup_ip_force(ip, force)`
- Treffer aus dem Speicher funktionieren **ohne API-Key** — sonst waere der
  Speicher wertlos, sobald der Key fehlt. Eigener Test dafuer.

### Alle `unsafe`-Bloecke in `gl_util.rs` (RELAY 2f)
`globe.rs` und `globe_view.rs` rufen nur noch Huellen
(`dreiecke_zeichnen`, `punkte_zeichnen`, `tiefe_schreiben`, `puffer_leeren`,
`kugel_puffer_anlegen` …). Messung:

```
crates/ev-render/src/gl_util.rs:23     alle uebrigen Dateien: 0
```

Damit stimmt die Aussage in `ARCHITECTURE.md`, die seit v0.3.0 falsch war und
die `werkzeug/messen.py` selbst aufgedeckt hatte. Die Regel steht jetzt dort:
wer draussen einen GL-Aufruf braucht, ergaenzt hier eine Huelle.

### Sichtpruefung nachgeholt
Schuetzen-Reiter und Scanner-Reiter erstmals im Bild geprueft. Ein Fund:
`⌂ lokal` erschien als leeres Kaestchen — **U+2302** fehlt ebenfalls.
Vierter Zeichenfund, vierter Eintrag in `glyphen::VERBOTEN`.

212 Tests, clippy `-D warnings` sauber.

---

## v1.1.0 — 2026-08-21 · Detailfenster, Theme-Dialog, Kopfzeilen-Knoepfe

Der groesste gemessene Rueckstand ist abgearbeitet: die drei `QDialog`-Klassen
aus `src/ui/widgets/`.

### Detailfenster (`ev-app::detail`)
Als schwebende `egui::Window` — das Gegenstueck zu `QDialog`. Geoeffnet per
Klick in den Monitoring-Spalten, wie `network_stats_widget.itemClicked`.

- **Host** (`host_detail_window.py`): Hostname per Reverse-DNS, Land,
  Adresstyp, Total Traffic, Status, Verbindungszahl, Tabelle
  „Traffic Details". Zusaetzlich der Blocklisten-Zustand.
- **Land** (`country_detail_window.py`): Total Traffic, Anteil in Prozent,
  Hostzahl, Tabelle „Hosts aus diesem Land".
- **Prozess** (`process_detail_window.py`): Abschnitte Info / Hosts / Alarme,
  Herausgeber-Heuristik 1:1 (`firefox` → Mozilla Corporation,
  `chrome`/`chromium` → Google LLC / Chromium, sonst Unknown), Programmpfad
  ueber `/proc/<pid>/exe` statt `psutil.Process(pid).exe()`.

Doppelklick auf einen Prozess in „Live Verbindungen" oeffnet dasselbe Fenster.

### Theme-Dialog und Kopfzeilen-Knoepfe (RELAY 3e, 2d)
Im Original stehen rechts neben „Suchen" zwei Knoepfe: ⚙ (Einstellungen) und
🎨 (Theme). Beide da. Das Theme-Fenster (`theme_dialog.py`) zeigt alle sechs
Themes mit Vorschau der vier Markerfarben.

### 🐞 Dritter Zeichenfund
Im Host-Fenster stand `□ Active` statt `🟢 Active`: **U+1F7E2** und die
Geschwister 🟡🟠 sind Unicode-12.0-Zeichen (2019) und fehlen in der
NotoEmoji-Fassung, die egui ausliefert. 🔴 (Unicode 6.0) ist dagegen
vorhanden. Status jetzt als farbiger Text. Drei Eintraege mehr in
`glyphen::VERBOTEN`, ein Test mehr.

Deckungsgrad: **346 von 586 Symbolen (59,0 %)**, 116 ungeklaert.
203 Tests, clippy `-D warnings` sauber.

---

## v1.0.0 — 2026-08-21 · 1:1-Betrieb als Voreinstellung

Vorgabe: *„Keine Abweichungen. Fuege keine neuen Features hinzu und lass keine
alten weg."* Bis v0.9.0 lief die Portierung mit meinen Korrekturen als
Standard. Das ist jetzt umgedreht.

### Originaltreue-Schalter (`ev_core::treue`)
Ein zentraler Schalter kapselt **alle** bewussten Abweichungen. Voreinstellung
ist **`Treue::Original`** — das Programm verhaelt sich exakt wie
EarthViewer 2.0, einschliesslich seiner Fehler:

| Abweichung | 1:1-Betrieb (Standard) | mit Korrekturen |
|---|---|---|
| Satelliten-Bezugssystem | TEME auf erdfeste Kugel, Drift ~15°/h | TEME → ECEF ueber GMST |
| Bodenspur-Achsen | `x=cos·cos, y=cos·sin, z=sin` | Konvention von `to_cartesian` |
| „Aequator"-Preset | zeigt den Nordpol | zeigt den Aequator |
| „Nordpol"/„Suedpol" | zeigen den Aequator | zeigen die Pole |
| Startansicht | Nordpol | Mitteleuropa |
| Beschriftungen | alle, auch uebereinander | 26 px Mindestabstand |

Umschaltbar im Reiter Einstellungen oder ueber
`EARTHVIEWER_TREUE=korrigiert`. Das Startbanner nennt die aktive Betriebsart.
Der Reiter listet jede Abweichung mit Originalverhalten, Korrektur und
Fundstelle im Python-Quelltext; ein Test prueft, dass jeder Eintrag vollstaendig
ist und auf eine `.py`-Datei zeigt.

### Neues Archiv ausgewertet
Das nachgelieferte `earthviewer_v0_2_miniCaptureExtra.zip` (8,8 MB,
unkomprimiert) enthaelt denselben Quelltext — 71 Dateien, 13.851 Zeilen. Neu
sind vier Eintraege: drei `.pyc`-Zwischenspeicher und
**`data/geodata/worldcities.xlsx`** (3,3 MB).

Die Tabelle wird **nicht ausgewertet**: `geo_manager.py` sucht nur `*.csv`,
und `requirements.txt` kennt weder `openpyxl` noch `pandas`. Sie einzulesen
waere ein neues Merkmal. Die Datei liegt 1:1 im Paket, der Grund steht in
`data/geodata/README.md`.

`Geodaten/` (grosses G) enthaelt nur leere Ordner — keine MMDB-Dateien.

### Werkzeug haerter
`gegenpruefung.py` faellt auf `unzip` zurueck, wenn Pythons `zipfile` ein
Archiv nicht oeffnet. Ausloeser war ein noch nicht fertig hochgeladenes ZIP;
der Rueckfall deckt auch unkomprimierte und Zip64-Archive ab.

Gemessen gegen das neue Archiv: 586 Symbole, **345 portiert (58,9 %)**,
124 begruendet ausgelassen, 117 ungeklaert.

197 Tests, clippy `-D warnings` sauber.

---

## v0.9.0 — 2026-08-21 · Satelliten-Reiter nach Vorlage, Beschriftungen ausgedünnt

### Satelliten-Zentrale auf das Original-Modell (RELAY 3b)
Bisher: ein Auswahlfeld für **eine** Gruppe, danach ein aus Namen geratener
Kategoriefilter. Im Original (`satellite_integration.py`) ist es anders herum:

- **Celestrak-Gruppen als Ankreuzfelder** — `Space Stations`, `Weather`,
  `Starlink`, `GPS`, genau die vier aus `self.cats`. Mehrere gleichzeitig
  möglich; beim Anhaken wird geladen, beim Abhaken entfernt. NORAD-IDs werden
  entdoppelt, damit die ISS nicht dreimal am Himmel steht.
- **Ankreuzfeld je Satellit** (Port von `sat_checkboxes`), dazu
  `Alle auswählen` / `Alle abwählen` und die Fußzeile
  `✅ N/M Satelliten aktiv`.
- `Tle` trägt jetzt seine Herkunftsgruppe, sonst ließe sich eine Gruppe nicht
  gezielt wieder entfernen.

Der namensbasierte Kategoriefilter ist entfallen — er war meine Erfindung und
im Original nie vorhanden. Clippy hat die Reste zuverlässig aufgezeigt.

### Beschriftungen ausgedünnt (RELAY 3f)
Im Original-Bildschirmfoto liegen bei 50 Treffern die Namen unlesbar
übereinander. `globe_view::thin_out` verwirft Beschriftungen, die einer
bereits gesetzten näher als 26 px kommen — **die Marker bleiben alle**, nur
die Schrift wird gelichtet. Sortiert von oben nach unten, damit die Auswahl
von Bild zu Bild stabil bleibt und nicht flackert. Fünf Tests, darunter genau
der Fall aus dem Bildschirmfoto (30 Hops auf einem Fleck → eine Beschriftung).

Das ist bewusst **kein** Nachbau: hier ist das Original schlechter.

### Behoben
Die Satellitenliste lief unten unter die Fußzeile `N/M aktiv` — beim
Sichttest aufgefallen, Höhenreserve von 26 auf 52 px erhöht.

189 Tests, clippy `-D warnings` sauber.

---

## v0.8.0 — 2026-08-21 · Monitoring vierspaltig, zwei weitere Zeichenfunde

Fortsetzung der Sichtprüfung aus v0.7.0. Ich hatte dort eingeräumt, dass
Monitoring, Graph und Schützen noch nicht im Bild geprüft waren — das ist
jetzt nachgeholt und hat prompt Fehler zutage gefördert.

### 🐞 Zwei weitere fehlende Schriftzeichen
Im Monitoring stand `□ Top Länder` und `□ unbekannt`:

- **U+1F3F3 `🏳`** (weiße Fahne) fehlt in NotoEmoji. `country::flag` gab sie
  für unbekannte ISO-Codes zurück. Jetzt schlichtes `?`, und
  `flag_and_name("")` liefert nur noch `unbekannt`.
- **U+1F50C `🔌`** (Stecker) erschien entstellt → `📊`.

Beide in `glyphen::VERBOTEN` eingetragen, mit zwei neuen Tests. Der
Zeichenvorrat ist damit an vier Stellen empirisch belegt statt geraten.

### Monitoring: vier Spalten nebeneinander (RELAY 3c)
`Apps | Hosts | Verkehr | Länder` per `ui.columns(4, …)`, je Spalte eigener
Scrollbereich mit Balken, Namen über 14 Zeichen gekürzt mit Tooltip.

**Ehrlich zu den Zahlen:** das Original zeigt dort Bytes (`235.1 KB`).
`/proc` liefert Verkehr aber nur pro Interface, nicht pro Socket — pro App
bräuchte es eBPF, den Weg von `nethogs`. Die Spalten zeigen deshalb
Verbindungszahlen, und der **gemessene** Gesamtdurchsatz steht als Zeile
darüber. Lieber eine ehrliche Zahl weniger als eine erfundene mehr. In
`OBERFLAECHE_REFERENZ.md` als bekannte Abweichung vermerkt.

### Graph: Achsen korrigiert
- Achsenbeschriftung stand als `B/s` da — sie war links angeschnitten.
  Jetzt oben links, Plotbereich um 18 px eingerückt.
- Skalenwerte zeigten bei kleinem Verkehr viermal `1`. Nachkommastellen
  richten sich jetzt nach der Größenordnung (0/1/2 Stellen).

187 Tests (vorher 185), clippy `-D warnings` sauber.

*Nebenbei:* der Build lief einmal gegen eine volle Platte
(`ld: No space left on device`) — 7,9 GB `target/`. Kein Codefehler, aber ein
Grund, `cargo clean` vor langen Sitzungen einzuplanen.

---

## v0.7.0 — 2026-08-21 · Maße, Farben, Scrollbalken

Anno: „kuck ob alles die richtige Größe hat, Schrift, Farbe und Scrollbalken —
nicht dass ich auf einen Scrollbalken komme und dahinter ist Schrift."
Er hatte recht: es gab genau diesen Fehler.

### 🐞 Scrollbalken über dem Text — behoben
Zwei Ursachen, beide echt:

1. **Schwebender Balken.** egui benutzt von Haus aus einen *floating*
   Scrollbalken, der über dem Inhalt liegt. Qt reserviert stattdessen Platz.
   → `style.spacing.scroll = ScrollStyle::solid()`; der Balken bekommt eine
   eigene Spalte, der Text endet davor.
2. **Verschachtelte Scrollbereiche.** Um alle Reiter lag ein äußerer
   `ScrollArea`, und sieben Reiter bringen ihren eigenen mit — zwei
   senkrechte Balken übereinander. → Jetzt scrollt genau eine Ebene.

### Neues Messwerkzeug: `werkzeug/farben.py`
Liest PNG **direkt aus der Bilder-ZIP** (eigener PNG-Dekoder, kein Pillow) und
misst Flächenfarben, Leistenbreite, Textzeilenhöhen, Scrollbalkenlage und
Akzentfarben. Erkennt, wenn das Fenster den Schirm nicht füllt — sonst misst
man den schwarzen Schreibtisch mit (ist mir passiert).

### Farben und Größen jetzt aus der Quelle
Statt Pixel zu raten: die Konstanten aus `config.py` des Originals, in
`ev_core::theme::ui` übernommen und gegen die Bildschirmfotos gegengemessen.

| | Original | v0.7.0 |
|---|---|---|
| Akzent | `#0d7377` | `#0d7377` ✅ |
| Seitenleiste | `#2b2b2b` | `#2b2b2b` ✅ |
| Eingabefelder | `#1e1e1e` | `#1e1e1e` ✅ |
| Knöpfe | `#3a3a3a` | `#3a3a3a` ✅ |
| Rahmen | `#555555` | `#555555` ✅ |
| Leistenbreite | 485 px (350–500) | 470 px ✅ |
| Schriftgrößen | 11/14/16/18/24 px | dieselben ✅ |
| Steuerkreuz | 137×90 px (0.65) | Verhältnis 0.65 ✅ |

### 🐞 Fehlende Schriftzeichen — behoben und abgesichert
Im Control Center stand `□ □ eth0 □ □` statt `— eth0 —`: U+2500
(Kästchen-Striche) fehlt in egui's Schriften. Neues Modul
`ev-app::glyphen` mit geprüftem Zeichenvorrat und sechs Tests, die
Reiter-, Werkzeug- und Oberflächentexte durchgehen. Der Test hat beim
Schreiben sofort zwei weitere gefunden: `▶` und `🛣`.

Nebenwirkung zum Guten: die Werkzeugnamen heißen jetzt schmucklos
`Traceroute / Ping / WHOIS` in dieser Reihenfolge — genau wie im Original.

185 Tests (vorher 174), clippy `-D warnings` sauber.

---

## v0.6.0 — 2026-08-21 · Satelliten-Sprites

Abarbeitung von `RELAY.md` §4, Punkt 3a und 3d — den beiden auffaelligsten
Abweichungen von den Original-Bildschirmfotos.

### Texturierte Satelliten-Symbole (3a)
Das Original zeichnete Satelliten als **Punkt-Sprites mit PNG-Icon**, nicht als
einfarbige Punkte. Nachgezogen:

- `shaders::SPRITE_VERT` / `SPRITE_FRAG` — **woertlich** aus
  `satellite_sprites.py` uebernommen (`gl_PointCoord` als UV, `discard` unter
  Alpha 0.1 fuer saubere Kanten).
- `Scene::SpriteBatch` + `GlobeRenderer::render_sprites`. Beim Zeichnen wird
  `depth_mask(false)` gesetzt: Sprites bleiben hinter der Kugel verdeckt,
  schneiden sich aber untereinander nicht weg.
- `gl_util::load_sprite_texture` mit `fit_into_square`.
  **Abweichung mit Absicht:** das Original gab `satellite_icon.png`
  (2221×1666, 4:3) unveraendert an GL — Punkt-Sprites sind quadratisch, das
  Icon wurde also um ein Viertel in die Breite gestaucht. Wir betten es
  proportionswahrend mittig ein und skalieren auf 128×128 (die Datei ist
  1,6 MB). 3 Tests decken das ab.
- Kategoriefarbe als `tint`, Groesse ueber Regler (Original: fest 32 px).
- Faellt auf einfarbige Punkte zurueck, wenn kein Icon gefunden wird.

### Satelliten beim Start (neu)
Das Original zeigte sofort Satelliten (`21/21 aktiv`). Jetzt laedt
`autoload_satellites()` beim Start **ohne Netzzugriff**: erst
`sessions/tle_*.txt`, sonst die eingebaute Notreserve. Ein Netz-Download beim
Start kostet Sekunden und kann haengen.

Nebenbei bestaetigt das den Nutzen der Alterswarnung aus v0.4.0: mit der
963 Tage alten Notreserve rechnet SGP4 die ISS auf 171 km Hoehe herunter —
sichtbar falsch, und die Warnung steht rot daneben.

### Traceroute-Ausgabe (3d)
Format aus dem Bildschirmfoto uebernommen:
`Hop 10: 176.52.252.32 (176.52.252.32) - 66.8ms`, Abschluss
`✅ N Hops lokalisiert`. Zusaetzlich je Hop eine eingerueckte Zeile mit
Landesfahne und Ort.

174 Tests (vorher 169), clippy `-D warnings` sauber.
Deckungsgrad unveraendert 57,8 % — `satellite_sprites.py` wandert von
„begruendet ausgelassen" nach „portiert".

---

## v0.5.0 — 2026-08-21 · Nach den Original-Bildschirmfotos

Anno hat 34 Aufnahmen des laufenden EarthViewer 2.0 geliefert. Bis v0.4.0
hatte ich die Oberflaeche aus dem Quelltext **erschlossen** — das war an
mehreren Stellen falsch. Jetzt gibt es eine gesehene Sollvorgabe:
`docs/OBERFLAECHE_REFERENZ.md`, dazu vier Originale in `docs/referenz/`.

### Der substanzielle Fund
Monitoring und Graph zeigen im Original **KB/s und KB**, nicht
Verbindungszahlen. Ich hatte Verbindungen gezaehlt — das war schlicht die
falsche Groesse.
→ Neues Modul **`ev-net::throughput`**: liest `/proc/net/dev`, bildet Deltas,
liefert Up/Down/Total in Byte pro Sekunde. Faengt Zaehlerueberlauf und
Interface-Neustart ab (`saturating_sub`), ueberspringt Loopback, damit
lokaler Verkehr nicht doppelt zaehlt. 8 Tests.

### Oberflaeche angeglichen
- **Kopf der Seitenleiste**: `🌍 EarthViewer <version>` in Tuerkis, darunter
  `Status: …` — die Statuszeile meldet jetzt Trefferzahlen und Ansichtswechsel.
- **Zoom-Fussleiste** `Zoom: 8.9x`, aus dem Kameraabstand gerechnet.
- **Reiterleiste einzeilig und scrollend** statt in drei Zeilen umbrechend.
- **Steuerungs-Reiter** nach Vorlage: grosses Steuerkreuz (⬆ mittig oben,
  ⬅ ⬇ ➡ darunter), Auto-Rotation als **Umschaltknopf** statt Ankreuzfeld,
  Ansicht als **Auswahlfeld** statt fuenf Knoepfen, Optionen auf die zwei
  originalen reduziert (`📍 Marker anzeigen`, `🏷 Namen anzeigen`) —
  alles Weitere unter „Mehr" eingeklappt.
- **Graph** als **gestapeltes Flaechendiagramm** in KB/s mit Legende
  Upload/Download/Total und 300 Datenpunkten, wie im Bild.

### Nicht angeglichen (bewusst, in RELAY §4 notiert)
Satelliten-Sprites (gruene Symbole statt Punkte), Satelliten-Reiter-Modell
(Kategorien = Celestrak-Gruppen mit Einzelauswahl je Objekt), Monitoring als
vier Tabellen nebeneinander mit Byte-Spalten, Traceroute-Ausgabeformat
`Hop N: host (ip) - RTTms`, ⚙/🎨-Knoepfe in der Kopfzeile.

169 Tests (vorher 158), clippy `-D warnings` sauber.

---

## v0.4.0 — 2026-08-21 · Gegengeprüft und gemessen

Diese Version entstand aus einer berechtigten Rüge: bis v0.3.0 hatte ich
**gelesen und behauptet**, nicht gemessen.

### Eigene Werkzeuge (neu)
- **`werkzeug/gegenpruefung.py`** — zerlegt jede lebende `.py` der Original-ZIP
  per `ast` und stuft jedes Symbol ein (OK / SKIP / FEHLT). Liest die ZIP
  **direkt**, entpackt nichts.
- **`werkzeug/messen.py`** — Umfang, Tests, Bauzeit, Binärgröße, `unsafe`-Blöcke,
  Startzeit bis zum ersten Frame.
- **`werkzeug/abbildung.json`** — 154 Umbenennungen, 29 begründete Auslassungen.
  Eine Auslassung ohne Begründung zählt nicht.
- `./pruefen.sh` ruft die Gegenprüfung als Schritt 5 mit auf.

### Was die Messung gefunden hat
Ausgangsstand v0.3.0: **21,7 % geprüft, 78,3 % ungeklärt.** Danach:

- `country_flags.py` war **nie geöffnet** → `ev-core::country`. Fahnen werden
  jetzt aus dem ISO-Code *gerechnet* (Regional-Indicator-Symbole), nicht aus
  einer 250-Zeilen-Tabelle. Fahne + Klarname in Verbindungs- und Länderliste.
- `orbit_renderer.py` war **nie geöffnet** → Bahnkurven werden gezeichnet.
  Die Mathematik lag seit v0.3.0 ungenutzt in `ev-sat`.
- `satellite_tracker_engine.py::OFFLINE_TLES` war **nie geöffnet** →
  `ev-sat::offline` mit fünf eingebauten TLE. Satelliten ohne Internet.
- `ConnectionTracker.classify_ip` fehlte → `ev-net::classify`, inklusive
  CGNAT (RFC 6598) und Dokumentationsnetzen, die das Original nicht kannte.
- `ARPScanner._resolve_hostname` fehlte → `classify::reverse_dns`.
- `SatelliteManager.add/remove_category` fehlten → Kategoriefilter.
- `globe_widget._check_hover` / `_check_satellite_click` / `_dist_to_segment`
  fehlten → Hover-Tooltips und Klick-Auswahl auf dem Globus.
- **Eigene Falschaussage gefunden:** `ARCHITECTURE.md` behauptete, `gl_util.rs`
  enthalte „das einzige `unsafe` im Projekt". Gemessen: 19 Blöcke in 3 Dateien.
  Korrigiert und mit Zahlen belegt.

Stand nach v0.4.0: **45,4 % geprüft, 22,2 % begründet ausgelassen,
32,4 % ungeklärt.** 158 Tests (vorher 127).

### Aus der Community übernommen
KVR Audio wurde geprüft und ist **die falsche Quelle** — dort geht es
ausschließlich um Musiksoftware, kein einziger Treffer zu Globus, Satelliten
oder Netzwerk. Stattdessen der Gpredict-Issue-Tracker, wo genau dieses
Programm diskutiert wird:

- **Issue #94 „Ground Track Improvements"** — Nutzer wollen bei Auswahl eines
  Satelliten Bodenspur *und* Sichtbarkeitskreis sehen, dazu Richtungspfeile
  für die Flugrichtung, und das pro Satellit abschaltbar.
  → `Scene::add_footprint` (Halbwinkel `acos(R/(R+h))`),
  `Scene::add_direction_arrow`, drei Schalter im Satelliten-Reiter.
- **Issue #4 „Improve TLE data management"** — mitgelieferte TLE veralten
  binnen Wochen, und niemand merkt es.
  → `offline::age_days` liest das Alter aus der TLE-Epoche selbst,
  `Freshness` warnt ab 14 Tagen farbig. Die Notreserve ist ausdrücklich als
  solche beschriftet, nicht als Datenquelle.

### Weiteres
- Satelliten-Reiter: Kategoriefilter mit Farben, Namensfilter, Auswahl zentriert
  die Kamera, Notreserve-Knopf.
- Verbindungstabelle färbt nicht-geolokalisierbare Adressen (privat, CGNAT,
  Loopback) ein und nennt beim Überfahren den Grund.

### Bekannte offene Punkte
Namentlich in `docs/RELAY.md` §4 — Detailfenster für Host/Land/Prozess,
texturierte Satelliten-Sprites, Custom-Theme-Farbwähler, VirusTotal-Cache.
Alle mit Fundstelle im Original.

---


## v0.3.0 — 2026-08-21 · Rust-Portierung

Vollständige Neuimplementierung von EarthViewer 2.0 (Python/PyQt6/PyOpenGL)
in Rust. Sechs Crates, 90 Tests, keine Python-Abhängigkeit mehr.

### Ersetzte Abhängigkeiten
- PyQt6 → `eframe`/`egui` 0.31
- PyOpenGL → `glow` 0.16
- numpy → `glam` 0.27
- psutil → nativer `/proc/net`-Parser
- scapy → passiver ARP-Cache (`/proc/net/arp`)
- skyfield → `sgp4` 1.2
- geoip2 → `maxminddb` 0.24
- requests → `ureq` 2
- Pillow → `image` 0.25
- pyqtgraph → entfällt

### Korrigierte Fehler des Originals
- **Satelliten-Bezugssystem**: TEME-Positionen wurden auf die erdfeste Kugel
  gezeichnet (~15°/h Drift). Jetzt TEME→ECEF über GMST. Altes Verhalten über
  `Frame::Inertial` weiterhin verfügbar.
- **Bodenspuren**: `calculate_ground_track()` nutzte eine andere Achskonvention
  als `GeoLocation.to_cartesian` — Spuren lagen komplett falsch.
- **VirusTotal-Key im Klartext** in `settings.json`, mit im Archiv ausgeliefert.
- **Blickwinkel-Presets**: „Äquator" zeigte den Nordpol, „Nordpol" und „Südpol"
  zeigten den Äquator. Drei von fünf Presets waren falsch, weil `align_view()`
  fest verdrahtete Matrizen benutzte statt `_align_to_location()`.
- **Startansicht** zeigte den Nordpol (sieht aus wie eine kaputte Textur) —
  startet jetzt auf Mitteleuropa.

### Neu
- TLE-Cache in `sessions/` — Satelliten auch ohne Internet
- WHOIS folgt `refer:`-Verweisen bis zum zuständigen RIR
- Textur-Fallback (Gradnetz) statt schwarzer Kugel bei fehlender `earth_map.jpg`
- Richtungslogik umschaltbar: 50/50-Optik (Original) oder Port-Auswertung
- OUI-Herstellertabelle für ARP-Einträge
- Traceroute erkennt Hops ohne Reverse-DNS
- Verbindungsbögen pulsieren (`animation_speed` war im Original berechnet,
  aber nie benutzt)
- `pruefen.sh` als verbindliches Qualitäts-Gate
- **`start.sh` richtet beim ersten Aufruf alles selbst ein** (Systempakete +
  Rust-Toolchain) und merkt sich das in `.setup_stamp`. Folgende Starts
  überspringen die Prüfung — gemessen 48 ms bis zum Programmstart.
  Erzwingbar mit `--setup`, überspringbar mit `--no-setup`.
- **MSAA-Rückfallkette 4×→2×→0×** — läuft dadurch auch auf llvmpipe, in VMs
  und auf alten iGPUs. Das Original stürzte dort ab bzw. Qt schluckte es still.
- Klartext-Hilfen bei Startfehlern (kein Display, kein GL-Kontext, fehlende Libs)

### Entfernt
- WLAN-Monitor-Modus (§202b StGB, siehe `docs/SECURITY_NOTES.md`)
- 20 Backup-Kopien von `globe_widget.py` und `satellite_integration.py`
- `install.py` (1593 Zeilen venv-Bootstrap) — ersetzt durch `cargo`
- Vier `*_large_window.py`-Klassen (identischer Inhalt, größeres Fenster)

### Nachtrag v0.3.0 (nach Rueckmeldung)
- **Alle 11 Reiter aus `sidebar.py` portiert** (vorher nur 4): Steuerung,
  Suche, Favoriten, Netzwerk, Live Verbindungen, Monitoring, Control Center,
  Graph, Schuetzen, Protokoll Analyse, Netzwerk Scanner. Plus Satelliten und
  Einstellungen = 13.
- **`data/` aus dem Original uebernommen** — die drei Erdtexturen, die
  Satelliten-Icons und `geodata/Germany/staedte.csv` mit 1746 Orten. Beim
  ersten Durchgang hatte ich nur leere Ordner mit READMEs angelegt.
- Neue Module: `ev-net::monitor` (Traffic-Statistik, Port von
  `network_monitor.py`), `ev-net::portscan` (Threadpool-Portscanner, Port von
  `PortScannerThread`), `ev-net::firewall` (Blockliste, Port von `ProtectionTab`).
- Screenshot-Funktion umgesetzt (`ViewportCommand::Screenshot` -> `screenshots/`).
- Favoriten sind jetzt persistent (`sessions/favorites.json`) — im Original
  waren sie nach dem Beenden weg.
- Wiederholungs-Modus im Netzwerk-Tab (Port von `_on_loop_tick`).
- `$EARTHVIEWER_TAB=<slug>` oeffnet einen Reiter direkt — fuer Screenshot-Tests.
- Glyphen bereinigt: U+FE0F erzeugte in egui leere Kaestchen, U+1F6F0 fehlt in
  NotoEmoji ganz.

### Verifikation
- 127 Tests grün, `clippy -D warnings` sauber
- **GUI unter Xvfb + llvmpipe gestartet und per Screenshot bestätigt**
  (`docs/screenshot.png`) — Fenster, Globus, Beleuchtung, Sidebar, Tabs,
  Renderer-Init und Connection-Tracker laufen.

### Bekannte Einschränkungen
- Noch nicht auf echter GPU-Hardware getestet (nur Software-Rendering)
- Satelliten-Detailfenster, Hover-Tooltips und Screenshot-Funktion fehlen noch

---

## v0.2 — 2025-11 · Python (Original)
- 3D-Globus mit PyQt6/PyOpenGL
- Netzwerk-Monitoring, ARP-Scanner, WiFi-Capture
- Satelliten-Integration, Orbit-Rendering
- Sechs Themes
