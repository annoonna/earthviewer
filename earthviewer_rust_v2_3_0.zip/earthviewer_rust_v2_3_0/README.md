# 🌍 EarthViewer 2.0 — Rust Edition

Interaktiver 3D-Globus mit Netzwerk-Monitoring, GeoIP-Lokalisierung und
Satelliten-Tracking. Vollständige Rust-Portierung von EarthViewer 2.0
(Python/PyQt6/PyOpenGL).

```
┌──────────────────────────────────────────────────────────────┐
│  🌍  [Suche: Stadt, Land, IP oder "lat, lon"]  🔍  ✖         │
│      ☐ Auto-Rotation   Verbindungen: 42 (⬇ 19 / ⬆ 23)       │
├──────────────────────────────────┬───────────────────────────┤
│                                  │ 🌐 Netzwerk  🛰 Satelliten │
│           ╭───────────╮          │ 🔧 Werkzeuge ⚙ Einstell.  │
│         ╭─┤  E R D E  ├─╮        ├───────────────────────────┤
│        ╱  ╰───────────╯  ╲       │ Prozess  Gegenstelle  Ort │
│       │   ·  ╱‾‾‾╲  ·     │      │ firefox  1.1.1.1:443  AU  │
│        ╲    ╱     ╲      ╱       │ ssh      10.0.0.5:22  —   │
│         ╰──╯       ╰────╯        │ …                         │
└──────────────────────────────────┴───────────────────────────┘
```

## Schnellstart

```bash
./start.sh
```

Mehr ist nicht nötig. **Beim ersten Aufruf** installiert das Skript selbst,
was fehlt — Systembibliotheken über den erkannten Paketmanager (apt, dnf,
pacman, zypper) und bei Bedarf die Rust-Toolchain — und baut danach.

**Jeder weitere Aufruf startet sofort.** Die abgeschlossene Einrichtung merkt
sich `.setup_stamp`; gemessen sind es 48 ms bis zum Programmstart. Der Stempel
enthält eine Signatur der Abhängigkeitsliste: ändert sie sich in einer späteren
Version, läuft die Einrichtung von selbst noch einmal.

```bash
./start.sh              # normal
./start.sh 1            # X11 direkt (empfohlen, auch unter Wayland via XWayland)
./start.sh 2            # Wayland nativ
./start.sh 3            # winit entscheidet
./start.sh --setup      # Einrichtung erzwingen (nach apt-Umbauten)
./start.sh --no-setup   # Einrichtung überspringen
./start.sh --help
```

## Voraussetzungen

Alles Folgende holt `./start.sh` beim ersten Start selbst — die Liste ist nur
zur Information bzw. für manuelle Installation:

- **Rust ≥ 1.85**
- **Debian/Kali**: `build-essential pkg-config libgl1-mesa-dev libx11-dev
  libxcursor-dev libxrandr-dev libxi-dev libxkbcommon-dev libxkbcommon-x11-dev
  libwayland-dev traceroute`

Hinkt das Distributionspaket hinterher (Ubuntu 24.04 liefert z. B. Rust 1.75),
sagt das Skript das und verweist auf rustup.

**root wird nicht benötigt.** Als root sieht der Connection-Tracker zusätzlich
fremde Prozesse — das ist der einzige Unterschied.

## Daten selbst kopieren

Es gibt zwei Fassungen:

| | Inhalt |
|---|---|
| `..._schlank.zip` (228 KB) | nur Programm und Werkzeuge, `data/` leer |
| `....zip` (12 MB) | mit 242 Länderlisten und Erdtexturen |

Bei der schlanken Fassung sagt dir **`data/KOPIEREN.md`**, was wohin gehört,
und **`./pruefe_daten.sh`** prüft es hinterher:

```bash
ALT=~/Videos/earthviewer_v0_2_miniCaptureExtra
cp -r "$ALT"/data/geodata/*  data/geodata/
cp -r "$ALT"/data/textures/* data/textures/
cp    "$ALT"/Geodaten/GeoLite2-City_*/GeoLite2-City.mmdb data/geodata/
./pruefe_daten.sh
```

## Daten bereitstellen

```
data/
├── textures/
│   ├── earth_map.jpg          <- NASA-Nachtlichter (Standard)
│   ├── earth_day.jpg          <- Tagseite
│   ├── earth_map1.jpg         <- hochaufloesende Variante
│   └── satellites/*.png
└── geodata/
    ├── <242 Laender>/staedte.csv   <- 47.867 Orte
    └── worldcities.xlsx            <- Quelle, vom Programm nicht gelesen
```

Diese Dateien sind **im Archiv enthalten** (aus dem Original uebernommen).
Weitere Laender: `data/geodata/<Land>/staedte.csv` anlegen, Spalten
`name|city`, `lat|latitude`, `lon|lng|longitude`. Der Ordnername ist das Land.
Andere Textur: einfach nach `earth_map.jpg` kopieren.

**GeoIP**: die MMDB gehoert nach `data/geodata/` — **nicht** in einen Ordner
`Geodaten/`, den liest das Programm nie (das Original tat es auch nicht).
Nur Dateien mit `city` im Namen werden ausgewertet; Country und ASN ignoriert
das Original. Unterordner sind erlaubt, die Suche ist rekursiv.

```bash
./geodaten_einrichten.sh /pfad/zu/Geodaten   # legt alles richtig ab
```

Ausfuehrlich in **`docs/GEOIP_EINRICHTEN.md`**, inklusive Aufteiler fuer die
simplemaps-Weltstaedte (`werkzeug/staedte_aufteilen.py`).

Aus Lizenzgruenden liegen die Datenbanken nicht im Paket - die MaxMind-EULA
untersagt die Weitergabe von Dateien aelter als 30 Tage. Bezug:
https://dev.maxmind.com/geoip/geolite2-free-geolocation-data
Ohne MMDB funktioniert alles ausser der IP-Lokalisierung.

## VirusTotal

Der API-Key kommt ausschließlich aus der Umgebung — nie aus einer Datei:

```bash
cp .env.example .env
$EDITOR .env          # EARTHVIEWER_VT_API_KEY=...
./start.sh
```

`.env` steht in `.gitignore` und wird beim Paketieren ausgeschlossen.

![EarthViewer](docs/screenshot.png)

## Funktionen

**Globus** — UV-Sphere mit Erdtextur und Diffuslicht, Maus-Rotation, Zoom,
Auto-Rotation, Blickwinkel-Presets (Deutschland, Pole, Äquator, Ziel),
sechs Themes.

**Suche** — Städte aus CSV, IP-Adressen über GeoIP, direkte Koordinaten
(`"51.34, 12.38"`). Der Globus dreht sich zum Treffer.

**Netzwerk** — Live-Verbindungen aus `/proc/net`, mit Prozessnamen und
GeoIP-Ort. Als pulsierende Great-Circle-Bögen auf dem Globus. Richtungslogik
umschaltbar zwischen der 50/50-Optik des Originals und technisch korrekter
Auswertung lauschender Ports.

**Werkzeuge** — Ping, Traceroute (Hops als Marker auf dem Globus), WHOIS mit
Referral-Verfolgung. Optional im Wiederholungs-Modus mit einstellbarem
Intervall. (Die Combo führt exakt Traceroute/Ping/WHOIS wie `network_tab.py`;
VirusTotal und ARP sitzen im Control Center bzw. den Detailfenstern.)

**Die 12 Reiter** (11 aus `sidebar.py`, Zeilen 78-119, plus Satelliten aus
`satellite_integration.py`). „Einstellungen" ist **kein** Reiter — das Zahnrad
oben öffnet wie im Original den Dialog „⚙ Erweiterte Einstellungen"
(`main_window._show_settings`):

| Reiter | Inhalt |
|---|---|
| Steuerung | Steuerkreuz, Auto-Rotation, Zuruecksetzen, Screenshot, Ansicht-Presets, Optionen |
| Suche | Ortssuche mit Trefferliste, Sprung zum Ort, Favorit merken |
| Favoriten | Gemerkte Orte, persistent in `sessions/favorites.json` |
| Netzwerk | Werkzeugwahl, Ziel, Wiederholung, Ergebnisfenster |
| Live Verbindungen | Verbindungstabelle Stadt/Land, Richtung, Protokoll, VirusTotal + Große Live-Analyse |
| Monitoring | Top Apps / Hosts / Verkehr / Laender mit Balken + Große Ansicht |
| Control Center | WLAN Control Center öffnen (Erweiterte Ansicht) |
| Graph | Verlaufsdiagramm Upload / Download / Total + Große Ansicht |
| Schuetzen | Blockliste, Freigeben, iptables-Export + Große Ansicht |
| Protokoll Analyse | Protokoll / Traffic / Pakete / Anteil % + Große Ansicht |
| Netzwerk Scanner | TCP-Portscan mit Threadpool und Dienstnamen + Große Ansicht |
| Satelliten | TLE-Gruppen, SGP4, Kategorien, PRO Monitor |

**Freistehende Fenster** (Ports der `QDialog`-Klassen, je über „Große Ansicht
öffnen" bzw. das Zahnrad erreichbar): Network Monitor (Live), Große
Live-Analyse, WLAN Control Center (WiFi Monitor · Live Statistiken ·
VirusTotal-Einstellungen), Netzwerk-Clients, Graph/Schutz/Protokoll/Scanner
groß, „⚙ Erweiterte Einstellungen" und der **SatMonitor PRO** (Spektrum ·
Sat-Tracking · Spectator API) über den Knopf „🖥 PRO Monitor öffnen" im
Satelliten-Reiter.

**SatMonitor PRO / Spektrum** — vollständig portierte SDR-Spektrum-Simulation
(`sat_monitor_window.py::SimulationWorker`): Grundrauschen plus die sechs
Signalprofile (Rauschen, Sinus-Test, Regen, Eis, Rauch/Interferenz,
Sat-Beacons), Sat-Profile (NOAA/METEOR/ADS-B/ACARS/AIS/ISS), FFT-Größe,
Farbschemata und Linie/Wasserfall-Diagramm. Reines Rust ohne numpy/pyqtgraph
(`ev-sat::spektrum`).

**Satelliten** — TLE von Celestrak mit lokalem Cache, SGP4-Propagation,
Kategorien mit Farbcodierung (Starlink, GNSS, Wetter, Wissenschaft, ISS,
Militär, Kommunikation). Erdfestes und inertiales Bezugssystem umschaltbar.

## Projektstruktur

```
crates/
├── ev-core     Konfiguration, Geometrie, Mathematik, Themes, Settings
├── ev-geo      Städte-CSV + MaxMind-MMDB, Suche
├── ev-net      /proc-Parser, Ping, Traceroute, WHOIS, ARP, VirusTotal
├── ev-sat      TLE, SGP4, Bezugssysteme, Bahnkurven
├── ev-render   OpenGL via glow (einziges unsafe im Projekt)
└── ev-app      eframe/egui — Fenster, Tabs, Interaktion
docs/
├── PORT_NOTES.md       Python → Rust, Datei für Datei
├── SECURITY_NOTES.md   Sicherheitsbefunde ⚠️ zuerst lesen
├── ARCHITECTURE.md     Warum sechs Crates
└── RELAY.md            Übergabe an die nächste Session
```

## Entwicklung

```bash
./pruefen.sh                    # Gate: fmt + clippy + Tests + Release-Build
cargo test --workspace          # 216 Tests

# Einzelnen Reiter direkt oeffnen (praktisch fuer Screenshot-Tests):
EARTHVIEWER_TAB=graph ./start.sh 1
cargo clippy --workspace --all-targets -- -D warnings
cargo build --release -p ev-app
```

Tests laufen ohne GPU und ohne Display — die Szenenbeschreibung (`ev-render::Scene`)
ist bewusst von den GL-Aufrufen getrennt.

## Messwerkzeuge

Zwei eigene Werkzeuge im Ordner `werkzeug/`. Beide lesen die **Original-ZIP
direkt** (`zipfile`) — es wird nichts entpackt, also gibt es auch keinen
falschen Pfad und keine veraltete Kopie.

```bash
# Deckungsgrad: welches Python-Symbol ist wo gelandet?
./werkzeug/gegenpruefung.py /pfad/earthviewer_v0_2_miniCaptureExtra.zip

# Kennzahlen: Umfang, Tests, Bauzeit, unsafe-Blöcke, Startzeit
./werkzeug/messen.py --schnell
```

`gegenpruefung.py` zerlegt jede lebende `.py` per `ast`, sammelt Klassen,
Methoden und Konstanten und stuft jedes Symbol ein: **OK** (portiert, direkt
oder über `werkzeug/abbildung.json`), **SKIP** (bewusst ausgelassen — jede
Auslassung braucht dort eine Begründung) oder **FEHLT**. Nur FEHLT zählt als
echter Fund. `./pruefen.sh` ruft die Gegenprüfung als Schritt 5 mit auf.

Gemessener Stand v0.9.0:

| Kennzahl | Wert |
|---|---:|
| Python-Symbole gesamt | 586 |
| davon portiert | 346 (59 %) |
| davon begründet ausgelassen | 130 (22 %) |
| davon ungeklärt | 116 (20 %) |
| Rust-Code / davon Tests | 5459 / 1522 Zeilen |
| Tests | 216 grün |
| `unsafe`-Blöcke | 23, **alle** in `gl_util.rs` |

Die 117 ungeklärten sind zu rund 60 Qt-Dekoration (`_setup_ui`, `_button_style`),
der Rest steht namentlich in `docs/RELAY.md` §4.

## Was sich gegenüber der Python-Version geändert hat

Drei Fehler des Originals sind korrigiert: Satelliten standen im falschen
Bezugssystem (~15°/h Drift), Bodenspuren nutzten vertauschte Achsen, und der
VirusTotal-Key lag im Klartext im Archiv. Details in `docs/PORT_NOTES.md`.

Die WLAN-Monitor-Funktion wurde **bewusst nicht portiert** — Begründung in
`docs/SECURITY_NOTES.md`.

## Lizenz

MIT — UKNS UG (haftungsbeschränkt)

Fremddaten: GeoLite2 © MaxMind (eigene Lizenz), TLE von Celestrak.
