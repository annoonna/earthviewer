#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# EarthViewer 2.0 — Rust Edition · Startskript
#
# Erster Aufruf : richtet Toolchain + Systembibliotheken ein, baut, startet.
# Jeder weitere : startet sofort (Einrichtung wird übersprungen).
#
# Die Einrichtung wird durch .setup_stamp gemerkt. Der Stempel enthält eine
# Signatur der Abhängigkeitsliste — ändert sich die Liste, läuft die
# Einrichtung von selbst noch einmal.
#
#   ./start.sh              normal starten
#   ./start.sh 1|2|3        Backend direkt wählen (X11 | Wayland | Auto)
#   ./start.sh --setup      Einrichtung erzwingen (nach apt-Umbauten)
#   ./start.sh --no-setup   Einrichtung überspringen
#   ./start.sh --help
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
export EARTHVIEWER_ROOT="$ROOT"

STAMP="$ROOT/.setup_stamp"
MIN_RUST="1.85"
SETUP_VERSION="1"          # hochzählen, wenn sich die Paketlisten ändern

# ── Was gebraucht wird ──────────────────────────────────────────────────────
# Build: Linker, pkg-config, GL- und Fenster-Header (winit/glutin)
PKGS_DEBIAN=(
    build-essential pkg-config
    libgl1-mesa-dev
    libx11-dev libxcursor-dev libxrandr-dev libxi-dev
    libxkbcommon-dev libxkbcommon-x11-dev
    libwayland-dev
    traceroute
)
PKGS_FEDORA=(
    gcc gcc-c++ pkgconf-pkg-config
    mesa-libGL-devel
    libX11-devel libXcursor-devel libXrandr-devel libXi-devel
    libxkbcommon-devel libxkbcommon-x11-devel
    wayland-devel
    traceroute
)
PKGS_ARCH=(
    base-devel pkgconf
    mesa libglvnd
    libx11 libxcursor libxrandr libxi
    libxkbcommon libxkbcommon-x11
    wayland
    traceroute
)

# ── Argumente ───────────────────────────────────────────────────────────────
FORCE_SETUP=0
SKIP_SETUP=0
CHOICE=""
for arg in "$@"; do
    case "$arg" in
        --setup)     FORCE_SETUP=1 ;;
        --no-setup)  SKIP_SETUP=1 ;;
        --help|-h)
            sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'
            exit 0 ;;
        1|2|3|x11|wayland|auto) CHOICE="$arg" ;;
        *) echo "⚠️  Unbekannte Option: $arg  (--help für Hilfe)" ;;
    esac
done

echo "╔══════════════════════════════════════════════════════╗"
echo "║       🌍 EarthViewer 2.0 Launcher (Rust)             ║"
echo "╚══════════════════════════════════════════════════════╝"

# ── Hilfsfunktionen ─────────────────────────────────────────────────────────
have() { command -v "$1" >/dev/null 2>&1; }

# Signatur der Einrichtung — ändert sich mit der Paketliste.
setup_signature() {
    printf '%s|%s|%s|%s' \
        "$SETUP_VERSION" "$MIN_RUST" \
        "${PKGS_DEBIAN[*]}" "$(uname -s)" \
        | md5sum 2>/dev/null | cut -d' ' -f1 \
        || printf 'v%s' "$SETUP_VERSION"
}

stamp_is_current() {
    [ -f "$STAMP" ] || return 1
    [ "$(head -n1 "$STAMP" 2>/dev/null)" = "$(setup_signature)" ]
}

# Rechte-Vorsatz ermitteln: root braucht nichts, sonst sudo/doas.
privilege_prefix() {
    if [ "$(id -u)" -eq 0 ]; then echo ""; return 0; fi
    if have sudo; then echo "sudo"; return 0; fi
    if have doas; then echo "doas"; return 0; fi
    return 1
}

# Paketmanager erkennen.
detect_pm() {
    if have apt-get; then echo apt
    elif have dnf;   then echo dnf
    elif have pacman;then echo pacman
    elif have zypper;then echo zypper
    else echo none; fi
}

# Versionsvergleich: gibt 0 zurück, wenn $1 >= $2.
version_ge() {
    [ "$(printf '%s\n%s\n' "$2" "$1" | sort -V | head -n1)" = "$2" ]
}

rust_version() { rustc --version 2>/dev/null | awk '{print $2}'; }

# ── Einrichtung ─────────────────────────────────────────────────────────────
run_setup() {
    echo ""
    echo "🔧 Einmalige Einrichtung — das passiert nur beim ersten Start."
    echo "   (später erzwingbar mit ./start.sh --setup)"
    echo ""

    local pm sudo_cmd missing=()
    pm="$(detect_pm)"

    if ! sudo_cmd="$(privilege_prefix)"; then
        echo "⚠️  Weder root noch sudo/doas — kann nichts installieren."
        pm="none"
    fi

    # ── Systempakete ───────────────────────────────────────────────────────
    case "$pm" in
        apt)
            for p in "${PKGS_DEBIAN[@]}"; do
                dpkg -s "$p" >/dev/null 2>&1 || missing+=("$p")
            done
            if [ ${#missing[@]} -gt 0 ]; then
                echo "📦 Fehlende Pakete: ${missing[*]}"
                $sudo_cmd apt-get update -qq || true
                if ! $sudo_cmd apt-get install -y "${missing[@]}"; then
                    echo "❌ apt-get install fehlgeschlagen."
                    return 1
                fi
            else
                echo "✅ Alle Systempakete vorhanden"
            fi
            ;;
        dnf)
            for p in "${PKGS_FEDORA[@]}"; do
                rpm -q "$p" >/dev/null 2>&1 || missing+=("$p")
            done
            [ ${#missing[@]} -gt 0 ] && $sudo_cmd dnf install -y "${missing[@]}"
            ;;
        pacman)
            for p in "${PKGS_ARCH[@]}"; do
                pacman -Qi "$p" >/dev/null 2>&1 || missing+=("$p")
            done
            [ ${#missing[@]} -gt 0 ] && $sudo_cmd pacman -S --needed --noconfirm "${missing[@]}"
            ;;
        zypper)
            $sudo_cmd zypper --non-interactive install -y \
                gcc-c++ pkg-config Mesa-libGL-devel libxkbcommon-devel wayland-devel || true
            ;;
        none)
            echo "⚠️  Kein unterstützter Paketmanager oder keine Rechte."
            echo "   Bitte von Hand installieren:"
            echo "     ${PKGS_DEBIAN[*]}"
            ;;
    esac

    # ── Rust-Toolchain ─────────────────────────────────────────────────────
    local rv
    rv="$(rust_version)"
    if [ -z "$rv" ]; then
        echo ""
        echo "🦀 Rust nicht gefunden — installiere..."
        if [ "$pm" = "apt" ]; then
            $sudo_cmd apt-get install -y cargo rustc || true
            rv="$(rust_version)"
        elif [ "$pm" = "dnf" ]; then
            $sudo_cmd dnf install -y cargo rust || true
            rv="$(rust_version)"
        elif [ "$pm" = "pacman" ]; then
            $sudo_cmd pacman -S --needed --noconfirm rust || true
            rv="$(rust_version)"
        fi
    fi

    if [ -z "$rv" ]; then
        echo "❌ Rust konnte nicht installiert werden."
        rustup_hint
        return 1
    fi

    if ! version_ge "$rv" "$MIN_RUST"; then
        echo ""
        echo "❌ rustc $rv ist zu alt (benötigt: >= $MIN_RUST)."
        echo "   Die Distributionspakete hinken oft hinterher."
        rustup_hint
        return 1
    fi
    echo "✅ rustc $rv"

    # ── Stempel setzen ─────────────────────────────────────────────────────
    {
        setup_signature
        echo "# EarthViewer-Einrichtung abgeschlossen: $(date -Is)"
        echo "# rustc $rv · Paketmanager: $pm"
        echo "# Diese Datei löschen oder ./start.sh --setup erzwingt eine Wiederholung."
    } > "$STAMP"

    echo "✅ Einrichtung abgeschlossen — künftige Starts überspringen diesen Schritt."
    echo ""
    return 0
}

rustup_hint() {
    cat <<'EOT'

   Aktuelles Rust über rustup:
     curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
     source "$HOME/.cargo/env"
   Danach:  ./start.sh --setup
EOT
}

# ── Entscheiden, ob eingerichtet werden muss ────────────────────────────────
if [ "$SKIP_SETUP" -eq 1 ]; then
    echo "⏭️  Einrichtung übersprungen (--no-setup)"
elif [ "$FORCE_SETUP" -eq 1 ]; then
    rm -f "$STAMP"
    run_setup || exit 1
elif stamp_is_current && have cargo; then
    : # Schnellpfad: schon eingerichtet, nichts zu tun
else
    run_setup || exit 1
fi

# ── Backend wählen (Pendant zur QT_QPA_PLATFORM-Abfrage der Python-Version) ──
if [ -z "$CHOICE" ]; then
    echo ""
    echo "Wähle Backend:"
    echo "  1) X11 (empfohlen, auch unter Wayland via XWayland) [Standard]"
    echo "  2) Wayland (nativ)"
    echo "  3) Auto (winit entscheidet)"
    echo ""
    read -r -t 15 -p "Auswahl (1-3) [1]: " CHOICE || true
    CHOICE="${CHOICE:-1}"
fi

case "$CHOICE" in
    2|wayland) echo "⚠️  Wayland-Backend";  export WINIT_UNIX_BACKEND=wayland ;;
    3|auto)    echo "🔄 Auto-Erkennung";     unset WINIT_UNIX_BACKEND ;;
    *)         echo "✅ X11-Backend";        export WINIT_UNIX_BACKEND=x11 ;;
esac

# ── VirusTotal-Key (NIE in settings.json, siehe docs/SECURITY_NOTES.md) ─────
if [ -f "$ROOT/.env" ]; then
    set -a; . "$ROOT/.env"; set +a
    echo "🔐 .env geladen"
fi
if [ -z "${EARTHVIEWER_VT_API_KEY:-}" ]; then
    echo "🛡  Kein VirusTotal-Key gesetzt (optional, siehe .env.example)"
fi

# ── Bauen, falls nötig ──────────────────────────────────────────────────────
BUILD_MODE="${EARTHVIEWER_BUILD:-release}"
if [ "$BUILD_MODE" = "debug" ]; then
    BIN="target/debug/earthviewer";   CARGO_FLAGS=()
else
    BIN="target/release/earthviewer"; CARGO_FLAGS=(--release)
fi

NEEDS_BUILD=0
if [ ! -x "$BIN" ]; then
    NEEDS_BUILD=1
elif [ -n "$(find crates Cargo.toml -newer "$BIN" -type f -print -quit 2>/dev/null)" ]; then
    NEEDS_BUILD=1
fi

if [ "$NEEDS_BUILD" -eq 1 ]; then
    echo ""
    if [ ! -x "$BIN" ]; then
        echo "🔨 Erster Build ($BUILD_MODE) — rund 380 Crates, das dauert einige Minuten."
        echo "   Folgende Starts sind dann sofort da."
    else
        echo "🔨 Quelltext geändert — baue neu ($BUILD_MODE)..."
    fi
    if ! cargo build "${CARGO_FLAGS[@]}" -p ev-app; then
        echo ""
        echo "❌ Build fehlgeschlagen."
        echo "   Fehlt eine Bibliothek?  ./start.sh --setup"
        exit 1
    fi
    echo "✅ Build fertig"
fi

echo ""
echo "🚀 Starte EarthViewer..."
echo "════════════════════════════════════════════════════════"
echo ""

"./$BIN"
exit_code=$?

echo ""
echo "════════════════════════════════════════════════════════"
if [ $exit_code -eq 0 ]; then
    echo "✅ EarthViewer wurde sauber beendet"
else
    echo "❌ EarthViewer mit Fehlercode beendet: $exit_code"
    echo "   Bei Grafikproblemen:  ./start.sh 1     (X11 erzwingen)"
    echo "   Bei fehlenden Libs :  ./start.sh --setup"
fi
exit $exit_code
